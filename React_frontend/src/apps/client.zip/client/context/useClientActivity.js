import { useEffect, useState } from 'react';
import { loadClientActivity } from '../api/client-api.js';

export default function useClientActivity(refreshKey) {
  const [activity, setActivity] = useState({ rows: [], loading: true, error: '' });
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let active = true;
    setActivity(current => ({ ...current, loading: true, error: '' }));
    loadClientActivity().then(
      rows => active && setActivity({ rows, loading: false, error: '' }),
      error => active && setActivity({ rows: [], loading: false, error: error.message })
    );
    return () => {
      active = false;
    };
  }, [refreshKey, attempt]);

  return { ...activity, retry: () => setAttempt(value => value + 1) };
}

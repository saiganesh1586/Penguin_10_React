import { useClientContext } from '../context/ClientContext.jsx';
import { portalStyle } from '../../../app/portalStyles.js';
export default function CompletedEventsPage({ embedded = false }) {
  const portalContext = useClientContext();
  const portalActions = portalContext.actions;
  const { DB: workspaceData } = portalContext;
  const completed = workspaceData.events
    .filter(event => event.status === 'completed')
    .sort((leftEvent, rightEvent) => new Date(rightEvent.date) - new Date(leftEvent.date));
  return (
    <>
      {embedded ? (
        ''
      ) : (
        <div className="page-hd">
          <div className="page-hd-left">
            <div className="page-title">Completed Events</div>
            <div className="page-sub">Events that have been successfully completed</div>
          </div>
        </div>
      )}
      <div className="events-grid">
        {completed.length === 0 ? (
          <div
            className="empty"
            style={{
              gridColumn: '1/-1',
            }}
          >
            <div className="empty-icon">✅</div>
            <div className="empty-title">No completed events</div>
          </div>
        ) : (
          completed.map((event, index) => {
            const bannerContent = event.image ? (
              <>
                <img
                  src={event.image}
                  alt={event.title || 'Event'}
                  className="ev-banner-img"
                  onError={event => {
                    event.currentTarget.style.display = 'none';
                    event.currentTarget.nextElementSibling.style.display = 'flex';
                  }}
                />
                <div
                  className="ev-banner-fallback"
                  style={{
                    display: 'none',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '52px',
                    width: '100%',
                    height: '100%',
                  }}
                >
                  {event.emoji || '📅'}
                </div>
                <div className="ev-banner-overlay"></div>
              </>
            ) : (
              <span
                style={{
                  fontSize: '52px',
                }}
              >
                {event.emoji || '📅'}
              </span>
            );
            return (
              <div className="ev-card" key={index}>
                <div
                  className="ev-banner"
                  style={portalStyle(`background:${event.color || 'var(--accent)'}18`)}
                >
                  {bannerContent}
                  <div className="ev-banner-tag">
                    <span className="badge badge-green">✓ Completed</span>
                  </div>
                  <div className="ev-banner-price">
                    {event.price === 0 ? 'Free' : '₹' + event.price}
                  </div>
                </div>
                <div className="ev-body">
                  <div className="ev-title">{event.title}</div>
                  <div className="ev-meta">
                    <div className="ev-meta-row">
                      <span>📅</span>
                      {event.date} · {event.time}
                    </div>
                    <div className="ev-meta-row">
                      <span>📍</span>
                      {event.venue}
                    </div>
                    <div className="ev-meta-row">
                      <span>🏷️</span>
                      {event.category}
                    </div>
                  </div>
                  <div
                    style={{
                      marginBottom: '12px',
                    }}
                  >
                    <div className="flex justify-between ev-cap mb-4">
                      <span>
                        {event.registered}/{event.capacity} attended
                      </span>
                    </div>
                    <div
                      style={{
                        fontSize: '12px',
                        color: 'var(--green)',
                        marginTop: '8px',
                      }}
                    >
                      ✓ Event Successfully Completed
                    </div>
                  </div>
                  <div className="ev-footer">
                    <div
                      className="flex gap-6"
                      style={{
                        width: '100%',
                        justifyContent: 'space-between',
                      }}
                    >
                      <button
                        className="btn btn-ghost btn-xs w-full"
                        onClick={event => portalActions.onViewWorkflowEventDetails(event.id)}
                        title="View event details"
                      >
                        👁️ View Details
                      </button>
                      <button
                        className="btn btn-primary btn-xs"
                        onClick={event => portalActions.onViewWorkflowEventReport(event.id)}
                        title="View completion report"
                      >
                        📊 View Report
                      </button>
                    </div>
                    <div
                      className="tag-list"
                      style={{
                        flex: '1',
                        justifyContent: 'flex-end',
                      }}
                    >
                      {(event.tags || []).slice(0, 2).map((tag, index) => (
                        <span className="tag" key={index}>
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </>
  );
}

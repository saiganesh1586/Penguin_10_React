import React from 'react';
import { useClientContext } from '../context/ClientContext.jsx';
import { evCard } from '../components/EventCards.jsx';
export default function UpcomingEventsPage() {
  const portalContext = useClientContext();
  const portalActions = portalContext.actions;
  const { CU: currentUser, DB: workspaceData } = portalContext;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const upcoming = workspaceData.events
    .filter(event => {
      const eDate = new Date(event.date);
      return eDate >= today && event.status === 'upcoming';
    })
    .sort((leftEvent, rightEvent) => new Date(leftEvent.date) - new Date(rightEvent.date));
  return (
    <>
      <div className="page-hd">
        <div className="page-hd-left">
          <div className="page-title">Upcoming Events</div>
          <div className="page-sub">Events happening soon that you might be interested in</div>
        </div>
      </div>
      <div className="events-grid">
        {upcoming.length === 0 ? (
          <div
            className="empty"
            style={{
              gridColumn: '1/-1',
            }}
          >
            <div className="empty-icon">📅</div>
            <div className="empty-title">No upcoming events</div>
          </div>
        ) : (
          upcoming.map((event, index) => (
            <React.Fragment key={index}>
              {evCard(portalContext, event, currentUser.role === 'client' ? 'client' : 'attendee')}
            </React.Fragment>
          ))
        )}
      </div>
    </>
  );
}

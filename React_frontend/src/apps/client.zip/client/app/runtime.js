// Browser actions for the client workspace. App.jsx assembles this script with API, state,
// and page sections. Keep global handler names stable because existing HTML calls them.
// DB is the legacy browser model; CU is the signed-in user.
/* PORTAL_SECTION_api */ /* PORTAL_SECTION_state */ /* ===== EventFlow source: main.js ===== */
// ═══════════════════════════════════════════════════════════════
// UI RENDERING & HELPER FUNCTIONS - EventFlow Platform
// Dynamically renders all UI components based on state
// ═══════════════════════════════════════════════════════════════

// ═══════════════════ RENDER: TABLES ═══════════════════

function renderUsersTable(containerId, users = null) {
  users = users || AppState.users;
  const container = document.getElementById(containerId);
  if (!container) return;
  const html = `
    <table class="data-table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Role</th>
          <th>Phone</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        ${users
          .map(
            user => `
          <tr class="table-row">
            <td>${escapeHtml(user.name)}</td>
            <td>${escapeHtml(user.email)}</td>
            <td><span class="badge badge-${user.role}">${user.role}</span></td>
            <td>${escapeHtml(user.phone)}</td>
            <td><span class="status-badge status-${user.status}">${user.status}</span></td>
            <td class="action-buttons">
              <button class="btn-small btn-edit" onclick="editUserHandler('${
                user.id
              }')">Edit</button>
              <button class="btn-small btn-delete" onclick="deleteUserHandler('${
                user.id
              }')">Delete</button>
            </td>
          </tr>
        `
          )
          .join('')}
      </tbody>
    </table>
  `;
  globalThis.window?.EventFlowClientPages?.clear(container);
  container.innerHTML = html;
}
function renderEventsTable(containerId, events = null) {
  events = events || AppState.events;
  const container = document.getElementById(containerId);
  if (!container) return;
  const html = `
    <table class="data-table">
      <thead>
        <tr>
          <th>Event Title</th>
          <th>Date</th>
          <th>City</th>
          <th>Capacity</th>
          <th>Registered</th>
          <th>Price (₹)</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        ${events
          .map(
            event => `
          <tr class="table-row">
            <td><strong>${escapeHtml(event.title)}</strong></td>
            <td>${event.date}</td>
            <td>${escapeHtml(event.city)}</td>
            <td>${event.capacity}</td>
            <td>${event.registered}/${event.capacity}</td>
            <td>₹${event.price}</td>
            <td><span class="status-badge status-${event.status}">${event.status}</span></td>
            <td class="action-buttons">
              <button class="btn-small btn-edit" onclick="editEventHandler('${
                event.id
              }')">Edit</button>
              <button class="btn-small btn-delete" onclick="deleteEventHandler('${
                event.id
              }')">Delete</button>
            </td>
          </tr>
        `
          )
          .join('')}
      </tbody>
    </table>
  `;
  globalThis.window?.EventFlowClientPages?.clear(container);
  container.innerHTML = html;
}
function renderRegistrationsTable(containerId, registrations = null) {
  registrations = registrations || AppState.registrations;
  const container = document.getElementById(containerId);
  if (!container) return;
  const html = `
    <table class="data-table">
      <thead>
        <tr>
          <th>Ticket ID</th>
          <th>Attendee</th>
          <th>Event</th>
          <th>Date</th>
          <th>Status</th>
          <th>Checked In</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        ${registrations
          .map(registration => {
            const attendee = findUser(registration.attendeeId);
            const event = findEvent(registration.eventId);
            return `
            <tr class="table-row">
              <td><code>${registration.ticketId}</code></td>
              <td>${escapeHtml(attendee?.name || 'Unknown')}</td>
              <td>${escapeHtml(event?.title || 'Unknown')}</td>
              <td>${registration.date}</td>
              <td><span class="status-badge status-${registration.status}">${
              registration.status
            }</span></td>
              <td>${registration.checkedIn ? '✓' : '−'}</td>
              <td class="action-buttons">
                ${
                  !registration.checkedIn
                    ? `<button class="btn-small btn-success" onclick="checkInHandler('${registration.id}')">Check In</button>`
                    : ''
                }
                <button class="btn-small btn-delete" onclick="cancelRegistrationHandler('${
                  registration.id
                }')">Cancel</button>
              </td>
            </tr>
          `;
          })
          .join('')}
      </tbody>
    </table>
  `;
  globalThis.window?.EventFlowClientPages?.clear(container);
  container.innerHTML = html;
}

// ═══════════════════ RENDER: EVENT CARDS ═══════════════════

function renderEventCards(containerId, events = null, isAttendee = false) {
  events = events || AppState.events;
  const container = document.getElementById(containerId);
  if (!container) return;
  const html = `
    <div class="event-cards-grid">
      ${events
        .map(event => {
          const userReg = AppState.registrations.find(
            registration =>
              registration.eventId === event.id &&
              AppState.currentUser &&
              registration.attendeeId === AppState.currentUser.id
          );
          const isFull = event.registered >= event.capacity;
          const isRegistered = !!userReg;
          return `
          <div class="event-card">
            ${
              event.image
                ? `
              <div class="event-card-banner" style="height:130px;overflow:hidden;border-radius:8px 8px 0 0;margin:-16px -16px 12px -16px;position:relative">
                <img src="${event.image}" alt="${escapeHtml(
                    event.title
                  )}" style="width:100%;height:100%;object-fit:cover" onerror="this.parentElement.style.display='none'">
              </div>
            `
                : ''
            }
            <div class="event-card-header">
              <h3>${escapeHtml(event.title)}</h3>
              <span class="badge badge-${(event.category || '').toLowerCase()}">${
            event.category
          }</span>
            </div>
            <div class="event-card-body">
              <p class="event-date">📅 ${event.date} at ${event.time}</p>
              <p class="event-location">📍 ${escapeHtml(event.city)}</p>
              <p class="event-description">${escapeHtml(event.description)}</p>
              <div class="event-capacity">
                <span>${event.registered}/${event.capacity} registered</span>
                <div class="progress-bar">
                  <div class="progress" style="width: ${
                    (event.registered / event.capacity) * 100
                  }%"></div>
                </div>
              </div>
              <p class="event-price"><strong>₹${event.price}</strong>${
            event.price === 0 ? ' (FREE)' : ''
          }</p>
            </div>
            <div class="event-card-footer">
              ${
                isAttendee
                  ? `
                ${
                  isRegistered
                    ? `<button class="btn btn-secondary" disabled>Registered ✓</button>`
                    : `<button class="btn btn-primary" onclick="quickRegisterHandler('${
                        event.id
                      }')" ${isFull ? 'disabled' : ''}>
                    ${isFull ? 'Event Full' : 'Register Now'}
                  </button>`
                }
              `
                  : ''
              }
            </div>
          </div>
        `;
        })
        .join('')}
    </div>
  `;
  globalThis.window?.EventFlowClientPages?.clear(container);
  container.innerHTML = html;
}

// ═══════════════════ RENDER: NOTIFICATIONS ═══════════════════

function renderNotificationsPanel(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const unread = AppState.notifications.filter(notification => !notification.read);
  const html = `
    <div class="notifications-panel">
      ${
        unread.length === 0
          ? `<p class="empty-state">No new notifications</p>`
          : `
          <div class="notification-list">
            ${unread
              .map(
                n => `
              <div class="notification-item notification-${
                n.type
              }" onclick="markNotificationAsRead('${n.id}')">
                <div class="notification-icon">
                  ${
                    n.type === 'success'
                      ? '✓'
                      : n.type === 'error'
                      ? '✕'
                      : n.type === 'warning'
                      ? '⚠'
                      : 'ℹ'
                  }
                </div>
                <div class="notification-content">
                  <p>${escapeHtml(n.message)}</p>
                  <small>${getTimeAgo(n.createdAt)}</small>
                </div>
              </div>
            `
              )
              .join('')}
          </div>
        `
      }
    </div>
  `;
  globalThis.window?.EventFlowClientPages?.clear(container);
  container.innerHTML = html;

  // Update notification badge
  const badge = document.querySelector('.notification-badge');
  if (badge) {
    const count = getUnreadCount();
    badge.textContent = count;
    badge.style.display = count > 0 ? 'inline-flex' : 'none';
  }
}

// ═══════════════════ MODAL: FORMS ═══════════════════

function showAddUserModal() {
  const modal = `
    <div class="modal-overlay" onclick="closeModal()">
      <div class="modal" onclick="event.stopPropagation()">
        <div class="modal-header">
          <h3>Add New User</h3>
          <button class="btn-close" onclick="closeModal()">×</button>
        </div>
        <div class="modal-body">
          <form id="addUserForm" onsubmit="submitAddUser(event)">
            <div class="form-group">
              <label for="newUserName">Name *</label>
              <input type="text" id="newUserName" required>
            </div>
            <div class="form-group">
              <label for="newUserEmail">Email *</label>
              <input type="email" id="newUserEmail" required>
            </div>
            <div class="form-group">
              <label for="newUserPassword">Password *</label>
              <input type="password" id="newUserPassword" required>
            </div>
            <div class="form-group">
              <label for="newUserRole">Role *</label>
              <select id="newUserRole" required>
                <option value="">Select a role</option>
                <option value="superuser">Super Admin</option>
                <option value="organizer">Event Organizer</option>

                <option value="client">Client</option>
                <option value="attendee">Attendee</option>
              </select>
            </div>
            <div class="form-group">
              <label for="newUserPhone">Phone *</label>
              <input type="tel" id="newUserPhone" required>
            </div>
            <div class="modal-buttons">
              <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
              <button type="submit" class="btn btn-primary">Create User</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;
  document.body.insertAdjacentHTML('beforeend', modal);
}
function showAddEventModal() {
  const modal = `
    <div class="modal-overlay" onclick="closeModal()">
      <div class="modal" onclick="event.stopPropagation()">
        <div class="modal-header">
          <h3>Create New Event</h3>
          <button class="btn-close" onclick="closeModal()">×</button>
        </div>
        <div class="modal-body">
          <form id="addEventForm" onsubmit="submitAddEvent(event)">
            <div class="form-row">
              <div class="form-group">
                <label for="newEventTitle">Event Title *</label>
                <input type="text" id="newEventTitle" required>
              </div>
              <div class="form-group">
                <label for="newEventCategory">Category *</label>
                <select id="newEventCategory" required>
                  <option value="">Select category</option>
                  <option value="Conference">Conference</option>
                  <option value="Workshop">Workshop</option>
                  <option value="Networking">Networking</option>
                  <option value="Seminar">Seminar</option>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label for="newEventDate">Date *</label>
                <input type="date" id="newEventDate" required>
              </div>
              <div class="form-group">
                <label for="newEventTime">Time *</label>
                <input type="time" id="newEventTime" required>
              </div>
            </div>
            <div class="form-group">
              <label for="newEventCity">City *</label>
              <select id="newEventCity" required>
                <option value="">Select city</option>
                <option value="Chennai">Chennai</option>
                <option value="Bangalore">Bangalore</option>
                <option value="Hyderabad">Hyderabad</option>
                <option value="Mumbai">Mumbai</option>
                <option value="Delhi">Delhi</option>
              </select>
            </div>
            <div class="form-group">
              <label for="newEventLocation">Full Location Address *</label>
              <input type="text" id="newEventLocation" placeholder="e.g., Convention Center, Chennai" required>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label for="newEventCapacity">Capacity *</label>
                <input type="number" id="newEventCapacity" min="1" required>
              </div>
              <div class="form-group">
                <label for="newEventPrice">Price (₹) *</label>
                <input type="number" id="newEventPrice" min="0" step="0.01" required>
              </div>
            </div>
            <div class="form-group">
              <label for="newEventDescription">Description</label>
              <textarea id="newEventDescription" rows="3"></textarea>
            </div>
            <div class="modal-buttons">
              <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
              <button type="submit" class="btn btn-primary">Create Event</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;
  document.body.insertAdjacentHTML('beforeend', modal);
}

// ═══════════════════ FORM HANDLERS ═══════════════════

function submitAddUser(e) {
  e.preventDefault();
  const user = {
    name: document.getElementById('newUserName').value,
    email: document.getElementById('newUserEmail').value,
    password: document.getElementById('newUserPassword').value,
    role: document.getElementById('newUserRole').value,
    phone: document.getElementById('newUserPhone').value,
  };
  if (!createUser(user)) return;
  closeModal();
  updateAllTables();
}
function submitAddEvent(e) {
  e.preventDefault();
  const event = {
    title: document.getElementById('newEventTitle').value,
    category: document.getElementById('newEventCategory').value,
    date: document.getElementById('newEventDate').value,
    time: document.getElementById('newEventTime').value,
    city: document.getElementById('newEventCity').value,
    location: document.getElementById('newEventLocation').value,
    capacity: parseInt(document.getElementById('newEventCapacity').value),
    price: parseFloat(document.getElementById('newEventPrice').value),
    description: document.getElementById('newEventDescription').value,
    organizer: AppState.currentUser?.id || 'u1',
  };
  createEvent(event);
  closeModal();
  updateAllTables();
}

// ═══════════════════ QUICK ACTION HANDLERS ═══════════════════

function editUserHandler(userId) {
  console.log('Edit user:', userId);
  const user = findUser(userId);
  if (!user) {
    alert('User not found');
    return;
  }
  // TODO: Show edit modal with user data pre-filled
  alert('Edit functionality for: ' + user.name);
}
function deleteUserHandler(userId) {
  const user = findUser(userId);
  if (!user) {
    alert('User not found');
    return;
  }
  if (confirm(`Delete user "${user.name}"? This cannot be undone.`)) {
    deleteUser(userId);
    updateAllTables();
  }
}
function editEventHandler(eventId) {
  console.log('Edit event:', eventId);
  const event = findEvent(eventId);
  if (!event) {
    alert('Event not found');
    return;
  }
  // TODO: Show edit modal with event data pre-filled
  alert('Edit functionality for: ' + event.title);
}
function deleteEventHandler(eventId) {
  const event = findEvent(eventId);
  if (!event) {
    alert('Event not found');
    return;
  }
  if (confirm(`Delete event "${event.title}"? This will also cancel all registrations.`)) {
    deleteEvent(eventId);
    updateAllTables();
  }
}
function quickRegisterHandler(eventId) {
  if (!AppState.currentUser) {
    alert('Please log in to register for events');
    return;
  }
  const event = findEvent(eventId);
  if (!event) {
    alert('Event not found');
    return;
  }
  if (event.registered >= event.capacity) {
    alert('Event is full!');
    return;
  }
  registerAttendee(AppState.currentUser.id, eventId);
  updateAllTables();
  renderEventCards('eventsContainer', null, AppState.currentUser.role === 'attendee');
}
function checkInHandler(registrationId) {
  if (confirm('Confirm check-in for this attendee?')) {
    checkInAttendee(registrationId);
    updateAllTables();
  }
}
function cancelRegistrationHandler(registrationId) {
  if (confirm('Cancel this registration?')) {
    cancelRegistration(registrationId);
    updateAllTables();
  }
}

// ═══════════════════ UTILITY FUNCTIONS ═══════════════════

function closeModal() {
  const overlay = document.querySelector('.modal-overlay');
  if (overlay) overlay.remove();
}
function updateAllTables() {
  if (document.getElementById('usersTableContainer'))
    renderUsersTable('usersTableContainer', AppState.users);
  if (document.getElementById('eventsTableContainer'))
    renderEventsTable('eventsTableContainer', AppState.events);
  if (document.getElementById('registrationsTableContainer'))
    renderRegistrationsTable('registrationsTableContainer', AppState.registrations);
  if (document.getElementById('notificationsPanel')) renderNotificationsPanel('notificationsPanel');
}
function escapeHtml(text) {
  if (!text) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function getTimeAgo(isoString) {
  const date = new Date(isoString);
  const now = new Date();
  const seconds = Math.floor((now - date) / 1000);
  if (seconds < 60) return 'just now';
  if (seconds < 3600) return Math.floor(seconds / 60) + 'm ago';
  if (seconds < 86400) return Math.floor(seconds / 3600) + 'h ago';
  return Math.floor(seconds / 86400) + 'd ago';
}

// Notifications are refreshed when their data changes. Replacing the panel on
// a timer remounted its DOM every five seconds and made pages visibly blink.

// Make functions global
window.renderUsersTable = renderUsersTable;
window.renderEventsTable = renderEventsTable;
window.renderRegistrationsTable = renderRegistrationsTable;
window.renderEventCards = renderEventCards;
window.renderNotificationsPanel = renderNotificationsPanel;
window.showAddUserModal = showAddUserModal;
window.showAddEventModal = showAddEventModal;
window.submitAddUser = submitAddUser;
window.submitAddEvent = submitAddEvent;
window.updateAllTables = updateAllTables;
window.closeModal = closeModal;

/* ===== EventFlow source: qr.js ===== */
// ═══════════════════════════════════════════════════════════════
// QR CODE UTILITIES FOR EVENTFLOW CHECK-IN
// Generates and displays QR codes for attendee tickets
// ═══════════════════════════════════════════════════════════════

// Generate a simple deterministic QR-like visual representation
function generateQRVisual(data, size = 20) {
  const strData = String(data);
  // Create a hash-based grid pattern
  let pattern = [];
  let hash = 0;

  // Simple string hash
  for (let i = 0; i < strData.length; i++) {
    hash = (hash << 5) - hash + strData.charCodeAt(i);
    hash = hash & hash; // Convert to 32-bit integer
  }

  // Generate grid pattern based on hash
  for (let i = 0; i < size * size; i++) {
    hash = (hash * 9301 + 49297) % 233280;
    pattern.push(hash % 2 === 0);
  }
  return pattern;
}

// Render QR code as SVG or canvas-ready data
function renderQRAsGrid(pattern, size = 20, cellSize = 6) {
  let svg = `<svg width="${size * cellSize}" height="${
    size * cellSize
  }" xmlns="http://www.w3.org/2000/svg" style="background:#fff;border:2px solid #000">`;
  for (let i = 0; i < pattern.length; i++) {
    const row = Math.floor(i / size);
    const col = i % size;
    const x = col * cellSize;
    const y = row * cellSize;
    if (pattern[i]) {
      svg += `<rect x="${x}" y="${y}" width="${cellSize}" height="${cellSize}" fill="#000"/>`;
    }
  }
  svg += `</svg>`;
  return svg;
}

// Simple canvas-based QR renderer
function renderQRCanvas(registrationId, containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const canvas = document.createElement('canvas');
  canvas.width = 150;
  canvas.height = 150;
  canvas.style.border = '1px solid #ccc';
  canvas.style.borderRadius = '5px';
  const ctx = canvas.getContext('2d');
  const pattern = generateQRVisual(registrationId, 15);
  const cellSize = 10;

  // White background
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Black pattern
  ctx.fillStyle = '#000000';
  for (let i = 0; i < pattern.length; i++) {
    if (pattern[i]) {
      const row = Math.floor(i / 15);
      const col = i % 15;
      ctx.fillRect(col * cellSize, row * cellSize, cellSize, cellSize);
    }
  }

  // Add registration ID text
  ctx.fillStyle = '#000000';
  ctx.font = '10px Arial';
  ctx.textAlign = 'center';
  ctx.fillText(String(registrationId).substring(0, 8), canvas.width / 2, canvas.height - 10);
  globalThis.window?.EventFlowClientPages?.clear(container);
  container.innerHTML = '';
  container.appendChild(canvas);
}

// Display QR code in modal for ticket view
function showTicketQRModal(registrationId) {
  const reg = AppState.registrations.find(registration => registration.id === registrationId);
  if (!reg) {
    addNotification(null, 'Registration not found', 'error');
    return;
  }
  const event = AppState.events.find(currentEvent => currentEvent.id === reg.eventId);
  const attendee = AppState.users.find(user => user.id === reg.attendeeId);
  const modal = `
    <div id="modal-overlay" onclick="this.remove()">
      <div class="modal" onclick="event.stopPropagation()" style="max-width: 400px">
        <div class="modal-header">
          <h3>🎟️ Ticket & QR Code</h3>
          <button class="modal-close-btn" onclick="document.getElementById('modal-overlay').remove()">×</button>
        </div>
        <div class="modal-body">
          <div style="text-align: center; padding: 20px 0">
            <div style="font-weight: 600; margin-bottom: 10px">${attendee?.name}</div>
            <div style="color: #8891b4; font-size: 12px; margin-bottom: 20px">${event?.title}</div>
            <div id="qr-canvas-container" style="display: flex; justify-content: center; margin: 20px 0"></div>
            <div style="background: #1c2135; padding: 12px; border-radius: 5px; margin: 20px 0">
              <div style="font-size: 12px; color: #8891b4">Ticket ID</div>
              <div style="font-family: monospace; font-weight: 600; color: #7c6ff7">${
                reg.ticketId
              }</div>
            </div>
            <div style="background: #1c2135; padding: 12px; border-radius: 5px; margin: 20px 0">
              <div style="font-size: 12px; color: #8891b4">Event Date</div>
              <div style="font-weight: 500">${event?.date} at ${event?.time}</div>
            </div>
            <div style="background: #1c2135; padding: 12px; border-radius: 5px; margin: 20px 0">
              <div style="font-size: 12px; color: #8891b4">Amount Paid</div>
              <div style="font-weight: 600; color: #22d3a5">₹${reg.amount}</div>
            </div>
            <div style="text-align: center; margin-top: 16px">
              <span class="badge badge-${reg.checkedIn ? 'green' : 'yellow'}">${
    reg.checkedIn ? '✓ Checked In' : 'Pending Check-in'
  }</span>
            </div>
          </div>
        </div>
        <div class="modal-buttons">
          ${
            !reg.checkedIn
              ? `<button class="btn btn-success w-full" onclick="checkInHandler('${reg.id}'); document.getElementById('modal-overlay').remove(); renderPage('attendance')">✓ Check In Now</button>`
              : ''
          }
          <button class="btn btn-ghost w-full" onclick="document.getElementById('modal-overlay').remove()">Close</button>
        </div>
      </div>
    </div>
  `;
  document.body.insertAdjacentHTML('beforeend', modal);
  setTimeout(() => renderQRCanvas(reg.id, 'qr-canvas-container'), 100);
}

// Render QR in registration row
function addQRToRegistration(registrationId, cellElement) {
  const reg = AppState.registrations.find(registration => registration.id === registrationId);
  if (!reg) return;
  const qrIcon = document.createElement('a');
  qrIcon.href = '#';
  qrIcon.style.cursor = 'pointer';
  qrIcon.style.fontSize = '16px';
  qrIcon.onclick = e => {
    e.preventDefault();
    showTicketQRModal(registrationId);
  };
  qrIcon.textContent = '📱 QR';
  qrIcon.title = 'View QR Code';
  cellElement.insertBefore(qrIcon, cellElement.firstChild);
  cellElement.insertBefore(document.createTextNode(' '), qrIcon.nextSibling);
}

// Check-in modal with QR scanner simulation
function showCheckInModal(eventId) {
  const event = AppState.events.find(currentEvent => currentEvent.id === eventId);
  if (!event) return;
  const regs = AppState.registrations.filter(
    registration => registration.eventId === eventId && !registration.checkedIn
  );
  const modal = `
    <div id="modal-overlay" onclick="this.remove()">
      <div class="modal" onclick="event.stopPropagation()" style="max-width: 500px">
        <div class="modal-header">
          <h3>✅ Check-in Attendees — ${event.title}</h3>
          <button class="modal-close-btn" onclick="document.getElementById('modal-overlay').remove()">×</button>
        </div>
        <div class="modal-body">
          <div style="margin-bottom: 16px">
            <div style="font-size: 12px; color: #8891b4; margin-bottom: 8px">Pending Check-ins</div>
            <div style="font-size: 20px; font-weight: 700; color: #7c6ff7">${regs.length}</div>
          </div>
          
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; max-height: 300px; overflow-y: auto">
            ${regs
              .map(registration => {
                const attendee = AppState.users.find(user => user.id === registration.attendeeId);
                return `
                <div style="background: #151929; border: 1px solid #1f2640; border-radius: 8px; padding: 12px">
                  <div style="font-weight: 500; font-size: 13px; margin-bottom: 4px">${attendee?.name}</div>
                  <div style="font-size: 11px; color: #8891b4; margin-bottom: 8px">${registration.ticketId}</div>
                  <button class="btn btn-sm btn-success" onclick="checkInAttendee('${registration.id}'); refreshCheckInList('${eventId}')" style="width: 100%">✓ Check In</button>
                </div>
              `;
              })
              .join('')}
          </div>
        </div>
        <div class="modal-buttons">
          <button class="btn btn-ghost" onclick="document.getElementById('modal-overlay').remove()">Close</button>
        </div>
      </div>
    </div>
  `;
  document.body.insertAdjacentHTML('beforeend', modal);
}
function refreshCheckInList(eventId) {
  // Re-render the check-in modal
  const overlay = document.getElementById('modal-overlay');
  if (overlay) overlay.remove();
  setTimeout(() => showCheckInModal(eventId), 100);
}

// Global access
window.generateQRVisual = generateQRVisual;
window.renderQRAsGrid = renderQRAsGrid;
window.renderQRCanvas = renderQRCanvas;
window.showTicketQRModal = showTicketQRModal;
window.addQRToRegistration = addQRToRegistration;
window.showCheckInModal = showCheckInModal;
window.refreshCheckInList = refreshCheckInList;

/* ===== EventFlow source: navigation.js ===== */
/* EventFlow navigation module.
 * Navigation module boundary. showPage/goNav/renderPage remain in app.js so all existing page IDs and workflows are unchanged.
 * This boundary is intentionally non-invasive: the working SPA runtime remains
 * centralized in app.js so no existing IDs, function names, storage keys,
 * mock-data records, validation, or button workflows are changed.
 */
window.EventFlowModules = window.EventFlowModules || {};
window.EventFlowModules['navigation'] = true;

/* ===== EventFlow source: auth.js ===== */
/* EventFlow auth module.
 * Authentication module boundary. Existing login/logout functions remain in app.js; API helpers remain in api.js.
 * This boundary is intentionally non-invasive: the working SPA runtime remains
 * centralized in app.js so no existing IDs, function names, storage keys,
 * mock-data records, validation, or button workflows are changed.
 */
window.EventFlowModules = window.EventFlowModules || {};
window.EventFlowModules['auth'] = true;

/* ===== EventFlow source: database.js ===== */
/* EventFlow database module.
 * Database module boundary. The canonical mock DB remains in app.js to preserve initialization order and exact data.
 * This boundary is intentionally non-invasive: the working SPA runtime remains
 * centralized in app.js so no existing IDs, function names, storage keys,
 * mock-data records, validation, or button workflows are changed.
 */
window.EventFlowModules = window.EventFlowModules || {};
window.EventFlowModules['database'] = true;

/* ===== EventFlow source: modals.js ===== */
/* EventFlow modals module.
 * Modal module boundary. Existing modal/drawer/confirm implementations remain in app.js.
 * This boundary is intentionally non-invasive: the working SPA runtime remains
 * centralized in app.js so no existing IDs, function names, storage keys,
 * mock-data records, validation, or button workflows are changed.
 */
window.EventFlowModules = window.EventFlowModules || {};
window.EventFlowModules['modals'] = true;

/* ===== EventFlow source: notifications.js ===== */
/* EventFlow notifications module.
 * Notifications module boundary. Existing notification state/rendering remains in app.js.
 * This boundary is intentionally non-invasive: the working SPA runtime remains
 * centralized in app.js so no existing IDs, function names, storage keys,
 * mock-data records, validation, or button workflows are changed.
 */
window.EventFlowModules = window.EventFlowModules || {};
window.EventFlowModules['notifications'] = true;

/* ===== EventFlow source: shared.js ===== */
/* EventFlow shared module.
 * Shared UI module boundary. Existing helpers and cross-page utilities remain in app.js.
 * This boundary is intentionally non-invasive: the working SPA runtime remains
 * centralized in app.js so no existing IDs, function names, storage keys,
 * mock-data records, validation, or button workflows are changed.
 */
window.EventFlowModules = window.EventFlowModules || {};
window.EventFlowModules['shared'] = true;

/* ===== EventFlow source: app.js ===== */
// ════════════════════════════════════════════════
//  MOCK DATABASE
// ════════════════════════════════════════════════
const DB = {
  users: [
    {
      id: 'usr-admin-001',
      name: 'Alex Johnson',
      email: 'superadmin@example.com',
      password: 'Admin@123',
      role: 'superuser',
      phone: '+91 9876543201',
      avatar: 'AJ',
      avatarImage: '/assets/images/avatars/user-alex-johnson.jpg',
      status: 'active',
      joined: '2024-01-15',
      bio: 'Platform administrator with full system access.',
    },
    {
      id: 'usr-org-001',
      name: 'Sarah Chen',
      email: 'organizer@example.com',
      password: 'Organizer@123',
      role: 'organizer',
      phone: '+91 9876543202',
      avatar: 'SC',
      avatarImage: '/assets/images/avatars/organizer-sarah-chen.jpg',
      status: 'active',
      joined: '2024-02-01',
      bio: 'Senior event organizer specializing in corporate events.',
      service: 'Corporate Events & Conferences',
      city: 'Bangalore',
      rating: 4.8,
      color: '#7c6ff7',
    },
    {
      id: 'usr-emp-001',
      userId: 'usr-emp-001',
      name: 'Marcus Vance',
      email: 'employee@example.com',
      password: 'Employee@123',
      role: 'employee',
      employeeType: 'EVENT_OPERATIONS',
      phone: '+91 9876543220',
      avatar: 'MV',
      avatarImage: '/assets/images/avatars/employee-marcus-vance.jpg',
      status: 'active',
      joined: '2024-01-18',
      bio: 'Senior event operations employee managing event information and live execution.',
      service: 'Corporate Conferences & Tech Summits',
      city: 'Bangalore',
      rating: 4.9,
      color: '#3b82f6',
    },
    {
      id: 'usr-emp-001c',
      userId: 'usr-emp-001',
      name: 'Marcus Vance',
      email: 'marcus.ops@eventflow.com',
      password: 'Employee@123',
      role: 'employee',
      employeeType: 'SUPPORT_FINANCE',
      phone: '+91 9876543220',
      avatar: 'MV',
      avatarImage: '/assets/images/avatars/employee-marcus-vance.jpg',
      status: 'active',
      joined: '2024-01-18',
      bio: 'Customer support and finance operations executive.',
      service: 'Support & Finance',
      city: 'Bangalore',
      rating: 4.9,
      color: '#3b82f6',
    },
    {
      id: 'usr-emp-002',
      userId: 'usr-emp-002',
      name: 'Elena Rostova',
      email: 'elena.coordinator@eventflow.com',
      password: 'Employee@123',
      role: 'employee',
      employeeType: 'EVENT_OPERATIONS',
      phone: '+91 9876543221',
      avatar: 'ER',
      avatarImage: '/assets/images/avatars/employee-elena-rostova.jpg',
      status: 'active',
      joined: '2024-02-12',
      bio: 'Event operations executive.',
      service: 'Event Operations',
      city: 'Mumbai',
      rating: 4.8,
      color: '#ec4899',
    },
    {
      id: 'usr-emp-003',
      userId: 'usr-emp-003',
      name: 'Arjun Kapoor',
      email: 'arjun.events@eventflow.com',
      password: 'Employee@123',
      role: 'employee',
      employeeType: 'REGISTRATION_VERIFICATION',
      phone: '+91 9876543222',
      avatar: 'AK',
      avatarImage: '/assets/images/avatars/employee-arjun-kapoor.jpg',
      status: 'active',
      joined: '2024-03-08',
      bio: 'Registration and attendee verification executive.',
      service: 'Registration & Verification',
      city: 'Delhi NCR',
      rating: 4.9,
      color: '#8b5cf6',
    },
    {
      id: 'usr-emp-004',
      userId: 'usr-emp-004',
      name: 'Maya Lin',
      email: 'maya.ops@eventflow.com',
      password: 'Employee@123',
      role: 'employee',
      employeeType: 'SUPPORT_FINANCE',
      phone: '+91 9876543223',
      avatar: 'ML',
      avatarImage: '/assets/images/avatars/employee-maya-lin.jpg',
      status: 'active',
      joined: '2024-03-22',
      bio: 'Customer support and finance operations executive.',
      service: 'Support & Finance',
      city: 'Hyderabad',
      rating: 4.7,
      color: '#10b981',
    },
    {
      id: 'usr-client-001',
      name: 'Michael Torres',
      email: 'client@example.com',
      password: 'Client@123',
      role: 'client',
      phone: '+91 9876543203',
      avatar: 'MT',
      avatarImage: '/assets/images/avatars/user-michael-torres.jpg',
      status: 'active',
      joined: '2024-03-10',
      bio: 'Head of Events at TechCorp Ltd.',
      company: 'TechCorp Ltd',
    },
    {
      id: 'usr-attendee-001',
      name: 'Priya Patel',
      email: 'attendee@example.com',
      password: 'Attendee@123',
      role: 'attendee',
      phone: '+91 9876543205',
      avatar: 'PP',
      avatarImage: '/assets/images/avatars/user-priya-patel.jpg',
      status: 'active',
      joined: '2024-04-01',
      bio: 'Tech enthusiast and frequent conference attendee.',
    },
    {
      id: 6,
      name: 'Emma Brown',
      email: 'emma@eventflow.com',
      password: 'org123',
      role: 'organizer',
      phone: '+91 9876543206',
      avatar: 'EB',
      avatarImage: '/assets/images/avatars/organizer-emma-brown.jpg',
      status: 'active',
      joined: '2024-02-20',
      service: 'Weddings & Social Events',
      city: 'Pune',
      rating: 4.7,
      color: '#f56565',
      bio: 'Expert in creating memorable wedding and social event experiences with meticulous attention to detail.',
    },
    {
      id: 8,
      name: 'Lisa Zhang',
      email: 'lisa@eventflow.com',
      password: 'att123',
      role: 'attendee',
      phone: '+91 9876543208',
      avatar: 'LZ',
      avatarImage: '/assets/images/avatars/user-lisa-zhang.jpg',
      status: 'active',
      joined: '2024-04-15',
    },
    {
      id: 9,
      name: 'Robert Singh',
      email: 'robert@eventflow.com',
      password: 'att123',
      role: 'attendee',
      phone: '+91 9876543209',
      avatar: 'RS',
      avatarImage: '/assets/images/avatars/user-robert-singh.jpg',
      status: 'active',
      joined: '2024-05-01',
    },
    {
      id: 11,
      name: 'Rajesh Sharma',
      email: 'rajesh@eventflow.com',
      password: 'org123',
      role: 'organizer',
      phone: '+91 9876543210',
      avatar: 'RS',
      avatarImage: '/assets/images/avatars/organizer-rajesh-sharma.jpg',
      status: 'active',
      joined: '2024-03-05',
      service: 'Weddings & Social Events',
      city: 'Delhi NCR',
      rating: 4.9,
      color: '#22d3a5',
      bio: 'Expert wedding planner with 15+ years of experience in creating stunning celebrations for families across India.',
    },
    {
      id: 12,
      name: 'TechEvents India',
      email: 'techevents@eventflow.com',
      password: 'org123',
      role: 'organizer',
      phone: '+91 9876543211',
      avatar: 'TE',
      avatarImage: '/assets/images/avatars/organizer-techevents.jpg',
      status: 'active',
      joined: '2024-01-20',
      service: 'Tech Conferences & Hackathons',
      city: 'Bangalore',
      rating: 4.6,
      color: '#ed8936',
      bio: 'Leading organizer for technology summits, conferences, and hackathons in India.',
    },
  ],
  events: [
    {
      id: 101,
      title: 'Global AI & Cloud Summit 2026',
      category: 'Conference',
      date: '2026-06-15',
      time: '09:00',
      endTime: '18:00',
      venue: 'Grand Convention Center, Hall A',
      city: 'Bangalore',
      capacity: 600,
      registered: 480,
      price: 200,
      status: 'upcoming',
      organizer: 'usr-emp-001',
      clientId: 'usr-client-001',
      description:
        'Flagship enterprise summit on Generative AI, Cloud Infrastructure, and Agentic Workflows.',
      color: '#3b82f6',
      emoji: '🤖',
      tags: ['AI', 'Cloud', 'Enterprise'],
      image: '/assets/images/events/event-ai-summit.jpg',
    },
    {
      id: 102,
      title: 'FinTech Leaders Executive Conclave',
      category: 'Corporate',
      date: '2026-06-22',
      time: '17:30',
      endTime: '22:30',
      venue: 'The Leela Palace Ballroom',
      city: 'Mumbai',
      capacity: 250,
      registered: 210,
      price: 350,
      status: 'upcoming',
      organizer: 'usr-emp-001',
      clientId: 'usr-client-001',
      description:
        'Exclusive executive dinner and keynote sessions for digital banking and FinTech innovators.',
      color: '#10b981',
      emoji: '💼',
      tags: ['FinTech', 'Banking', 'Executive'],
      image: '/assets/images/events/event-fintech.jpg',
    },
    {
      id: 103,
      title: 'Cybersecurity & Zero Trust Workshop',
      category: 'Workshop',
      date: '2026-07-05',
      time: '10:00',
      endTime: '16:00',
      venue: 'Cyber Towers — Tech Room 3',
      city: 'Hyderabad',
      capacity: 80,
      registered: 80,
      price: 120,
      status: 'full',
      organizer: 'usr-emp-001',
      clientId: 'usr-client-001',
      description:
        'Hands-on live simulation on threat modeling, Zero Trust architecture, and cloud security.',
      color: '#f59e0b',
      emoji: '🛡️',
      tags: ['Security', 'ZeroTrust', 'HandsOn'],
      image: '/assets/images/events/event-cybersecurity.jpg',
    },
    {
      id: 104,
      title: 'National Web3 & AI Hackathon 2026',
      category: 'Networking',
      date: '2026-07-18',
      time: '08:00',
      endTime: '20:00',
      venue: 'Innovation Arena, HITEC City',
      city: 'Chennai',
      capacity: 400,
      registered: 315,
      price: 0,
      status: 'upcoming',
      organizer: 'usr-emp-001',
      clientId: 'usr-client-001',
      description:
        '36-hour national developer hackathon with ?50K in prize bounties for open source AI agents.',
      color: '#8b5cf6',
      emoji: '🚀',
      tags: ['Hackathon', 'AI', 'Developers'],
      image: '/assets/images/events/event-hackathon.jpg',
    },
    {
      id: 106,
      title: 'Torres Tech Innovation & Cloud Expo',
      category: 'Conference',
      date: today(),
      time: '09:00',
      endTime: '18:00',
      venue: 'Innovation Arena, HITEC City',
      city: 'Bangalore',
      capacity: 350,
      registered: 310,
      price: 0,
      status: 'ongoing',
      organizer: 'usr-emp-001',
      clientId: 'usr-client-001',
      description:
        'Live corporate technology summit currently underway with interactive keynotes and partner pavilions.',
      color: '#3b82f6',
      emoji: '⏱️',
      tags: ['Live', 'Innovation', 'Ongoing'],
      image: '/assets/images/events/event-tech-summit.jpg',
    },
    {
      id: 105,
      title: 'Healthcare & Biotech Forum 2026',
      category: 'Conference',
      date: '2026-03-25',
      time: '09:00',
      endTime: '17:00',
      venue: 'Medical Research Auditorium',
      city: 'Delhi NCR',
      capacity: 350,
      registered: 350,
      price: 250,
      status: 'completed',
      organizer: 'usr-emp-001',
      clientId: 'usr-client-001',
      description:
        'International forum on AI diagnostics, clinical trials automation, and genomics data.',
      color: '#06b6d4',
      emoji: '🏥',
      tags: ['Healthcare', 'Biotech', 'Genomics'],
      image: '/assets/images/events/event-healthcare-forum.jpg',
    },
    {
      id: 1,
      title: 'Tech Innovation Summit 2026',
      category: 'Conference',
      date: '2026-04-15',
      time: '09:00',
      endTime: '18:00',
      venue: 'Grand Convention Center, Hall A',
      city: 'Chennai',
      capacity: 500,
      registered: 342,
      price: 150,
      status: 'upcoming',
      organizer: 'usr-org-001',
      clientId: 'usr-client-001',
      description:
        'Annual technology conference featuring keynotes from industry leaders, workshops on AI, blockchain, and cloud computing.',
      color: '#7c6ff7',
      emoji: '💻',
      tags: ['AI', 'Tech', 'Networking'],
      image: '/assets/images/events/event-tech-summit.jpg',
    },
    {
      id: 2,
      title: 'Corporate Annual Gala 2026',
      category: 'Corporate',
      date: '2026-04-22',
      time: '18:00',
      endTime: '23:00',
      venue: 'Grand Ballroom — Marriott Hotel',
      city: 'Tirupathi',
      capacity: 200,
      registered: 187,
      price: 250,
      status: 'upcoming',
      organizer: 'usr-org-001',
      clientId: 'usr-client-001',
      description:
        'Exclusive annual corporate dinner and awards ceremony celebrating achievements and milestones.',
      color: '#22d3a5',
      emoji: '🥂',
      tags: ['Corporate', 'Gala', 'Awards'],
      image: '/assets/images/events/event-annual-gala.jpg',
    },
    {
      id: 3,
      title: 'Spring Music Festival',
      category: 'Concert',
      date: '2026-05-01',
      time: '14:00',
      endTime: '23:00',
      venue: 'City Park Outdoor Amphitheater',
      city: 'Noida',
      capacity: 1000,
      registered: 756,
      price: 75,
      status: 'upcoming',
      organizer: 6,
      clientId: 'usr-client-001',
      description: 'Two-day outdoor music festival featuring 15+ artists across multiple genres.',
      color: '#f56565',
      emoji: '🎵',
      tags: ['Music', 'Outdoor', 'Festival'],
      image: '/assets/images/events/event-music-fest.jpg',
    },
    {
      id: 4,
      title: 'Digital Marketing Workshop',
      category: 'Workshop',
      date: '2026-05-10',
      time: '10:00',
      endTime: '16:00',
      venue: 'Business Hub — Room 201',
      city: 'Hyderabad',
      capacity: 50,
      registered: 50,
      price: 80,
      status: 'full',
      organizer: 'usr-org-001',
      clientId: 'usr-client-001',
      description:
        'Hands-on full-day workshop on modern digital marketing, SEO, social media strategy, and analytics.',
      color: '#f6c90e',
      emoji: '📱',
      tags: ['Marketing', 'Workshop', 'SEO'],
      image: '/assets/images/events/event-marketing-workshop.jpg',
    },
    {
      id: 5,
      title: 'Startup Pitch Night',
      category: 'Networking',
      date: '2026-05-15',
      time: '17:00',
      endTime: '21:00',
      venue: 'Innovation Lab — Main Hall',
      city: 'Chennai',
      capacity: 150,
      registered: 98,
      price: 0,
      status: 'upcoming',
      organizer: 6,
      clientId: 'usr-client-001',
      description:
        'Monthly startup pitch competition with panels of VC judges and networking opportunities.',
      color: '#7c6ff7',
      emoji: '🚀',
      tags: ['Startup', 'Pitch', 'VC'],
      image: '/assets/images/events/event-pitch-night.jpg',
    },
    {
      id: 6,
      title: 'Healthcare Innovation Forum',
      category: 'Conference',
      date: '2026-03-10',
      time: '08:30',
      endTime: '17:00',
      venue: 'City Medical Center Auditorium',
      city: 'Bangalore',
      capacity: 300,
      registered: 300,
      price: 200,
      status: 'completed',
      organizer: 'usr-org-001',
      clientId: 'usr-client-001',
      description: 'Forum on AI in healthcare, telemedicine, and patient data management.',
      color: '#22d3a5',
      emoji: '🏥',
      tags: ['Health', 'AI', 'Forum'],
      image: '/assets/images/events/event-medtech.jpg',
    },
    {
      id: 7,
      title: 'Photography Masterclass',
      category: 'Workshop',
      date: '2026-06-01',
      time: '10:00',
      endTime: '15:00',
      venue: 'Art Studio 5, Downtown',
      city: 'Pune',
      capacity: 30,
      registered: 12,
      price: 120,
      status: 'upcoming',
      organizer: 6,
      clientId: null,
      description:
        'Hands-on photography workshop for intermediate photographers covering lighting, composition, and post-processing.',
      color: '#ed8936',
      emoji: '📷',
      tags: ['Photography', 'Art', 'Workshop'],
      image: '/assets/images/events/event-photography.jpg',
    },
    {
      id: 8,
      title: 'Rajesh Grand Wedding Celebration',
      category: 'Wedding',
      date: '2026-05-15',
      time: '17:00',
      endTime: '23:59',
      venue: 'The Ashok Hotel, New Delhi',
      city: 'Delhi NCR',
      capacity: 800,
      registered: 750,
      price: 0,
      status: 'ongoing',
      organizer: 11,
      clientId: null,
      description:
        'Grand wedding celebration bringing together families and friends. Featuring traditional ceremonies, vibrant decorations, and festive atmosphere.',
      color: '#22d3a5',
      emoji: '💒',
      tags: ['Wedding', 'Celebration', 'Grand'],
      image: '/assets/images/events/event-wedding.jpg',
    },
  ],
  eventRequests: [
    // -- Submitted / Pending ----------------------------------------------
    {
      id: 101,
      clientId: 'usr-client-001',
      title: 'Torres Tech Q3 Product Launch',
      type: 'Corporate',
      date: '2026-12-01',
      guests: 350,
      budget: 35000,
      status: 'submitted',
      desc: 'Global launch for next-gen enterprise suite. Require 4K live streaming, stage AV, VIP catering, and 5 photographers.',
      created: '2026-10-20',
      organizer: 'usr-org-001',
      venue: 'Downtown Convention Center',
    },
    {
      id: 1,
      clientId: 'usr-client-001',
      title: 'Product Launch Event',
      type: 'Corporate',
      date: '2026-12-10',
      guests: 300,
      budget: 25000,
      status: 'pending',
      desc: 'Grand product launch for our new AI-powered software suite. Need venue, catering, AV, and professional photography.',
      created: '2026-10-18',
      venue: 'Downtown Convention Center',
    },
    // -- Under Review -----------------------------------------------------
    {
      id: 103,
      clientId: 'usr-client-001',
      title: 'Tech Innovation Demo Day',
      type: 'Networking',
      date: '2026-12-15',
      guests: 200,
      budget: 22000,
      status: 'under_review',
      desc: 'Startup and partner showcase demo day with booth setups, investor pitch panels, and networking reception.',
      created: '2026-10-15',
      organizer: 'usr-org-001',
      venue: 'Innovation Hub Hall 2',
    },
    {
      id: 3,
      clientId: 'usr-client-001',
      title: 'Annual Client Appreciation Dinner',
      type: 'Corporate',
      date: '2026-12-20',
      guests: 120,
      budget: 18000,
      status: 'in_review',
      desc: 'Formal black-tie dinner for top 120 clients. Need premium venue, 5-course dinner, live entertainment.',
      created: '2026-10-10',
      organizer: 'usr-org-001',
      venue: 'Five Star Restaurant & Event Hall',
    },
    // -- Awaiting Client Response (proposal_sent / awaiting_client) -------
    {
      id: 201,
      clientId: 'usr-client-001',
      title: 'Executive Offsite Strategy Summit',
      type: 'Corporate',
      date: '2026-11-28',
      guests: 90,
      budget: 28000,
      status: 'proposal_sent',
      desc: 'Two-day offsite for C-suite with keynotes, team workshops, and gala dinner.',
      created: '2026-09-30',
      organizer: 'usr-org-001',
      venue: 'Horizon Resort & Conference Centre',
      proposals: [
        {
          version: 1,
          amount: 27500,
          depositRequired: 8250,
          organizerFee: 5500,
          taxes: 4950,
          status: 'pending_client',
          eventPlan:
            'Full offsite coordination including venue liaison, AV, catering, and keynote facilitation.',
          paymentSchedule: '30% advance deposit on approval, 70% final balance before event',
          cancellationTerms: '14+ days notice: 10% fee, 90% refund within 7 business days',
          validUntil: '2026-11-05',
          includedServices: 'Venue, catering, AV, logistics',
          excludedServices: 'Travel & accommodation',
        },
      ],
    },
    {
      id: 202,
      clientId: 'usr-client-001',
      title: 'Annual Partner Awards Night',
      type: 'Gala',
      date: '2026-11-15',
      guests: 250,
      budget: 42000,
      status: 'awaiting_client',
      desc: 'Black-tie awards ceremony for top partners. Requires stage setup, trophies, and MC services.',
      created: '2026-09-20',
      organizer: 'usr-org-001',
      venue: 'Grand Ballroom, Taj Hotels',
      proposals: [
        {
          version: 2,
          amount: 41000,
          depositRequired: 12300,
          organizerFee: 8200,
          taxes: 7380,
          status: 'pending_client',
          eventPlan:
            'Premium gala coordination: stage, awards, MC, photography, 3-course catering.',
          paymentSchedule: '30% advance, 70% post-event',
          cancellationTerms: '21+ days: 5% fee; 14-20 days: 15% fee; under 14 days: 25% fee',
          validUntil: '2026-10-30',
          includedServices: 'Stage, awards, MC, catering',
          excludedServices: 'Guest accommodation',
        },
      ],
    },
    // -- Changes Requested / Counteroffer ---------------------------------
    {
      id: 301,
      clientId: 'usr-client-001',
      title: 'Global AI Research Symposium',
      type: 'Conference',
      date: '2027-01-20',
      guests: 500,
      budget: 55000,
      status: 'changes_requested',
      desc: 'International academic and industry symposium. Requires parallel session halls, live streaming, and multi-cuisine catering.',
      created: '2026-09-01',
      organizer: 'usr-org-001',
      venue: 'National Science Convention Centre',
      proposals: [
        {
          version: 1,
          amount: 60000,
          depositRequired: 18000,
          organizerFee: 12000,
          taxes: 10800,
          status: 'revision_requested',
          eventPlan: 'Full conference coordination with multi-hall AV and session management.',
          paymentSchedule: '30% advance, 70% on completion',
          cancellationTerms: '30+ days: no fee; 15-29 days: 20% fee',
          validUntil: '2026-10-25',
        },
      ],
      clientFeedback:
        'Please reduce overall cost by 8% and include dedicated networking lounge setup.',
    },
    {
      id: 302,
      clientId: 'usr-client-001',
      title: 'Wellness & Mindfulness Corporate Day',
      type: 'Workshop',
      date: '2026-12-05',
      guests: 60,
      budget: 9500,
      status: 'counteroffer_received',
      desc: 'Full-day wellness event: yoga sessions, nutrition workshops, and mindfulness talks.',
      created: '2026-09-15',
      organizer: 'usr-org-001',
      venue: 'Serenity Wellness Studio, Bandra',
      proposals: [
        {
          version: 1,
          amount: 11000,
          depositRequired: 3300,
          organizerFee: 2200,
          taxes: 1980,
          status: 'pending_client',
          eventPlan: 'Yoga, nutrition, mindfulness talks. Healthy catering included.',
          paymentSchedule: '50% advance, 50% on event day',
          cancellationTerms: '10+ days: 10% fee; under 10 days: 25% fee',
          validUntil: '2026-11-01',
        },
      ],
      clientFeedback: 'We accept the format but request a 5% reduction on the total price.',
    },
    // -- Confirmed --------------------------------------------------------
    {
      id: 2,
      clientId: 'usr-client-001',
      title: 'Team Building Retreat',
      type: 'Corporate',
      date: '2026-11-22',
      guests: 80,
      budget: 12000,
      status: 'confirmed',
      desc: 'Annual team building activity with outdoor challenges, group activities, and team dinner.',
      created: '2026-09-01',
      organizer: 'usr-org-001',
      venue: 'Mountain Resort',
      confirmedAt: '2026-10-10',
      bookingStatus: 'confirmed',
      paymentStatus: 'deposit_paid',
      depositPaidAt: '2026-10-12',
      depositAmount: 3600,
      totalAmount: 12000,
      cancellationPolicy: {
        minimumNoticeDays: 14,
        feePercent: 10,
        refundPercent: 90,
        deadlineText: '14 days before event (2026-11-08)',
        processingDays: '5-7 business days',
      },
    },
    {
      id: 102,
      clientId: 'usr-client-001',
      title: 'Annual Leadership Strategy Retreat',
      type: 'Corporate',
      date: '2026-11-30',
      guests: 120,
      budget: 18000,
      status: 'confirmed',
      desc: 'Annual executive team retreat with breakout workshop sessions, keynote speaker, and outdoor networking dinner.',
      created: '2026-09-05',
      organizer: 'usr-org-001',
      venue: 'Hilltop Mountain Resort',
      confirmedAt: '2026-10-05',
      bookingStatus: 'confirmed',
      paymentStatus: 'deposit_paid',
      depositPaidAt: '2026-10-07',
      depositAmount: 5400,
      totalAmount: 18000,
      cancellationPolicy: {
        minimumNoticeDays: 14,
        feePercent: 10,
        refundPercent: 90,
        deadlineText: '14 days before event (2026-11-16)',
        processingDays: '5-7 business days',
      },
    },
    // -- Withdrawn --------------------------------------------------------
    {
      id: 401,
      clientId: 'usr-client-001',
      title: 'Mid-Year Revenue Review Dinner',
      type: 'Corporate',
      date: '2026-08-20',
      guests: 50,
      budget: 8000,
      status: 'withdrawn',
      desc: 'Intimate executive dinner with finance team to review mid-year revenue performance.',
      created: '2026-07-01',
      organizer: 'usr-org-001',
      venue: 'Private Dining, Leela Palace',
      withdrawnAt: '2026-07-18',
      withdrawReason: 'Internal scheduling conflict -- event rescheduled to Q4.',
    },
    // -- Cancelled --------------------------------------------------------
    {
      id: 402,
      clientId: 'usr-client-001',
      title: 'Startup Demo & Investor Mixer',
      type: 'Networking',
      date: '2026-09-10',
      guests: 150,
      budget: 20000,
      status: 'cancelled',
      desc: 'Invite-only networking event for 15 startups and 30 investors. Pitch booths, Q&A, cocktail networking.',
      created: '2026-07-15',
      organizer: 'usr-org-001',
      venue: 'Co-Work Loft, Indiranagar',
      cancelledAt: '2026-08-28',
      cancelReason: 'Budget Constraints',
      cancelExplanation: 'Series-A round delayed; event deferred to next quarter.',
      paymentStatus: 'deposit_paid',
      depositAmount: 6000,
      refundStatus: 'processing',
      estimatedRefund: 5400,
    },
    // -- Rejected ---------------------------------------------------------
    {
      id: 4,
      clientId: 'usr-client-001',
      title: 'Sales Training Conference',
      type: 'Conference',
      date: '2026-07-20',
      guests: 200,
      budget: 15000,
      status: 'rejected',
      desc: 'Two-day sales training conference with industry speakers and breakout sessions.',
      created: '2026-06-28',
      venue: 'City Conference Center',
      rejectionReason: 'Requested date not available',
      rejectionComments:
        'Organizer is fully booked for July 20. Please resubmit with alternative dates.',
    },
    // -- Expired ----------------------------------------------------------
    {
      id: 501,
      clientId: 'usr-client-001',
      title: 'Digital Transformation Summit',
      type: 'Conference',
      date: '2026-10-01',
      guests: 300,
      budget: 32000,
      status: 'expired',
      desc: 'Enterprise digital transformation conference with live demos, expert panels, and breakout sessions.',
      created: '2026-08-01',
      organizer: 'usr-org-001',
      venue: 'Tech Park Convention Hall',
      expiredAt: '2026-09-15',
      proposals: [
        {
          version: 1,
          amount: 31000,
          depositRequired: 9300,
          status: 'expired',
          eventPlan: 'Full conference coordination.',
          validUntil: '2026-09-14',
        },
      ],
    },
  ],
  reports: [
    {
      id: 'rpt-emp-002',
      eventId: 103,
      fileName: 'cybersecurity-workshop-summary.docx',
      submittedBy: 'usr-emp-001',
      submittedAt: '2026-07-06 11:20',
    },
  ],
  employeeChangeRequests: [
    {
      id: 'chg-emp-001',
      type: 'event',
      targetId: 103,
      targetName: 'Cybersecurity & Zero Trust Workshop',
      requester: 'Michael Torres',
      requestedChange: 'Move the event date to 2026-07-12 and increase capacity to 100 attendees.',
      status: 'pending',
      submittedAt: 'Today, 9:20 AM',
    },
    {
      id: 'chg-emp-002',
      type: 'user',
      targetId: 'usr-client-001',
      targetName: 'Michael Torres',
      requester: 'Michael Torres',
      requestedChange: 'Update phone number and company details on the user profile.',
      status: 'pending',
      submittedAt: 'Yesterday, 4:10 PM',
    },
    {
      id: 'chg-emp-003',
      type: 'event',
      targetId: 105,
      targetName: 'Healthcare & Biotech Forum 2026',
      requester: 'James Wilson',
      requestedChange: 'Add the final attendance count to the event record.',
      status: 'approved',
      submittedAt: '2 days ago',
    },
  ],
  registrations: [
    {
      id: 101,
      attendeeId: 'usr-attendee-001',
      eventId: 101,
      date: '2026-03-01',
      ticketId: 'TKT-EMP-101',
      status: 'confirmed',
      payment: 'paid',
      amount: 200,
      checkedIn: false,
      seat: 'VIP-12',
      verificationStatus: 'Verified',
      verified: true,
      docType: 'Govt Aadhaar ID',
      docRef: 'ID-8849-XXXX-1029',
      notes: 'Verified via Govt ID submission.',
    },
    {
      id: 102,
      attendeeId: 'usr-client-001',
      eventId: 102,
      date: '2026-03-05',
      ticketId: 'TKT-EMP-102',
      status: 'confirmed',
      payment: 'paid',
      amount: 350,
      checkedIn: false,
      seat: 'A-01',
      verificationStatus: 'Verified',
      verified: true,
      docType: 'Corporate Access Badge',
      docRef: 'CORP-TC-9941',
      notes: 'Executive corporate verification completed.',
    },
    {
      id: 103,
      attendeeId: 'usr-attendee-001',
      eventId: 103,
      date: '2026-03-08',
      ticketId: 'TKT-EMP-103',
      status: 'confirmed',
      payment: 'paid',
      amount: 120,
      checkedIn: true,
      seat: 'Lab-04',
      verificationStatus: 'Verified',
      verified: true,
      docType: 'Passport Verification',
      docRef: 'PASS-Z992014',
      notes: 'Workshop credentials verified.',
    },
    {
      id: 104,
      attendeeId: 8,
      eventId: 104,
      date: '2026-03-12',
      ticketId: 'TKT-EMP-104',
      status: 'pending',
      payment: 'paid',
      amount: 0,
      checkedIn: false,
      seat: 'Desk-22',
      verificationStatus: 'Pending Review',
      verified: false,
      docType: 'Student University ID',
      docRef: 'UNI-STU-4820',
      notes: 'Student ID photo blur — pending manual review.',
    },
    {
      id: 105,
      attendeeId: 9,
      eventId: 105,
      date: '2026-03-15',
      ticketId: 'TKT-EMP-105',
      status: 'confirmed',
      payment: 'paid',
      amount: 250,
      checkedIn: true,
      seat: 'Hall-55',
      verificationStatus: 'Verified',
      verified: true,
      docType: 'Govt Driving License',
      docRef: 'DL-MH-04-2024009',
      notes: 'Healthcare delegate identity confirmed.',
    },
    {
      id: 1,
      attendeeId: 5,
      eventId: 1,
      date: '2026-03-01',
      ticketId: 'TKT-2026-001',
      status: 'pending',
      payment: 'paid',
      amount: 150,
      checkedIn: false,
      seat: 'A-042',
      verificationStatus: 'Pending Review',
      verified: false,
      docType: 'Govt Aadhaar ID',
      docRef: 'ID-4421-XXXX-9912',
      notes: 'Identity proof uploaded, awaiting approval.',
    },
    {
      id: 2,
      attendeeId: 5,
      eventId: 2,
      date: '2026-03-05',
      ticketId: 'TKT-2026-002',
      status: 'confirmed',
      payment: 'paid',
      amount: 250,
      checkedIn: false,
      seat: 'T-015',
      verificationStatus: 'Verified',
      verified: true,
      docType: 'Corporate Invite Pass',
      docRef: 'GALA-INV-0192',
      notes: 'Gala guest verification confirmed.',
    },
    {
      id: 3,
      attendeeId: 8,
      eventId: 1,
      date: '2026-03-02',
      ticketId: 'TKT-2026-003',
      status: 'pending',
      payment: 'paid',
      amount: 150,
      checkedIn: true,
      seat: 'A-043',
      verificationStatus: 'Flagged',
      verified: false,
      docType: 'Company ID Card',
      docRef: 'EMP-ID-MISSING',
      flagReason: 'Company ID badge image missing back side.',
      notes: 'Flagged for re-upload.',
    },
    {
      id: 4,
      attendeeId: 5,
      eventId: 3,
      date: '2026-03-10',
      ticketId: 'TKT-2026-004',
      status: 'confirmed',
      payment: 'paid',
      amount: 75,
      checkedIn: false,
      seat: 'GA',
      verificationStatus: 'Verified',
      verified: true,
      docType: 'E-Ticket Pass',
      docRef: 'TKT-FEST-8819',
      notes: 'Festival online registration verified.',
    },
    {
      id: 5,
      attendeeId: 9,
      eventId: 1,
      date: '2026-03-03',
      ticketId: 'TKT-2026-005',
      status: 'pending',
      payment: 'paid',
      amount: 150,
      checkedIn: true,
      seat: 'A-044',
      verificationStatus: 'Pending Review',
      verified: false,
      docType: 'Govt Aadhaar ID',
      docRef: 'ID-1102-XXXX-7741',
      notes: 'Online verification pending.',
    },
    {
      id: 6,
      attendeeId: 8,
      eventId: 3,
      date: '2026-03-12',
      ticketId: 'TKT-2026-006',
      status: 'confirmed',
      payment: 'paid',
      amount: 75,
      checkedIn: false,
      seat: 'GA',
      verificationStatus: 'Verified',
      verified: true,
      docType: 'E-Ticket Pass',
      docRef: 'TKT-FEST-8820',
      notes: 'Pass verified.',
    },
    {
      id: 7,
      attendeeId: 2,
      eventId: 1,
      date: '2026-03-14',
      ticketId: 'TKT-2026-007',
      status: 'confirmed',
      payment: 'paid',
      amount: 150,
      checkedIn: false,
      seat: 'A-045',
      verificationStatus: 'Verified',
      verified: true,
      docType: 'Organizer VIP Access',
      docRef: 'ORG-VIP-002',
      notes: 'Organizer VIP pass verified.',
    },
    {
      id: 8,
      attendeeId: 3,
      eventId: 1,
      date: '2026-03-15',
      ticketId: 'TKT-2026-008',
      status: 'confirmed',
      payment: 'paid',
      amount: 150,
      checkedIn: false,
      seat: 'A-046',
      verificationStatus: 'Verified',
      verified: true,
      docType: 'Client Pass',
      docRef: 'CLT-PASS-104',
      notes: 'Client registration verified.',
    },
  ],
  userQueries: [
    {
      id: 'UQR-501',
      userId: 'usr-attendee-001',
      userName: 'Priya Patel',
      userEmail: 'attendee@example.com',
      type: 'Account Deletion',
      subject: 'Request permanent account deletion',
      detail:
        'User requested permanent deletion of their attendee account and associated personal data.',
      source: 'User Request',
      status: 'Pending',
      date: 'Today, 10:30 AM',
    },
    {
      id: 'UQR-502',
      userId: 'usr-client-001',
      userName: 'Michael Torres',
      userEmail: 'client@example.com',
      type: 'Email Change',
      subject: 'Update profile email address to corporate domain',
      detail: 'Requested email update from client@example.com to m.torres@techcorp.com.',
      source: 'User Request',
      status: 'In Progress',
      date: 'Yesterday, 4:15 PM',
    },
    {
      id: 'UQR-503',
      userId: 8,
      userName: 'Lisa Zhang',
      userEmail: 'lisa@eventflow.com',
      type: 'Escalated Support',
      subject: 'Verification failed for Hackathon registration badge',
      detail:
        'Escalated by Customer Support (Employee 3): Student ID upload unreadable, needs re-verification.',
      source: 'Employee 3 Escalation',
      status: 'Pending',
      date: '2 days ago',
    },
    {
      id: 'UQR-504',
      userId: 9,
      userName: 'Robert Singh',
      userEmail: 'robert@eventflow.com',
      type: 'Profile Update',
      subject: 'Contact phone number correction & name spelling',
      detail: 'Requested phone update to +91 9876543209 and correction on badge name.',
      source: 'User Request',
      status: 'Resolved',
      date: '2026-08-26',
    },
    {
      id: 'UQR-505',
      userId: 'usr-attendee-001',
      userName: 'Priya Patel',
      userEmail: 'attendee@example.com',
      type: 'Escalated Support',
      subject: 'Ticket details correction request',
      detail: 'User requested a correction to the attendee name on their Tech Summit ticket.',
      source: 'Employee 3 Escalation',
      status: 'Pending',
      date: 'Today, 8:45 AM',
    },
  ],
  notifications: [
    {
      id: 101,
      title: 'New Event Proposal',
      msg: 'Michael Torres submitted "Torres Tech Q3 Product Launch" with ₹35,000 budget.',
      time: '10 mins ago',
      read: false,
      type: 'info',
      icon: '📋',
    },
    {
      id: 103,
      title: 'Capacity Milestone Reached',
      msg: 'Cybersecurity Workshop reached 100% capacity (80/80 registered).',
      time: '3 hrs ago',
      read: true,
      type: 'warning',
      icon: '🎟️',
    },
    {
      id: 104,
      title: 'Event Request Approved',
      msg: 'Annual Leadership Strategy Retreat proposal was approved by the client.',
      time: '1 day ago',
      read: true,
      type: 'success',
      icon: '🎉',
    },
    {
      id: 1,
      title: 'New Event Request',
      msg: 'Michael Torres submitted: "Product Launch Event" — ?25,000 budget',
      time: '2 hrs ago',
      read: false,
      type: 'info',
      icon: '📋',
    },
    {
      id: 2,
      title: 'Registration Confirmed',
      msg: 'Priya Patel registered for Tech Innovation Summit 2026',
      time: '4 hrs ago',
      read: false,
      type: 'success',
      icon: '✅',
    },
    {
      id: 4,
      title: 'Event Plan Submitted',
      msg: 'Team Building Retreat plan submitted to client for review',
      time: '1 day ago',
      read: true,
      type: 'info',
      icon: '📤',
    },
    {
      id: 5,
      title: 'Event Approved',
      msg: 'Corporate Annual Gala 2026 has been approved and is now live',
      time: '2 days ago',
      read: true,
      type: 'success',
      icon: '🎉',
    },
    {
      id: 6,
      title: 'Attendee Checked In',
      msg: '3 attendees checked in at Healthcare Innovation Forum',
      time: '3 days ago',
      read: true,
      type: 'success',
      icon: '✅',
    },
    {
      id: 7,
      title: 'New Assignment',
      msg: 'Sarah Johnson assigned you as Photographer & Videographer for Corporate Annual Gala 2026 — ?1,100 fee',
      time: '1 hr ago',
      read: false,
      type: 'warning',
      icon: '📸',
    },
    {
      id: 8,
      title: 'New Assignment',
      msg: 'Sarah Johnson assigned you as Stage Photographer for Spring Music Festival — ?750 fee',
      time: '3 hrs ago',
      read: false,
      type: 'warning',
      icon: '🎵',
    },
    {
      id: 9,
      title: 'New Assignment',
      msg: 'Assigned as Event Documentarian for Startup Pitch Night — ?500 fee',
      time: '5 hrs ago',
      read: false,
      type: 'warning',
      icon: '🚀',
    },
    {
      id: 'sf-notif-001',
      employeeType: 'SUPPORT_FINANCE',
      title: 'New Support Request',
      msg: 'Michael Torres requested a payment receipt for Global AI & Cloud Summit 2026.',
      time: '12 mins ago',
      read: false,
      type: 'info',
      icon: '📩',
    },
    {
      id: 'sf-notif-002',
      employeeType: 'SUPPORT_FINANCE',
      title: 'Refund Awaiting Review',
      msg: 'Refund REF-2026-001 for ₹350 is ready for finance review.',
      time: '28 mins ago',
      read: false,
      type: 'warning',
      icon: '↩️',
    },
    {
      id: 'sf-notif-003',
      employeeType: 'SUPPORT_FINANCE',
      title: 'Transaction Completed',
      msg: 'Transaction TXN-2026-005 was completed successfully for Michael Torres.',
      time: '1 hr ago',
      read: true,
      type: 'success',
      icon: '💳',
    },
    {
      id: 'sf-notif-004',
      employeeType: 'SUPPORT_FINANCE',
      title: 'Report Reviewed',
      msg: 'August service operations was reviewed by Super Admin.',
      time: 'Yesterday',
      read: true,
      type: 'success',
      icon: '📊',
    },
  ],
  attendanceReports: {},
  // {eventId: {total, checked, pending, report}}
  supportRequests: [
    {
      id: 'sup-001',
      userId: 'usr-client-001',
      eventId: 101,
      subject: 'Payment receipt needed',
      message: 'Please resend the receipt for my summit registration.',
      status: 'Pending',
      response: '',
      created: today(),
      updated: '10 mins ago',
    },
    {
      id: 'sup-002',
      userId: 'usr-attendee-001',
      eventId: 103,
      subject: 'Unable to download ticket',
      message: 'My payment is complete but the ticket link is not opening.',
      status: 'In Progress',
      response: 'We are checking your ticket record now.',
      created: '2026-08-27',
      updated: '1 hr ago',
    },
    {
      id: 'sup-003',
      userId: 'usr-client-001',
      eventId: 102,
      subject: 'Refund request',
      message: 'Two registrations were made by mistake. Please refund one.',
      status: 'Resolved',
      response: 'Your refund request has been forwarded to finance.',
      created: '2026-08-26',
      updated: 'Yesterday',
    },
    {
      id: 'sup-004',
      userId: 'usr-attendee-001',
      eventId: 104,
      subject: 'Event location question',
      message: 'Could you confirm the venue entrance details?',
      status: 'Closed',
      response: 'Venue instructions were sent to your email.',
      created: '2026-08-25',
      updated: '2 days ago',
    },
  ],
  financeTransactions: [
    {
      id: 'TXN-2026-001',
      userId: 'usr-attendee-001',
      eventId: 101,
      amount: 200,
      status: 'Successful',
      date: today(),
    },
    {
      id: 'TXN-2026-002',
      userId: 'usr-client-001',
      eventId: 102,
      amount: 350,
      status: 'Successful',
      date: today(),
    },
    {
      id: 'TXN-2026-005',
      userId: 'usr-client-001',
      eventId: 101,
      amount: 200,
      status: 'Successful',
      date: today(),
    },
    {
      id: 'TXN-2026-003',
      userId: 'usr-attendee-001',
      eventId: 103,
      amount: 120,
      status: 'Pending',
      date: '2026-08-27',
    },
    {
      id: 'TXN-2026-004',
      userId: 'usr-client-001',
      eventId: 104,
      amount: 0,
      status: 'Failed',
      date: '2026-08-26',
    },
  ],
  financeRefunds: [
    {
      id: 'REF-2026-001',
      userId: 'usr-client-001',
      eventId: 102,
      amount: 350,
      reason: 'Duplicate registration',
      status: 'Requested',
      date: today(),
    },
    {
      id: 'REF-2026-002',
      userId: 'usr-attendee-001',
      eventId: 103,
      amount: 120,
      reason: 'Event schedule conflict',
      status: 'Processing',
      date: '2026-08-27',
    },
    {
      id: 'REF-2026-003',
      userId: 'usr-attendee-001',
      eventId: 101,
      amount: 200,
      reason: 'Cancelled attendance',
      status: 'Completed',
      date: '2026-08-25',
    },
    {
      id: 'REF-2026-004',
      userId: 'usr-client-001',
      eventId: 104,
      amount: 0,
      reason: 'Invalid request',
      status: 'Rejected',
      date: '2026-08-24',
    },
  ],
  operationalReports: [
    {
      id: 'OPR-001',
      type: 'Support Report',
      title: 'Weekly support queue',
      owner: 'Marcus Vance',
      status: 'Draft',
      updated: 'Today',
    },
    {
      id: 'OPR-002',
      type: 'Finance Report',
      title: 'Transaction reconciliation',
      owner: 'Marcus Vance',
      status: 'Submitted',
      updated: 'Yesterday',
    },
    {
      id: 'OPR-003',
      type: 'Combined Operational Report',
      title: 'August service operations',
      owner: 'Maya Lin',
      status: 'Reviewed',
      updated: '2026-08-25',
    },
  ],
  eventOperationsTasks: [
    {
      id: 'EOP-101',
      eventId: 101,
      eventTitle: 'Global AI & Cloud Summit 2026',
      type: 'Venue & Capacity Review',
      priority: 'High',
      status: 'In Progress',
      description: 'Verify Hall A seating capacity for 600 attendees and check AV setup.',
      updated: '15 mins ago',
    },
    {
      id: 'EOP-102',
      eventId: 102,
      eventTitle: 'FinTech Leaders Executive Conclave',
      type: 'Schedule Conflict',
      priority: 'Medium',
      status: 'Pending',
      description:
        'Review ballroom entrance timeline to avoid setup overlap with hotel guest event.',
      updated: '1 hr ago',
    },
    {
      id: 'EOP-103',
      eventId: 103,
      eventTitle: 'Cybersecurity & Zero Trust Workshop',
      type: 'Equipment & Tech Check',
      priority: 'Low',
      status: 'Resolved',
      description: 'Simulated threat modeling server and projector connection verified.',
      updated: 'Yesterday',
    },
    {
      id: 'EOP-104',
      eventId: 104,
      eventTitle: 'National Web3 & AI Hackathon 2026',
      type: 'Security & Access Audit',
      priority: 'High',
      status: 'Pending',
      description: 'Confirm overnight security pass authorizations and 24-hour venue access.',
      updated: '3 hrs ago',
    },
    {
      id: 'EOP-105',
      eventId: 105,
      eventTitle: 'Torres Tech Q3 Product Launch',
      type: 'Information Correction',
      priority: 'Medium',
      status: 'In Progress',
      description: 'Correct banner imagery resolution and VIP guest list count.',
      updated: 'Today',
    },
  ],
  eventOpsReports: [
    {
      id: 'EOR-001',
      type: 'Event Performance Report',
      title: 'Event Performance Summary — Q2 Summit & Conclave',
      scope: 'Global AI & Cloud Summit 2026',
      period: 'Q2 2026',
      owner: 'Elena Rostova',
      status: 'Reviewed',
      fileName: 'Q2_Performance_Summary.pdf',
      updated: '2026-08-25',
    },
    {
      id: 'EOR-002',
      type: 'Event Operations Report',
      title: 'Venue & Logistics Operations Report',
      scope: 'Main Convention Center',
      period: 'August 2026',
      owner: 'Elena Rostova',
      status: 'Pending Review',
      fileName: 'Logistics_Audit_Report.docx',
      updated: 'Yesterday',
    },
    {
      id: 'EOR-003',
      type: 'Event Activity Report',
      title: 'Monthly Event Activity Report — August 2026',
      scope: 'Platform Wide',
      period: 'August 2026',
      owner: 'Elena Rostova',
      status: 'Reviewed',
      fileName: 'August_Activity_Log.xlsx',
      updated: '2026-08-22',
    },
    {
      id: 'EOR-004',
      type: 'Event Operations Report',
      title: 'Schedule & Venue Audit Report',
      scope: 'FinTech Leaders Executive Conclave',
      period: 'August 2026',
      owner: 'Elena Rostova',
      status: 'Draft',
      fileName: null,
      updated: 'Today',
    },
    {
      id: 'EOR-005',
      type: 'Event Performance Report',
      title: 'Event Issue Resolution & Operations Report',
      scope: 'All Q3 Events',
      period: 'Q3 2026',
      owner: 'Elena Rostova',
      status: 'Submitted',
      fileName: 'Issue_Resolution_Q3.pdf',
      updated: '2 days ago',
    },
    {
      id: 'EOR-006',
      type: 'Event Activity Report',
      title: 'National Hackathon Operations & Equipment Log',
      scope: 'National Web3 & AI Hackathon 2026',
      period: 'August Week 4',
      owner: 'Elena Rostova',
      status: 'Submitted',
      fileName: 'Hackathon_Ops_Log.xlsx',
      updated: '3 days ago',
    },
  ],
  eventOpsRequests: [
    {
      id: 'EOR-REQ-001',
      eventId: 101,
      eventTitle: 'Global AI & Cloud Summit 2026',
      issue:
        'Venue capacity insufficient — attendee count exceeds Hall A limit by 85 seats. Requesting overflow arrangement.',
      source: 'User (Direct)',
      raisedBy: 'Priya Mehta',
      priority: 'High',
      status: 'In Progress',
      date: '2026-08-30 · 9:14 AM',
      notes: '',
    },
    {
      id: 'EOR-REQ-002',
      eventId: 102,
      eventTitle: 'FinTech Leaders Executive Conclave',
      issue:
        'Schedule conflict reported — keynote session overlaps with hotel ballroom booking. Attendees facing confusion.',
      source: 'Escalated by Emp 3',
      raisedBy: 'Customer Support',
      priority: 'High',
      status: 'Pending',
      date: '2026-08-30 · 8:45 AM',
      notes: '',
    },
    {
      id: 'EOR-REQ-003',
      eventId: 103,
      eventTitle: 'Cybersecurity & Zero Trust Workshop',
      issue:
        'Event banner shows wrong venue floor. Requesting information correction on registration confirmation emails.',
      source: 'User (Direct)',
      raisedBy: 'Ravi Kumar',
      priority: 'Medium',
      status: 'Pending',
      date: '2026-08-29 · 4:32 PM',
      notes: '',
    },
    {
      id: 'EOR-REQ-004',
      eventId: 104,
      eventTitle: 'National Web3 & AI Hackathon 2026',
      issue:
        'Cancellation request raised by team lead — team unable to attend due to visa delays. Refund and slot reallocation required.',
      source: 'Escalated by Emp 3',
      raisedBy: 'Customer Support',
      priority: 'High',
      status: 'Pending',
      date: '2026-08-29 · 2:10 PM',
      notes: '',
    },
    {
      id: 'EOR-REQ-005',
      eventId: 105,
      eventTitle: 'Torres Tech Q3 Product Launch',
      issue:
        'VIP seating arrangement request — 3 executives require reserved front-row access and separate registration check-in.',
      source: 'User (Direct)',
      raisedBy: 'Ananya Sharma',
      priority: 'Medium',
      status: 'Resolved',
      date: '2026-08-28 · 11:05 AM',
      notes: 'VIP arrangement confirmed with venue coordinator.',
    },
    {
      id: 'EOR-REQ-006',
      eventId: 106,
      eventTitle: 'Global Health & MedTech Expo 2026',
      issue:
        'AV equipment malfunction reported during rehearsal — projectors in Hall B not syncing with laptop output.',
      source: 'Escalated by Emp 3',
      raisedBy: 'Customer Support',
      priority: 'High',
      status: 'In Progress',
      date: '2026-08-28 · 9:30 AM',
      notes: '',
    },
    {
      id: 'EOR-REQ-007',
      eventId: 107,
      eventTitle: 'Women in Leadership Summit',
      issue:
        'Schedule update needed — opening ceremony moved 30 mins earlier. Attendees need updated confirmation with new timings.',
      source: 'User (Direct)',
      raisedBy: 'Meera Iyer',
      priority: 'Medium',
      status: 'Resolved',
      date: '2026-08-27 · 3:18 PM',
      notes: 'Updated schedule sent to all registered attendees.',
    },
    {
      id: 'EOR-REQ-008',
      eventId: 108,
      eventTitle: 'Renewable Energy Innovation Forum',
      issue:
        'Capacity oversubscription — event sold 20% over venue limit due to system error. Waiting list and capacity review needed.',
      source: 'Escalated by Emp 3',
      raisedBy: 'Customer Support',
      priority: 'High',
      status: 'Closed',
      date: '2026-08-26 · 10:50 AM',
      notes: 'Capacity expanded to secondary hall. Waitlisted attendees notified.',
    },
    {
      id: 'EOR-REQ-009',
      eventId: 101,
      eventTitle: 'Global AI & Cloud Summit 2026',
      issue:
        'Parking arrangement inquiry — group of 40 attendees from outstation require dedicated parking slots near venue entrance.',
      source: 'User (Direct)',
      raisedBy: 'Sameer Joshi',
      priority: 'Low',
      status: 'Pending',
      date: '2026-08-30 · 7:00 AM',
      notes: '',
    },
    {
      id: 'EOR-REQ-010',
      eventId: 103,
      eventTitle: 'Cybersecurity & Zero Trust Workshop',
      issue:
        'Speaker travel logistics — confirmed keynote speaker requires airport pickup and hotel arrangement from organizer side.',
      source: 'User (Direct)',
      raisedBy: 'Organizing Team',
      priority: 'Medium',
      status: 'In Progress',
      date: '2026-08-29 · 6:45 PM',
      notes: '',
    },
  ],
  regReports: [
    {
      id: 'RVR-001',
      type: 'Registration Report',
      title: 'Monthly Online Registration & Conversion Audit — August 2026',
      owner: 'Arjun Kapoor',
      status: 'Reviewed',
      period: 'August 2026',
      fileName: 'Monthly_Registration_Audit_Aug2026.pdf',
      updated: '2026-08-25',
    },
    {
      id: 'RVR-002',
      type: 'User Management Report',
      title: 'Account Access & Verification Summary — Q2 2026',
      owner: 'Arjun Kapoor',
      status: 'Submitted',
      period: 'Q2 2026 (Apr–Jun)',
      fileName: 'Account_Access_Verification_Q2_2026.docx',
      updated: 'Yesterday',
    },
    {
      id: 'RVR-003',
      type: 'Registration Activity Report',
      title: 'Q2 Attendee Registration Activity & Demographics Analysis',
      owner: 'Arjun Kapoor',
      status: 'Reviewed',
      period: 'Q2 2026 (Apr–Jun)',
      fileName: 'Q2_Registration_Activity_Demographics.xlsx',
      updated: '2026-08-20',
    },
    {
      id: 'RVR-004',
      type: 'Registration Report',
      title: 'Tech Summit 2026 — Online Registration Status & Completion Report',
      owner: 'Arjun Kapoor',
      status: 'Submitted',
      period: 'July 2026',
      fileName: 'TechSummit_Registration_Report.pdf',
      updated: '2 days ago',
    },
    {
      id: 'RVR-005',
      type: 'User Management Report',
      title: 'User Account Deactivation & Access Audit — July 2026',
      owner: 'Arjun Kapoor',
      status: 'Draft',
      period: 'July 2026',
      fileName: null,
      updated: 'Today',
    },
    {
      id: 'RVR-006',
      type: 'Registration Activity Report',
      title: 'Pending & Flagged Registrations Weekly Summary — Wk 34',
      owner: 'Arjun Kapoor',
      status: 'Draft',
      period: 'August Week 4',
      fileName: null,
      updated: 'Today',
    },
  ],
  _nextId: {
    users: 14,
    events: 9,
    reqs: 5,
    regs: 9,
    notifs: 10,
  },
};

// ════════════════════════════════════════════════
//  DATA PERSISTENCE (LOCALSTORAGE)
// ════════════════════════════════════════════════
function saveDB() {
  try {
    localStorage.setItem('ffsd_db', JSON.stringify(DB));
  } catch (e) {
    console.log('Storage quota exceeded or private mode');
  }
}
// `persist` is disabled for storage events so receiving tabs do not write the
// same data back and trigger another refresh in every open session.
function loadDB(persist = true) {
  try {
    const saved = localStorage.getItem('ffsd_db');
    if (saved) {
      const parsed = JSON.parse(saved);
      const initialUsers = [...DB.users];
      const initialEvents = [...DB.events];
      const initialRequests = [...DB.eventRequests];
      const initialRegs = [...DB.registrations];
      const initialNotifs = [...DB.notifications];
      const initialReports = [...(DB.reports || [])];
      const initialChangeRequests = [...(DB.employeeChangeRequests || [])];
      const initialSupportRequests = [...(DB.supportRequests || [])];
      const initialFinanceTransactions = [...(DB.financeTransactions || [])];
      const initialFinanceRefunds = [...(DB.financeRefunds || [])];
      const initialOperationalReports = [...(DB.operationalReports || [])];
      const initialEventOperationsTasks = [...(DB.eventOperationsTasks || [])];
      const initialEventOpsReports = [...(DB.eventOpsReports || [])];
      const initialUserQueries = [...(DB.userQueries || [])];
      Object.assign(DB, parsed);
      window.EventFlowAccountPolicy.migrateLegacyDemoData(DB);

      // Ensure optional arrays exist

      if (!DB.reports) DB.reports = [];
      if (!DB.employeeChangeRequests) DB.employeeChangeRequests = [];
      if (!DB.attendanceReports) DB.attendanceReports = {};
      if (!DB.supportRequests) DB.supportRequests = [];
      if (!DB.financeTransactions) DB.financeTransactions = [];
      if (!DB.financeRefunds) DB.financeRefunds = [];
      if (!DB.operationalReports) DB.operationalReports = [];
      if (!DB.eventOperationsTasks) DB.eventOperationsTasks = [];
      if (!DB.eventOpsReports) DB.eventOpsReports = [];
      if (!DB.eventOpsRequests) DB.eventOpsRequests = [];
      if (!DB.userQueries) DB.userQueries = [];
      if (!DB.routedRequests) DB.routedRequests = [];

      // Sync all demo/seed users and passwords from latest build
      initialUsers.forEach(initU => {
        const existing = DB.users.find(
          user =>
            (user.email && user.email.toLowerCase() === initU.email.toLowerCase()) ||
            user.id === initU.id
        );
        if (!existing) {
          DB.users.push(initU);
        } else {
          existing.password = initU.password;
          existing.status = 'active';
          if (initU.role) existing.role = initU.role;
          if (initU.name) existing.name = initU.name;
          if (initU.avatarImage) existing.avatarImage = initU.avatarImage;
          if (initU.avatar) existing.avatar = initU.avatar;
          if (initU.service) existing.service = initU.service;
          if (initU.bio) existing.bio = initU.bio;
          if (initU.color) existing.color = initU.color;
        }
      });

      // Always restore missing mock events (ensuring employee events are always populated)
      initialEvents.forEach(ev => {
        const existing = DB.events.find(event => String(event.id) === String(ev.id));
        if (!existing) {
          DB.events.push(ev);
        } else {
          if (ev.image) existing.image = ev.image;
          if (ev.color) existing.color = ev.color;
          if (ev.emoji) existing.emoji = ev.emoji;
        }
      });

      // Always restore missing mock event requests & migrate legacy client IDs
      initialRequests.forEach(req => {
        const existing = DB.eventRequests.find(request => String(request.id) === String(req.id));
        if (!existing) {
          DB.eventRequests.push(req);
        } else if (
          existing.clientId === 3 ||
          existing.clientId === '3' ||
          !DB.users.find(user => String(user.id) === String(existing.clientId))
        ) {
          existing.clientId = 'usr-client-001';
        }
      });
      DB.eventRequests.forEach(request => {
        if (
          request.clientId === 3 ||
          request.clientId === '3' ||
          !DB.users.find(user => String(user.id) === String(request.clientId))
        ) {
          request.clientId = 'usr-client-001';
        }
      });

      // Always restore missing mock registrations and sync verification statuses
      initialRegs.forEach(reg => {
        const existing = DB.registrations.find(
          registration => String(registration.id) === String(reg.id)
        );
        if (!existing) {
          DB.registrations.push(reg);
        } else {
          if (reg.verificationStatus && !existing.verificationStatus)
            existing.verificationStatus = reg.verificationStatus;
          if (reg.docType && !existing.docType) existing.docType = reg.docType;
          if (reg.docRef && !existing.docRef) existing.docRef = reg.docRef;
        }
      });

      // Always restore userQueries
      initialUserQueries.forEach(query => {
        const existing = DB.userQueries.find(q => String(q.id) === String(query.id));
        if (!existing) DB.userQueries.push(query);
      });

      // Always restore missing mock notifications
      initialNotifs.forEach(notif => {
        if (!DB.notifications.find(notification => String(notification.id) === String(notif.id))) {
          DB.notifications.push(notif);
        }
      });

      // Always restore missing mock event reports
      initialReports.forEach(report => {
        if (!DB.reports.find(r => String(r.id) === String(report.id))) {
          DB.reports.push(report);
        }
      });
      initialChangeRequests.forEach(request => {
        if (!DB.employeeChangeRequests.find(r => String(r.id) === String(request.id))) {
          DB.employeeChangeRequests.push(request);
        }
      });
      initialSupportRequests.forEach(request => {
        const existing = DB.supportRequests.find(r => String(r.id) === String(request.id));
        if (!existing) DB.supportRequests.push(request);
      });
      initialFinanceTransactions.forEach(transaction => {
        const existing = DB.financeTransactions.find(
          item => String(item.id) === String(transaction.id)
        );
        if (!existing) DB.financeTransactions.push(transaction);
        else if (['TXN-2026-001', 'TXN-2026-002', 'TXN-2026-005'].includes(transaction.id))
          existing.date = transaction.date;
      });
      initialFinanceRefunds.forEach(refund => {
        const existing = DB.financeRefunds.find(item => String(item.id) === String(refund.id));
        if (!existing) DB.financeRefunds.push(refund);
        else if (['REF-2026-001'].includes(refund.id)) existing.date = refund.date;
      });
      initialOperationalReports.forEach(report => {
        if (!DB.operationalReports.find(item => String(item.id) === String(report.id)))
          DB.operationalReports.push(report);
      });
      initialEventOperationsTasks.forEach(task => {
        if (!DB.eventOperationsTasks.find(item => String(item.id) === String(task.id)))
          DB.eventOperationsTasks.push(task);
      });
      initialEventOpsReports.forEach(report => {
        if (!DB.eventOpsReports.find(item => String(item.id) === String(report.id)))
          DB.eventOpsReports.push(report);
      });
      (DB._initialEventOpsRequests || DB.eventOpsRequests.slice()).forEach(() => {});
      // Restore event ops requests from seed
      if (typeof initialEventOpsRequests !== 'undefined') {
        initialEventOpsRequests.forEach(request => {
          if (!DB.eventOpsRequests.find(item => String(item.id) === String(request.id)))
            DB.eventOpsRequests.push(request);
        });
      }

      // SAFETY: Sync _nextId with actual data max IDs to prevent collisions
      const _maxId = (arr, key) =>
        arr.length ? Math.max(0, ...arr.map(x => (isNaN(x[key]) ? 0 : parseInt(x[key])))) : 0;
      DB._nextId.users = Math.max(DB._nextId.users || 0, _maxId(DB.users, 'id') + 1);
      DB._nextId.events = Math.max(DB._nextId.events || 0, _maxId(DB.events, 'id') + 1);
      DB._nextId.regs = Math.max(DB._nextId.regs || 0, _maxId(DB.registrations, 'id') + 1);
      DB._nextId.reqs = Math.max(DB._nextId.reqs || 0, _maxId(DB.eventRequests, 'id') + 1);

      // Persist seed-data migrations only for local loads. A storage event
      // must remain read-only to avoid a cross-tab update loop.
      if (persist || Number(parsed.accountSchemaVersion || 0) < 2) saveDB();
    }
  } catch (e) {
    console.log('Could not load DB from storage');
  }
  window.EventFlowAccountPolicy.migrateLegacyDemoData(DB);
}

// ════════════════════════════════════════════════
//  STATE
// ════════════════════════════════════════════════
let CU = null; // current user
let _confirmCb = null;
let _currentPage = 'dashboard';
let _workflowRequestId = null;
let _workflowReturnPage = 'request-status';
let _workflowEventTab = 'upcoming';
const ROLE_LABELS = {
  superuser: 'Super Administrator',
  organizer: 'Event Organizer',
  client: 'Client',
  employee: 'Employee',
  attendee: 'Attendee',
};
const ROLE_COLORS = {
  superuser: 'red',
  organizer: 'purple',
  client: 'yellow',
  employee: 'green',
  attendee: 'blue',
};
const DEMO_CREDS = {
  employee: {
    email: 'employee@example.com',
    pw: 'Employee@123',
  },
  organizer: {
    email: 'organizer@example.com',
    pw: 'Organizer@123',
  },
  client: {
    email: 'client@example.com',
    pw: 'Client@123',
  },
  attendee: {
    email: 'attendee@example.com',
    pw: 'Attendee@123',
  },
  superuser: {
    email: 'superadmin@example.com',
    pw: 'Admin@123',
  },
};
function isEmployeeAccount() {
  return (CU?.email || '').toLowerCase() === DEMO_CREDS.employee.email;
}
function isDepartmentEmployee() {
  return CU?.role === 'employee' && !!CU?.employeeType;
}

// ════════════════════════════════════════════════
//  PAGE SWITCHING
// ════════════════════════════════════════════════
function showPage(p) {
  document.getElementById('landing').style.display = p === 'landing' ? 'block' : 'none';
  document.getElementById('login').style.display = p === 'login' ? 'flex' : 'none';
  document.getElementById('find-events').style.display = p === 'find-events' ? 'block' : 'none';
  document.getElementById('gallery').style.display = p === 'gallery' ? 'block' : 'none';
  document.getElementById('about').style.display = p === 'about' ? 'block' : 'none';
  document.getElementById('contact').style.display = p === 'contact' ? 'block' : 'none';
  document.getElementById('app').style.display = p === 'app' ? 'block' : 'none';
}
function gotoLogin(role) {
  showPage('login');
}

// ════════════════════════════════════════════════
//  AUTH
// ════════════════════════════════════════════════

function fillLogin(email, pass) {
  for (const [id, value] of [
    ['l-email', email],
    ['l-pass', pass],
  ]) {
    const input = g(id);
    if (!input) continue;
    input.value = value;
    input.dispatchEvent(
      new Event('input', {
        bubbles: true,
      })
    );
  }
  toast('Demo credentials loaded: ' + email, 'info');
}
function doLogin() {
  const email = g('l-email').value.trim();
  const pass = g('l-pass').value.trim();
  let ok = true;
  if (!email || !email.includes('@')) {
    showErr('l-email-err');
    ok = false;
  } else hideErr('l-email-err');
  if (!pass || pass.length < 3) {
    showErr('l-pass-err');
    ok = false;
  } else hideErr('l-pass-err');
  if (!ok) return;
  const button = document.querySelector('#login .btn-primary');
  if (button) {
    button.textContent = 'Signing in…';
    button.disabled = true;
  }

  // Try backend first, with instant fallback to local DB if backend is offline
  apiLogin(email, pass)
    .then(function (userData) {
      const roleMap = {
        EMPLOYEE: 'employee',
        employee: 'employee',
        SUPER_ADMIN: 'superuser',
        super_admin: 'superuser',
        CLIENT: 'client',
        client: 'client',
        EVENT_ORGANIZER: 'organizer',
        event_organizer: 'organizer',
        ATTENDEE: 'attendee',
        attendee: 'attendee',
      };
      const frontendRole =
        roleMap[userData.role || userData.userRole] ||
        (userData.role || userData.userRole || '').toLowerCase();
      CU = {
        id: userData.userId,
        userId: userData.userId,
        name: userData.name,
        email: userData.email,
        token: userData.token,
        role: frontendRole,
        userRole: userData.role || userData.userRole,
        employeeType: userData.employeeType,
        status: userData.status,
        avatar: (userData.name || 'U')
          .split(' ')
          .map(n => n[0])
          .join('')
          .toUpperCase()
          .slice(0, 2),
      };
      try {
        sessionStorage.setItem('ef_cu', JSON.stringify(CU));
      } catch (e) {}
      if (routeToRoleWorkspace(CU)) return;
      initApp();
      showPage('app');
      document.documentElement.classList.remove('restoring-session');
      toast(`Welcome back, ${CU.name}! 👋`, 'success');
    })
    .catch(function (error) {
      // Check local DB if offline or if password matches demo aliases
      const localUser = DB.users.find(user => user.email.toLowerCase() === email.toLowerCase());
      const norm = s => (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      const inNorm = norm(pass);
      const stNorm = localUser ? norm(localUser.password) : '';
      const localMatches =
        localUser &&
        (localUser.password === pass ||
          localUser.password.toLowerCase() === pass.toLowerCase() ||
          inNorm === stNorm ||
          inNorm === 'employee123' ||
          inNorm === 'employee' ||
          inNorm === 'organizer123' ||
          inNorm === 'org123' ||
          inNorm === 'organizer' ||
          inNorm === 'client123' ||
          inNorm === 'client' ||
          inNorm === 'attendee123' ||
          inNorm === 'att123' ||
          inNorm === 'attendee' ||
          inNorm === 'admin123' ||
          inNorm === 'admin');
      if (localMatches) {
        CU = {
          id: localUser.id || localUser.userId,
          userId: localUser.userId || localUser.id,
          name: localUser.name,
          email: localUser.email,
          role: localUser.role,
          userRole: localUser.userRole || localUser.role,
          employeeType: localUser.employeeType,
          status: localUser.status || 'active',
          avatar: (localUser.name || 'U')
            .split(' ')
            .map(n => n[0])
            .join('')
            .toUpperCase()
            .slice(0, 2),
        };
        try {
          sessionStorage.setItem('ef_cu', JSON.stringify(CU));
        } catch (e) {}
        if (routeToRoleWorkspace(CU)) return;
        initApp();
        showPage('app');
        document.documentElement.classList.remove('restoring-session');
        toast(`Welcome back, ${CU.name}! 👋`, 'success');
      } else {
        const msg = error.message || 'Invalid email or password';
        toast(msg, 'error');
        showErr('l-pass-err');
        g('l-pass-err').textContent = msg;
      }
    })
    .finally(function () {
      if (button) {
        button.textContent = 'Sign In →';
        button.disabled = false;
      }
    });
}
function doLogout() {
  CU = null;
  try {
    sessionStorage.removeItem('ef_cu');
  } catch (e) {}
  document.documentElement.classList.remove('restoring-session');
  if (window.EventFlowRole?.key !== 'landing') {
    window.location.replace('/landing');
    return;
  }
  showPage('landing');
  toast('Signed out successfully', 'info');
}
function openRegisterModal() {
  if (
    window.EventFlowOrganizerRegistration &&
    typeof window.EventFlowOrganizerRegistration.openRegisterModal === 'function'
  ) {
    return window.EventFlowOrganizerRegistration.openRegisterModal();
  }
  openModal(
    'Create New Account',
    `
    <div class="grid-2">
      <div class="form-group"><label class="form-label">Full Name *</label><input class="form-control" id="rg-name" placeholder="John Doe"></div>
      <div class="form-group"><label class="form-label">Email *</label><input class="form-control" id="rg-email" type="email" placeholder="you@example.com"></div>
    </div>
    <div class="grid-2">
      <div class="form-group"><label class="form-label">Password *</label><input class="form-control" id="rg-pass" type="password" placeholder="Min 6 characters"></div>
      <div class="form-group"><label class="form-label">Phone</label><input class="form-control" id="rg-phone" placeholder="+91 9876543200"></div>
    </div>
    <div class="form-group"><label class="form-label">Register As *</label>
      <select class="form-control" id="rg-role">
        <option value="attendee">🎟️ Attendee</option>
        <option value="client">💼 Client</option>

        <option value="organizer">🎯 Event Organizer</option>
      </select>
    </div>
  `,
    [
      {
        lbl: 'Create Account',
        cls: 'btn-primary',
        fn: 'submitRegister()',
      },
    ],
    false
  );
}
function submitRegister() {
  const name = v('rg-name');
  const email = v('rg-email');
  const pass = v('rg-pass');
  const phone = v('rg-phone');
  const role = v('rg-role');
  if (!name) {
    toast('Name is required', 'error');
    return;
  }
  if (!email || !email.includes('@')) {
    toast('Valid email is required', 'error');
    return;
  }
  if (!pass || pass.length < 6) {
    toast('Password must be at least 6 characters', 'error');
    return;
  }
  if (window.EventFlowAccountPolicy.isEmailInUse(DB.users, email)) {
    toast('Email already registered', 'error');
    return;
  }
  const initials = name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
  DB.users.push({
    id: DB._nextId.users++,
    name,
    email,
    password: pass,
    role,
    phone,
    avatar: initials,
    status: 'active',
    joined: today(),
  });
  closeModal();
  toast('Account created! You can now sign in.', 'success');
  g('l-email').value = email;
  g('l-pass').value = pass;
}

// ════════════════════════════════════════════════
//  APP INIT
// ════════════════════════════════════════════════
const NAV = {
  superuser: [
    {
      ic: '📊',
      lbl: 'Dashboard',
      pg: 'dashboard',
    },
    {
      ic: '👥',
      lbl: 'User Reports',
      pg: 'user-reports',
    },
    {
      ic: '🗓️',
      lbl: 'Event Reports',
      pg: 'event-reports',
    },
    {
      ic: '💰',
      lbl: 'Revenue Reports',
      pg: 'revenue-reports',
    },
  ],
  organizer: [
    {
      ic: '📊',
      lbl: 'Dashboard',
      pg: 'dashboard',
    },
    {
      ic: '🗓️',
      lbl: 'Manage Events',
      pg: 'events',
    },
    {
      ic: '📋',
      lbl: 'Event Requests',
      pg: 'event-requests',
    },
    {
      ic: '👥',
      lbl: 'Attendee Management',
      pg: 'attendees',
    },
    {
      ic: '📈',
      lbl: 'Event Reports',
      pg: 'reports',
    },
  ],
  employee: [
    {
      ic: '📊',
      lbl: 'Dashboard',
      pg: 'dashboard',
    },
    {
      ic: '📈',
      lbl: 'Reports',
      pg: 'reports',
    },
    {
      ic: '👤',
      lbl: 'Profile',
      pg: 'profile',
    },
  ],
  client: [
    {
      ic: '📊',
      lbl: 'Dashboard',
      pg: 'dashboard',
    },
    {
      ic: '🔍',
      lbl: 'Find Organizers',
      pg: 'find-organizers',
    },
    {
      ic: '📅',
      lbl: 'Events',
      pg: 'my-events',
    },
    {
      ic: '📋',
      lbl: 'Request Status',
      pg: 'request-status',
    },
  ],
  attendee: [
    {
      ic: '📊',
      lbl: 'Dashboard',
      pg: 'dashboard',
    },
    {
      ic: '🔍',
      lbl: 'Browse Events',
      pg: 'browse-events',
    },
    {
      ic: '🎟️',
      lbl: 'My Tickets',
      pg: 'my-tickets',
    },
  ],
};

// ════════════════════════════════════════════════
//  ADMIN: Employee Stats & Management (superuser)
// ════════════════════════════════════════════════
function buildGroupedAnalyticsBars(groups, height, legend) {
  let max = 1;
  groups.forEach(g => {
    (g.bars || []).forEach(b => {
      if ((b.value || 0) > max) max = b.value;
    });
  });
  const chartHeight = height || 200;
  return `
  <div style="display:flex;flex-direction:column;gap:10px">
    ${
      legend
        ? `
    <div style="display:flex;justify-content:flex-end;gap:16px;font-size:12px;color:var(--text2);margin-bottom:4px">
      ${legend
        .map(
          l =>
            `<span style="display:inline-flex;align-items:center;gap:6px"><span style="width:10px;height:10px;border-radius:3px;background:${l.color}"></span>${l.label}</span>`
        )
        .join('')}
    </div>`
        : ''
    }
    <div style="display:flex;align-items:flex-end;gap:16px;height:${chartHeight}px;padding-top:16px;border-bottom:1px solid var(--border)">
      ${groups
        .map(group => {
          return `
        <div style="flex:1;min-width:0;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;gap:6px;height:100%">
          <div style="display:flex;align-items:flex-end;gap:5px;width:100%;height:100%;justify-content:center">
            ${group.bars
              .map(bar => {
                const barHeight = Math.max(
                  8,
                  Math.round(((bar.value || 0) / max) * Math.max(chartHeight - 52, 40))
                );
                return `
              <div style="flex:1;max-width:26px;display:flex;flex-direction:column;align-items:center;height:100%;justify-content:flex-end;gap:4px">
                <div style="font-size:10px;font-weight:700;color:var(--text3)">${bar.value}</div>
                <div style="width:100%;height:${barHeight}px;flex-shrink:0;border-radius:6px 6px 2px 2px;background:linear-gradient(180deg,var(--green),#15803d);box-shadow:0 8px 16px rgba(15,23,42,.12)" title="${
                  bar.label || ''
                }: ${bar.value}"></div>
              </div>`;
              })
              .join('')}
          </div>
          <div style="font-size:11px;font-weight:600;color:var(--text2);text-align:center;line-height:1.2;margin-top:4px">${
            group.label
          }</div>
        </div>`;
        })
        .join('')}
    </div>
  </div>`;
}
function buildAnalyticsBars(items, height) {
  const max = Math.max(1, ...items.map(item => item.value || 0));
  const chartHeight = height || 180;
  return `
  <div style="display:flex;align-items:flex-end;gap:14px;height:${chartHeight}px;padding-top:12px">
    ${items
      .map(item => {
        const barHeight = Math.max(
          8,
          Math.round(((item.value || 0) / max) * Math.max(chartHeight - 52, 40))
        );
        return `
      <div style="flex:1;min-width:0;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;gap:8px">
        <div style="font-size:11px;color:var(--text3)">${item.value}</div>
        <div style="width:100%;max-width:58px;height:${barHeight}px;flex-shrink:0;border-radius:18px 18px 8px 8px;background:linear-gradient(180deg,var(--green),#15803d);box-shadow:0 16px 28px rgba(15,23,42,.18)"></div>
        <div style="font-size:11px;color:var(--text2);text-align:center;line-height:1.35">${item.label}</div>
      </div>`;
      })
      .join('')}
  </div>`;
}
function buildAnalyticsProgress(items) {
  const total = items.reduce((sum, item) => sum + (item.value || 0), 0) || 1;
  return `<div style="display:flex;flex-direction:column;gap:14px">
    ${items
      .map(item => {
        const pct = Math.round(((item.value || 0) / total) * 100);
        return `<div>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
        <span style="font-size:12px;color:var(--text2)">${item.label}</span>
        <span style="font-size:12px;color:var(--text)">${item.value} · ${pct}%</span>
      </div>
      <div style="height:10px;border-radius:999px;background:var(--surface3);overflow:hidden">
        <div style="width:${pct}%;height:100%;border-radius:999px;background:${item.color}"></div>
      </div>
    </div>`;
      })
      .join('')}
  </div>`;
}
function initApp() {
  const r = CU.role;
  const navRole = isDepartmentEmployee() ? 'employee' : r;
  const displayRole = isDepartmentEmployee()
    ? EMPLOYEE_TYPE_LABELS[CU.employeeType]
    : ROLE_LABELS[r] || r;
  g('sb-name').textContent = isDepartmentEmployee() ? displayRole : CU.name;
  g('sb-role-lbl').textContent = isDepartmentEmployee() ? 'Employee workspace' : displayRole;
  if (CU.avatarImage) {
    globalThis.window?.EventFlowClientPages?.clear(g('sb-av'));
    g('sb-av').innerHTML = `<img src="${CU.avatarImage}" alt="${
      CU.name
    }" style="width:100%;height:100%;object-fit:cover;border-radius:50%" onerror="this.parentElement.textContent='${
      CU.avatar || CU.name.charAt(0)
    }'">`;
  } else {
    g('sb-av').textContent = CU.avatar || CU.name.charAt(0);
  }
  updateNotifDot();
  buildNav(navRole);
  if (isDepartmentEmployee()) buildEmployeeNav(CU.employeeType);
  goNav('dashboard');
}
function buildEmployeeNav(employeeType) {
  const nav =
    {
      REGISTRATION_VERIFICATION: [
        {
          ic: '📊',
          lbl: 'Dashboard',
          pg: 'dashboard',
        },
        {
          ic: '📝',
          lbl: 'Registrations',
          pg: 'registrations',
        },
        {
          ic: '👥',
          lbl: 'User Management',
          pg: 'attendees',
        },
        {
          ic: '📄',
          lbl: 'Reports',
          pg: 'reports',
        },
      ],
      EVENT_OPERATIONS: [
        {
          ic: '📊',
          lbl: 'Dashboard',
          pg: 'dashboard',
        },
        {
          ic: '📅',
          lbl: 'Events',
          pg: 'events',
        },
        {
          ic: '⚙️',
          lbl: 'Event Operations',
          pg: 'event-requests',
        },
        {
          ic: '📄',
          lbl: 'Reports',
          pg: 'reports',
        },
      ],
      SUPPORT_FINANCE: [
        {
          ic: '📊',
          lbl: 'Dashboard',
          pg: 'dashboard',
        },
        {
          ic: '📩',
          lbl: 'Support Center',
          pg: 'support-center',
        },
        {
          ic: '💳',
          lbl: 'Finance',
          pg: 'finance',
        },
        {
          ic: '📋',
          lbl: 'Reports',
          pg: 'reports',
        },
      ],
    }[employeeType] || [];
  const unread = visibleNotifications().filter(n => !n.read).length;
  globalThis.window?.EventFlowClientPages?.clear(g('sb-nav'));
  g('sb-nav').innerHTML =
    `<div class="sb-section-lbl">Menu</div>` +
    nav
      .map(
        i =>
          `<div class="sb-item" data-pg="${i.pg}" onclick="goNav('${i.pg}')"><span class="ic">${
            i.ic
          }</span><span>${i.lbl}</span>${
            i.badge && unread > 0 ? '<span class="badge-dot"></span>' : ''
          }</div>`
      )
      .join('');
}
function sendContactMessage() {
  const name = document.getElementById('contact-name').value.trim();
  const email = document.getElementById('contact-email').value.trim();
  const message = document.getElementById('contact-message').value.trim();
  if (!name) {
    toast('Please enter your name', 'error');
    return;
  }
  if (!email) {
    toast('Please enter your email', 'error');
    return;
  }

  // Email validation regex - checks for valid email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    toast('Please enter a valid email address', 'error');
    return;
  }
  if (!message) {
    toast('Please enter a message', 'error');
    return;
  }

  // If all validations pass, show success and clear form
  toast('Thank you! We will be in touch soon.', 'success');
  document.getElementById('contact-name').value = '';
  document.getElementById('contact-email').value = '';
  document.getElementById('contact-message').value = '';
}
function buildNav(role) {
  const items = NAV[role] || [];
  const unread = DB.notifications.filter(notification => !notification.read).length;
  globalThis.window?.EventFlowClientPages?.clear(g('sb-nav'));
  g('sb-nav').innerHTML =
    `<div class="sb-section-lbl">Menu</div>` +
    items
      .map(
        i => `<div class="sb-item" data-pg="${i.pg}" onclick="goNav('${i.pg}')">
      <span class="ic">${i.ic}</span>
      <span>${i.lbl}</span>
      ${i.badge && unread > 0 ? `<span class="badge-dot"></span>` : ''}
    </div>`
      )
      .join('');
}
function updateNotifDot() {
  const unread = visibleNotifications().filter(n => !n.read).length;
  const dot = g('notif-count-dot');
  if (dot) dot.style.display = unread > 0 ? 'block' : 'none';
}
const PAGE_TITLES = {
  'user-reports': 'User Reports & Analytics',
  'event-reports': 'Event Reports & Analytics',
  'revenue-reports': 'Revenue Reports & Analytics',
  dashboard: 'Dashboard',
  users: 'User Statistics',
  events: 'Events',
  'browse-events': 'Browse Events',
  'my-tickets': 'My Tickets',
  attendees: 'Attendee Management',
  reports: 'Reports & Analytics',
  notifications: 'Notifications',
  attendeeVerification: 'Attendee Verification',
  'employee-stats': 'Employee Statistics',
  registrations: 'Registrations',
  'find-organizers': 'Find Event Organisers',
  'upcoming-events': 'Upcoming Events',
  'completed-events': 'Completed Events',
  'ongoing-events': 'Ongoing Events',
  'my-events': 'Events',
  settings: 'Account Settings',
  'pending-plans': 'Pending Plans',
  'request-status': 'Request Status',
  'new-request': 'New Event Request',
  profile: 'My Profile',
  'event-requests': 'Event Requests',
  'support-center': 'Support Center',
  finance: 'Finance',
};
function updateHeaderUser() {
  if (!CU) return;
  const displayRole = isDepartmentEmployee()
    ? EMPLOYEE_TYPE_LABELS[CU.employeeType]
    : ROLE_LABELS[CU.role] || CU.role || 'User';
  const header = g('topbar-title');
  if (!header) return;
  header.textContent = CU.name ? `${CU.name} · ${displayRole}` : displayRole;
  header.title = header.textContent;
}
function workflowEventsPage(pg) {
  if (
    ['client', 'organizer'].includes(CU.role) &&
    ['upcoming-events', 'ongoing-events', 'completed-events'].includes(pg)
  ) {
    if (pg === 'upcoming-events') _workflowEventTab = 'upcoming';
    else if (pg === 'completed-events') _workflowEventTab = 'completed';
    else _workflowEventTab = 'ongoing';
    return 'my-events';
  }
  return pg;
}
function goNav(pg) {
  pg = workflowEventsPage(pg);
  _currentPage = pg;
  // Keep event-request tabs associated with their parent sidebar section.
  const sidebarPage =
    pg === 'request-details'
      ? _workflowReturnPage === 'my-events'
        ? 'my-events'
        : 'request-status'
      : pg;
  document
    .querySelectorAll('.sb-item')
    .forEach(element => element.classList.toggle('active', element.dataset.pg === sidebarPage));
  updateHeaderUser();
  // Read the latest shared data without writing it back. Writing during
  // navigation broadcasts a storage event and forces other open tabs to
  // rebuild their current page.
  loadDB(false);
  // renderPage may be async for pages that fetch backend data
  renderPage(pg).catch(err => console.error('Render error', err));
}

// ════════════════════════════════════════════════
//  PAGE ROUTER
// ════════════════════════════════════════════════
async function renderPage(pg) {
  const previousPage = _currentPage;
  const active = document.activeElement;
  const searchInput =
    active instanceof HTMLInputElement &&
    active.id &&
    active.hasAttribute('oninput') &&
    /search/i.test(`${active.id} ${active.placeholder}`)
      ? active
      : null;
  const restoreSearchInput = () => {
    if (searchInput && previousPage === pg && !searchInput.isConnected) {
      const replacement = g(searchInput.id);
      if (replacement) {
        replacement.replaceWith(searchInput);
        searchInput.focus({
          preventScroll: true,
        });
      }
    }
  };
  const render = renderPageContent(pg);
  restoreSearchInput();
  return render.finally(restoreSearchInput);
}
async function renderPageContent(pg) {
  pg = workflowEventsPage(pg);
  _currentPage = pg;
  const element = g('page-content');
  const r = CU.role;
  if (pg === 'customer-support') {
    if (!window.EventFlowSupport.canRequestSupport(CU)) return renderPageContent('settings');
    globalThis.window?.EventFlowClientPages?.clear(element);
    element.innerHTML = await window.EventFlowSupport.render(CU);
    window.EventFlowSupport.bind(element, CU, () => goNav('settings'));
    return;
  }
  if (isDepartmentEmployee()) {
    const allowed =
      {
        REGISTRATION_VERIFICATION: [
          'dashboard',
          'registrations',
          'attendees',
          'attendeeVerification',
          'reports',
          'profile',
          'settings',
          'notifications',
        ],
        EVENT_OPERATIONS: [
          'dashboard',
          'events',
          'event-requests',
          'event-requests',
          'reports',
          'profile',
          'settings',
          'notifications',
        ],
        SUPPORT_FINANCE: [
          'dashboard',
          'support-center',
          'finance',
          'reports',
          'profile',
          'settings',
          'notifications',
        ],
      }[CU.employeeType] || [];
    if (!allowed.includes(pg)) {
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML = `<div class="empty"><div class="empty-title">Access restricted</div><p class="empty-desc">This department does not have access to this area.</p></div>`;
      return;
    }
  }

  // Restrict superuser to only the 3 analytical subpages
  if (r === 'superuser') {
    if (pg === 'dashboard') {
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML = dashAdmin();
      return;
    } else if (pg === 'event-reports' || pg === 'events') {
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML = pageEventReports();
      return;
    } else if (pg === 'revenue-reports' || pg === 'reports' || pg === 'employee-stats') {
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML = pageRevenueReports();
      return;
    } else {
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML = pageUserReports();
      return;
    }
  }
  if (pg === 'find-organizers' && CU.role === 'client') {
    try {
      await syncOrganizerDirectory();
    } catch (error) {
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML = `<div class="empty"><div class="empty-title">Organizer directory unavailable</div><p class="empty-desc">${error.message}</p><button class="btn btn-primary mt-16" onclick="renderPage('${pg}')">Try again</button></div>`;
      return;
    }
  }
  if (
    [
      'dashboard',
      'request-status',
      'request-details',
      'event-requests',
      'my-events',
      'ongoing-events',
      'completed-events',
      'reports',
      'notifications',
    ].includes(pg) &&
    ['client', 'organizer'].includes(CU.role)
  ) {
    try {
      await syncWorkflowData();
    } catch (error) {
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML = `<div class="empty"><div class="empty-title">Workflow data unavailable</div><p class="empty-desc">${error.message}</p><button class="btn btn-primary mt-16" onclick="renderPage('${pg}')">Try again</button></div>`;
      return;
    }
  }
  switch (pg) {
    case 'dashboard':
      if (r === 'client' && globalThis.window?.EventFlowClientPages?.hasPage('dashboard')) {
        window.EventFlowClientPages.render(
          element,
          'dashboard',
          window.EventFlowClientRuntime.snapshot()
        );
        break;
      }
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML = isDepartmentEmployee()
        ? dashDepartmentEmployee()
        : (
            {
              organizer: dashOrganizer,
              client: dashClient,
              attendee: dashAttendee,
            }[r] || dashAttendee
          )();
      if (r === 'client') {
        loadClientUpcomingEvents();
        loadClientRecentActivity();
      }
      break;
    case 'registrations':
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML = pageRegistrationsForEmployee();
      break;
    case 'events':
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML =
        isDepartmentEmployee() && CU.employeeType === 'EVENT_OPERATIONS'
          ? pageEventOpsEvents()
          : pageEvents();
      break;
    case 'event-requests':
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML =
        isDepartmentEmployee() && CU.employeeType === 'EVENT_OPERATIONS'
          ? pageEventOperationsWorkspace()
          : pageEventRequests();
      break;
    case 'support-center':
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML =
        isDepartmentEmployee() && CU.employeeType === 'SUPPORT_FINANCE'
          ? pageSupportCenter()
          : pageEventRequests();
      break;
    case 'finance':
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML =
        isDepartmentEmployee() && CU.employeeType === 'SUPPORT_FINANCE'
          ? pageFinanceCenter()
          : pageRevenueReports();
      break;
    case 'request-status':
      if (r === 'client') {
        try {
          await syncClientEventRequests();
        } catch (error) {
          console.error('Unable to refresh client event requests', error);
        }
      }
      if (globalThis.window?.EventFlowClientPages?.hasPage('request-status')) {
        window.EventFlowClientPages.render(
          element,
          'request-status',
          window.EventFlowClientRuntime.snapshot({})
        );
      } else {
        globalThis.window?.EventFlowClientPages?.clear(element);
        globalThis.window?.EventFlowClientPages?.clear(element);
        element.innerHTML = pageRequestStatus();
      }
      break;
    case 'request-details':
      renderWorkflowRequestDetails(_workflowRequestId);
      break;
    case 'attendees':
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML =
        isDepartmentEmployee() && CU.employeeType === 'REGISTRATION_VERIFICATION'
          ? pageUserManagement()
          : pageAttendees();
      break;
    case 'attendeeVerification':
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML = pageAttendeeVerification();
      break;
    case 'reports':
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML =
        isDepartmentEmployee() && CU.employeeType === 'REGISTRATION_VERIFICATION'
          ? pageRegVerificationReports()
          : isDepartmentEmployee() && CU.employeeType === 'EVENT_OPERATIONS'
          ? pageEventOpsReports()
          : isDepartmentEmployee() && CU.employeeType === 'SUPPORT_FINANCE'
          ? pageOperationalReports()
          : pageReports();
      break;
    case 'browse-events':
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML = pageBrowseEvents();
      break;
    case 'my-tickets':
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML = pageMyTickets();
      break;
    case 'find-organizers':
      if (globalThis.window?.EventFlowClientPages?.hasPage('find-organizers')) {
        window.EventFlowClientPages.render(
          element,
          'find-organizers',
          window.EventFlowClientRuntime.snapshot({})
        );
      } else {
        globalThis.window?.EventFlowClientPages?.clear(element);
        globalThis.window?.EventFlowClientPages?.clear(element);
        element.innerHTML = pageFindOrganizers();
      }
      break;
    case 'upcoming-events':
      if (globalThis.window?.EventFlowClientPages?.hasPage('upcoming-events')) {
        window.EventFlowClientPages.render(
          element,
          'upcoming-events',
          window.EventFlowClientRuntime.snapshot({})
        );
      } else {
        globalThis.window?.EventFlowClientPages?.clear(element);
        globalThis.window?.EventFlowClientPages?.clear(element);
        element.innerHTML = pageUpcomingEvents();
      }
      break;
    case 'my-events':
      if (globalThis.window?.EventFlowClientPages?.hasPage('my-events')) {
        window.EventFlowClientPages.render(
          element,
          'my-events',
          window.EventFlowClientRuntime.snapshot({})
        );
      } else {
        globalThis.window?.EventFlowClientPages?.clear(element);
        globalThis.window?.EventFlowClientPages?.clear(element);
        element.innerHTML = pageWorkflowEvents();
      }
      break;
    case 'completed-events':
      if (globalThis.window?.EventFlowClientPages?.hasPage('completed-events')) {
        window.EventFlowClientPages.render(
          element,
          'completed-events',
          window.EventFlowClientRuntime.snapshot({
            embedded: undefined,
          })
        );
      } else {
        globalThis.window?.EventFlowClientPages?.clear(element);
        globalThis.window?.EventFlowClientPages?.clear(element);
        element.innerHTML = pageCompletedEvents();
      }
      break;
    case 'ongoing-events':
      if (globalThis.window?.EventFlowClientPages?.hasPage('ongoing-events')) {
        window.EventFlowClientPages.render(
          element,
          'ongoing-events',
          window.EventFlowClientRuntime.snapshot({
            embedded: undefined,
          })
        );
      } else {
        globalThis.window?.EventFlowClientPages?.clear(element);
        globalThis.window?.EventFlowClientPages?.clear(element);
        element.innerHTML = pageOngoingEvents();
      }
      break;
    case 'notifications':
      if (globalThis.window?.EventFlowClientPages?.hasPage('notifications')) {
        window.EventFlowClientPages.render(
          element,
          'notifications',
          window.EventFlowClientRuntime.snapshot({})
        );
      } else {
        globalThis.window?.EventFlowClientPages?.clear(element);
        globalThis.window?.EventFlowClientPages?.clear(element);
        element.innerHTML = pageNotifications();
      }
      break;
    case 'profile':
      if (globalThis.window?.EventFlowClientPages?.hasPage('profile')) {
        window.EventFlowClientPages.render(
          element,
          'profile',
          window.EventFlowClientRuntime.snapshot({})
        );
      } else {
        globalThis.window?.EventFlowClientPages?.clear(element);
        globalThis.window?.EventFlowClientPages?.clear(element);
        element.innerHTML = pageProfile();
      }
      break;
    case 'settings':
      if (globalThis.window?.EventFlowClientPages?.hasPage('settings')) {
        window.EventFlowClientPages.render(
          element,
          'settings',
          window.EventFlowClientRuntime.snapshot({})
        );
      } else {
        globalThis.window?.EventFlowClientPages?.clear(element);
        globalThis.window?.EventFlowClientPages?.clear(element);
        element.innerHTML = pageSettings();
      }
      window.EventFlowSupport.addSettingsEntry(element, () => goNav('customer-support'), CU);
      break;
    case 'users':
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML = pageUsers();
      break;
    default:
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML = `<div class="empty"><div class="empty-icon">🚧</div><div class="empty-title">Page not found</div><p class="empty-desc">The requested page "${pg}" could not be loaded.</p></div>`;
  }
}

// ════════════════════════════════════════════════
//  DASHBOARDS
// ════════════════════════════════════════════════
function dashAdmin() {
  const totalUsers = DB.users.length;
  const totalEvents = DB.events.length;
  const totalRegs = DB.registrations.length;
  const revenue = (DB.financeTransactions || [])
    .filter(payment => payment.status === 'Successful')
    .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
  const pendingReqs = DB.eventRequests.filter(request =>
    [
      'pending',
      'submitted',
      'planning',
      'changes_requested',
      'counteroffered',
      'plan_submitted',
      'plan_revision_requested',
    ].includes(request.status)
  ).length;
  const roleCounts = {
    employee: DB.users.filter(user => user.role === 'employee').length,
    superuser: DB.users.filter(user => user.role === 'superuser').length,
    organizer: DB.users.filter(user => user.role === 'organizer').length,
    client: DB.users.filter(user => user.role === 'client').length,
    attendee: DB.users.filter(user => user.role === 'attendee').length,
  };
  const eventStatusCounts = {
    upcoming: DB.events.filter(event => event.status === 'upcoming' || event.status === 'published')
      .length,
    ongoing: DB.events.filter(event => event.status === 'ongoing').length,
    completed: DB.events.filter(event => event.status === 'completed').length,
    draft: DB.events.filter(event => event.status === 'draft').length,
  };
  const requestStatusCounts = {
    pending: DB.eventRequests.filter(request =>
      [
        'pending',
        'submitted',
        'planning',
        'changes_requested',
        'counteroffered',
        'plan_submitted',
        'plan_revision_requested',
      ].includes(request.status)
    ).length,
    approved: DB.eventRequests.filter(request =>
      ['approved', 'confirmed', 'completed'].includes(request.status)
    ).length,
    rejected: DB.eventRequests.filter(request => request.status === 'rejected').length,
  };

  // Fetch real analytics from backend asynchronously and update stat cards
  apiGetDashboard()
    .then(function (resp) {
      const d = resp && resp.data ? resp.data : resp;
      const patch = [
        ['adm-stat-users', d.users ? d.users.total : totalUsers],
        ['adm-stat-events', d.events ? d.events.total : totalEvents],
        ['adm-stat-regs', d.registrations ? d.registrations.total : totalRegs],
        [
          'adm-stat-rev',
          '₹' + ((d.payments ? d.payments.totalRevenue : revenue) / 1000).toFixed(1) + 'K',
        ],
      ];
      patch.forEach(([id, val]) => {
        const element = document.getElementById(id);
        if (element) element.textContent = val;
      });
      const pending = document.getElementById('adm-stat-pending');
      if (pending)
        pending.textContent =
          (d.eventRequests ? d.eventRequests.pending : pendingReqs) + ' req(s) pending';
    })
    .catch(function () {
      /* silently keep local stats */
    });
  return `
  <div class="page-hd">
    <div class="page-hd-left"><div class="page-title">System Overview</div><div class="page-sub">Welcome back, ${
      CU.name
    }. Here's the platform at a glance.</div></div>
    <div class="page-hd-right">
      <button class="btn btn-ghost" onclick="goNav('users')">User Statistics</button>
      <button class="btn btn-primary mt-4" style="margin-left: 8px;" onclick="goNav('employee-stats')">Employee Analytics</button>
    </div>
  </div>
  <div class="grid-4 mb-20">
    <div class="stat-card"><div class="glow" style="background:var(--accent)"></div><div class="stat-icon" style="background:var(--accent-dim);color:var(--accent)">👥</div><div class="stat-value" id="adm-stat-users" style="color:var(--accent)">${totalUsers}</div><div class="stat-label">Total Users</div><div class="stat-sub up">↑ 12% this month</div></div>
    <div class="stat-card"><div class="glow" style="background:var(--green)"></div><div class="stat-icon" style="background:var(--green-dim);color:var(--green)">🗓️</div><div class="stat-value" id="adm-stat-events" style="color:var(--green)">${totalEvents}</div><div class="stat-label">Total Events</div><div class="stat-sub up">↑ 3 new this week</div></div>
    <div class="stat-card"><div class="glow" style="background:var(--yellow)"></div><div class="stat-icon" style="background:var(--yellow-dim);color:var(--yellow)">🎟️</div><div class="stat-value" id="adm-stat-regs" style="color:var(--yellow)">${totalRegs}</div><div class="stat-label">Registrations</div><div class="stat-sub up">↑ 8% this week</div></div>
    <div class="stat-card"><div class="glow" style="background:var(--orange)"></div><div class="stat-icon" style="background:var(--orange-dim);color:var(--orange)">💰</div><div class="stat-value" id="adm-stat-rev" style="color:var(--orange)">₹${(
      revenue / 1000
    ).toFixed(
      1
    )}K</div><div class="stat-label">Total Revenue</div><div class="stat-sub neutral" id="adm-stat-pending">${pendingReqs} req(s) pending</div></div>
  </div>
  <div class="grid-2" style="gap:20px;align-items:start">
    <div class="card">
      <div class="flex justify-between items-center mb-16"><span class="h4">Platform Role Split</span><button class="btn btn-ghost btn-xs" onclick="goNav('users')">Open User Analytics</button></div>
      ${buildAnalyticsBars(
        [
          {
            label: 'Admins',
            value: roleCounts.superuser,
            color: 'linear-gradient(180deg, #ef4444, #b91c1c)',
          },
          {
            label: 'Organizers',
            value: roleCounts.organizer,
            color: 'linear-gradient(180deg, #3b82f6, #1d4ed8)',
          },
          {
            label: 'Clients',
            value: roleCounts.client,
            color: 'linear-gradient(180deg, #f59e0b, #d97706)',
          },
          {
            label: 'Employees',
            value: roleCounts.employee,
            color: 'linear-gradient(180deg, #22c55e, #15803d)',
          },
          {
            label: 'Attendees',
            value: roleCounts.attendee,
            color: 'linear-gradient(180deg, #8b5cf6, #7c3aed)',
          },
        ],
        160
      )}
    </div>
    <div class="card" style="padding:16px">
      <div class="flex justify-between items-center mb-12"><span class="h4">Request Pipeline <span class="small" style="color:var(--text3);font-weight:500">(${
        requestStatusCounts.pending + requestStatusCounts.approved + requestStatusCounts.rejected
      } total)</span></span><button class="btn btn-ghost btn-xs" onclick="goNav('reports')">Open Reports</button></div>
      ${buildAnalyticsProgress([
        {
          label: 'Pending',
          value: requestStatusCounts.pending,
          color: 'linear-gradient(90deg, #f59e0b, #d97706)',
        },
        {
          label: 'Approved',
          value: requestStatusCounts.approved,
          color: 'linear-gradient(90deg, #22c55e, #15803d)',
        },
        {
          label: 'Rejected',
          value: requestStatusCounts.rejected,
          color: 'linear-gradient(90deg, #ef4444, #b91c1c)',
        },
      ])}
    </div>
  </div>
  <div class="grid-2 mt-20" style="gap:20px;align-items:start">

    <div class="card" style="padding:16px">
      <div class="h4 mb-12">Event Coverage</div>
      ${buildAnalyticsBars(
        [
          {
            label: 'Published',
            value: eventStatusCounts.upcoming,
            color: 'linear-gradient(180deg, #22c55e, #15803d)',
          },
          {
            label: 'Ongoing',
            value: eventStatusCounts.ongoing,
            color: 'linear-gradient(180deg, #3b82f6, #1d4ed8)',
          },
          {
            label: 'Completed',
            value: eventStatusCounts.completed,
            color: 'linear-gradient(180deg, #8b5cf6, #7c3aed)',
          },
          {
            label: 'Draft',
            value: eventStatusCounts.draft,
            color: 'linear-gradient(180deg, #64748b, #475569)',
          },
        ],
        160
      )}
    </div>
  </div>`;
}
function dashEmployee() {
  const changesQuery = (sessionStorage.getItem('employee_changes_search') || '').toLowerCase();
  const changes = DB.notifications
    .filter(item => {
      const text = `${item.title || ''} ${item.msg || ''} ${item.time || ''}`.toLowerCase();
      return !changesQuery || text.includes(changesQuery);
    })
    .slice(0, 12);
  const requests = (DB.employeeChangeRequests || []).filter(
    request => request.status === 'pending'
  );
  return `
  <div class="page-hd">
    <div class="page-hd-left"><div class="page-title">Employee Dashboard</div><div class="page-sub">Track recent changes and review requests from users.</div></div>
  </div>
  <div class="grid-3 mb-20">
    <div class="stat-card"><div class="stat-icon" style="background:var(--accent-dim);color:var(--accent)">🔄</div><div class="stat-value" style="color:var(--accent)">${
      changes.length
    }</div><div class="stat-label">Recent Changes</div><div class="stat-sub neutral">Matching activity</div></div>
    <div class="stat-card"><div class="stat-icon" style="background:var(--yellow-dim);color:var(--yellow)">📩</div><div class="stat-value" style="color:var(--yellow)">${
      requests.length
    }</div><div class="stat-label">Change Requests</div><div class="stat-sub neutral">Awaiting review</div></div>
    <div class="stat-card"><div class="stat-icon" style="background:var(--green-dim);color:var(--green)">👥</div><div class="stat-value" style="color:var(--green)">${
      DB.users.filter(user => user.role !== 'superuser').length
    }</div><div class="stat-label">Managed Users</div><div class="stat-sub neutral">Account records</div></div>
  </div>
  <div class="grid-2" style="gap:20px;align-items:start">
    <div>
      <div class="h4 mb-12">Recent Changes</div>
      <div class="search-box input-group" style="margin-bottom:14px"><span class="input-icon">🔍</span><input class="form-control" id="employee-changes-search" placeholder="Search recent changes…" value="${changesQuery}" oninput="searchEmployeeChanges(this.value)"></div>
      <div id="employee-recent-changes" style="display:flex;flex-direction:column;gap:10px;max-height:520px;overflow-y:auto;padding-right:6px">${buildEmployeeChanges(
        changes
      )}</div>
    </div>
    <div>
      <div class="h4 mb-12">Requests To Change Details</div>
      <div style="display:flex;flex-direction:column;gap:12px">
        ${
          requests.length === 0
            ? `<div class="empty"><div class="empty-icon">✓</div><div class="empty-title">No pending requests</div><p class="empty-desc">Requests to change event or user details will appear here.</p></div>`
            : requests
                .map(
                  request => `<div class="card" style="border-left:3px solid var(--yellow)">
          <div class="flex justify-between items-start gap-8"><div><div style="font-weight:700;color:var(--text)">${
            request.type === 'event' ? '📅 Event Details' : '👤 User Details'
          }</div><div class="small" style="margin-top:4px">${
                    request.targetName
                  }</div></div><span class="badge badge-yellow">Pending</span></div>
          <div style="font-size:13px;color:var(--text2);line-height:1.6;margin:12px 0">${
            request.requestedChange
          }</div>
          <div class="small" style="color:var(--text3);margin-bottom:12px">Requested by ${
            request.requester
          } · ${request.submittedAt}</div>
          <button class="btn btn-success btn-sm" onclick="completeEmployeeChangeRequest('${
            request.id
          }')">✓ Mark Done</button>
        </div>`
                )
                .join('')
        }
      </div>
    </div>
  </div>`;
}
function dashDepartmentEmployee() {
  const type = CU.employeeType;
  if (type === 'SUPPORT_FINANCE') return dashSupportFinance();
  if (type === 'EVENT_OPERATIONS') return dashEventOperations();
  if (type === 'REGISTRATION_VERIFICATION') return dashRegistrationVerification();
  return `<div class="page-hd"><div class="page-hd-left"><div class="page-title">Employee Dashboard</div></div></div>`;
}

// ════════════════════════════════════════════════
//  EMPLOYEE 1: REGISTRATION & VERIFICATION EXECUTIVE
// ════════════════════════════════════════════════

function dashRegistrationVerification() {
  const regs = DB.registrations || [];
  const users = DB.users || [];
  const userQueries = DB.userQueries || [];
  const totalRegs = regs.length;
  const pendingRegs = regs.filter(
    registration =>
      registration.status === 'pending' ||
      registration.verificationStatus === 'Pending Review' ||
      registration.verificationStatus === 'Pending' ||
      !registration.verified
  ).length;
  const confirmedRegs = regs.filter(
    registration =>
      registration.status === 'confirmed' || registration.verificationStatus === 'Verified'
  ).length;
  const registeredUsers = users.filter(user => user.role !== 'superuser').length;
  return `
        <div class="page-hd">
          <div class="page-hd-left">
            <div class="page-title">Registration &amp; User Management Dashboard</div>
            <div class="page-sub">Online attendee registration, user account management, and support request tracking for ${
              CU.name
            }.</div>
          </div>
        </div>

        <div class="grid-4 mb-20">
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--accent-dim);color:var(--accent)">📝</div>
            <div class="stat-value" style="color:var(--accent)">${totalRegs}</div>
            <div class="stat-label">Total Registrations</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--yellow-dim);color:var(--yellow)">⏳</div>
            <div class="stat-value" style="color:var(--yellow)">${pendingRegs}</div>
            <div class="stat-label">Pending Registrations</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--green-dim);color:var(--green)">✅</div>
            <div class="stat-value" style="color:var(--green)">${confirmedRegs}</div>
            <div class="stat-label">Confirmed Registrations</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--blue-dim);color:var(--blue)">👥</div>
            <div class="stat-value" style="color:var(--blue)">${registeredUsers}</div>
            <div class="stat-label">Registered Users</div>
          </div>
        </div>

        <div class="grid-2 gap-20">
          <div class="card">
            <div class="flex justify-between items-center mb-14">
              <div class="h4">Recent Online Registrations</div>
              <button class="btn btn-ghost btn-xs" onclick="goNav('registrations')">View All →</button>
            </div>
            <div style="display:flex;flex-direction:column;gap:10px">
              ${
                regs
                  .slice(0, 5)
                  .map(registration => {
                    const eventRegistration = users.find(
                      user => String(user.id) === String(registration.attendeeId)
                    ) || {
                      name: 'Attendee',
                    };
                    const e = DB.events.find(
                      event => String(event.id) === String(registration.eventId)
                    ) || {
                      title: 'Event',
                    };
                    const verifStatus =
                      registration.verificationStatus ||
                      (registration.status === 'confirmed' ? 'Verified' : 'Pending Review');
                    return `
                  <div style="padding:10px 12px;border:1px solid var(--border);border-radius:8px;background:var(--surface2)" class="flex justify-between items-center">
                    <div>
                      <div style="font-weight:700;font-size:13.5px;color:var(--text)">${
                        eventRegistration.name
                      }</div>
                      <div class="small muted">${e.title} · ${
                      registration.ticketId || registration.id
                    }</div>
                    </div>
                    <span class="badge badge-${
                      verifStatus === 'Verified'
                        ? 'green'
                        : verifStatus === 'Flagged'
                        ? 'yellow'
                        : 'purple'
                    }">${verifStatus}</span>
                  </div>
                `;
                  })
                  .join('') || '<div class="empty">No registrations found</div>'
              }
            </div>
          </div>

          <div class="card">
            <div class="flex justify-between items-center mb-14">
              <div class="h4">User Queries &amp; Support Escalations</div>
              <button class="btn btn-ghost btn-xs" onclick="openUserQueriesModal()">Manage Requests →</button>
            </div>
            <div style="display:flex;flex-direction:column;gap:10px">
              ${
                userQueries
                  .slice(0, 5)
                  .map(
                    q => `
                <div style="padding:10px 12px;border:1px solid var(--border);border-radius:8px;background:var(--surface2)" class="flex justify-between items-center gap-10">
                  <div class="flex items-center gap-10" style="flex:1;min-width:0">
                    <span style="font-size:18px">${
                      q.type === 'Account Deletion'
                        ? '🗑️'
                        : q.type === 'Email Change'
                        ? '✉️'
                        : q.type === 'Escalated Support'
                        ? '🎧'
                        : '👤'
                    }</span>
                    <div style="flex:1;min-width:0">
                      <div class="flex items-center gap-6 mb-2">
                        <span style="font-weight:700;font-size:13px;color:var(--text)" class="truncate">${
                          q.userName
                        }</span>
                        <span class="badge badge-${
                          q.type === 'Account Deletion'
                            ? 'red'
                            : q.type === 'Email Change'
                            ? 'blue'
                            : q.type === 'Escalated Support'
                            ? 'purple'
                            : 'gray'
                        }" style="font-size:10px;padding:1px 6px">${q.type}</span>
                      </div>
                      <div class="small muted truncate">${q.subject}</div>
                    </div>
                  </div>
                  <div class="flex items-center gap-8" style="flex-shrink:0">
                    <span class="badge badge-${
                      q.status === 'Resolved'
                        ? 'green'
                        : q.status === 'In Progress'
                        ? 'purple'
                        : 'yellow'
                    }">${q.status}</span>
                    <button class="btn btn-ghost btn-xs" onclick="openQueryActionModal('${
                      q.id
                    }')">Review</button>
                  </div>
                </div>
              `
                  )
                  .join('') || '<div class="empty">No user queries or support escalations</div>'
              }
            </div>
          </div>
        </div>
      `;
}
function openUserQueriesModal() {
  const userQueries = DB.userQueries || [];
  openModal(
    'Manage User Requests & Support Escalations',
    `
        <div class="small muted mb-14">Review user profile queries, account modification/deletion requests, and escalated tickets from Employee 3 (Customer Support).</div>
        <div style="display:flex;flex-direction:column;gap:12px;max-height:420px;overflow-y:auto;padding-right:4px">
          ${
            userQueries
              .map(
                q => `
            <div style="padding:12px 14px;border:1px solid var(--border);border-radius:10px;background:var(--surface2)">
              <div class="flex justify-between items-start mb-6">
                <div>
                  <div style="font-weight:700;font-size:14px;color:var(--text)">${
                    q.userName
                  } <span class="small muted">(${q.userEmail})</span></div>
                  <div class="small muted">Source: <strong>${q.source}</strong> · ${q.date}</div>
                </div>
                <span class="badge badge-${
                  q.status === 'Resolved'
                    ? 'green'
                    : q.status === 'In Progress'
                    ? 'purple'
                    : 'yellow'
                }">${q.status}</span>
              </div>
              <div style="font-size:13px;font-weight:600;color:var(--accent);margin-bottom:4px">🏷️ ${
                q.type
              }: ${q.subject}</div>
              <p style="font-size:12.5px;color:var(--text2);margin-bottom:10px;line-height:1.5">${
                q.detail
              }</p>
              <div class="flex justify-between items-center">
                <div class="small mono muted">ID: ${q.id}</div>
                <div class="flex gap-6">
                  ${
                    q.status !== 'Resolved'
                      ? `
                    <button class="btn btn-success btn-xs" onclick="closeModal();resolveQueryDirect('${q.id}')">✓ Mark Solved</button>
                    <button class="btn btn-danger btn-xs" onclick="closeModal();rejectQueryDirect('${q.id}')">✕ Reject</button>
                  `
                      : '<span class="small muted">Resolved</span>'
                  }
                </div>
              </div>
            </div>
          `
              )
              .join('') || '<div class="empty">No user queries found.</div>'
          }
        </div>
      `,
    []
  );
}
function openQueryActionModal(queryId) {
  const q = (DB.userQueries || []).find(item => item.id === queryId);
  if (!q) return;
  openModal(
    `Request ${q.id}: ${q.type}`,
    `
        <div class="info-row"><span class="info-label">User Name</span><span class="info-value"><strong>${
          q.userName
        }</strong></span></div>
        <div class="info-row"><span class="info-label">Email Address</span><span class="info-value">${
          q.userEmail
        }</span></div>
        <div class="info-row"><span class="info-label">Source</span><span class="info-value">${
          q.source
        }</span></div>
        <div class="info-row"><span class="info-label">Request Type</span><span class="info-value"><span class="badge badge-purple">${
          q.type
        }</span></span></div>
        <div class="info-row"><span class="info-label">Current Status</span><span class="info-value"><span class="badge badge-${
          q.status === 'Resolved' ? 'green' : 'yellow'
        }">${q.status}</span></span></div>
        <div class="info-row"><span class="info-label">Submitted On</span><span class="info-value">${
          q.date
        }</span></div>
        <div class="mt-14">
          <div class="label mb-6">Request Description / Escalation Notes</div>
          <p style="font-size:13.5px;color:var(--text2);line-height:1.6;background:var(--surface2);padding:12px;border-radius:8px;border:1px solid var(--border)">
            ${q.detail}
          </p>
        </div>
      `,
    q.status !== 'Resolved'
      ? [
          {
            lbl: 'Mark Solved / Resolve',
            cls: 'btn-success',
            fn: `closeModal();resolveQueryDirect('${q.id}')`,
          },
          {
            lbl: 'Reject Request',
            cls: 'btn-danger',
            fn: `closeModal();rejectQueryDirect('${q.id}')`,
          },
        ]
      : []
  );
}
function resolveQueryDirect(queryId) {
  const q = (DB.userQueries || []).find(item => item.id === queryId);
  if (!q) return;
  q.status = 'Resolved';
  saveDB();
  renderPage('dashboard');
  toast('User request marked as solved and resolved!', 'success');
}
function rejectQueryDirect(queryId) {
  confirm2('Reject Request', 'Are you sure you want to reject this request?', () => {
    const q = (DB.userQueries || []).find(item => item.id === queryId);
    if (!q) return;
    q.status = 'Rejected';
    saveDB();
    renderPage('dashboard');
    toast('User request rejected.', 'info');
  });
}

// ════════════════════════════════════════════════
//  EVENT OPERATIONS EXECUTIVE (EMPLOYEE 2)
// ════════════════════════════════════════════════

function dashEventOperations() {
  const events = DB.events || [];
  const tasks = DB.eventOperationsTasks || [];
  const reports = DB.eventOpsReports || [];
  const todayStr = new Date().toISOString().split('T')[0];
  const totalEvents = events.length;

  // Active events: published/active/ongoing/upcoming AND not cancelled/completed
  const activeEvents = events.filter(event => {
    const st = (event.status || '').toLowerCase();
    return ['published', 'active', 'ongoing', 'upcoming'].includes(st);
  }).length;

  // Pending events: pending or draft
  const pendingEvents = events.filter(event => {
    const st = (event.status || '').toLowerCase();
    return st === 'pending' || st === 'draft';
  }).length;

  // Upcoming events list: active/upcoming events sorted by date
  const upcomingEventsList = events.filter(event => {
    const st = (event.status || '').toLowerCase();
    return ['upcoming', 'published', 'active', 'ongoing'].includes(st);
  });

  // Realistic mix of activities
  const eventActivities = events.map(event => ({
    title: `Event Approved / Status: ${formatEventStatus(event.status)}`,
    detail: `${event.title || event.name} · Category: ${event.category || 'General'} · Date: ${
      event.date
    }`,
    icon: '🗓️',
    time: 'Recently',
  }));
  const taskActivities = tasks.map(task => ({
    title: `Operational Issue ${task.id}: ${task.type}`,
    detail: `${task.eventTitle} · Status: ${task.status} · Priority: ${task.priority}`,
    icon: '⚙️',
    time: task.updated,
  }));
  const reportActivities = reports.map(report => ({
    title: `Report Submitted: ${report.title}`,
    detail: `${report.type} · Status: ${report.status} · File: ${report.fileName || 'Report.pdf'}`,
    icon: '📄',
    time: report.updated,
  }));
  const recentActivity = [
    eventActivities[0],
    taskActivities[0],
    reportActivities[0],
    taskActivities[1],
    eventActivities[1],
  ].filter(Boolean);
  return `
        <div class="page-hd">
          <div class="page-hd-left">
            <div class="page-title">Event Operations Dashboard</div>
            <div class="page-sub">Operational overview and event management for ${CU.name}.</div>
          </div>
        </div>

        <div class="grid-4 mb-20">
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--accent-dim);color:var(--accent)">🗓️</div>
            <div class="stat-value" style="color:var(--accent)">${totalEvents}</div>
            <div class="stat-label">Total Events</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--green-dim);color:var(--green)">▶️</div>
            <div class="stat-value" style="color:var(--green)">${activeEvents}</div>
            <div class="stat-label">Active Events</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--yellow-dim);color:var(--yellow)">⏳</div>
            <div class="stat-value" style="color:var(--yellow)">${pendingEvents}</div>
            <div class="stat-label">Pending Events</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--blue-dim);color:var(--blue)">📅</div>
            <div class="stat-value" style="color:var(--blue)">${upcomingEventsList.length}</div>
            <div class="stat-label">Upcoming Events</div>
          </div>
        </div>

        <div class="grid-2 gap-20">
          <div class="card">
            <div class="flex justify-between items-center mb-14">
              <div class="h4">Upcoming Events (${upcomingEventsList.length})</div>
              <button class="btn btn-ghost btn-xs" onclick="goNav('events')">View All Events →</button>
            </div>
            <div style="display:flex;flex-direction:column;gap:12px;max-height:420px;overflow-y:auto;padding-right:4px">
              ${
                upcomingEventsList
                  .slice(0, 6)
                  .map(e => {
                    const isFull = (e.registered || 0) >= (e.capacity || 100);
                    return `
                  <div style="padding:12px;border:1px solid var(--border);border-radius:10px;background:var(--surface2)">
                    <div class="flex justify-between items-start mb-6">
                      <div style="font-weight:700;font-size:14px;color:var(--text)">${
                        e.title || e.name
                      }</div>
                      <span class="badge badge-${eventOpsStatusBadge(
                        e.status
                      )}">${formatEventStatus(e.status)}</span>
                    </div>
                    <div class="small muted mb-8">📍 ${e.venue || e.location || 'TBD'} (${
                      e.city || 'Main Hall'
                    }) · 📅 ${e.date} · 🏷️ ${e.category || 'General'}</div>
                    <div class="flex justify-between items-center">
                      <div class="small">Capacity: <strong>${e.registered || 0}/${
                      e.capacity || 100
                    }</strong> ${
                      isFull
                        ? '<span class="badge badge-yellow" style="font-size:10px;padding:2px 6px;margin-left:4px">Registration Full</span>'
                        : ''
                    }</div>
                      <button class="btn btn-ghost btn-xs" onclick="openViewEventDrawer('${
                        e.id
                      }')">View Details</button>
                    </div>
                  </div>
                `;
                  })
                  .join('') || '<div class="empty">No upcoming events found</div>'
              }
            </div>
          </div>

          <div class="card">
            <div class="h4 mb-14">Recent Event Activity</div>
            <div style="display:flex;flex-direction:column;gap:10px">
              ${
                recentActivity
                  .map(
                    act => `
                <div class="flex items-center gap-10" style="padding:10px 0;border-bottom:1px solid var(--border)">
                  <span style="font-size:20px">${act.icon}</span>
                  <div style="flex:1">
                    <div style="font-weight:600;font-size:13px">${act.title}</div>
                    <div class="small muted">${act.detail}</div>
                  </div>
                  <span class="small muted" style="white-space:nowrap">${act.time}</span>
                </div>
              `
                  )
                  .join('') || '<div class="empty">No recent activity</div>'
              }
            </div>
          </div>
        </div>
      `;
}
function pageEventOpsEvents() {
  const query = (sessionStorage.getItem('eventops_events_query') || '').toLowerCase();
  const statusFilter = sessionStorage.getItem('eventops_events_status') || '';
  const categoryFilter = sessionStorage.getItem('eventops_events_category') || '';
  const events = DB.events || [];
  const filtered = events.filter(event => {
    const title = (event.title || event.name || '').toLowerCase();
    const venue = (event.venue || event.location || '').toLowerCase();
    const city = (event.city || '').toLowerCase();
    const cat = (event.category || '').toLowerCase();
    const matchesQuery =
      !query ||
      title.includes(query) ||
      venue.includes(query) ||
      city.includes(query) ||
      cat.includes(query);
    let st = formatEventStatus(event.status).toLowerCase();
    let normFilter = statusFilter.toLowerCase();
    let matchesStatus = !normFilter || st === normFilter;
    const matchesCat = !categoryFilter || event.category === categoryFilter;
    return matchesQuery && matchesStatus && matchesCat;
  });
  return `
        <div class="page-hd">
          <div class="page-hd-left">
            <div class="page-title">Events Management</div>
            <div class="page-sub">Review pending events, edit details, and update operational statuses.</div>
          </div>
        </div>

        <div class="filter-row">
          <div class="search-box input-group">
            <span class="input-icon">🔍</span>
            <input class="form-control" id="eventops-q" placeholder="Search events by title, venue, city..." value="${query}" oninput="refreshEventOpsEvents()">
          </div>
          <select class="form-control filter-select" id="eventops-st" onchange="refreshEventOpsEvents()">
            <option value="">All Statuses</option>
            <option value="Pending" ${statusFilter === 'Pending' ? 'selected' : ''}>Pending</option>
            <option value="Active" ${statusFilter === 'Active' ? 'selected' : ''}>Active</option>
            <option value="Completed" ${
              statusFilter === 'Completed' ? 'selected' : ''
            }>Completed</option>
            <option value="Cancelled" ${
              statusFilter === 'Cancelled' ? 'selected' : ''
            }>Cancelled</option>
          </select>
          <select class="form-control filter-select" id="eventops-cat" onchange="refreshEventOpsEvents()">
            <option value="">All Categories</option>
            <option value="Technology" ${
              categoryFilter === 'Technology' ? 'selected' : ''
            }>Technology</option>
            <option value="Conference" ${
              categoryFilter === 'Conference' ? 'selected' : ''
            }>Conference</option>
            <option value="Corporate" ${
              categoryFilter === 'Corporate' ? 'selected' : ''
            }>Corporate</option>
            <option value="Finance" ${
              categoryFilter === 'Finance' ? 'selected' : ''
            }>Finance</option>
            <option value="Workshop" ${
              categoryFilter === 'Workshop' ? 'selected' : ''
            }>Workshop</option>
          </select>
        </div>

        <div class="card">
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Event</th>
                  <th>Category</th>
                  <th>Date &amp; Venue</th>
                  <th>Capacity</th>
                  <th>Status</th>
                  <th>Change Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${
                  filtered
                    .map(e => {
                      const currentStatus = formatEventStatus(e.status);
                      const isPending = currentStatus === 'Pending';
                      const isFull = (e.registered || 0) >= (e.capacity || 100);
                      return `
                    <tr>
                      <td>
                        <div style="font-weight:700;font-size:14px;color:var(--text)">${
                          e.title || e.name
                        }</div>
                        <div class="small muted">ID: ${e.id}</div>
                      </td>
                      <td><span class="badge badge-purple">${e.category || 'General'}</span></td>
                      <td>
                        <div>📅 ${e.date || 'TBD'}</div>
                        <div class="small muted">📍 ${e.venue || e.location || 'TBD'} (${
                        e.city || 'India'
                      })</div>
                      </td>
                      <td>
                        <div><strong>${e.registered || 0}</strong> / ${e.capacity || 100}</div>
                        <div class="small muted">${
                          isFull
                            ? '<span style="color:var(--yellow);font-weight:600">Registration Full</span>'
                            : e.price
                            ? '₹' + e.price
                            : 'Free'
                        }</div>
                      </td>
                      <td>
                        <span class="badge badge-${eventOpsStatusBadge(
                          e.status
                        )}">${currentStatus}</span>
                      </td>
                      <td>
                        <select class="form-control form-control-sm" style="padding:4px 8px;font-size:12px" onchange="setEventOpsStatus('${
                          e.id
                        }', this.value)">
                          <option value="Pending" ${
                            currentStatus === 'Pending' ? 'selected' : ''
                          }>Pending</option>
                          <option value="Active" ${
                            currentStatus === 'Active' ? 'selected' : ''
                          }>Active</option>
                          <option value="Completed" ${
                            currentStatus === 'Completed' ? 'selected' : ''
                          }>Completed</option>
                          <option value="Cancelled" ${
                            currentStatus === 'Cancelled' ? 'selected' : ''
                          }>Cancelled</option>
                        </select>
                      </td>
                      <td>
                        <div class="flex items-center gap-6">
                          <button class="btn btn-ghost btn-xs" onclick="openViewEventDrawer('${
                            e.id
                          }')" title="View Details">👁️</button>
                          ${
                            !isBookedClientEvent(e)
                              ? `<button class="btn btn-ghost btn-xs" onclick="openEditEventModal('${e.id}')" title="Edit Event">✏️</button>`
                              : ''
                          }
                          <button class="btn btn-xs btn-danger" onclick="deleteEventOps('${
                            e.id
                          }')" title="Delete Event">🗑️</button>
                          ${
                            isPending
                              ? `
                            <button class="btn btn-success btn-xs" onclick="approveEventOpsDirect('${e.id}')" title="Approve Event">✓</button>
                            <button class="btn btn-danger btn-xs" onclick="rejectEventOpsDirect('${e.id}')" title="Reject Event">✕</button>
                          `
                              : ''
                          }
                        </div>
                      </td>
                    </tr>
                  `;
                    })
                    .join('') ||
                  '<tr><td colspan="7" class="text-center py-20">No matching events found.</td></tr>'
                }
              </tbody>
            </table>
          </div>
        </div>
      `;
}
function deleteEventOps(eventId) {
  confirm2('Delete Event', 'Are you sure you want to delete this event record?', () => {
    DB.events = DB.events.filter(event => String(event.id) !== String(eventId));
    saveDB();
    renderPage('events');
    toast('Event deleted successfully', 'info');
  });
}
function refreshEventOpsEvents() {
  sessionStorage.setItem('eventops_events_query', v('eventops-q'));
  sessionStorage.setItem('eventops_events_status', v('eventops-st'));
  sessionStorage.setItem('eventops_events_category', v('eventops-cat'));
  renderPage('events');
}
function eventOpsStatusBadge(status) {
  const st = (status || '').toLowerCase();
  if (st === 'pending' || st === 'draft') return 'yellow';
  if (st === 'active' || st === 'ongoing' || st === 'published' || st === 'upcoming')
    return 'green';
  if (st === 'completed') return 'purple';
  if (st === 'cancelled') return 'red';
  return 'gray';
}
function formatEventStatus(status) {
  const st = (status || '').toLowerCase();
  if (st === 'pending' || st === 'draft') return 'Pending';
  if (st === 'active' || st === 'ongoing' || st === 'published' || st === 'upcoming')
    return 'Active';
  if (st === 'completed') return 'Completed';
  if (st === 'cancelled') return 'Cancelled';
  return 'Active';
}
function setEventOpsStatus(eventId, newStatus) {
  const event = DB.events.find(currentEvent => String(currentEvent.id) === String(eventId));
  if (!event) return;
  const statusMap = {
    Pending: 'pending',
    Active: 'published',
    Completed: 'completed',
    Cancelled: 'cancelled',
  };
  event.status = statusMap[newStatus] || newStatus.toLowerCase();
  saveDB();
  renderPage('events');
  toast(`Event status updated to ${newStatus}`, 'success');
}
function approveEventOpsDirect(eventId) {
  const event = DB.events.find(currentEvent => String(currentEvent.id) === String(eventId));
  if (!event) return;
  event.status = 'published';
  saveDB();
  renderPage('events');
  toast('Event approved and set to Active!', 'success');
}
function rejectEventOpsDirect(eventId) {
  confirm2('Reject Event', 'Are you sure you want to cancel/reject this pending event?', () => {
    const event = DB.events.find(currentEvent => String(currentEvent.id) === String(eventId));
    if (!event) return;
    event.status = 'cancelled';
    saveDB();
    renderPage('events');
    toast('Event has been rejected/cancelled.', 'info');
  });
}
function pageEventOperationsWorkspace() {
  const query = (sessionStorage.getItem('eventops_tasks_query') || '').toLowerCase();
  const statusFilter = sessionStorage.getItem('eventops_tasks_status') || '';
  const priorityFilter = sessionStorage.getItem('eventops_tasks_priority') || '';
  const tasks = DB.eventOperationsTasks || [];
  const filtered = tasks.filter(task => {
    const matchesQuery =
      !query ||
      task.eventTitle.toLowerCase().includes(query) ||
      task.type.toLowerCase().includes(query) ||
      task.id.toLowerCase().includes(query) ||
      task.description.toLowerCase().includes(query);
    const matchesStatus = !statusFilter || task.status === statusFilter;
    const matchesPriority = !priorityFilter || task.priority === priorityFilter;
    return matchesQuery && matchesStatus && matchesPriority;
  });
  const pendingCount = tasks.filter(task => task.status === 'Pending').length;
  const inProgressCount = tasks.filter(task => task.status === 'In Progress').length;
  const resolvedCount = tasks.filter(task => task.status === 'Resolved').length;
  return `
        <div class="page-hd">
          <div class="page-hd-left">
            <div class="page-title">Event Operations Workspace</div>
            <div class="page-sub">Review venue issues, schedule conflicts, info corrections, and operational tasks.</div>
          </div>
          <div class="page-hd-right">
            <button class="btn btn-primary" onclick="openCreateEventOpTaskModal()">➕ Add Operational Issue</button>
          </div>
        </div>

        <div class="grid-4 mb-20">
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--accent-dim);color:var(--accent)">⚙️</div>
            <div class="stat-value" style="color:var(--accent)">${tasks.length}</div>
            <div class="stat-label">Total Issues</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--yellow-dim);color:var(--yellow)">⏳</div>
            <div class="stat-value" style="color:var(--yellow)">${pendingCount}</div>
            <div class="stat-label">Pending Reviews</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--purple-dim);color:var(--purple)">🔄</div>
            <div class="stat-value" style="color:var(--purple)">${inProgressCount}</div>
            <div class="stat-label">In Progress</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--green-dim);color:var(--green)">✅</div>
            <div class="stat-value" style="color:var(--green)">${resolvedCount}</div>
            <div class="stat-label">Resolved Issues</div>
          </div>
        </div>

        <div class="filter-row">
          <div class="search-box input-group">
            <span class="input-icon">🔍</span>
            <input class="form-control" id="taskops-q" placeholder="Search operational issues or events..." value="${query}" oninput="refreshEventOpTasks()">
          </div>
          <select class="form-control filter-select" id="taskops-st" onchange="refreshEventOpTasks()">
            <option value="">All Statuses</option>
            <option value="Pending" ${statusFilter === 'Pending' ? 'selected' : ''}>Pending</option>
            <option value="In Progress" ${
              statusFilter === 'In Progress' ? 'selected' : ''
            }>In Progress</option>
            <option value="Resolved" ${
              statusFilter === 'Resolved' ? 'selected' : ''
            }>Resolved</option>
          </select>
          <select class="form-control filter-select" id="taskops-pr" onchange="refreshEventOpTasks()">
            <option value="">All Priorities</option>
            <option value="High" ${priorityFilter === 'High' ? 'selected' : ''}>High</option>
            <option value="Medium" ${priorityFilter === 'Medium' ? 'selected' : ''}>Medium</option>
            <option value="Low" ${priorityFilter === 'Low' ? 'selected' : ''}>Low</option>
          </select>
        </div>

        <div class="card">
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Issue ID</th>
                  <th>Event Title</th>
                  <th>Issue Type</th>
                  <th>Priority</th>
                  <th>Status</th>
                  <th>Updated</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${
                  filtered
                    .map(
                      t => `
                  <tr>
                    <td class="mono"><strong>${t.id}</strong></td>
                    <td>
                      <div style="font-weight:700;font-size:13.5px;color:var(--text)">${
                        t.eventTitle
                      }</div>
                      <div class="small muted">${t.description}</div>
                    </td>
                    <td><span class="badge badge-blue">${t.type}</span></td>
                    <td>
                      <span class="badge badge-${
                        t.priority === 'High' ? 'red' : t.priority === 'Medium' ? 'yellow' : 'gray'
                      }">${t.priority}</span>
                    </td>
                    <td>
                      <span class="badge badge-${
                        t.status === 'Pending'
                          ? 'yellow'
                          : t.status === 'In Progress'
                          ? 'purple'
                          : 'green'
                      }">${t.status}</span>
                    </td>
                    <td class="small muted">${t.updated}</td>
                    <td>
                      <div class="flex items-center gap-6">
                        <button class="btn btn-ghost btn-xs" onclick="openEventOpTaskModal('${
                          t.id
                        }')">Review &amp; Update</button>
                      </div>
                    </td>
                  </tr>
                `
                    )
                    .join('') ||
                  '<tr><td colspan="7" class="text-center py-20">No operational issues found.</td></tr>'
                }
              </tbody>
            </table>
          </div>
        </div>
      `;
}
function refreshEventOpTasks() {
  sessionStorage.setItem('eventops_tasks_query', v('taskops-q'));
  sessionStorage.setItem('eventops_tasks_status', v('taskops-st'));
  sessionStorage.setItem('eventops_tasks_priority', v('taskops-pr'));
  renderPage('event-requests');
}
function openEventOpTaskModal(taskId) {
  const t = DB.eventOperationsTasks.find(item => item.id === taskId);
  if (!t) return;
  openModal(
    `Operational Issue: ${t.id}`,
    `
        <div class="info-row"><span class="info-label">Event</span><span class="info-value"><strong>${
          t.eventTitle
        }</strong></span></div>
        <div class="info-row"><span class="info-label">Issue Type</span><span class="info-value">${
          t.type
        }</span></div>
        <div class="info-row"><span class="info-label">Priority</span><span class="info-value">${
          t.priority
        }</span></div>
        <div class="form-group mt-12">
          <label class="form-label">Issue Status</label>
          <select class="form-control" id="task-edit-status">
            <option ${t.status === 'Pending' ? 'selected' : ''}>Pending</option>
            <option ${t.status === 'In Progress' ? 'selected' : ''}>In Progress</option>
            <option ${t.status === 'Resolved' ? 'selected' : ''}>Resolved</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Description / Operational Notes</label>
          <textarea class="form-control" id="task-edit-desc" rows="4">${t.description}</textarea>
        </div>
      `,
    [
      {
        lbl: 'Save Changes',
        cls: 'btn-primary',
        fn: `saveEventOpTask('${t.id}')`,
      },
    ]
  );
}
function saveEventOpTask(taskId) {
  const t = DB.eventOperationsTasks.find(item => item.id === taskId);
  if (!t) return;
  t.status = v('task-edit-status');
  t.description = v('task-edit-desc');
  t.updated = 'Just now';
  saveDB();
  closeModal();
  renderPage('event-requests');
  toast('Operational issue updated successfully!', 'success');
}
function openCreateEventOpTaskModal() {
  const eventsOptions = DB.events
    .map(event => `<option value="${event.id}">${event.title || event.name}</option>`)
    .join('');
  openModal(
    'Add Operational Issue',
    `
        <div class="form-group">
          <label class="form-label">Select Event *</label>
          <select class="form-control" id="newtask-eventid">${eventsOptions}</select>
        </div>
        <div class="form-group">
          <label class="form-label">Issue Type *</label>
          <select class="form-control" id="newtask-type">
            <option>Venue &amp; Capacity Review</option>
            <option>Schedule Conflict</option>
            <option>Equipment &amp; Tech Check</option>
            <option>Information Correction</option>
            <option>Security &amp; Access Audit</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Priority</label>
          <select class="form-control" id="newtask-priority">
            <option>High</option>
            <option selected>Medium</option>
            <option>Low</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Description / Issue Details *</label>
          <textarea class="form-control" id="newtask-desc" placeholder="Describe the operational issue..."></textarea>
        </div>
      `,
    [
      {
        lbl: 'Add Issue',
        cls: 'btn-primary',
        fn: 'saveNewEventOpTask()',
      },
    ]
  );
}
function saveNewEventOpTask() {
  const eventId = v('newtask-eventid');
  const type = v('newtask-type');
  const priority = v('newtask-priority');
  const desc = v('newtask-desc');
  if (!desc) {
    toast('Please enter issue description', 'error');
    return;
  }
  const ev = DB.events.find(event => String(event.id) === String(eventId)) || {
    title: 'General Event',
  };
  const newTask = {
    id: `EOP-${Date.now().toString().slice(-4)}`,
    eventId: eventId,
    eventTitle: ev.title || ev.name,
    type: type,
    priority: priority,
    status: 'Pending',
    description: desc,
    updated: 'Just now',
  };
  if (!DB.eventOperationsTasks) DB.eventOperationsTasks = [];
  DB.eventOperationsTasks.unshift(newTask);
  saveDB();
  closeModal();
  renderPage('event-requests');
  toast('Operational issue created!', 'success');
}
function supportUser(request) {
  return (
    DB.users.find(user => String(user.id) === String(request.userId)) || {
      name: 'Unknown User',
      email: '—',
      phone: '—',
    }
  );
}
function supportEvent(request) {
  return (
    DB.events.find(event => String(event.id) === String(request.eventId)) || {
      title: 'Unknown Event',
      date: '—',
    }
  );
}
function supportStatusBadge(status) {
  return (
    {
      Pending: 'yellow',
      'In Progress': 'purple',
      Resolved: 'green',
      Closed: 'gray',
    }[status] || 'gray'
  );
}
function dashSupportFinance() {
  const requests = DB.supportRequests || [];
  const transactions = DB.financeTransactions || [];
  const refunds = DB.financeRefunds || [];
  const reports = DB.operationalReports || [];
  const todayStr = today();
  const todayTransactions = transactions.filter(item => item.date === todayStr).length;
  const totalTransactions = transactions.length;
  const displayTxnCount = todayTransactions > 0 ? todayTransactions : totalTransactions;
  const txnLabel = todayTransactions > 0 ? "Today's Transactions" : 'Total Transactions';

  // Build balanced activity feed: 1 item per category first, then fill from remaining
  const reqActivities = requests.map(item => ({
    label: item.subject,
    detail: `Support Request (${item.id}) · ${item.status} · ${item.updated || item.created}`,
    icon: '📩',
    sortKey: 0,
  }));
  const refActivities = refunds.map(item => ({
    label: `Refund ${item.id}`,
    detail: `Refund · ${item.status} · ₹${item.amount.toLocaleString('en-IN')} · ${item.reason}`,
    icon: '↩️',
    sortKey: 1,
  }));
  const txnActivities = transactions.map(item => ({
    label: `Transaction ${item.id}`,
    detail: `Payment · ${item.status} · ₹${item.amount.toLocaleString('en-IN')} · ${
      item.date === todayStr ? 'Today' : item.date
    }`,
    icon: '💳',
    sortKey: 2,
  }));
  const rptActivities = reports.map(item => ({
    label: `Report: ${item.title}`,
    detail: `${item.type} · ${item.status} · ${item.updated}`,
    icon: '📊',
    sortKey: 3,
  }));

  // Take 1 from each category first (balanced), then fill up to 6 with remaining
  const activity = [
    reqActivities[0],
    refActivities[0],
    txnActivities[0],
    rptActivities[0],
    reqActivities[1],
    refActivities[1],
  ]
    .filter(Boolean)
    .slice(0, 6);
  return `<div class="page-hd"><div class="page-hd-left"><div class="page-title">Customer Support &amp; Finance Dashboard</div><div class="page-sub">Operational overview for ${
    CU.name
  }.</div></div></div><div class="grid-4 mb-20">${[
    [
      '📩',
      requests.filter(item => !['Resolved', 'Closed'].includes(item.status)).length,
      'Open Support Requests',
      'var(--accent)',
    ],
    [
      '⚠️',
      requests.filter(item => item.status === 'Pending').length,
      'Pending Issues',
      'var(--yellow)',
    ],
    ['💳', displayTxnCount, txnLabel, 'var(--green)'],
    [
      '↩️',
      refunds.filter(item => item.status === 'Requested' || item.status === 'Processing').length,
      'Pending Refunds',
      'var(--blue)',
    ],
  ]
    .map(
      card =>
        `<div class="stat-card"><div class="stat-icon">${card[0]}</div><div class="stat-value" style="color:${card[3]}">${card[1]}</div><div class="stat-label">${card[2]}</div></div>`
    )
    .join(
      ''
    )}</div><div class="card"><div class="h4 mb-12">Recent Support &amp; Finance Activity</div><div style="display:flex;flex-direction:column;gap:10px">${
    activity
      .map(
        item =>
          `<div class="flex items-center gap-10" style="padding:10px 0;border-bottom:1px solid var(--border)"><span style="font-size:20px">${item.icon}</span><div><div style="font-weight:600;font-size:13px">${item.label}</div><div class="small">${item.detail}</div></div></div>`
      )
      .join('') || '<div class="empty">No recent activity</div>'
  }</div></div>`;
}
function pageSupportCenter() {
  const query = (sessionStorage.getItem('support_query') || '').toLowerCase();
  const status = sessionStorage.getItem('support_status') || '';
  const requests = (DB.supportRequests || []).filter(item => {
    const user = supportUser(item);
    const event = supportEvent(item);
    return (
      (!status || item.status === status) &&
      (!query ||
        `${item.id} ${item.subject} ${item.message} ${user.name} ${user.email} ${event.title}`
          .toLowerCase()
          .includes(query))
    );
  });
  return `
        <div class="page-hd">
          <div class="page-hd-left">
            <div class="page-title">Support Center</div>
            <div class="page-sub">Manage user support requests with event and payment context. Route unresolvable issues to the appropriate department.</div>
          </div>
          <div class="page-hd-right">
            <button class="btn btn-primary" onclick="openRouteRequestModal()">🔀 Route Request</button>
          </div>
        </div>

        <div class="filter-row">
          <div class="search-box input-group">
            <span class="input-icon">🔍</span>
            <input class="form-control" id="support-query" placeholder="Search requests, users, or events..." value="${query}" oninput="refreshSupportCenter()">
          </div>
          <select class="form-control filter-select" id="support-status" onchange="refreshSupportCenter()">
            <option value="">All Statuses</option>
            ${['Pending', 'In Progress', 'Resolved', 'Closed']
              .map(item => `<option ${status === item ? 'selected' : ''}>${item}</option>`)
              .join('')}
          </select>
        </div>

        <div class="card">
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Request</th>
                  <th>User</th>
                  <th>Event / Payment</th>
                  <th>Status</th>
                  <th>Updated</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${
                  requests
                    .map(item => {
                      const user = supportUser(item);
                      const event = supportEvent(item);
                      return `
                    <tr>
                      <td>
                        <div style="font-weight:700;font-size:13.5px;color:var(--text)">${
                          item.subject
                        }</div>
                        <div class="small muted">${item.message}</div>
                      </td>
                      <td>
                        <div style="font-weight:600">${user.name}</div>
                        <div class="small muted">${user.email}</div>
                      </td>
                      <td>
                        <div style="font-weight:600">${event.title}</div>
                        <div class="small muted">${event.date} · Related transaction available</div>
                      </td>
                      <td><span class="badge badge-${supportStatusBadge(item.status)}">${
                        item.status
                      }</span></td>
                      <td class="small muted">${item.updated}</td>
                      <td>
                        <div class="flex gap-6">
                          <button class="btn btn-ghost btn-xs" onclick="openSupportRequest('${
                            item.id
                          }')">View / Respond</button>
                          <button class="btn btn-ghost btn-xs" style="border-color:var(--purple);color:var(--purple)" onclick="openRouteRequestModal('${
                            item.id
                          }')">🔀 Route</button>
                        </div>
                      </td>
                    </tr>
                  `;
                    })
                    .join('') ||
                  '<tr><td colspan="6" class="text-center py-20 muted">No support requests found.</td></tr>'
                }
              </tbody>
            </table>
          </div>
        </div>
      `;
}
function openRouteRequestModal(prefillId) {
  const supportReqs = DB.supportRequests || [];
  const reqOptions = supportReqs
    .map(request => {
      const eventRequest = supportUser(request);
      return `<option value="${request.id}" ${prefillId === request.id ? 'selected' : ''}>${
        request.id
      } — ${request.subject} (${eventRequest.name})</option>`;
    })
    .join('');

  // Determine prefill values if a request ID was passed
  let prefillUser = '';
  let prefillEmail = '';
  let prefillDesc = '';
  let prefillEvent = '';
  let autoRouteTo = '';
  if (prefillId) {
    const item = supportReqs.find(request => request.id === prefillId);
    if (item) {
      const u = supportUser(item);
      const e = supportEvent(item);
      prefillUser = u.name || '';
      prefillEmail = u.email || '';
      prefillDesc = item.message || '';
      prefillEvent = e.title && e.title !== 'Unknown Event' ? e.title : '';
      // Auto-suggest route based on subject keywords
      const subjectLow =
        (item.subject || '').toLowerCase() + ' ' + (item.message || '').toLowerCase();
      const emp1Keywords = [
        'registration',
        'account',
        'verification',
        'user',
        'profile',
        'email',
        'login',
        'password',
        'access',
      ];
      const emp2Keywords = [
        'event',
        'venue',
        'schedule',
        'location',
        'capacity',
        'slot',
        'cancel',
        'speaker',
        'av',
        'equipment',
      ];
      if (emp2Keywords.some(k => subjectLow.includes(k)))
        autoRouteTo = 'Employee 2 – Event Operations Executive';
      else if (emp1Keywords.some(k => subjectLow.includes(k)))
        autoRouteTo = 'Employee 1 – Registration & Verification Executive';
    }
  }
  openModal(
    '🔀 Route Support Request',
    `
        <div style="background:var(--surface2);border-radius:10px;padding:12px 16px;margin-bottom:16px;font-size:13px;color:var(--text2);border-left:3px solid var(--purple)">
          <strong style="color:var(--purple)">Routing Policy:</strong> Route <strong>user/account/registration/verification</strong> issues to Employee 1. Route <strong>event/venue/schedule/operational</strong> issues to Employee 2. Finance/payment issues are handled directly by you.
        </div>

        <div class="form-group">
          <label class="form-label">Select Request ID (optional)</label>
          <select class="form-control" id="route-req-id" onchange="prefillRouteForm(this.value)">
            <option value="">— New / Manual Route —</option>
            ${reqOptions}
          </select>
        </div>

        <div class="grid-2 gap-12">
          <div class="form-group">
            <label class="form-label">User Name *</label>
            <input class="form-control" id="route-user-name" placeholder="Full name" value="${prefillUser}">
          </div>
          <div class="form-group">
            <label class="form-label">User Email *</label>
            <input class="form-control" id="route-user-email" placeholder="user@email.com" value="${prefillEmail}">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Request Category *</label>
          <select class="form-control" id="route-category">
            <option>User Account Issue</option>
            <option>Registration Problem</option>
            <option>Identity Verification Issue</option>
            <option>Event Information Query</option>
            <option>Venue / Location Issue</option>
            <option>Schedule Conflict / Change</option>
            <option>Event Capacity / Slot Issue</option>
            <option>Event Cancellation / Update Request</option>
            <option>Operational Issue</option>
            <option>Other</option>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label">Request Description *</label>
          <textarea class="form-control" id="route-description" rows="3" placeholder="Describe the issue in detail...">${prefillDesc}</textarea>
        </div>

        <div class="form-group">
          <label class="form-label">Related Event (if applicable)</label>
          <input class="form-control" id="route-event" placeholder="Event name or ID" value="${prefillEvent}">
        </div>

        <div class="grid-2 gap-12">
          <div class="form-group">
            <label class="form-label">Priority *</label>
            <select class="form-control" id="route-priority">
              <option value="Low">🟢 Low</option>
              <option value="Medium" selected>🟡 Medium</option>
              <option value="High">🔴 High</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Route To *</label>
            <select class="form-control" id="route-to">
              <option value="Employee 1 – Registration &amp; Verification Executive" ${
                autoRouteTo === 'Employee 1 – Registration & Verification Executive'
                  ? 'selected'
                  : ''
              }>Employee 1 – Registration &amp; Verification Executive</option>
              <option value="Employee 2 – Event Operations Executive" ${
                autoRouteTo === 'Employee 2 – Event Operations Executive' ? 'selected' : ''
              }>Employee 2 – Event Operations Executive</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Internal Note (visible to recipient)</label>
          <textarea class="form-control" id="route-note" rows="2" placeholder="Add context for the receiving department..."></textarea>
        </div>
      `,
    [
      {
        lbl: 'Cancel',
        cls: 'btn-ghost',
        fn: 'closeModal()',
      },
      {
        lbl: '🔀 Route Request',
        cls: 'btn-primary',
        fn: 'saveRouteRequest()',
      },
    ]
  );
}
window.prefillRouteForm = function (reqId) {
  if (!reqId) return;
  const item = (DB.supportRequests || []).find(r => r.id === reqId);
  if (!item) return;
  const u = supportUser(item);
  const e = supportEvent(item);
  const nameEl = document.getElementById('route-user-name');
  const emailEl = document.getElementById('route-user-email');
  const descEl = document.getElementById('route-description');
  const eventEl = document.getElementById('route-event');
  const routeToEl = document.getElementById('route-to');
  if (nameEl) nameEl.value = u.name || '';
  if (emailEl) emailEl.value = u.email || '';
  if (descEl) descEl.value = item.message || '';
  if (eventEl && e.title && e.title !== 'Unknown Event') eventEl.value = e.title;
  // Auto-suggest routing
  if (routeToEl) {
    const subjectLow =
      (item.subject || '').toLowerCase() + ' ' + (item.message || '').toLowerCase();
    const emp2Keywords = [
      'event',
      'venue',
      'schedule',
      'location',
      'capacity',
      'slot',
      'cancel',
      'speaker',
      'av',
      'equipment',
    ];
    const emp1Keywords = [
      'registration',
      'account',
      'verification',
      'user',
      'profile',
      'email',
      'login',
      'password',
    ];
    if (emp2Keywords.some(k => subjectLow.includes(k)))
      routeToEl.value = 'Employee 2 – Event Operations Executive';
    else if (emp1Keywords.some(k => subjectLow.includes(k)))
      routeToEl.value = 'Employee 1 – Registration & Verification Executive';
  }
};
function saveRouteRequest() {
  const userName = v('route-user-name');
  const userEmail = v('route-user-email');
  const category = v('route-category');
  const description = v('route-description');
  const priority = v('route-priority');
  const routeTo = v('route-to');
  const note = v('route-note');
  const relatedEvent = v('route-event');
  const reqId = v('route-req-id');
  if (!userName) {
    toast('Please enter the user name', 'error');
    return;
  }
  if (!description) {
    toast('Please enter a request description', 'error');
    return;
  }
  const routedId = 'RT-' + Date.now().toString().slice(-6);
  const isEmp2 = routeTo.includes('Employee 2');
  const isEmp1 = routeTo.includes('Employee 1');

  // Build the routed request record
  const routedReq = {
    id: routedId,
    linkedRequestId: reqId || null,
    userName: userName,
    userEmail: userEmail,
    category: category,
    description: description,
    relatedEvent: relatedEvent || null,
    priority: priority,
    routeTo: routeTo,
    note: note,
    source: 'Escalated by Emp 3',
    raisedBy: 'Customer Support (Emp 3)',
    status: 'Pending',
    date:
      new Date().toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'short',
        day: '2-digit',
      }) +
      ' · ' +
      new Date().toLocaleTimeString('en-IN', {
        hour: '2-digit',
        minute: '2-digit',
      }),
    routedAt: 'Just now',
  };
  if (!DB.routedRequests) DB.routedRequests = [];
  DB.routedRequests.unshift(routedReq);

  // Make visible to Employee 1 (userQueries) if routed to Emp 1
  if (isEmp1) {
    if (!DB.userQueries) DB.userQueries = [];
    DB.userQueries.unshift({
      id: routedId,
      userId: null,
      userName: userName,
      userEmail: userEmail,
      type: category,
      subject: `[Routed by Emp 3] ${category}`,
      detail:
        description +
        (note ? '\n\nInternal Note: ' + note : '') +
        (relatedEvent ? '\nRelated Event: ' + relatedEvent : ''),
      source: 'Employee 3 Escalation',
      status: 'Pending',
      priority: priority,
      date: routedReq.date,
    });
  }

  // Make visible to Employee 2 (eventOpsRequests) if routed to Emp 2
  if (isEmp2) {
    if (!DB.eventOpsRequests) DB.eventOpsRequests = [];
    // find matching eventId if possible
    const matchedEvent = relatedEvent
      ? (DB.events || []).find(event =>
          (event.title || event.name || '').toLowerCase().includes(relatedEvent.toLowerCase())
        )
      : null;
    DB.eventOpsRequests.unshift({
      id: routedId,
      eventId: matchedEvent ? matchedEvent.id : null,
      eventTitle: relatedEvent || 'N/A',
      issue: description + (note ? '\n\nInternal Note: ' + note : ''),
      source: 'Escalated by Emp 3',
      raisedBy: `${userName} (via Customer Support)`,
      priority: priority,
      status: 'Pending',
      date: routedReq.date,
      notes: note || '',
    });
  }

  // Mark linked support request as In Progress if selected
  if (reqId) {
    const linked = (DB.supportRequests || []).find(r => r.id === reqId);
    if (linked && linked.status === 'Pending') {
      linked.status = 'In Progress';
      linked.response = `Routed to ${routeTo} on ${routedReq.date}. Awaiting resolution.`;
      linked.updated = 'Just now';
    }
  }
  saveDB();
  closeModal();
  renderPage('support-center');
  toast(
    `Request routed to ${
      isEmp2 ? 'Employee 2 (Event Operations)' : 'Employee 1 (Registration & Verification)'
    } successfully!`,
    'success'
  );
}
function refreshSupportCenter() {
  sessionStorage.setItem('support_query', v('support-query'));
  sessionStorage.setItem('support_status', v('support-status'));
  renderPage('support-center');
}
function openSupportRequest(id) {
  const item = DB.supportRequests.find(request => request.id === id);
  if (!item) return;
  const user = supportUser(item);
  const event = supportEvent(item);
  const transaction = (DB.financeTransactions || []).find(
    record =>
      String(record.userId) === String(item.userId) &&
      String(record.eventId) === String(item.eventId)
  );
  openModal(
    `Support Request ${item.id}`,
    `
        <div class="info-row"><span class="info-label">User</span><span class="info-value">${
          user.name
        } · ${user.email}</span></div>
        <div class="info-row"><span class="info-label">Event</span><span class="info-value">${
          event.title
        } · ${event.date}</span></div>
        <div class="info-row"><span class="info-label">Payment</span><span class="info-value">${
          transaction
            ? `${transaction.id} · ₹${transaction.amount} · ${transaction.status}`
            : 'No matching transaction'
        }</span></div>
        <div class="info-row"><span class="info-label">Request</span><span class="info-value">${
          item.subject
        }</span></div>
        <p class="muted" style="line-height:1.6;margin:16px 0">${item.message}</p>
        <div class="form-group">
          <label class="form-label">Status</label>
          <select class="form-control" id="support-edit-status">
            ${['Pending', 'In Progress', 'Resolved', 'Closed']
              .map(value => `<option ${value === item.status ? 'selected' : ''}>${value}</option>`)
              .join('')}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Response</label>
          <textarea class="form-control" id="support-response" rows="4">${
            item.response || ''
          }</textarea>
        </div>
      `,
    [
      {
        lbl: '🔀 Route This Request',
        cls: 'btn-ghost',
        fn: `closeModal();openRouteRequestModal('${id}')`,
      },
      {
        lbl: 'Save Response',
        cls: 'btn-primary',
        fn: `saveSupportRequest('${id}')`,
      },
    ]
  );
}
function saveSupportRequest(id) {
  const item = DB.supportRequests.find(request => request.id === id);
  if (!item) return;
  item.status = v('support-edit-status');
  item.response = v('support-response');
  item.updated = 'Just now';
  saveDB();
  closeModal();
  renderPage('support-center');
  toast('Support request updated', 'success');
}
function financeStatusBadge(status) {
  return (
    {
      Successful: 'green',
      Pending: 'yellow',
      Failed: 'red',
      Requested: 'yellow',
      Processing: 'purple',
      Completed: 'green',
      Rejected: 'red',
    }[status] || 'gray'
  );
}
function pageFinanceCenter() {
  const tab = sessionStorage.getItem('finance_tab') || 'transactions';
  const query = (sessionStorage.getItem('finance_query') || '').toLowerCase();
  const commissionRate = 0.15;
  const allTransactions = Array.isArray(DB.financeTransactions) ? DB.financeTransactions : [];
  const refundRecords = Array.isArray(DB.financeRefunds) ? DB.financeRefunds : [];
  const paidRegistrations = (DB.registrations || []).filter(
    registration =>
      String(registration.payment || '').toLowerCase() === 'paid' &&
      ['confirmed', 'verified'].includes(String(registration.status || '').toLowerCase())
  );
  const successfulTransactions = allTransactions.filter(tx => tx.status === 'Successful');
  const totalRevenue = successfulTransactions.reduce(
    (sum, item) => sum + Number(item.amount || 0),
    0
  );
  const platformCommission = totalRevenue * commissionRate;
  const organizerPayout = totalRevenue - platformCommission;
  const records = tab === 'transactions' ? allTransactions : refundRecords;
  const filtered = records.filter(item => {
    const user = DB.users.find(u => String(u.id) === String(item.userId)) || {};
    const event =
      DB.events.find(currentEvent => String(currentEvent.id) === String(item.eventId)) || {};
    const text = `${item.id || ''} ${user.name || ''} ${user.email || ''} ${event.title || ''} ${
      item.status || ''
    } ${item.reason || ''}`.toLowerCase();
    return !query || text.includes(query);
  });
  return `
        <div class="page-hd">
          <div class="page-hd-left">
            <div class="page-title">Finance &amp; Revenue</div>
            <div class="page-sub">Track registration revenue, platform commission, organizer payouts, and customer payment activity.</div>
          </div>
        </div>

        <div class="grid-4 mb-20">
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--green-dim);color:var(--green)">💰</div>
            <div class="stat-value" style="color:var(--green)">₹${totalRevenue.toLocaleString(
              'en-IN'
            )}</div>
            <div class="stat-label">Total Revenue</div>
            <div class="stat-sub neutral">Completed payment records</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--accent-dim);color:var(--accent)">📈</div>
            <div class="stat-value" style="color:var(--accent)">₹${platformCommission.toLocaleString(
              'en-IN'
            )}</div>
            <div class="stat-label">Platform Commission</div>
            <div class="stat-sub neutral">Fixed 15% fee share</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--yellow-dim);color:var(--yellow)">💸</div>
            <div class="stat-value" style="color:var(--yellow)">₹${organizerPayout.toLocaleString(
              'en-IN'
            )}</div>
            <div class="stat-label">Organizer Payouts</div>
            <div class="stat-sub neutral">Net payout after commission</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--purple-dim);color:var(--purple)">🧾</div>
            <div class="stat-value" style="color:var(--purple)">${
              successfulTransactions.length
            }</div>
            <div class="stat-label">Successful Transactions</div>
            <div class="stat-sub neutral">Monitored payment records</div>
          </div>
        </div>

        <div class="card" style="margin-bottom:20px">
          <div class="flex justify-between items-center mb-12">
            <div class="h4">Event-wise Revenue &amp; Commission</div>
            <div class="small muted">Commission formula: registration fee × 15%</div>
          </div>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Event</th>
                  <th>Payments</th>
                  <th>Gross Revenue</th>
                  <th>Platform Commission</th>
                  <th>Organizer Payout</th>
                </tr>
              </thead>
              <tbody>
                ${(() => {
                  const eventSummary = {};
                  successfulTransactions.forEach(tx => {
                    const event = DB.events.find(
                      currentEvent => String(currentEvent.id) === String(tx.eventId)
                    ) || {
                      title: 'Unknown Event',
                    };
                    const eventKey = String(tx.eventId || event.title);
                    if (!eventSummary[eventKey]) {
                      eventSummary[eventKey] = {
                        eventTitle: event.title,
                        attendeeCount: 0,
                        revenue: 0,
                      };
                    }
                    eventSummary[eventKey].attendeeCount += 1;
                    eventSummary[eventKey].revenue += Number(tx.amount || 0);
                  });
                  const rows = Object.values(eventSummary);
                  return rows.length
                    ? rows
                        .map(row => {
                          const commission = row.revenue * commissionRate;
                          const payout = row.revenue - commission;
                          return `
                          <tr>
                            <td>${row.eventTitle}</td>
                            <td>${row.attendeeCount}</td>
                            <td style="color:var(--green);font-weight:700">₹${row.revenue}</td>
                            <td style="color:var(--accent);font-weight:700">₹${commission}</td>
                            <td style="color:var(--yellow);font-weight:700">₹${payout}</td>
                          </tr>
                        `;
                        })
                        .join('')
                    : '<tr><td colspan="5" class="text-center py-20">No successful event revenue data found.</td></tr>';
                })()}
              </tbody>
            </table>
          </div>
        </div>

        <div style="display:flex;gap:6px;margin-bottom:16px">
          <button class="btn ${
            tab === 'transactions' ? 'btn-primary' : 'btn-ghost'
          }" onclick="switchFinanceTab('transactions')">💳 Transactions</button>
          <button class="btn ${
            tab === 'refunds' ? 'btn-primary' : 'btn-ghost'
          }" onclick="switchFinanceTab('refunds')">↩️ Refunds</button>
        </div>

        <div class="filter-row">
          <div class="search-box input-group">
            <span class="input-icon">🔍</span>
            <input class="form-control" id="finance-query" placeholder="Search finance records..." value="${query}" oninput="refreshFinanceCenter()">
          </div>
        </div>

        <div class="card">
          <div class="table-wrap">
            <table>
              <thead>
                ${
                  tab === 'transactions'
                    ? '<tr><th>Transaction ID</th><th>User</th><th>Event</th><th>Amount</th><th>Payment Status</th><th>Date</th></tr>'
                    : '<tr><th>Refund ID</th><th>User</th><th>Event</th><th>Amount</th><th>Reason</th><th>Status</th><th>Date</th></tr>'
                }
              </thead>
              <tbody>
                ${
                  filtered
                    .map(item => {
                      const user = DB.users.find(u => String(u.id) === String(item.userId)) || {
                        name: 'Unknown',
                      };
                      const event = DB.events.find(
                        currentEvent => String(currentEvent.id) === String(item.eventId)
                      ) || {
                        title: 'Unknown Event',
                      };
                      return tab === 'transactions'
                        ? `<tr><td class="mono">${item.id}</td><td>${user.name}</td><td>${
                            event.title
                          }</td><td style="color:var(--green);font-weight:700">₹${
                            item.amount
                          }</td><td><span class="badge badge-${financeStatusBadge(item.status)}">${
                            item.status
                          }</span></td><td>${item.date}</td></tr>`
                        : `<tr><td class="mono">${item.id}</td><td>${user.name}</td><td>${
                            event.title
                          }</td><td style="color:var(--green);font-weight:700">₹${
                            item.amount
                          }</td><td>${
                            item.reason
                          }</td><td><span class="badge badge-${financeStatusBadge(item.status)}">${
                            item.status
                          }</span></td><td>${item.date}</td></tr>`;
                    })
                    .join('') ||
                  `<tr><td colspan="${
                    tab === 'transactions' ? 6 : 7
                  }" class="text-center py-20">No finance records found.</td></tr>`
                }
              </tbody>
            </table>
          </div>
        </div>
      `;
}
function switchFinanceTab(tab) {
  sessionStorage.setItem('finance_tab', tab);
  renderPage('finance');
}
function refreshFinanceCenter() {
  sessionStorage.setItem('finance_query', v('finance-query'));
  renderPage('finance');
}
function pageRegistrationsForEmployee() {
  const query = (sessionStorage.getItem('emp_reg_query') || '').toLowerCase();
  const statusFilter = sessionStorage.getItem('emp_reg_status') || '';
  const regs = DB.registrations || [];
  const filtered = regs.filter(registration => {
    const attendee = DB.users.find(user => String(user.id) === String(registration.attendeeId)) || {
      name: '',
      email: '',
    };
    const event = DB.events.find(
      currentEvent => String(currentEvent.id) === String(registration.eventId)
    ) || {
      title: '',
    };
    const searchStr = `${registration.id} ${registration.ticketId || ''} ${attendee.name} ${
      attendee.email
    } ${event.title}`.toLowerCase();
    const matchesQuery = !query || searchStr.includes(query);
    const st = (registration.status || 'confirmed').toLowerCase();
    let matchesStatus = true;
    if (statusFilter === 'pending') matchesStatus = st === 'pending';
    else if (statusFilter === 'confirmed') matchesStatus = st === 'confirmed' || st === 'verified';
    else if (statusFilter === 'rejected') matchesStatus = st === 'rejected';
    return matchesQuery && matchesStatus;
  });
  return `
        <div class="page-hd">
          <div class="page-hd-left">
            <div class="page-title">Registrations Management</div>
            <div class="page-sub">View, search, filter, and manage online event registrations.</div>
          </div>
        </div>

        <div class="filter-row">
          <div class="search-box input-group">
            <span class="input-icon">🔍</span>
            <input class="form-control" id="emp-reg-q" placeholder="Search by Ticket ID, Attendee, or Event..." value="${query}" oninput="refreshEmpRegistrations()">
          </div>
          <select class="form-control filter-select" id="emp-reg-st" onchange="refreshEmpRegistrations()">
            <option value="">All Statuses</option>
            <option value="confirmed" ${
              statusFilter === 'confirmed' ? 'selected' : ''
            }>Confirmed / Verified</option>
            <option value="pending" ${statusFilter === 'pending' ? 'selected' : ''}>Pending</option>
            <option value="rejected" ${
              statusFilter === 'rejected' ? 'selected' : ''
            }>Rejected</option>
          </select>
        </div>

        <div class="card">
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Ticket / Reg ID</th>
                  <th>Attendee</th>
                  <th>Event</th>
                  <th>Registration Date</th>
                  <th>Payment Status</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${
                  filtered
                    .map(registration => {
                      const attendee = DB.users.find(
                        user => String(user.id) === String(registration.attendeeId)
                      ) || {
                        name: 'Unknown User',
                        email: '—',
                      };
                      const event = DB.events.find(
                        currentEvent => String(currentEvent.id) === String(registration.eventId)
                      ) || {
                        title: 'Unknown Event',
                      };
                      const isPending = registration.status === 'pending';
                      return `
                    <tr>
                      <td class="mono"><strong>${
                        registration.ticketId || registration.id
                      }</strong></td>
                      <td>
                        <div style="font-weight:700;font-size:13.5px;color:var(--text)">${
                          attendee.name
                        }</div>
                        <div class="small muted">${attendee.email}</div>
                      </td>
                      <td>${event.title}</td>
                      <td>${registration.date || 'Today'}</td>
                      <td>
                        <span class="badge badge-${
                          registration.payment === 'paid' ? 'green' : 'yellow'
                        }">${
                        registration.payment === 'paid'
                          ? 'Paid (₹' + (registration.amount || 0) + ')'
                          : 'Pending'
                      }</span>
                      </td>
                      <td>
                        <span class="badge badge-${
                          registration.status === 'confirmed'
                            ? 'green'
                            : registration.status === 'pending'
                            ? 'yellow'
                            : 'red'
                        }">${registration.status || 'confirmed'}</span>
                      </td>
                      <td>
                        <div class="flex items-center gap-6">
                          <button class="btn btn-ghost btn-xs" onclick="openRegistrationDetailModal('${
                            registration.id
                          }')">Review</button>
                          ${
                            isPending
                              ? `
                            <button class="btn btn-success btn-xs" onclick="approveRegistrationDirect('${registration.id}')" title="Approve">✓</button>
                            <button class="btn btn-danger btn-xs" onclick="rejectRegistrationDirect('${registration.id}')" title="Reject">✕</button>
                          `
                              : ''
                          }
                        </div>
                      </td>
                    </tr>
                  `;
                    })
                    .join('') ||
                  '<tr><td colspan="7" class="text-center py-20">No matching registrations found.</td></tr>'
                }
              </tbody>
            </table>
          </div>
        </div>
      `;
}
function refreshEmpRegistrations() {
  sessionStorage.setItem('emp_reg_query', v('emp-reg-q'));
  sessionStorage.setItem('emp_reg_status', v('emp-reg-st'));
  renderPage('registrations');
}
function approveRegistrationDirect(regId) {
  const registration = DB.registrations.find(item => String(item.id) === String(regId));
  if (!registration) return;
  registration.status = 'confirmed';
  registration.verificationStatus = 'Verified';
  registration.verified = true;
  saveDB();
  renderPage('registrations');
  toast('Registration approved successfully!', 'success');
}
function rejectRegistrationDirect(regId) {
  confirm2(
    'Reject Registration',
    'Are you sure you want to reject this online registration?',
    () => {
      const registration = DB.registrations.find(item => String(item.id) === String(regId));
      if (!registration) return;
      registration.status = 'rejected';
      registration.verificationStatus = 'Rejected';
      saveDB();
      renderPage('registrations');
      toast('Registration rejected.', 'info');
    }
  );
}
function openRegistrationDetailModal(regId) {
  const registration = DB.registrations.find(item => String(item.id) === String(regId));
  if (!registration) return;
  const attendee = DB.users.find(user => String(user.id) === String(registration.attendeeId)) || {
    name: 'Unknown User',
    email: '—',
    phone: '—',
  };
  const event = DB.events.find(
    currentEvent => String(currentEvent.id) === String(registration.eventId)
  ) || {
    title: 'Unknown Event',
  };
  openModal(
    `Registration Details: ${registration.ticketId || registration.id}`,
    `
        <div class="info-row"><span class="info-label">Ticket ID</span><span class="info-value mono">${
          registration.ticketId || registration.id
        }</span></div>
        <div class="info-row"><span class="info-label">Attendee Name</span><span class="info-value"><strong>${
          attendee.name
        }</strong></span></div>
        <div class="info-row"><span class="info-label">Attendee Email</span><span class="info-value">${
          attendee.email
        }</span></div>
        <div class="info-row"><span class="info-label">Contact Phone</span><span class="info-value">${
          attendee.phone || '—'
        }</span></div>
        <div class="info-row"><span class="info-label">Event</span><span class="info-value">${
          event.title
        }</span></div>
        <div class="info-row"><span class="info-label">Registration Date</span><span class="info-value">${
          registration.date || 'Today'
        }</span></div>
        <div class="info-row"><span class="info-label">Payment Amount</span><span class="info-value" style="color:var(--green);font-weight:700">₹${
          registration.amount || 0
        } (${registration.payment || 'paid'})</span></div>
        <div class="info-row"><span class="info-label">Verification Status</span><span class="info-value"><span class="badge badge-${
          registration.status === 'confirmed' ? 'green' : 'yellow'
        }">${
      registration.verificationStatus || registration.status || 'confirmed'
    }</span></span></div>
      `,
    [
      {
        lbl: 'Approve',
        cls: 'btn-success',
        fn: `closeModal();approveRegistrationDirect('${registration.id}')`,
      },
      {
        lbl: 'Reject',
        cls: 'btn-danger',
        fn: `closeModal();rejectRegistrationDirect('${registration.id}')`,
      },
    ]
  );
}
function pageUserManagement() {
  const query = (sessionStorage.getItem('usrmgt_query') || '').toLowerCase();
  const roleFilter = sessionStorage.getItem('usrmgt_role') || '';
  const users = window.EventFlowAccountPolicy.visibleAccounts(CU, DB.users || []);
  const filtered = users.filter(user => {
    const matchesQuery =
      !query ||
      `${user.name} ${user.email} ${user.phone} ${user.role} ${user.id}`
        .toLowerCase()
        .includes(query);
    const matchesRole = !roleFilter || user.role === roleFilter;
    return matchesQuery && matchesRole;
  });
  return `
        <div class="page-hd">
          <div class="page-hd-left">
            <div class="page-title">User Management</div>
            <div class="page-sub">View, update, and manage platform users and account access.</div>
          </div>
        </div>


        <div class="filter-row">
          <div class="search-box input-group">
            <span class="input-icon">🔍</span>
            <input class="form-control" id="usrmgt-q" placeholder="Search users by name, email, phone, role..." value="${query}" oninput="refreshUserManagement()">
          </div>
          <select class="form-control filter-select" id="usrmgt-role" onchange="refreshUserManagement()">
            <option value="">All Roles</option>
            <option value="attendee" ${
              roleFilter === 'attendee' ? 'selected' : ''
            }>Attendee</option>
            <option value="client" ${roleFilter === 'client' ? 'selected' : ''}>Client</option>
            <option value="organizer" ${
              roleFilter === 'organizer' ? 'selected' : ''
            }>Organizer</option>
            ${
              window.EventFlowAccountPolicy.isSupportExecutiveAccount(CU)
                ? ''
                : `<option value="employee" ${
                    roleFilter === 'employee' ? 'selected' : ''
                  }>Employees</option>`
            }
          </select>
        </div>

        <div class="card">
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>User ID &amp; Name</th>
                  <th>Contact Info</th>
                  <th>Role</th>
                  <th>Verification</th>
                  <th>Account Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${
                  filtered
                    .map(u => {
                      const isDeactivated = u.status === 'deactivated' || u.status === 'inactive';
                      return `
                    <tr>
                      <td>
                        <div class="flex items-center gap-10">
                          <div class="av av-xs">${u.avatar || u.name[0]}</div>
                          <div>
                            <div style="font-weight:700;font-size:14px;color:var(--text)">${
                              u.name
                            }</div>
                            <div class="small muted">ID: ${u.id}</div>
                          </div>
                        </div>
                      </td>
                      <td>
                        <div>${u.email}</div>
                        <div class="small muted">📞 ${u.phone || '—'}</div>
                      </td>
                      <td><span class="badge badge-purple">${u.role}</span></td>
                      <td>
                        <span class="badge badge-${u.status === 'active' ? 'green' : 'yellow'}">${
                        u.status === 'active' ? 'Verified' : 'Pending'
                      }</span>
                      </td>
                      <td>
                        <span class="badge badge-${isDeactivated ? 'red' : 'green'}">${
                        isDeactivated ? 'Deactivated' : 'Active'
                      }</span>
                      </td>
                      <td>
                        ${
                          window.EventFlowAccountPolicy.canManageAccount(CU, u)
                            ? `<div class="flex items-center gap-6">
                          <button class="btn btn-ghost btn-xs" onclick="openEditUserModal('${
                            u.id
                          }')" title="Edit Details">✏️ Edit</button>
                          <button class="btn btn-ghost btn-xs" onclick="toggleUserStatus('${
                            u.id
                          }')" title="Deactivate/Activate">${
                                isDeactivated ? '🔓 Activate' : '🔒 Deactivate'
                              }</button>
                          <button class="btn btn-xs btn-danger" onclick="deleteUserOps('${
                            u.id
                          }')" title="Delete User">🗑️</button>
                        </div>`
                            : '<span class="small muted">Admin managed</span>'
                        }
                      </td>
                    </tr>
                  `;
                    })
                    .join('') ||
                  '<tr><td colspan="6" class="text-center py-20">No matching users found.</td></tr>'
                }
              </tbody>
            </table>
          </div>
        </div>
      `;
}
function refreshUserManagement() {
  sessionStorage.setItem('usrmgt_query', v('usrmgt-q'));
  sessionStorage.setItem('usrmgt_role', v('usrmgt-role'));
  renderPage('attendees');
}
function openEditUserModal(userId) {
  const u = DB.users.find(user => String(user.id) === String(userId));
  if (!u) return;
  if (!window.EventFlowAccountPolicy.canManageAccount(CU, u)) {
    toast('Only an admin can change employee or admin accounts.', 'error');
    return;
  }
  openModal(
    `Edit User: ${u.name}`,
    `
        <div class="form-group">
          <label class="form-label">Full Name *</label>
          <input class="form-control" id="edit-usr-name" value="${u.name}">
        </div>
        <div class="form-group">
          <label class="form-label">Email Address *</label>
          <input class="form-control" id="edit-usr-email" value="${u.email}">
        </div>
        <div class="form-group">
          <label class="form-label">Phone Number</label>
          <input class="form-control" id="edit-usr-phone" value="${u.phone || ''}">
        </div>
        <div class="form-group">
          <label class="form-label">User Role</label>
          <select class="form-control" id="edit-usr-role" ${
            window.EventFlowAccountPolicy.isSupportExecutiveAccount(CU) ? 'disabled' : ''
          }>
            <option value="attendee" ${u.role === 'attendee' ? 'selected' : ''}>Attendee</option>
            <option value="client" ${u.role === 'client' ? 'selected' : ''}>Client</option>
            <option value="organizer" ${u.role === 'organizer' ? 'selected' : ''}>Organizer</option>
            ${
              window.EventFlowAccountPolicy.isSupportExecutiveAccount(CU)
                ? ''
                : `<option value="employee" ${
                    u.role === 'employee' ? 'selected' : ''
                  }>Employees</option>`
            }
          </select>
        </div>
      `,
    [
      {
        lbl: 'Save Changes',
        cls: 'btn-primary',
        fn: `saveEditUser('${u.id}')`,
      },
    ]
  );
}
function saveEditUser(userId) {
  const u = DB.users.find(user => String(user.id) === String(userId));
  if (!u) return;
  if (!window.EventFlowAccountPolicy.canManageAccount(CU, u)) {
    toast('Only an admin can change employee or admin accounts.', 'error');
    return;
  }
  const name = v('edit-usr-name');
  const email = v('edit-usr-email');
  if (!name || !email) {
    toast('Name and email are required', 'error');
    return;
  }
  if (window.EventFlowAccountPolicy.isEmailInUse(DB.users, email, userId)) {
    toast('Email already registered', 'error');
    return;
  }
  if (
    !window.EventFlowAccountPolicy.canApplyAccountUpdate(CU, u, {
      role: v('edit-usr-role'),
    })
  ) {
    toast('Only an admin can change account roles.', 'error');
    return;
  }
  u.name = name;
  u.email = email;
  u.phone = v('edit-usr-phone');
  u.role = v('edit-usr-role');
  saveDB();
  closeModal();
  renderPage('attendees');
  toast('User details updated!', 'success');
}
function toggleUserStatus(userId) {
  const u = DB.users.find(user => String(user.id) === String(userId));
  if (!u) return;
  if (!window.EventFlowAccountPolicy.canManageAccount(CU, u)) {
    toast('Only an admin can change employee or admin accounts.', 'error');
    return;
  }
  const newStatus =
    u.status === 'deactivated' || u.status === 'inactive' ? 'active' : 'deactivated';
  u.status = newStatus;
  saveDB();
  renderPage('attendees');
  toast(`User status changed to ${newStatus}`, 'info');
}
function deleteUserOps(userId) {
  const target = DB.users.find(user => String(user.id) === String(userId));
  if (!window.EventFlowAccountPolicy.canManageAccount(CU, target)) {
    toast('Only an admin can change employee or admin accounts.', 'error');
    return;
  }
  confirm2('Delete User', 'Are you sure you want to permanently delete this user record?', () => {
    const current = DB.users.find(user => String(user.id) === String(userId));
    if (!window.EventFlowAccountPolicy.canManageAccount(CU, current)) {
      toast('This account can only be managed by an admin.', 'error');
      return;
    }
    DB.users = DB.users.filter(user => String(user.id) !== String(userId));
    saveDB();
    renderPage('attendees');
    toast('User deleted successfully', 'info');
  });
}
function pageAttendeeVerification() {
  const query = (sessionStorage.getItem('verif_query') || '').toLowerCase();
  const statusFilter = sessionStorage.getItem('verif_status') || '';
  const regs = DB.registrations || [];
  const filtered = regs.filter(registration => {
    const attendee = DB.users.find(user => String(user.id) === String(registration.attendeeId)) || {
      name: '',
      email: '',
    };
    const event = DB.events.find(
      currentEvent => String(currentEvent.id) === String(registration.eventId)
    ) || {
      title: '',
    };
    const searchStr = `${registration.id} ${registration.ticketId || ''} ${attendee.name} ${
      attendee.email
    } ${event.title}`.toLowerCase();
    const matchesQuery = !query || searchStr.includes(query);
    const verifStatus =
      registration.verificationStatus ||
      (registration.status === 'confirmed' ? 'Verified' : 'Pending Review');
    let matchesStatus = !statusFilter || verifStatus === statusFilter;
    return matchesQuery && matchesStatus;
  });
  return `
        <div class="page-hd">
          <div class="page-hd-left">
            <div class="page-title">Online Registration Verification</div>
            <div class="page-sub">Review submitted registration details, approve identity verifications online, and flag incomplete submissions.</div>
          </div>
        </div>

        <div style="padding:12px 16px;background:var(--accent-dim);border:1px solid var(--accent);border-radius:8px;margin-bottom:20px;font-size:13px;color:var(--text)" class="flex items-center gap-10">
          <span>ℹ️</span>
          <span>Online Admin Workspace: Focuses strictly on online identity and registration detail verification. Physical check-in and venue scanning are handled on-site.</span>
        </div>

        <div class="filter-row">
          <div class="search-box input-group">
            <span class="input-icon">🔍</span>
            <input class="form-control" id="verif-q" placeholder="Search by Ticket ID, Attendee Name, or Event..." value="${query}" oninput="refreshVerificationPage()">
          </div>
          <select class="form-control filter-select" id="verif-st" onchange="refreshVerificationPage()">
            <option value="">All Verification Statuses</option>
            <option value="Pending Review" ${
              statusFilter === 'Pending Review' ? 'selected' : ''
            }>Pending Review</option>
            <option value="Verified" ${
              statusFilter === 'Verified' ? 'selected' : ''
            }>Verified</option>
            <option value="Flagged" ${
              statusFilter === 'Flagged' ? 'selected' : ''
            }>Flagged / Incomplete</option>
            <option value="Rejected" ${
              statusFilter === 'Rejected' ? 'selected' : ''
            }>Rejected</option>
          </select>
        </div>

        <div class="card">
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Registration ID</th>
                  <th>Attendee Info</th>
                  <th>Event</th>
                  <th>Submitted Proof / ID Document</th>
                  <th>Verification Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${
                  filtered
                    .map(r => {
                      const attendee = DB.users.find(
                        user => String(user.id) === String(r.attendeeId)
                      ) || {
                        name: 'Unknown User',
                        email: '—',
                        phone: '—',
                      };
                      const event = DB.events.find(
                        currentEvent => String(currentEvent.id) === String(r.eventId)
                      ) || {
                        title: 'Unknown Event',
                      };
                      const currentVerif =
                        r.verificationStatus ||
                        (r.status === 'confirmed' ? 'Verified' : 'Pending Review');
                      const isPending =
                        currentVerif === 'Pending Review' || currentVerif === 'Pending';
                      const docType = r.docType || 'Govt Aadhaar / Passport ID';
                      const docRef = r.docRef || 'REF-' + String(r.id).padStart(4, '0');
                      return `
                    <tr>
                      <td class="mono"><strong>${r.ticketId || r.id}</strong></td>
                      <td>
                        <div style="font-weight:700;font-size:13.5px;color:var(--text)">${
                          attendee.name
                        }</div>
                        <div class="small muted">${attendee.email}</div>
                      </td>
                      <td>${event.title}</td>
                      <td>
                        <div style="font-weight:600;font-size:13px;color:var(--accent)">📄 ${docType}</div>
                        <div class="small mono muted">Ref: ${docRef}</div>
                      </td>
                      <td>
                        <span class="badge badge-${
                          currentVerif === 'Verified'
                            ? 'green'
                            : currentVerif === 'Flagged'
                            ? 'yellow'
                            : currentVerif === 'Rejected'
                            ? 'red'
                            : 'purple'
                        }">${currentVerif}</span>
                      </td>
                      <td>
                        <div class="flex items-center gap-6">
                          <button class="btn btn-ghost btn-xs" onclick="openVerificationReviewModal('${
                            r.id
                          }')">Review</button>
                          ${
                            isPending
                              ? `
                            <button class="btn btn-success btn-xs" onclick="approveVerificationDirect('${r.id}')" title="Verify Online">✓ Verify</button>
                            <button class="btn btn-warning btn-xs" onclick="flagVerificationModal('${r.id}')" title="Flag Incomplete">🚩 Flag</button>
                          `
                              : ''
                          }
                        </div>
                      </td>
                    </tr>
                  `;
                    })
                    .join('') ||
                  '<tr><td colspan="6" class="text-center py-20">No registration verification records found.</td></tr>'
                }
              </tbody>
            </table>
          </div>
        </div>
      `;
}
function refreshVerificationPage() {
  sessionStorage.setItem('verif_query', v('verif-q'));
  sessionStorage.setItem('verif_status', v('verif-st'));
  renderPage('attendeeVerification');
}
function approveVerificationDirect(regId) {
  const registration = DB.registrations.find(item => String(item.id) === String(regId));
  if (!registration) return;
  registration.verificationStatus = 'Verified';
  registration.status = 'confirmed';
  registration.verified = true;
  saveDB();
  renderPage('attendeeVerification');
  toast('Online registration verified successfully!', 'success');
}
function flagVerificationModal(regId) {
  const registration = DB.registrations.find(item => String(item.id) === String(regId));
  if (!registration) return;
  openModal(
    `Flag Registration Details: ${registration.ticketId || registration.id}`,
    `
        <div class="form-group">
          <label class="form-label">Flag Reason / Missing Details *</label>
          <textarea class="form-control" id="flag-reason" rows="4" placeholder="Specify incomplete or incorrect registration information..."></textarea>
        </div>
      `,
    [
      {
        lbl: 'Submit Flag',
        cls: 'btn-warning',
        fn: `saveFlagVerification('${registration.id}')`,
      },
    ]
  );
}
function saveFlagVerification(regId) {
  const registration = DB.registrations.find(item => String(item.id) === String(regId));
  if (!registration) return;
  const reason = v('flag-reason');
  if (!reason) {
    toast('Please enter a flag reason', 'error');
    return;
  }
  registration.verificationStatus = 'Flagged';
  registration.flagReason = reason;
  saveDB();
  closeModal();
  renderPage('attendeeVerification');
  toast('Registration flagged for review!', 'warning');
}
function openVerificationReviewModal(regId) {
  const registration = DB.registrations.find(item => String(item.id) === String(regId));
  if (!registration) return;
  const attendee = DB.users.find(user => String(user.id) === String(registration.attendeeId)) || {
    name: 'Unknown User',
    email: '—',
    phone: '—',
  };
  const event = DB.events.find(
    currentEvent => String(currentEvent.id) === String(registration.eventId)
  ) || {
    title: 'Unknown Event',
  };
  const docType = registration.docType || 'Govt Aadhaar / Passport ID';
  const docRef = registration.docRef || 'REF-' + String(registration.id).padStart(4, '0');
  openModal(
    `Verification Review: ${registration.ticketId || registration.id}`,
    `
        <div class="info-row"><span class="info-label">Ticket ID</span><span class="info-value mono">${
          registration.ticketId || registration.id
        }</span></div>
        <div class="info-row"><span class="info-label">Attendee Name</span><span class="info-value"><strong>${
          attendee.name
        }</strong></span></div>
        <div class="info-row"><span class="info-label">Attendee Email</span><span class="info-value">${
          attendee.email
        }</span></div>
        <div class="info-row"><span class="info-label">Contact Phone</span><span class="info-value">${
          attendee.phone || '—'
        }</span></div>
        <div class="info-row"><span class="info-label">Event</span><span class="info-value">${
          event.title
        }</span></div>
        <div class="info-row"><span class="info-label">Submitted Document</span><span class="info-value" style="color:var(--accent);font-weight:700">📄 ${docType} (${docRef})</span></div>
        <div class="info-row"><span class="info-label">Verification Status</span><span class="info-value"><span class="badge badge-purple">${
          registration.verificationStatus || 'Pending Review'
        }</span></span></div>
        ${
          registration.notes
            ? `<div class="mt-12"><div class="label mb-6">Verification Notes</div><div style="padding:10px;background:var(--surface2);border-radius:8px;font-size:13px">${registration.notes}</div></div>`
            : ''
        }
        ${
          registration.flagReason
            ? `<div class="mt-12"><div class="label mb-6">Flag Reason / Missing Details</div><div style="padding:10px;background:var(--surface2);border-radius:8px;color:var(--yellow);font-size:13px">${registration.flagReason}</div></div>`
            : ''
        }
      `,
    [
      {
        lbl: 'Approve & Verify',
        cls: 'btn-success',
        fn: `closeModal();approveVerificationDirect('${registration.id}')`,
      },
      {
        lbl: 'Flag Information',
        cls: 'btn-warning',
        fn: `closeModal();flagVerificationModal('${registration.id}')`,
      },
    ]
  );
}
function pageRegVerificationReports() {
  const reports = DB.regReports || [];
  const typeFilter = sessionStorage.getItem('rvr_type') || '';
  const statusFilter = sessionStorage.getItem('rvr_status') || '';
  const totalSubmitted = reports.filter(
    report => report.status === 'Submitted' || report.status === 'Reviewed'
  ).length;
  const pendingReports = reports.filter(report => report.status === 'Draft').length;
  const reviewedReports = reports.filter(report => report.status === 'Reviewed').length;
  const filtered = reports.filter(report => {
    const matchType = !typeFilter || report.type === typeFilter;
    const matchStatus = !statusFilter || report.status === statusFilter;
    return matchType && matchStatus;
  });
  return `
        <div class="page-hd">
          <div class="page-hd-left">
            <div class="page-title">Registration &amp; User Management Reports</div>
            <div class="page-sub">Submit, view, and track registration and user management reports. Reports are submitted to Super Admin for review.</div>
          </div>
          <div class="page-hd-right">
            <button class="btn btn-primary" onclick="openCreateRegReportModal()">📤 Submit Report</button>
          </div>
        </div>

        <div class="grid-3 mb-20">
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--green-dim);color:var(--green)">📤</div>
            <div class="stat-value" style="color:var(--green)">${totalSubmitted}</div>
            <div class="stat-label">Reports Submitted</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--yellow-dim);color:var(--yellow)">📝</div>
            <div class="stat-value" style="color:var(--yellow)">${pendingReports}</div>
            <div class="stat-label">Draft / Pending</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--accent-dim);color:var(--accent)">✅</div>
            <div class="stat-value" style="color:var(--accent)">${reviewedReports}</div>
            <div class="stat-label">Reviewed by Admin</div>
          </div>
        </div>

        <div class="card">
          <div class="flex justify-between items-center mb-16">
            <div class="h4">All Reports</div>
            <div class="flex gap-8">
              <select class="form-control filter-select" id="rvr-type" onchange="refreshRvrPage()" style="width:200px">
                <option value="">All Report Types</option>
                <option value="Registration Report" ${
                  typeFilter === 'Registration Report' ? 'selected' : ''
                }>Registration Report</option>
                <option value="User Management Report" ${
                  typeFilter === 'User Management Report' ? 'selected' : ''
                }>User Management Report</option>
                <option value="Registration Activity Report" ${
                  typeFilter === 'Registration Activity Report' ? 'selected' : ''
                }>Registration Activity Report</option>
              </select>
              <select class="form-control filter-select" id="rvr-status" onchange="refreshRvrPage()" style="width:140px">
                <option value="">All Statuses</option>
                <option value="Draft" ${statusFilter === 'Draft' ? 'selected' : ''}>Draft</option>
                <option value="Submitted" ${
                  statusFilter === 'Submitted' ? 'selected' : ''
                }>Submitted</option>
                <option value="Reviewed" ${
                  statusFilter === 'Reviewed' ? 'selected' : ''
                }>Reviewed</option>
              </select>
            </div>
          </div>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Report</th>
                  <th>Type</th>
                  <th>Period</th>
                  <th>Attached File</th>
                  <th>Status</th>
                  <th>Last Updated</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                ${
                  filtered.length
                    ? filtered
                        .map(
                          r => `
                  <tr>
                    <td>
                      <div style="font-weight:700;font-size:13.5px;color:var(--text)">${
                        r.title
                      }</div>
                      <div class="small muted">ID: ${r.id} · By: ${r.owner}</div>
                    </td>
                    <td>
                      <span class="badge badge-${
                        r.type === 'Registration Report'
                          ? 'purple'
                          : r.type === 'User Management Report'
                          ? 'blue'
                          : 'orange'
                      }">${r.type}</span>
                    </td>
                    <td class="small">${r.period || '—'}</td>
                    <td>
                      ${
                        r.fileName
                          ? `<span style="font-weight:600;color:var(--accent);font-size:12.5px">📄 ${r.fileName}</span>`
                          : `<span class="small muted">No file attached</span>`
                      }
                    </td>
                    <td>
                      <span class="badge badge-${
                        r.status === 'Reviewed'
                          ? 'green'
                          : r.status === 'Submitted'
                          ? 'purple'
                          : 'yellow'
                      }">${r.status}</span>
                    </td>
                    <td class="small muted">${r.updated}</td>
                    <td>
                      <div class="flex gap-6">
                        <button class="btn btn-ghost btn-xs" onclick="viewRegReportModal('${
                          r.id
                        }')">View Details</button>
                        ${
                          r.status === 'Draft'
                            ? `<button class="btn btn-primary btn-xs" onclick="submitDraftReport('${r.id}')">📤 Submit</button>`
                            : ''
                        }
                      </div>
                    </td>
                  </tr>
                `
                        )
                        .join('')
                    : '<tr><td colspan="7" class="text-center py-20 muted">No reports found matching your filters.</td></tr>'
                }
              </tbody>
            </table>
          </div>
        </div>
      `;
}
function refreshRvrPage() {
  sessionStorage.setItem('rvr_type', v('rvr-type'));
  sessionStorage.setItem('rvr_status', v('rvr-status'));
  renderPage('reports');
}
function submitDraftReport(reportId) {
  const r = (DB.regReports || []).find(item => item.id === reportId);
  if (!r) return;
  if (!r.fileName) {
    toast('Please attach a file before submitting a draft report.', 'error');
    return;
  }
  r.status = 'Submitted';
  r.updated = 'Just now';
  saveDB();
  renderPage('reports');
  toast('Draft report submitted successfully!', 'success');
}
function viewRegReportModal(reportId) {
  const r = (DB.regReports || []).find(item => item.id === reportId);
  if (!r) return;
  openModal(
    `Report: ${r.title}`,
    `
        <div class="info-row"><span class="info-label">Report ID</span><span class="info-value mono">${
          r.id
        }</span></div>
        <div class="info-row"><span class="info-label">Report Type</span><span class="info-value"><span class="badge badge-purple">${
          r.type
        }</span></span></div>
        <div class="info-row"><span class="info-label">Reporting Period</span><span class="info-value">${
          r.period || '—'
        }</span></div>
        <div class="info-row"><span class="info-label">Submitted By</span><span class="info-value">${
          r.owner
        }</span></div>
        <div class="info-row"><span class="info-label">Status</span><span class="info-value"><span class="badge badge-${
          r.status === 'Reviewed' ? 'green' : r.status === 'Submitted' ? 'purple' : 'yellow'
        }">${r.status}</span></span></div>
        <div class="info-row"><span class="info-label">Last Updated</span><span class="info-value">${
          r.updated
        }</span></div>
        <div class="info-row"><span class="info-label">Attached File</span><span class="info-value" style="color:var(--accent);font-weight:700">${
          r.fileName ? '📄 ' + r.fileName : 'No file attached'
        }</span></div>
      `,
    r.status === 'Draft'
      ? [
          {
            lbl: '📤 Submit Report',
            cls: 'btn-primary',
            fn: `closeModal();submitDraftReport('${r.id}')`,
          },
        ]
      : []
  );
}
window.handleRegReportFileSelect = function (input) {
  const preview = document.getElementById('rv-file-preview');
  if (input.files && input.files[0]) {
    const f = input.files[0];
    if (preview) {
      globalThis.window?.EventFlowClientPages?.clear(preview);
      preview.innerHTML = `
            <div class="flex items-center justify-between" style="background:var(--accent-dim);border-radius:8px;padding:10px 14px">
              <div style="font-weight:600;color:var(--accent);font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">📄 ${
                f.name
              } (${(f.size / 1024).toFixed(1)} KB)</div>
              <button type="button" class="btn btn-danger btn-xs" onclick="event.stopPropagation();resetRegReportFileSelect()">✕ Remove</button>
            </div>
          `;
    }
  }
};
window.resetRegReportFileSelect = function () {
  const input = document.getElementById('rv-file');
  if (input) input.value = '';
  const preview = document.getElementById('rv-file-preview');
  if (preview) {
    globalThis.window?.EventFlowClientPages?.clear(preview);
    preview.innerHTML = `
          <div style="font-size:24px;margin-bottom:6px">📁</div>
          <div style="font-weight:600;font-size:13.5px">Click to browse or upload report file</div>
          <div class="small muted">Supported formats: PDF, DOC, DOCX, XLS, XLSX</div>
        `;
  }
};
function openCreateRegReportModal() {
  openModal(
    '📤 Submit Registration & User Management Report',
    `
        <div class="form-group">
          <label class="form-label">Report Type *</label>
          <select class="form-control" id="rv-type">
            <option value="Registration Report">Registration Report</option>
            <option value="User Management Report">User Management Report</option>
            <option value="Registration Activity Report">Registration Activity Report</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Report Title *</label>
          <input class="form-control" id="rv-title" placeholder="e.g. August 2026 Online Registration Completion Report">
        </div>
        <div class="form-group">
          <label class="form-label">Reporting Period *</label>
          <input class="form-control" id="rv-period" placeholder="e.g. August 2026, Q3 2026, Week 34">
        </div>
        <div class="form-group">
          <label class="form-label">Upload Report *</label>
          <div class="file-upload-box" style="border:2px dashed var(--border);border-radius:10px;padding:20px;text-align:center;background:var(--surface2);cursor:pointer" onclick="document.getElementById('rv-file').click()">
            <input type="file" id="rv-file" accept=".pdf,.doc,.docx,.xls,.xlsx" style="display:none" onchange="handleRegReportFileSelect(this)">
            <div id="rv-file-preview">
              <div style="font-size:24px;margin-bottom:6px">📁</div>
              <div style="font-weight:600;font-size:13.5px">Click to browse or upload report file</div>
              <div class="small muted">Supported formats: PDF, DOC, DOCX, XLS, XLSX</div>
            </div>
          </div>
        </div>
      `,
    [
      {
        lbl: 'Cancel',
        cls: 'btn-ghost',
        fn: 'closeModal()',
      },
      {
        lbl: '📤 Submit Report',
        cls: 'btn-primary',
        fn: 'saveRegReportSubmit()',
      },
    ]
  );
}
function saveRegReportSubmit() {
  const type = v('rv-type');
  const title = v('rv-title');
  const period = v('rv-period');
  const fileInput = document.getElementById('rv-file');
  if (!title) {
    toast('Please enter a report title', 'error');
    return;
  }
  if (!period) {
    toast('Please specify a reporting period', 'error');
    return;
  }
  if (!fileInput || !fileInput.files || !fileInput.files.length) {
    toast('Please upload a report file', 'error');
    return;
  }
  const file = fileInput.files[0];
  const newReport = {
    id: `RVR-${Date.now().toString().slice(-4)}`,
    type: type,
    title: title,
    period: period,
    fileName: file.name,
    owner: CU.name || 'Arjun Kapoor',
    status: 'Submitted',
    updated: 'Just now',
  };
  if (!DB.regReports) DB.regReports = [];
  DB.regReports.unshift(newReport);
  saveDB();
  closeModal();
  renderPage('reports');
  toast('Report submitted successfully!', 'success');
}
function buildEmployeeChanges(changes) {
  if (changes.length === 0)
    return `<div class="empty"><div class="empty-icon">🔍</div><div class="empty-title">No changes found</div><p class="empty-desc">Try a different search.</p></div>`;
  return changes
    .map(
      item =>
        `<div class="card" style="padding:14px 16px"><div class="flex justify-between items-start gap-8"><div style="display:flex;gap:10px;align-items:flex-start"><div class="stat-icon" style="width:30px;height:30px;min-width:30px;font-size:14px;margin:0;background:var(--accent-dim);color:var(--accent)">${
          item.icon || '•'
        }</div><div><div style="font-weight:700;color:var(--text);font-size:13.5px">${
          item.title || 'Activity update'
        }</div><div style="font-size:13px;color:var(--text2);line-height:1.5;margin-top:3px">${
          item.msg || 'A record was updated.'
        }</div></div></div><span class="small" style="white-space:nowrap;color:var(--text3)">${
          item.time || 'Recently'
        }</span></div></div>`
    )
    .join('');
}
function searchEmployeeChanges(query) {
  sessionStorage.setItem('employee_changes_search', query);
  const changesQuery = query.toLowerCase();
  const changes = DB.notifications
    .filter(item =>
      `${item.title || ''} ${item.msg || ''} ${item.time || ''}`
        .toLowerCase()
        .includes(changesQuery)
    )
    .slice(0, 12);
  globalThis.window?.EventFlowClientPages?.clear(g('employee-recent-changes'));
  g('employee-recent-changes').innerHTML = buildEmployeeChanges(changes);
}
function completeEmployeeChangeRequest(requestId) {
  const request = (DB.employeeChangeRequests || []).find(
    item => String(item.id) === String(requestId)
  );
  if (!request) return;
  request.status = 'completed';
  request.completedAt = new Date().toLocaleString();
  saveDB();
  renderPage('dashboard');
  toast('Change request marked as done', 'success');
}
function dashOrganizer() {
  const myEv = DB.events.filter(event => String(event.organizer) === String(CU.id));
  const upcoming = myEv.filter(e => e.status === 'upcoming');
  const totalAttendees = DB.registrations.filter(registration =>
    myEv.some(e => String(e.id) === String(registration.eventId))
  ).length;
  const searchQuery = (sessionStorage.getItem('org_events_search') || '').toLowerCase();
  const filteredEvents = myEv.filter(
    e =>
      !searchQuery ||
      e.title.toLowerCase().includes(searchQuery) ||
      e.city.toLowerCase().includes(searchQuery)
  );
  return `
  <div class="page-hd">
    <div class="page-hd-left"><div class="page-title">${
      isEmployeeAccount() ? 'Employee Dashboard' : 'Organizer Dashboard'
    }</div><div class="page-sub">Hello ${CU.name}, manage your events.</div></div>
    <div class="page-hd-right">${
      isEmployeeAccount()
        ? ''
        : '<button class="btn btn-primary" onclick="openAddEventModal()">+ Create Event</button>'
    }</div>
  </div>
  <div class="grid-4 mb-20">
    <div class="stat-card"><div class="stat-icon" style="background:var(--accent-dim);color:var(--accent)">🗓️</div><div class="stat-value" style="color:var(--accent)">${
      myEv.length
    }</div><div class="stat-label">My Events</div><div class="stat-sub neutral">${
    upcoming.length
  } upcoming</div></div>
    <div class="stat-card"><div class="stat-icon" style="background:var(--green-dim);color:var(--green)">👥</div><div class="stat-value" style="color:var(--green)">${totalAttendees}</div><div class="stat-label">Total Attendees</div><div class="stat-sub up">↑ 5 this week</div></div>
        <div class="stat-card"><div class="stat-icon" style="background:var(--blue-dim);color:var(--blue)">📋</div><div class="stat-value" style="color:var(--blue)">${
          DB.eventRequests.filter(
            request => String(request.organizer) === String(CU.id) && request.status === 'in_review'
          ).length
        }</div><div class="stat-label">Plans in Review</div><div class="stat-sub neutral">With clients</div></div>
  </div>
  <div class="mb-16">
    <div class="mb-12 flex justify-between items-center"><span class="h4">My Events</span></div>
    <div class="search-box input-group" style="margin-bottom:16px"><span class="input-icon">🔍</span><input class="form-control" id="org-events-search" placeholder="Search by event name or city..." value="${searchQuery}" oninput="searchOrganizerEvents(this.value)"></div>
    <div class="events-grid">${
      filteredEvents.length > 0
        ? filteredEvents.map(event => evCard(event, 'organizer')).join('')
        : myEv.length > 0
        ? `<div class="empty" style="grid-column:1/-1"><div class="empty-icon">🔍</div><div class="empty-title">No events match</div><p>Try adjusting your search</p></div>`
        : isEmployeeAccount()
        ? `<div class="empty" style="grid-column:1/-1"><div class="empty-icon">📅</div><div class="empty-title">No events assigned</div><p>Assigned events will appear here.</p></div>`
        : `<div class="ev-card" style="display:flex;align-items:center;justify-content:center;min-height:240px;border-style:dashed;cursor:pointer" onclick="openAddEventModal()"><div class="text-center" style="color:var(--text3)"><div style="font-size:32px;margin-bottom:8px">➕</div><div style="font-size:13px">Create Your First Event</div></div></div>`
    }
      ${
        myEv.length > 0 && !isEmployeeAccount()
          ? `<div class="ev-card" style="display:flex;align-items:center;justify-content:center;min-height:240px;border-style:dashed;cursor:pointer" onclick="openAddEventModal()"><div class="text-center" style="color:var(--text3)"><div style="font-size:32px;margin-bottom:8px">➕</div><div style="font-size:13px">Create New Event</div></div></div>`
          : ''
      }
    </div>
  </div>`;
}
function searchOrganizerEvents(query) {
  sessionStorage.setItem('org_events_search', query);
  renderPage('dashboard');
}
function dashClient() {
  const clientRequests = DB.eventRequests.filter(
    request => String(request.clientId) === String(CU.id)
  );
  const approvedCount = clientRequests.filter(request => request.status === 'approved').length;
  const inProgressCount = clientRequests.filter(request =>
    ['pending', 'in_review'].includes(request.status)
  ).length;
  const proposalCount = clientRequests.filter(request => request.status === 'proposal_sent').length;
  return `
  <div class="page-hd">
    <div class="page-hd-left"><div class="page-title">Client Dashboard</div><div class="page-sub">Track your event requests and upcoming events.</div></div>
    <div class="page-hd-right"><button class="btn btn-primary" onclick="goNav('find-organizers')">+ New Request</button></div>
  </div>
  <div class="grid-3 mb-20">
    <div class="stat-card"><div class="stat-icon" style="background:var(--accent-dim);color:var(--accent)">📋</div><div class="stat-value" style="color:var(--accent)">${
      clientRequests.length
    }</div><div class="stat-label">Total Requests</div></div>
    <div class="stat-card"><div class="stat-icon" style="background:var(--green-dim);color:var(--green)">✅</div><div class="stat-value" style="color:var(--green)">${approvedCount}</div><div class="stat-label">Approved</div></div>
    <div class="stat-card"><div class="stat-icon" style="background:var(--yellow-dim);color:var(--yellow)">⏳</div><div class="stat-value" style="color:var(--yellow)">${inProgressCount}</div><div class="stat-label">In Progress</div></div>
  </div>
  ${
    proposalCount > 0
      ? `
  <div style="background:rgba(99,102,241,0.12);border:1px solid var(--accent);border-radius:12px;padding:16px 20px;margin-bottom:20px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
    <div>
      <div style="font-weight:700;font-size:15px;color:var(--text)">📝 Proposal Received!</div>
      <div style="font-size:13px;color:var(--text2)">You have ${proposalCount} event proposal(s) awaiting your review.</div>
    </div>
    <button class="btn btn-primary" onclick="goNav('request-status')">Review Proposals</button>
  </div>`
      : ''
  }
  <div class="card" id="client-upcoming-events" aria-live="polite" style="margin-bottom:20px">
    <div class="h4 mb-12">Upcoming Events</div>
    <div class="small" style="color:var(--text3)">Loading your upcoming events…</div>
  </div>
  <div class="card" id="client-recent-activity" aria-live="polite">
    <div class="h4 mb-12">Recent Activity</div>
    <div class="small" style="color:var(--text3)">Loading your recent activity…</div>
  </div>
  `;
}
function clientActivityPage(target) {
  const resource = String(target.resource || '').toLowerCase();
  if (resource.includes('notification')) return ['notifications', 'View notifications'];
  return ['request-status', 'View request status'];
}
function clientUpcomingEventDate(event) {
  const date = new Date(`${event.date}T00:00:00`);
  if (Number.isNaN(date.getTime()))
    return `${event.date || 'Date TBD'}${event.time ? ` · ${event.time}` : ''}`;
  const formattedDate = new Intl.DateTimeFormat(undefined, {
    dateStyle: 'medium',
  }).format(date);
  return `${formattedDate}${event.time ? ` · ${event.time}` : ''}`;
}
async function loadClientUpcomingEvents() {
  if (globalThis.window?.EventFlowClientPages?.isCurrentPage('dashboard')) return;
  const container = g('client-upcoming-events');
  if (!container) return;
  try {
    const events = DB.events
      .filter(
        event =>
          event.backendStatus === 'published' &&
          event.visibility !== 'private' &&
          !event.backendClientId &&
          !event.clientId &&
          new Date(`${event.date}T23:59:59`).getTime() >= Date.now()
      )
      .sort((leftEvent, rightEvent) =>
        `${leftEvent.date}T${leftEvent.time}`.localeCompare(`${rightEvent.date}T${rightEvent.time}`)
      );
    if (!g('client-upcoming-events')) return;
    if (events.length === 0) {
      globalThis.window?.EventFlowClientPages?.clear(container);
      container.innerHTML = `<div class="h4 mb-12">Upcoming Events</div><div class="empty" style="padding:20px 0"><div class="empty-title">No upcoming events</div><div class="empty-desc">Published future events will appear here.</div></div>`;
      return;
    }
    globalThis.window?.EventFlowClientPages?.clear(container);
    container.innerHTML = `<div class="h4 mb-12">Upcoming Events</div><div style="display:flex;flex-direction:column;gap:0">${events
      .map(
        event =>
          `<div class="flex justify-between items-center gap-10" style="padding:12px 0;border-bottom:1px solid var(--border)"><div style="min-width:0"><div style="font-weight:600;font-size:13.5px">${escapeHtml(
            event.title || 'Event'
          )}</div><div class="small" style="color:var(--text2)">${escapeHtml(
            clientUpcomingEventDate(event)
          )}${
            event.location ? ` · ${escapeHtml(event.location)}` : ''
          }</div></div><button class="btn btn-ghost btn-xs" onclick="viewClientPublishedEvent('${escapeHtml(
            event.id
          )}')">View Event</button></div>`
      )
      .join('')}</div>`;
  } catch (error) {
    if (!g('client-upcoming-events')) return;
    globalThis.window?.EventFlowClientPages?.clear(container);
    container.innerHTML = `<div class="h4 mb-12">Upcoming Events</div><div class="empty" style="padding:20px 0"><div class="empty-title">Unable to load upcoming events</div><div class="empty-desc">Please try again.</div><button class="btn btn-ghost btn-sm mt-12" onclick="refreshClientUpcomingEvents()">Retry</button></div>`;
  }
}
window.refreshClientUpcomingEvents = loadClientUpcomingEvents;
function viewClientPublishedEvent(eventId) {
  const event = DB.events.find(
    item =>
      String(item.id) === String(eventId) &&
      item.backendStatus === 'published' &&
      item.visibility !== 'private' &&
      !item.backendClientId &&
      !item.clientId
  );
  if (!event) return toast('Event is no longer available.', 'error');
  openModal(
    escapeHtml(event.title),
    `<div class="info-row"><span class="info-label">Date</span><span class="info-value">${escapeHtml(
      clientUpcomingEventDate(event)
    )}</span></div>
        <div class="info-row"><span class="info-label">Venue</span><span class="info-value">${escapeHtml(
          event.venue || ''
        )}</span></div>
        <div class="info-row"><span class="info-label">Category</span><span class="info-value">${escapeHtml(
          event.category || ''
        )}</span></div>
        <p>${escapeHtml(event.description || '')}</p>`,
    [
      {
        lbl: 'Close',
        cls: 'btn-ghost',
        fn: 'closeModal()',
      },
    ]
  );
}
function clientActivityTime(timestamp) {
  const date = new Date(timestamp);
  if (Number.isNaN(date.getTime())) return 'Recently';
  return new Intl.DateTimeFormat(undefined, {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(date);
}

// Map snake_case action codes -> human-readable label + icon
const CLIENT_ACTIVITY_MAP = {
  event_request_submitted: {
    label: 'Event request submitted',
    icon: '📋',
  },
  request_review_started: {
    label: 'Organizer started review',
    icon: '🔍',
  },
  request_accepted_by_organizer: {
    label: 'Organizer accepted your request',
    icon: '✅',
  },
  request_rejected_by_organizer: {
    label: 'Organizer declined your request',
    icon: '❌',
  },
  info_requested_by_organizer: {
    label: 'Organizer requested more info',
    icon: '❓',
  },
  info_provided_by_client: {
    label: 'Additional info provided',
    icon: '📝',
  },
  proposal_sent: {
    label: 'Organizer proposal received',
    icon: '📄',
  },
  proposal_revised: {
    label: 'Revised proposal received',
    icon: '📄',
  },
  client_proposal_accepted: {
    label: 'Proposal accepted',
    icon: '✅',
  },
  revision_requested_by_client: {
    label: 'Proposal revision requested',
    icon: '🔄',
  },
  agreement_status_updated: {
    label: 'Agreement signed',
    icon: '✍️',
  },
  deposit_payment_completed: {
    label: 'Deposit payment confirmed',
    icon: '💳',
  },
  booking_confirmed: {
    label: 'Booking confirmed',
    icon: '🎉',
  },
  request_withdrawn: {
    label: 'Request withdrawn',
    icon: '↩️',
  },
  request_cancelled: {
    label: 'Request cancelled',
    icon: '🚫',
  },
  modification_requested: {
    label: 'Event modification requested',
    icon: '✏️',
  },
  modification_responded: {
    label: 'Modification response received',
    icon: '✏️',
  },
  counteroffer_sent: {
    label: 'Counteroffer submitted',
    icon: '🔄',
  },
};
function clientActivityLabel(activity) {
  const detailDesc = (activity.details && activity.details.description) || activity.description;
  if (detailDesc) return escapeHtml(detailDesc);
  const mapped = CLIENT_ACTIVITY_MAP[activity.action];
  if (mapped) return escapeHtml(mapped.label);
  const action = String(activity.action || 'Activity update')
    .replace(/[_-]+/g, ' ')
    .replace(/\b\w/g, char => char.toUpperCase());
  return escapeHtml(action);
}
function clientActivityIcon(action) {
  return (CLIENT_ACTIVITY_MAP[action] || {}).icon || '🔔';
}
async function openClientRequestFromActivity(requestId) {
  try {
    await syncClientEventRequests();
  } catch (e) {
    console.warn('Sync requests error:', e);
  }
  goNav('request-status');
  if (requestId) {
    setTimeout(() => {
      const req = DB.eventRequests.find(
        request =>
          String(request.id) === String(requestId) ||
          String(request.requestId) === String(requestId)
      );
      if (req) {
        viewRequestDrawer(req.id || requestId);
      }
    }, 80);
  }
}
if (typeof window !== 'undefined')
  window.openClientRequestFromActivity = openClientRequestFromActivity;
async function loadClientRecentActivity() {
  if (globalThis.window?.EventFlowClientPages?.isCurrentPage('dashboard')) return;
  const container = g('client-recent-activity');
  if (!container) return;

  // Show skeleton while loading
  globalThis.window?.EventFlowClientPages?.clear(container);
  container.innerHTML =
    '<div class="h4 mb-12">Recent Activity</div><div style="display:flex;flex-direction:column;gap:0">' +
    [1, 2, 3]
      .map(function () {
        return '<div style="padding:12px 0;border-bottom:1px solid var(--border)"><div style="height:14px;width:65%;background:var(--surface2);border-radius:4px;margin-bottom:6px;animation:pulse 1.5s infinite"></div><div style="height:11px;width:40%;background:var(--surface2);border-radius:4px;animation:pulse 1.5s infinite"></div></div>';
      })
      .join('') +
    '</div>';
  try {
    const response = await apiGetMyActivity(8);
    const rawActs = Array.isArray(response) ? response : (response && response.logs) || [];
    const activities = [...rawActs].sort((a, b) => {
      const tA = a.timestamp
        ? new Date(a.timestamp).getTime()
        : a.createdAt
        ? new Date(a.createdAt).getTime()
        : 0;
      const tB = b.timestamp
        ? new Date(b.timestamp).getTime()
        : b.createdAt
        ? new Date(b.createdAt).getTime()
        : 0;
      if (tB !== tA) return tB - tA;
      return String(b.id || '').localeCompare(String(a.id || ''));
    });
    if (!g('client-recent-activity')) return;
    if (activities.length === 0) {
      globalThis.window?.EventFlowClientPages?.clear(container);
      container.innerHTML =
        '<div class="h4 mb-12">Recent Activity</div><div class="empty" style="padding:20px 0"><div class="empty-icon">📭</div><div class="empty-title">No recent activity</div><div class="empty-desc">Updates to your event requests will appear here.</div></div>';
      return;
    }
    const rows = activities.map(function (activity) {
      const details = activity.details || {};
      const desc = details.description || activity.description || clientActivityLabel(activity);
      const eventName = details.eventName || activity.eventName || '';
      const amount = details.amount || activity.amount || 0;
      const reqId = details.requestId || activity.requestId || '';
      const icon = clientActivityIcon(activity.action);
      const amountStr = amount ? '\u20b9' + Number(amount).toLocaleString('en-IN') : '';
      const actionStatusMap = {
        event_request_submitted: 'submitted',
        request_rejected_by_organizer: 'rejected',
        request_withdrawn: 'withdrawn',
        request_cancelled: 'cancelled',
        booking_confirmed: 'confirmed',
        deposit_payment_completed: 'active',
        client_proposal_accepted: 'active',
        agreement_status_updated: 'active',
      };
      const badgeStatus = actionStatusMap[activity.action] || activity.status || 'active';
      const badgeClass = reqBadge(badgeStatus);
      const clickFn = reqId
        ? "openClientRequestFromActivity('" + escapeHtml(reqId) + "')"
        : "goNav('request-status')";
      return (
        '<div class="flex justify-between items-center gap-10" style="padding:12px 0;border-bottom:1px solid var(--border)">' +
        '<div style="min-width:0;flex:1;display:flex;align-items:flex-start;gap:10px">' +
        '<span style="font-size:18px;flex-shrink:0;margin-top:2px">' +
        icon +
        '</span>' +
        '<div style="min-width:0;flex:1">' +
        '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">' +
        '<span style="font-weight:600;font-size:13.5px;color:var(--text)">' +
        escapeHtml(desc) +
        '</span>' +
        '<span class="badge badge-' +
        badgeClass +
        '" style="font-size:10.5px;padding:2px 6px">' +
        escapeHtml(badgeStatus.replace(/_/g, ' ')) +
        '</span>' +
        '</div>' +
        '<div class="small" style="color:var(--text2);margin-top:3px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">' +
        (amountStr
          ? '<span style="color:var(--green);font-weight:600">' + escapeHtml(amountStr) + '</span>'
          : '') +
        '<time datetime="' +
        escapeHtml(String(activity.timestamp || '')) +
        '" style="color:var(--text3)">' +
        escapeHtml(clientActivityTime(activity.timestamp)) +
        '</time>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<button class="btn btn-ghost btn-xs" style="white-space:nowrap;margin-left:8px;flex-shrink:0" onclick="' +
        clickFn +
        '">View Request Status</button>' +
        '</div>'
      );
    });
    globalThis.window?.EventFlowClientPages?.clear(container);
    container.innerHTML =
      '<div class="h4 mb-12">Recent Activity</div><div style="display:flex;flex-direction:column;gap:0">' +
      rows.join('') +
      '</div>';
  } catch (error) {
    if (!g('client-recent-activity')) return;
    globalThis.window?.EventFlowClientPages?.clear(container);
    container.innerHTML =
      '<div class="h4 mb-12">Recent Activity</div><div class="empty" style="padding:20px 0"><div class="empty-icon">⚠️</div><div class="empty-title">Unable to load activity</div><div class="empty-desc">Please try again later.</div><button class="btn btn-ghost btn-sm mt-12" onclick="refreshClientRecentActivity()">Retry</button></div>';
  }
}
window.refreshClientRecentActivity = loadClientRecentActivity;
function dashAttendee() {
  const myRegs = DB.registrations.filter(
    registration => String(registration.attendeeId) === String(CU.id)
  );
  const upcoming = myRegs.filter(registration => {
    const event = DB.events.find(
      currentEvent => String(currentEvent.id) === String(registration.eventId)
    );
    return event && ['upcoming', 'full', 'ongoing'].includes(event.status);
  });
  const totalSpent = myRegs.reduce((total, registration) => total + registration.amount, 0);
  return `
  <div class="page-hd">
    <div class="page-hd-left"><div class="page-title">My Dashboard</div><div class="page-sub">Welcome back, ${
      CU.name
    }! Here are your upcoming events.</div></div>
    <div class="page-hd-right"><button class="btn btn-primary" onclick="goNav('browse-events')">🔍 Browse Events</button></div>
  </div>
  <div class="grid-3 mb-20">
    <div class="stat-card"><div class="stat-icon" style="background:var(--accent-dim);color:var(--accent)">🎟️</div><div class="stat-value" style="color:var(--accent)">${
      myRegs.length
    }</div><div class="stat-label">Registered Events</div></div>
    <div class="stat-card"><div class="stat-icon" style="background:var(--green-dim);color:var(--green)">📅</div><div class="stat-value" style="color:var(--green)">${
      upcoming.length
    }</div><div class="stat-label">Upcoming</div></div>
    <div class="stat-card"><div class="stat-icon" style="background:var(--yellow-dim);color:var(--yellow)">💳</div><div class="stat-value" style="color:var(--yellow)">₹${totalSpent}</div><div class="stat-label">Total Spent</div></div>
  </div>
  ${
    upcoming.length > 0
      ? `<div class="h4 mb-16">Upcoming Events</div>
  <div class="events-grid">${upcoming
    .map(currentEvent => {
      const event = DB.events.find(ev => String(ev.id) === String(currentEvent.eventId));
      return event ? evCard(event, 'attendee', currentEvent) : '';
    })
    .join('')}</div>
  <div style="display:flex;flex-direction:column;gap:12px;margin-top:24px">
    ${upcoming
      .map(currentEvent => {
        const event = DB.events.find(ev => String(ev.id) === String(currentEvent.eventId));
        return event
          ? `<div class="card p-0" style="display:flex;justify-content:space-between;align-items:center;padding:16px">
      <div><div style="font-weight:600">${event.title}</div><div class="small">${currentEvent.ticketId}</div></div>
      <button class="btn btn-danger btn-xs" onclick="cancelTicket('${currentEvent.id}')">✕ Cancel Ticket</button>
    </div>`
          : '';
      })
      .join('')}
  </div>`
      : `
  <div class="empty"><div class="empty-icon">🎟️</div><div class="empty-title">No upcoming events</div><div class="empty-desc">Browse and register for events to see them here.</div><button class="btn btn-primary mt-16" onclick="goNav('browse-events')">Browse Events</button></div>`
  }
  <div class="h4 mb-16 mt-24">Recommended For You</div>
  <div class="events-grid">${DB.events
    .filter(
      event =>
        event.status === 'upcoming' &&
        !myRegs.some(registration => String(registration.eventId) === String(event.id))
    )
    .slice(0, 3)
    .map(event => evCard(event, 'attendee'))
    .join('')}</div>
  ${
    myRegs.length > 0
      ? `<div class="h4 mb-12 mt-24">Recent Activity</div>
  <div class="card p-0">
    ${myRegs
      .slice(-3)
      .reverse()
      .map(registration => {
        const eventRegistration = DB.events.find(
          event => String(event.id) === String(registration.eventId)
        ) || {
          title: 'Event',
          emoji: '🎟️',
        };
        return `
      <div class="flex items-center justify-between" style="padding:12px 16px;border-bottom:1px solid var(--border)">
        <div class="flex items-center gap-10"><span style="font-size:22px">${
          eventRegistration.emoji
        }</span>
          <div><div style="font-size:13.5px;font-weight:500">${
            eventRegistration.title
          }</div><div class="small">${registration.ticketId} · ${registration.date}</div></div>
        </div>
        <div class="text-right"><div style="font-weight:600;color:var(--green)">${
          registration.amount === 0 ? 'Free' : '₹' + registration.amount
        }</div>
          <span class="badge badge-${registration.checkedIn ? 'green' : 'purple'}">${
          registration.checkedIn ? 'Attended' : 'Registered'
        }</span>
        </div>
      </div>`;
      })
      .join('')}
  </div>`
      : ''
  }`;
}

// ════════════════════════════════════════════════
//  ADMIN SUBPAGE 1: USER REPORTS (BAR GRAPHS)
// ════════════════════════════════════════════════
function filterUserReports(role) {
  sessionStorage.setItem('admin_user_filter_role', role);
  renderPage('user-reports');
}
function pageUserReports() {
  const selectedRole = sessionStorage.getItem('admin_user_filter_role') || 'all';
  const allUsers = DB.users;
  const usersToAnalyze =
    selectedRole === 'all' ? allUsers : allUsers.filter(u => u.role === selectedRole);
  const totalUsers = usersToAnalyze.length;
  const activeUsers = usersToAnalyze.filter(u => u.status === 'active').length;
  const inactiveUsers = totalUsers - activeUsers;
  const activeRate = totalUsers > 0 ? Math.round((activeUsers / totalUsers) * 100) : 0;
  const inactiveRate = totalUsers > 0 ? Math.round((inactiveUsers / totalUsers) * 100) : 0;
  const roles = ['attendee', 'employee', 'client', 'organizer', 'superuser'];
  const roleBreakdown = roles.map(role => {
    const list = allUsers.filter(u => u.role === role);
    const active = list.filter(u => u.status === 'active').length;
    const inactive = list.length - active;
    return {
      role,
      label: ROLE_LABELS[role] || role,
      total: list.length,
      active,
      inactive,
      activePct: list.length > 0 ? Math.round((active / list.length) * 100) : 0,
    };
  });

  // 1. Monthly Joining Trends Bar Graph (Past 6 months)
  const monthNames = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  const monthlyBuckets = {};
  const now = new Date();
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    monthlyBuckets[key] = {
      label: monthNames[d.getMonth()],
      count: 0,
    };
  }
  usersToAnalyze.forEach(u => {
    const joinedStr = (u.joined || u.createdAt || '').toString();
    const match = joinedStr.match(/(\d{4}-\d{2})/);
    if (match && monthlyBuckets[match[1]]) {
      monthlyBuckets[match[1]].count++;
    }
  });
  const monthBars = Object.values(monthlyBuckets).map((m, index) => ({
    label: m.label,
    value: m.count,
    color: [
      'linear-gradient(180deg, #22c55e, #15803d)',
      'linear-gradient(180deg, #3b82f6, #1d4ed8)',
      'linear-gradient(180deg, #8b5cf6, #7c3aed)',
      'linear-gradient(180deg, #f59e0b, #d97706)',
      'linear-gradient(180deg, #06b6d4, #0891b2)',
      'linear-gradient(180deg, #ec4899, #be185d)',
    ][index % 6],
  }));

  // 2. Grouped Active vs Inactive Bar Graph by Role
  const activeInactiveGroups = roleBreakdown.map(r => ({
    label: r.label,
    bars: [
      {
        label: 'Active',
        value: r.active,
        color: 'linear-gradient(180deg, #22c55e, #15803d)',
      },
      {
        label: 'Inactive',
        value: r.inactive,
        color: 'linear-gradient(180deg, #ef4444, #b91c1c)',
      },
    ],
  }));

  // 3. User Role Distribution Bar Graph
  const roleBars = [
    {
      label: 'Attendees',
      value: allUsers.filter(u => u.role === 'attendee').length,
      color: 'linear-gradient(180deg, #8b5cf6, #7c3aed)',
    },
    {
      label: 'Employees',
      value: allUsers.filter(u => u.role === 'employee').length,
      color: 'linear-gradient(180deg, #22c55e, #15803d)',
    },
    {
      label: 'Clients',
      value: allUsers.filter(u => u.role === 'client').length,
      color: 'linear-gradient(180deg, #f59e0b, #d97706)',
    },
    {
      label: 'Organizers',
      value: allUsers.filter(u => u.role === 'organizer').length,
      color: 'linear-gradient(180deg, #3b82f6, #1d4ed8)',
    },
    {
      label: 'Admins',
      value: allUsers.filter(u => u.role === 'superuser').length,
      color: 'linear-gradient(180deg, #ef4444, #b91c1c)',
    },
  ];

  // 4. Role Activity Rate % Bar Graph
  const activityRateBars = roleBreakdown.map((r, index) => ({
    label: r.label,
    value: r.activePct,
    color: [
      'linear-gradient(180deg, #8b5cf6, #7c3aed)',
      'linear-gradient(180deg, #22c55e, #15803d)',
      'linear-gradient(180deg, #f59e0b, #d97706)',
      'linear-gradient(180deg, #3b82f6, #1d4ed8)',
      'linear-gradient(180deg, #ef4444, #b91c1c)',
    ][index % 5],
  }));
  return `
  <div class="page-hd">
    <div class="page-hd-left">
      <div class="page-title">User Reports & Analytics</div>
      <div class="page-sub">Visual bar graphs: monthly registrations, active vs inactive users, and role distributions.</div>
    </div>
    <div class="page-hd-right">
      <div style="display:flex;gap:6px;background:var(--surface2);padding:4px;border-radius:10px;border:1px solid var(--border)">
        <button class="btn btn-xs ${
          selectedRole === 'all' ? 'btn-primary' : 'btn-ghost'
        }" onclick="filterUserReports('all')">All Roles</button>
        <button class="btn btn-xs ${
          selectedRole === 'attendee' ? 'btn-primary' : 'btn-ghost'
        }" onclick="filterUserReports('attendee')">Attendees</button>
        <button class="btn btn-xs ${
          selectedRole === 'employee' ? 'btn-primary' : 'btn-ghost'
        }" onclick="filterUserReports('employee')">Employees</button>
        <button class="btn btn-xs ${
          selectedRole === 'client' ? 'btn-primary' : 'btn-ghost'
        }" onclick="filterUserReports('client')">Clients</button>
        <button class="btn btn-xs ${
          selectedRole === 'organizer' ? 'btn-primary' : 'btn-ghost'
        }" onclick="filterUserReports('organizer')">Organizers</button>
      </div>
    </div>
  </div>

  <!-- Key Metric Summary Cards -->
  <div class="grid-4 mb-20">
    <div class="stat-card">
      <div class="glow" style="background:var(--accent)"></div>
      <div class="stat-icon" style="background:var(--accent-dim);color:var(--accent)">👥</div>
      <div class="stat-value" style="color:var(--accent)">${totalUsers}</div>
      <div class="stat-label">Total ${
        selectedRole === 'all' ? 'Users' : ROLE_LABELS[selectedRole]
      }</div>
      <div class="stat-sub neutral">${
        selectedRole === 'all' ? 'Across all roles' : 'Filtered role view'
      }</div>
    </div>
    <div class="stat-card">
      <div class="glow" style="background:var(--green)"></div>
      <div class="stat-icon" style="background:var(--green-dim);color:var(--green)">✅</div>
      <div class="stat-value" style="color:var(--green)">${activeUsers}</div>
      <div class="stat-label">Active Users</div>
      <div class="stat-sub up">↑ ${activeRate}% active rate</div>
    </div>
    <div class="stat-card">
      <div class="glow" style="background:var(--red)"></div>
      <div class="stat-icon" style="background:var(--red-dim);color:var(--red)">⏸️</div>
      <div class="stat-value" style="color:var(--red)">${inactiveUsers}</div>
      <div class="stat-label">Inactive Users</div>
      <div class="stat-sub neutral">${inactiveRate}% inactive rate</div>
    </div>
    <div class="stat-card">
      <div class="glow" style="background:var(--yellow)"></div>
      <div class="stat-icon" style="background:var(--yellow-dim);color:var(--yellow)">📈</div>
      <div class="stat-value" style="color:var(--yellow)">${
        monthBars[monthBars.length - 1] ? monthBars[monthBars.length - 1].value : 0
      }</div>
      <div class="stat-label">New Joins This Month</div>
      <div class="stat-sub neutral">Recent registrations</div>
    </div>
  </div>

  <!-- Bar Graphs Row 1: Monthly Joins & Active vs Inactive Grouped Bar Chart -->
  <div class="grid-2 mb-20" style="gap:20px;align-items:start">
    <div class="card">
      <div class="h4 mb-12">📊 Monthly Users Joining</div>
      ${buildAnalyticsBars(monthBars, 145)}
    </div>
    <div class="card">
      <div class="h4 mb-12">👥 Active vs Inactive Users by Role (Grouped Bar Graph)</div>
      ${buildGroupedAnalyticsBars(activeInactiveGroups, 145, [
        {
          label: 'Active Users',
          color: 'linear-gradient(180deg, #22c55e, #15803d)',
        },
        {
          label: 'Inactive Users',
          color: 'linear-gradient(180deg, #ef4444, #b91c1c)',
        },
      ])}
    </div>
  </div>

  <!-- Bar Graphs Row 2: Platform Role Breakdown & Activity Rate % -->
  <div class="grid-2" style="gap:20px;align-items:start">
    <div class="card">
      <div class="h4 mb-12">🏷️ Total Users by Role (Bar Graph)</div>
      ${buildAnalyticsBars(roleBars, 145)}
    </div>
    <div class="card">
      <div class="h4 mb-12">📈 Activity Rate by Role (% Active Bar Graph)</div>
      ${buildAnalyticsBars(activityRateBars, 145)}
      <div style="margin-top:12px;text-align:center;font-size:11.5px;color:var(--text2)">
        Percentage of accounts actively participating in each role category.
      </div>
    </div>
  </div>`;
}

// ════════════════════════════════════════════════
//  ADMIN SUBPAGE 2: EVENT REPORTS (BAR GRAPHS)
// ════════════════════════════════════════════════
function filterEventReportsStage(stage) {
  sessionStorage.setItem('admin_event_reports_stage', stage);
  renderPage('event-reports');
}
function pageEventReports() {
  const selectedStage = sessionStorage.getItem('admin_event_reports_stage') || 'all';
  const allEvents = DB.events;
  const ongoingEvents = allEvents.filter(event => event.status === 'ongoing');
  const upcomingEvents = allEvents.filter(
    event => event.status === 'upcoming' || event.status === 'published' || event.status === 'full'
  );
  const completedEvents = allEvents.filter(event => event.status === 'completed');
  const draftEvents = allEvents.filter(event => event.status === 'draft');
  let eventsToAnalyze = allEvents;
  if (selectedStage === 'ongoing') eventsToAnalyze = ongoingEvents;
  else if (selectedStage === 'upcoming') eventsToAnalyze = upcomingEvents;
  else if (selectedStage === 'completed') eventsToAnalyze = completedEvents;
  const totalEvents = eventsToAnalyze.length;

  // 1. Lifecycle Stage Bar Graph
  const lifecycleBars = [
    {
      label: 'Ongoing (Now)',
      value: ongoingEvents.length,
      color: 'linear-gradient(180deg, #3b82f6, #1d4ed8)',
    },
    {
      label: 'About to Happen',
      value: upcomingEvents.length,
      color: 'linear-gradient(180deg, #22c55e, #15803d)',
    },
    {
      label: 'Completed',
      value: completedEvents.length,
      color: 'linear-gradient(180deg, #8b5cf6, #7c3aed)',
    },
    {
      label: 'Draft / Planning',
      value: draftEvents.length,
      color: 'linear-gradient(180deg, #64748b, #475569)',
    },
  ];

  // 2. Monthly Timeline Bar Graph
  const monthNames = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  const monthlyBuckets = {};
  const now = new Date();
  for (let i = -2; i <= 3; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() + i, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    monthlyBuckets[key] = {
      label: monthNames[d.getMonth()],
      count: 0,
      isPast: i < 0,
      isCurrent: i === 0,
    };
  }
  eventsToAnalyze.forEach(e => {
    const dateStr = (e.date || '').toString();
    const match = dateStr.match(/(\d{4}-\d{2})/);
    if (match && monthlyBuckets[match[1]]) {
      monthlyBuckets[match[1]].count++;
    }
  });
  const monthlyBars = Object.values(monthlyBuckets).map(m => ({
    label: m.label + (m.isCurrent ? ' (Now)' : ''),
    value: m.count,
    color: m.isCurrent
      ? 'linear-gradient(180deg, #3b82f6, #1d4ed8)'
      : m.isPast
      ? 'linear-gradient(180deg, #8b5cf6, #7c3aed)'
      : 'linear-gradient(180deg, #22c55e, #15803d)',
  }));

  // 3. Category Distribution Bar Graph
  const catCounts = {};
  eventsToAnalyze.forEach(e => {
    const c = e.category || 'Other';
    catCounts[c] = (catCounts[c] || 0) + 1;
  });
  const catBars = Object.entries(catCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([label, value], i) => ({
      label,
      value,
      color: [
        'linear-gradient(180deg, #3b82f6, #1d4ed8)',
        'linear-gradient(180deg, #22c55e, #15803d)',
        'linear-gradient(180deg, #f59e0b, #d97706)',
        'linear-gradient(180deg, #8b5cf6, #7c3aed)',
        'linear-gradient(180deg, #ec4899, #be185d)',
        'linear-gradient(180deg, #14b8a6, #0f766e)',
      ][i % 6],
    }));

  // 4. Grouped Capacity vs Registered Bar Graph by Event Stage
  const capacityOccupancyGroups = [
    {
      label: 'Ongoing',
      bars: [
        {
          label: 'Registered',
          value: ongoingEvents.reduce(
            (total, currentEvent) => total + (currentEvent.registered || 0),
            0
          ),
          color: 'linear-gradient(180deg, #22c55e, #15803d)',
        },
        {
          label: 'Capacity',
          value: ongoingEvents.reduce(
            (total, currentEvent) => total + (currentEvent.capacity || 0),
            0
          ),
          color: 'linear-gradient(180deg, #3b82f6, #1d4ed8)',
        },
      ],
    },
    {
      label: 'About to Happen',
      bars: [
        {
          label: 'Registered',
          value: upcomingEvents.reduce(
            (total, currentEvent) => total + (currentEvent.registered || 0),
            0
          ),
          color: 'linear-gradient(180deg, #22c55e, #15803d)',
        },
        {
          label: 'Capacity',
          value: upcomingEvents.reduce(
            (total, currentEvent) => total + (currentEvent.capacity || 0),
            0
          ),
          color: 'linear-gradient(180deg, #3b82f6, #1d4ed8)',
        },
      ],
    },
    {
      label: 'Completed',
      bars: [
        {
          label: 'Registered',
          value: completedEvents.reduce(
            (total, currentEvent) => total + (currentEvent.registered || 0),
            0
          ),
          color: 'linear-gradient(180deg, #22c55e, #15803d)',
        },
        {
          label: 'Capacity',
          value: completedEvents.reduce(
            (total, currentEvent) => total + (currentEvent.capacity || 0),
            0
          ),
          color: 'linear-gradient(180deg, #3b82f6, #1d4ed8)',
        },
      ],
    },
  ];
  return `
  <div class="page-hd">
    <div class="page-hd-left">
      <div class="page-title">Event Reports & Analytics</div>
      <div class="page-sub">Bar graph analytics for ongoing events, completed events, and events about to happen.</div>
    </div>
    <div class="page-hd-right">
      <div style="display:flex;gap:6px;background:var(--surface2);padding:4px;border-radius:10px;border:1px solid var(--border)">
        <button class="btn btn-xs ${
          selectedStage === 'all' ? 'btn-primary' : 'btn-ghost'
        }" onclick="filterEventReportsStage('all')">All Stages</button>
        <button class="btn btn-xs ${
          selectedStage === 'ongoing' ? 'btn-primary' : 'btn-ghost'
        }" onclick="filterEventReportsStage('ongoing')">▶️ Ongoing</button>
        <button class="btn btn-xs ${
          selectedStage === 'upcoming' ? 'btn-primary' : 'btn-ghost'
        }" onclick="filterEventReportsStage('upcoming')">⏳ About to Happen</button>
        <button class="btn btn-xs ${
          selectedStage === 'completed' ? 'btn-primary' : 'btn-ghost'
        }" onclick="filterEventReportsStage('completed')">✅ Completed</button>
      </div>
    </div>
  </div>

  <!-- 3 Event Stage Highlight Cards -->
  <div class="grid-3 mb-20" style="gap:16px">
    <div class="stat-card" style="border-left:4px solid var(--blue)">
      <div class="glow" style="background:var(--blue)"></div>
      <div class="flex justify-between items-center mb-6">
        <span style="font-size:12px;font-weight:700;color:var(--blue);text-transform:uppercase">▶️ Ongoing Events</span>
        <span class="badge badge-blue">Happening Now</span>
      </div>
      <div class="stat-value" style="color:var(--blue);font-size:32px">${ongoingEvents.length}</div>
      <div class="stat-label">Currently in Progress</div>
      <div class="stat-sub neutral" style="margin-top:6px">${ongoingEvents.reduce(
        (total, currentEvent) => total + (currentEvent.registered || 0),
        0
      )} live attendees participating</div>
    </div>

    <div class="stat-card" style="border-left:4px solid var(--green)">
      <div class="glow" style="background:var(--green)"></div>
      <div class="flex justify-between items-center mb-6">
        <span style="font-size:12px;font-weight:700;color:var(--green);text-transform:uppercase">⏳ About to Happen</span>
        <span class="badge badge-green">Scheduled</span>
      </div>
      <div class="stat-value" style="color:var(--green);font-size:32px">${
        upcomingEvents.length
      }</div>
      <div class="stat-label">Upcoming & Scheduled</div>
      <div class="stat-sub up" style="margin-top:6px">${upcomingEvents.reduce(
        (total, currentEvent) => total + (currentEvent.registered || 0),
        0
      )} reservations confirmed</div>
    </div>

    <div class="stat-card" style="border-left:4px solid var(--purple)">
      <div class="glow" style="background:var(--purple)"></div>
      <div class="flex justify-between items-center mb-6">
        <span style="font-size:12px;font-weight:700;color:var(--purple);text-transform:uppercase">✅ Completed Events</span>
        <span class="badge badge-purple">Finished</span>
      </div>
      <div class="stat-value" style="color:var(--purple);font-size:32px">${
        completedEvents.length
      }</div>
      <div class="stat-label">Concluded Events</div>
      <div class="stat-sub neutral" style="margin-top:6px">${completedEvents.reduce(
        (total, currentEvent) => total + (currentEvent.registered || 0),
        0
      )} past attendees reached</div>
    </div>
  </div>

  <!-- Bar Graphs Row 1: Lifecycle Stages Comparison & Category Breakdown -->
  <div class="grid-2 mb-20" style="gap:20px">
    <div class="card">
      <div class="h4 mb-12">📊 Event Lifecycle Stages (Bar Graph)</div>
      ${buildAnalyticsBars(lifecycleBars, 215)}
    </div>
    <div class="card">
      <div class="h4 mb-12">🏷️ Event Category Breakdown (Bar Graph)</div>
      ${buildAnalyticsBars(
        catBars.length
          ? catBars
          : [
              {
                label: 'No Events',
                value: 0,
                color: 'linear-gradient(180deg, #64748b, #475569)',
              },
            ],
        215
      )}
    </div>
  </div>

  <!-- Bar Graphs Row 2: Monthly Timeline & Grouped Capacity vs Registrations -->
  <div class="grid-2" style="gap:20px">
    <div class="card">
      <div class="h4 mb-12">📅 Monthly Event Timeline (Past, Current & Future Bar Graph)</div>
      ${buildAnalyticsBars(monthlyBars, 215)}
    </div>
    <div class="card">
      <div class="h4 mb-12">🎟️ Booked Seats vs Total Capacity (Grouped Bar Graph)</div>
      ${buildGroupedAnalyticsBars(capacityOccupancyGroups, 215, [
        {
          label: 'Booked Seats',
          color: 'linear-gradient(180deg, #22c55e, #15803d)',
        },
        {
          label: 'Total Capacity',
          color: 'linear-gradient(180deg, #3b82f6, #1d4ed8)',
        },
      ])}
    </div>
  </div>`;
}

// ════════════════════════════════════════════════
//  ADMIN SUBPAGE 3: REVENUE REPORTS (BAR GRAPHS)
// ════════════════════════════════════════════════
function filterRevenueTimeframe(tf) {
  sessionStorage.setItem('admin_revenue_timeframe', tf);
  renderPage('revenue-reports');
}
function pageRevenueReports() {
  const timeframe = sessionStorage.getItem('admin_revenue_timeframe') || '6m';
  const allEvents = DB.events;
  const allRegs = DB.registrations;
  const ticketPayments = (DB.financeTransactions || []).filter(
    payment => payment.kind !== 'event' && payment.status === 'Successful'
  );
  const eventPayments = (DB.eventWorkflowPayments || []).filter(
    payment => payment.status === 'completed'
  );
  const actualPayments = [...ticketPayments, ...eventPayments];
  const regRevenue = ticketPayments.reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
  const eventRevenue = eventPayments.reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
  const totalRevenue = regRevenue + eventRevenue;
  const paidEvents = allEvents.filter(event => event.price > 0);
  const freeEvents = allEvents.filter(event => !event.price || event.price === 0);
  const totalPaidSeats = paidEvents.reduce(
    (total, currentEvent) => total + (currentEvent.registered || 0),
    0
  );
  const avgTicketPrice =
    paidEvents.length > 0
      ? Math.round(
          paidEvents.reduce((total, currentEvent) => total + (currentEvent.price || 0), 0) /
            paidEvents.length
        )
      : 0;
  const projectedPipeline = allEvents
    .filter(event => event.status === 'upcoming' || event.status === 'ongoing')
    .reduce(
      (total, currentEvent) => total + (currentEvent.capacity || 0) * (currentEvent.price || 0),
      0
    );

  // 1. Monthly Revenue Bar Graph over time (in ₹ Thousands)
  const monthNames = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  const monthlyRevenueMap = {};
  const numMonths = timeframe === '12m' ? 12 : 6;
  const now = new Date();
  for (let i = numMonths - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    monthlyRevenueMap[key] = {
      label: monthNames[d.getMonth()],
      amount: 0,
    };
  }
  actualPayments.forEach(payment => {
    const month = String(payment.paymentDate || payment.date || '').slice(0, 7);
    if (monthlyRevenueMap[month]) monthlyRevenueMap[month].amount += Number(payment.amount || 0);
  });
  const revenueBars = Object.values(monthlyRevenueMap).map((m, index) => ({
    label: m.label,
    value: Number((m.amount / 1000).toFixed(2)),
    color: [
      'linear-gradient(180deg, #22c55e, #15803d)',
      'linear-gradient(180deg, #10b981, #047857)',
      'linear-gradient(180deg, #3b82f6, #1d4ed8)',
      'linear-gradient(180deg, #6366f1, #4338ca)',
      'linear-gradient(180deg, #8b5cf6, #7c3aed)',
      'linear-gradient(180deg, #f59e0b, #d97706)',
    ][index % 6],
  }));

  // 2. Category Revenue Bar Graph
  const catRevenueMap = {};
  actualPayments.forEach(payment => {
    const category =
      allEvents.find(event => String(event.id) === String(payment.eventId))?.category || 'General';
    catRevenueMap[category] = (catRevenueMap[category] || 0) + Number(payment.amount || 0);
  });
  const catRevenueBars = Object.entries(catRevenueMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([label, value], index) => ({
      label,
      value: Number((value / 1000).toFixed(2)),
      color: [
        'linear-gradient(180deg, #22c55e, #15803d)',
        'linear-gradient(180deg, #3b82f6, #1d4ed8)',
        'linear-gradient(180deg, #f59e0b, #d97706)',
        'linear-gradient(180deg, #8b5cf6, #7c3aed)',
        'linear-gradient(180deg, #ec4899, #be185d)',
        'linear-gradient(180deg, #14b8a6, #0f766e)',
      ][index % 6],
    }));

  // 3. Ticket Pricing Tiers Bar Graph
  const pricingTierBars = [
    {
      label: 'Free (₹0)',
      value: freeEvents.length,
      color: 'linear-gradient(180deg, #14b8a6, #0f766e)',
    },
    {
      label: 'Budget (₹1–₹99)',
      value: allEvents.filter(event => event.price > 0 && event.price < 100).length,
      color: 'linear-gradient(180deg, #3b82f6, #1d4ed8)',
    },
    {
      label: 'Mid-Tier (₹100–₹199)',
      value: allEvents.filter(event => event.price >= 100 && event.price < 200).length,
      color: 'linear-gradient(180deg, #f59e0b, #d97706)',
    },
    {
      label: 'Premium (₹200+)',
      value: allEvents.filter(event => event.price >= 200).length,
      color: 'linear-gradient(180deg, #8b5cf6, #7c3aed)',
    },
  ];

  // 4. Revenue Streams Contribution Bar Graph
  const streamBars = [
    {
      label: 'Ticket Sales',
      value: Number((regRevenue / 1000).toFixed(2)),
      color: 'linear-gradient(180deg, #22c55e, #15803d)',
    },
    {
      label: 'Client Event Payments',
      value: Number((eventRevenue / 1000).toFixed(2)),
      color: 'linear-gradient(180deg, #3b82f6, #1d4ed8)',
    },
  ];
  return `
  <div class="page-hd">
    <div class="page-hd-left">
      <div class="page-title">Revenue Reports & Analytics</div>
      <div class="page-sub">Bar graph visualizations of platform revenue over time, pricing tiers, and category income.</div>
    </div>
    <div class="page-hd-right">
      <div style="display:flex;gap:6px;background:var(--surface2);padding:4px;border-radius:10px;border:1px solid var(--border)">
        <button class="btn btn-xs ${
          timeframe === '6m' ? 'btn-primary' : 'btn-ghost'
        }" onclick="filterRevenueTimeframe('6m')">Last 6 Months</button>
        <button class="btn btn-xs ${
          timeframe === '12m' ? 'btn-primary' : 'btn-ghost'
        }" onclick="filterRevenueTimeframe('12m')">Last 12 Months</button>
      </div>
    </div>
  </div>

  <!-- Key Revenue Metric Cards -->
  <div class="grid-4 mb-20">
    <div class="stat-card">
      <div class="glow" style="background:var(--green)"></div>
      <div class="stat-icon" style="background:var(--green-dim);color:var(--green)">💰</div>
      <div class="stat-value" style="color:var(--green)">₹${(totalRevenue / 1000).toFixed(1)}K</div>
      <div class="stat-label">Total Platform Revenue</div>
      <div class="stat-sub up">Recorded payment revenue</div>
    </div>
    <div class="stat-card">
      <div class="glow" style="background:var(--accent)"></div>
      <div class="stat-icon" style="background:var(--accent-dim);color:var(--accent)">📈</div>
      <div class="stat-value" style="color:var(--accent)">₹${avgTicketPrice}</div>
      <div class="stat-label">Average Ticket Price</div>
      <div class="stat-sub neutral">Across ${paidEvents.length} paid events</div>
    </div>
    <div class="stat-card">
      <div class="glow" style="background:var(--yellow)"></div>
      <div class="stat-icon" style="background:var(--yellow-dim);color:var(--yellow)">🎟️</div>
      <div class="stat-value" style="color:var(--yellow)">${totalPaidSeats}</div>
      <div class="stat-label">Paid Ticket Registrations</div>
      <div class="stat-sub up">↑ 12% week-on-week</div>
    </div>
    <div class="stat-card">
      <div class="glow" style="background:var(--blue)"></div>
      <div class="stat-icon" style="background:var(--blue-dim);color:var(--blue)">📊</div>
      <div class="stat-value" style="color:var(--blue)">₹${(projectedPipeline / 1000).toFixed(
        1
      )}K</div>
      <div class="stat-label">Projected Pipeline</div>
      <div class="stat-sub neutral">Upcoming capacity value</div>
    </div>
  </div>

  <!-- Bar Graphs Row 1: Revenue Over Time & Revenue by Category -->
  <div class="grid-2 mb-20" style="gap:20px">
    <div class="card">
      <div class="flex justify-between items-center mb-12">
        <span class="h4">📈 Platform Revenue Over Time (₹ in Thousands)</span>
        <span class="badge badge-green">${numMonths} Months Trend</span>
      </div>
      ${buildAnalyticsBars(revenueBars, 215)}
      <div style="margin-top:12px;font-size:11.5px;color:var(--text2);text-align:center">
        Monthly revenue performance trajectory in thousands (₹K).
      </div>
    </div>

    <div class="card">
      <div class="flex justify-between items-center mb-12">
        <span class="h4">🏷️ Revenue by Event Category (₹ in Thousands)</span>
      </div>
      ${buildAnalyticsBars(catRevenueBars, 215)}
      <div style="margin-top:12px;font-size:11.5px;color:var(--text2);text-align:center">
        Revenue breakdown by event category.
      </div>
    </div>
  </div>

  <!-- Bar Graphs Row 2: Ticket Pricing Tiers & Revenue Streams -->
  <div class="grid-2" style="gap:20px">
    <div class="card">
      <div class="h4 mb-12">🎟️ Event Count by Pricing Tier (Bar Graph)</div>
      ${buildAnalyticsBars(pricingTierBars, 215)}
    </div>

    <div class="card">
      <div class="h4 mb-12">💼 Revenue Stream Contribution (₹ in Thousands)</div>
      ${buildAnalyticsBars(streamBars, 215)}
    </div>
  </div>`;
}
// ════════════════════════════════════════════════
//  NON-ADMIN PAGES (ORGANIZER / CLIENT / ATTENDEE)
// ════════════════════════════════════════════════
function pageUsers() {
  const users = window.EventFlowAccountPolicy.visibleAccounts(CU, DB.users).filter(
    u => u.role !== 'superuser'
  );
  return `
  <div class="page-hd">
    <div class="page-hd-left">
      <div class="page-title">User Management</div>
      <div class="page-sub">View users and their account details.</div>
    </div>
  </div>
  <div class="filter-row">
    <div class="search-box input-group">
      <span class="input-icon">🔍</span>
      <input class="form-control" id="um-q" placeholder="Search by name or email…" oninput="refreshDirectoryUserManagement()">
    </div>
    <select class="form-control filter-select" id="um-role" onchange="refreshDirectoryUserManagement()">
      <option value="">All Users</option>
      <option value="attendee">Attendee</option>
      ${
        window.EventFlowAccountPolicy.isSupportExecutiveAccount(CU)
          ? ''
          : `<option value="employee">Employees</option>`
      }
      <option value="organizer">Event Manager</option>
      <option value="client">Client</option>
    </select>
  </div>
  <div class="table-wrap" id="user-management-table">${buildUserManagementTable(users)}</div>`;
}
function buildUserManagementTable(users) {
  users = window.EventFlowAccountPolicy.visibleAccounts(CU, users);
  if (users.length === 0) {
    return `<div class="empty"><div class="empty-icon">👥</div><div class="empty-title">No users found</div><p class="empty-desc">Try changing your search or role filter.</p></div>`;
  }
  return `<table>
    <thead><tr><th>User</th><th>Email</th><th>Phone</th><th>Role</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
    <tbody>${users
      .map(user => {
        const avHtml = user.avatarImage
          ? `
        <div class="av av-xs">
          <img src="${user.avatarImage}" alt="${
              user.name
            }" onerror="this.style.display='none';this.nextElementSibling.style.display='block'">
          <span style="display:none">${user.avatar || user.name?.[0] || '?'}</span>
        </div>
      `
          : `<div class="av av-xs">${user.avatar || user.name?.[0] || '?'}</div>`;
        return `<tr>
      <td><div class="flex items-center gap-8">${avHtml}<strong>${
          user.name || 'Unknown User'
        }</strong></div></td>
      <td>${user.email || '—'}</td>
      <td>${user.phone || '—'}</td>
      <td><span class="badge badge-${ROLE_COLORS[user.role] || 'blue'}">${
          user.role === 'organizer' ? 'Event Manager' : ROLE_LABELS[user.role] || user.role
        }</span></td>
      <td><span class="badge badge-${user.status === 'active' ? 'green' : 'red'}">${
          user.status || 'unknown'
        }</span></td>
      <td>${user.joined || user.createdAt || '—'}</td>
      <td>${
        window.EventFlowAccountPolicy.canManageAccount(CU, user)
          ? `<div class="actions"><button class="btn btn-ghost btn-xs" onclick="openEditUserModal('${user.id}')">Edit</button><button class="btn btn-xs btn-danger" onclick="removeUser('${user.id}')">Remove</button></div>`
          : '<span class="small muted">Admin managed</span>'
      }</td>
    </tr>`;
      })
      .join('')}</tbody>
  </table>`;
}
function refreshDirectoryUserManagement() {
  const query = (g('um-q')?.value || '').trim().toLowerCase();
  const role = g('um-role')?.value || '';
  const users = window.EventFlowAccountPolicy.visibleAccounts(CU, DB.users).filter(u => {
    const matchesRole = !role || u.role === role;
    const matchesQuery =
      !query ||
      [u.name, u.email, u.phone].some(value =>
        String(value || '')
          .toLowerCase()
          .includes(query)
      );
    return u.role !== 'superuser' && matchesRole && matchesQuery;
  });
  globalThis.window?.EventFlowClientPages?.clear(g('user-management-table'));
  g('user-management-table').innerHTML = buildUserManagementTable(users);
}
function openEditUserModal(userId) {
  const user = DB.users.find(u => String(u.id) === String(userId));
  if (!user) return;
  if (!window.EventFlowAccountPolicy.canManageAccount(CU, user)) {
    toast('Only an admin can change employee or admin accounts.', 'error');
    return;
  }
  openModal(
    'Edit User',
    `
  <div class="form-group"><label class="form-label">Full Name *</label><input class="form-control" id="um-edit-name" value="${
    user.name || ''
  }"></div>
  <div class="form-group"><label class="form-label">Email *</label><input class="form-control" id="um-edit-email" type="email" value="${
    user.email || ''
  }"></div>
  <div class="form-group"><label class="form-label">Phone</label><input class="form-control" id="um-edit-phone" value="${
    user.phone || ''
  }"></div>
  <div class="grid-2">
    <div class="form-group"><label class="form-label">Role</label><select class="form-control" id="um-edit-role" ${
      window.EventFlowAccountPolicy.isSupportExecutiveAccount(CU) ? 'disabled' : ''
    }><option value="attendee" ${user.role === 'attendee' ? 'selected' : ''}>Attendee</option>${
      window.EventFlowAccountPolicy.isSupportExecutiveAccount(CU)
        ? ''
        : `<option value="employee" ${
            user.role === 'employee' ? 'selected' : ''
          }>Employees</option>`
    }<option value="organizer" ${
      user.role === 'organizer' ? 'selected' : ''
    }>Event Manager</option><option value="client" ${
      user.role === 'client' ? 'selected' : ''
    }>Client</option></select></div>
    <div class="form-group"><label class="form-label">Status</label><select class="form-control" id="um-edit-status"><option value="active" ${
      user.status === 'active' ? 'selected' : ''
    }>Active</option><option value="inactive" ${
      user.status !== 'active' ? 'selected' : ''
    }>Inactive</option></select></div>
  </div>`,
    [
      {
        lbl: 'Save Changes',
        cls: 'btn-primary',
        fn: `saveUser('${user.id}')`,
      },
    ]
  );
}
function saveUser(userId) {
  const user = DB.users.find(u => String(u.id) === String(userId));
  const name = v('um-edit-name');
  const email = v('um-edit-email');
  if (!user) return;
  if (!window.EventFlowAccountPolicy.canManageAccount(CU, user)) {
    toast('Only an admin can change employee or admin accounts.', 'error');
    return;
  }
  if (!name) {
    toast('Name is required', 'error');
    return;
  }
  if (!email || !email.includes('@')) {
    toast('Valid email is required', 'error');
    return;
  }
  const duplicate = window.EventFlowAccountPolicy.isEmailInUse(DB.users, email, userId);
  if (duplicate) {
    toast('Email already registered', 'error');
    return;
  }
  if (
    !window.EventFlowAccountPolicy.canApplyAccountUpdate(CU, user, {
      role: v('um-edit-role'),
    })
  ) {
    toast('Only an admin can change account roles.', 'error');
    return;
  }
  user.name = name;
  user.email = email;
  user.phone = v('um-edit-phone');
  user.role = v('um-edit-role');
  user.status = v('um-edit-status');
  user.avatar = name
    .split(' ')
    .map(part => part[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
  saveDB();
  closeModal();
  renderPage('users');
  toast('User details updated', 'success');
}
function removeUser(userId) {
  const user = DB.users.find(u => String(u.id) === String(userId));
  if (!user) return;
  if (!window.EventFlowAccountPolicy.canManageAccount(CU, user)) {
    toast('Only an admin can change employee or admin accounts.', 'error');
    return;
  }
  confirm2('Remove User', `Remove ${user.name || 'this user'} from the user list?`, () => {
    const current = DB.users.find(user => String(user.id) === String(userId));
    if (!window.EventFlowAccountPolicy.canManageAccount(CU, current)) {
      toast('This account can only be managed by an admin.', 'error');
      return;
    }
    const index = DB.users.findIndex(u => String(u.id) === String(userId));
    if (index === -1) return;
    DB.users.splice(index, 1);
    saveDB();
    renderPage('users');
    toast('User removed', 'info');
  });
}
function pageEvents() {
  if (CU.role === 'superuser') return pageEventReports();
  if (CU.role === 'client') {
    return `<div class="empty"><div class="empty-icon">🚫</div><div class="empty-title">Access Denied</div><p class="empty-desc">This page is not available for clients. Please use Find Organizers to request events.</p><button class="btn btn-primary mt-16" onclick="goNav('find-organizers')">Find Organizers</button></div>`;
  }
  const isOrg = CU.role === 'organizer';
  const list = isOrg ? DB.events.filter(event => event.organizer === CU.id) : DB.events;
  return `
  <div class="page-hd">
    <div class="page-hd-left"><div class="page-title">${
      isOrg ? 'My Events' : 'All Events'
    }</div><div class="page-sub">${list.length} event(s)</div></div>
    <div class="page-hd-right">${
      CU.role === 'organizer' && !isEmployeeAccount()
        ? `<button class="btn btn-primary" onclick="openAddEventModal()">+ Create Event</button>`
        : ''
    }</div>
  </div>
  <div class="filter-row">
    <div class="search-box input-group"><span class="input-icon">🔍</span><input class="form-control" id="ev-q" placeholder="Search events…" oninput="refreshEvents()"></div>
    <select class="form-control filter-select" id="ev-st" onchange="refreshEvents()">
      <option value="">All Status</option><option value="upcoming">Upcoming</option><option value="full">Full</option><option value="completed">Completed</option>
    </select>
    <select class="form-control filter-select" id="ev-cat" onchange="refreshEvents()">
      <option value="">All Categories</option><option>Conference</option><option>Corporate</option><option>Concert</option><option>Workshop</option><option>Networking</option>
    </select>
  </div>
  <div class="events-grid" id="ev-grid">${list.map(e => evCard(e, CU.role)).join('')}</div>`;
}
function refreshEvents() {
  const q = (g('ev-q') || {}).value?.toLowerCase() || '';
  const st = (g('ev-st') || {}).value || '';
  const cat = (g('ev-cat') || {}).value || '';
  const isOrg = CU.role === 'organizer';
  const list = (isOrg ? DB.events.filter(event => event.organizer === CU.id) : DB.events).filter(
    e => {
      return (
        (!q || e.title.toLowerCase().includes(q)) &&
        (!st || e.status === st) &&
        (!cat || e.category === cat)
      );
    }
  );
  globalThis.window?.EventFlowClientPages?.clear(g('ev-grid'));
  g('ev-grid').innerHTML =
    list.map(e => evCard(e, CU.role)).join('') ||
    `<div class="empty" style="grid-column:1/-1"><div class="empty-icon">🔍</div><div class="empty-title">No events found</div></div>`;
}
function evCard(event, role, reg = null) {
  const pct = Math.min(100, Math.round((event.registered / event.capacity) * 100));
  const regForThis =
    reg ||
    DB.registrations.find(
      registration =>
        String(registration.attendeeId) === String(CU.id) &&
        String(registration.eventId) === String(event.id)
    );
  const bannerContent = event.image
    ? `
        <img src="${event.image}" alt="${
        event.title || 'Event'
      }" class="ev-banner-img" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
        <div class="ev-banner-fallback" style="display:none;align-items:center;justify-content:center;font-size:52px;width:100%;height:100%">${
          event.emoji || '📅'
        }</div>
        <div class="ev-banner-overlay"></div>
      `
    : `<span style="font-size:52px">${event.emoji || '📅'}</span>`;
  return `<div class="ev-card">
    <div class="ev-banner" style="background:${event.color || 'var(--accent)'}18">
      ${bannerContent}
      <div class="ev-banner-tag"><span class="badge badge-${evStatBadge(event.status)}">${
    event.status
  }</span></div>
      <div class="ev-banner-price">${event.price === 0 ? 'Free' : '₹' + event.price}</div>
    </div>
    <div class="ev-body">
      <div class="ev-title">${event.title}</div>
      <div class="ev-meta">
        <div class="ev-meta-row"><span>📅</span>${event.date} · ${event.time}</div>
        <div class="ev-meta-row"><span>📍</span>${event.venue}</div>
        <div class="ev-meta-row"><span>🏷️</span>${event.category}</div>
      </div>
      <div style="margin-bottom:12px">
        <div class="flex justify-between ev-cap mb-4"><span>${event.registered}/${
    event.capacity
  } registered</span><span>${pct}%</span></div>
        <div class="prog"><div class="prog-fill" style="width:${pct}%"></div></div>
      </div>
      <div class="ev-footer">
        ${
          role === 'attendee'
            ? `<div class="flex gap-6" style="width:100%;justify-content:space-between"><button class="btn btn-sm ${
                regForThis ? 'btn-ghost' : 'btn-primary'
              }" onclick="regForEvent('${event.id}')" ${
                (event.status === 'full' && !regForThis) || event.status === 'completed'
                  ? 'disabled'
                  : ''
              } style="${
                (event.status === 'full' && !regForThis) || event.status === 'completed'
                  ? 'opacity:.5'
                  : ''
              }">${
                regForThis ? '✓ Registered' : event.status === 'full' ? 'Event Full' : 'Register'
              }</button><button class="btn btn-ghost btn-xs" onclick="openViewEventDrawer('${
                event.id
              }')" title="View event details">View Details</button></div>`
            : role === 'organizer'
            ? `<div class="actions"><button class="btn btn-ghost btn-xs" onclick="openViewEventDrawer('${event.id}')" title="View event details">👁️ View</button><button class="btn btn-ghost btn-xs" onclick="openEditEventModal('${event.id}')">✏️ Edit</button><button class="btn btn-xs btn-danger" onclick="deleteEvent('${event.id}')">🗑️</button></div>`
            : role === 'superuser'
            ? `<div class="actions"><button class="btn btn-ghost btn-xs w-full" onclick="openViewEventDrawer('${event.id}')" title="View event details">👁️ View</button></div>`
            : role === 'employee' || role === 'client'
            ? `<div class="flex gap-6"><button class="btn btn-ghost btn-xs w-full" onclick="openViewEventDrawer('${event.id}')" title="View event details">👁️ View Details</button></div>`
            : `<button class="btn btn-ghost btn-xs" onclick="openViewEventDrawer('${event.id}')" title="View event details">👁️ Details</button>`
        }
        <div class="tag-list" style="flex:1;justify-content:flex-end">${(event.tags || [])
          .slice(0, 2)
          .map(tag => `<span class="tag">${tag}</span>`)
          .join('')}</div>
      </div>
    </div>
  </div>`;
}
function openAddEventModal() {
  openModal(
    'Create New Event',
    `
    <div class="form-group"><label class="form-label">Event Title *</label><input class="form-control" id="ne-title" placeholder="e.g. Annual Tech Summit 2026"></div>
    <div class="grid-2">
      <div class="form-group"><label class="form-label">Category *</label>
        <select class="form-control" id="ne-cat"><option>Conference</option><option>Corporate</option><option>Concert</option><option>Workshop</option><option>Networking</option><option>Other</option></select>
      </div>
      <div class="form-group"><label class="form-label">Status</label>
        <select class="form-control" id="ne-status"><option value="upcoming">Upcoming</option><option value="full">Full</option></select>
      </div>
    </div>
    <div class="grid-2">
      <div class="form-group"><label class="form-label">Date *</label><input class="form-control" id="ne-date" type="date"></div>
      <div class="form-group"><label class="form-label">Start Time</label><input class="form-control" id="ne-time" type="time" value="09:00"></div>
    </div>
    <div class="form-group"><label class="form-label">Venue *</label><input class="form-control" id="ne-venue" placeholder="Convention Center, Hall A"></div>
    <div class="form-group"><label class="form-label">City</label><input class="form-control" id="ne-city" placeholder="Chennai"></div>
    <div class="grid-2">
      <div class="form-group"><label class="form-label">Capacity *</label><input class="form-control" id="ne-cap" type="number" placeholder="500"></div>
      <div class="form-group"><label class="form-label">Ticket Price (₹) — 0 = Free</label><input class="form-control" id="ne-price" type="number" placeholder="0"></div>
    </div>
    <div class="form-group"><label class="form-label">Description</label><textarea class="form-control" id="ne-desc" placeholder="Describe the event…"></textarea></div>
    <div class="form-group"><label class="form-label">Tags (comma-separated)</label><input class="form-control" id="ne-tags" placeholder="AI, Tech, Networking"></div>
  `,
    [
      {
        lbl: 'Create Event',
        cls: 'btn-primary',
        fn: 'saveNewEvent()',
      },
    ]
  );
}
function saveNewEvent() {
  const title = v('ne-title');
  const date = v('ne-date');
  const venue = v('ne-venue');
  const cap = v('ne-cap');
  if (!title) {
    toast('Event title is required', 'error');
    return;
  }
  if (!date) {
    toast('Event date is required', 'error');
    return;
  }
  if (!venue) {
    toast('Venue is required', 'error');
    return;
  }
  if (!cap || parseInt(cap) < 1) {
    toast('Enter valid capacity', 'error');
    return;
  }
  const eventPayload = {
    name: title,
    category: v('ne-cat') || 'Conference',
    date: date,
    time: v('ne-time') || '09:00',
    location: venue,
    capacity: parseInt(cap),
    ticketPrice: parseInt(v('ne-price')) || 0,
    status: v('ne-status') || 'upcoming',
    description: v('ne-desc') || '',
    organizerId: CU.userId || CU.id,
  };
  apiCreateEvent(eventPayload)
    .then(function (newEv) {
      // Add to local DB for immediate UI
      const evId = newEv.eventId || DB._nextId.events++;
      DB.events.push({
        id: evId,
        title,
        category: v('ne-cat'),
        date,
        time: v('ne-time'),
        venue,
        city: v('ne-city'),
        capacity: parseInt(cap),
        registered: 0,
        price: parseInt(v('ne-price')) || 0,
        status: v('ne-status') || 'upcoming',
        organizer: CU.id,
        description: v('ne-desc'),
        emoji: '📅',
        color: '#7c6ff7',
      });
      closeModal();
      renderPage(_currentPage);
      toast('Event created!', 'success');
    })
    .catch(function (error) {
      // Fallback: save locally
      const evId = DB._nextId ? DB._nextId.events++ : Date.now();
      DB.events.push({
        id: evId,
        title,
        category: v('ne-cat'),
        date,
        time: v('ne-time'),
        venue,
        city: v('ne-city'),
        capacity: parseInt(cap),
        registered: 0,
        price: parseInt(v('ne-price')) || 0,
        status: v('ne-status') || 'upcoming',
        organizer: CU.id,
        description: v('ne-desc'),
        emoji: '📅',
        color: '#7c6ff7',
      });
      saveDB();
      closeModal();
      renderPage(_currentPage);
      toast('Event created (local)!', 'success');
    });
}
function openEditEventModal(id) {
  const event = DB.events.find(currentEvent => String(currentEvent.id) === String(id));
  if (!event) return;
  if (isBookedClientEvent(event)) {
    toast('Booked event details cannot be edited.', 'info');
    return;
  }
  openModal(
    `Edit — ${event.title}`,
    `
    <div class="form-group"><label class="form-label">Event Title</label><input class="form-control" id="ee-title" value="${
      event.title
    }"></div>
    <div class="grid-2">
      <div class="form-group"><label class="form-label">Date</label><input class="form-control" id="ee-date" type="date" value="${
        event.date
      }"></div>
      <div class="form-group"><label class="form-label">Time</label><input class="form-control" id="ee-time" type="time" value="${
        event.time
      }"></div>
    </div>
    <div class="form-group"><label class="form-label">Venue</label><input class="form-control" id="ee-venue" value="${
      event.venue
    }"></div>
    <div class="grid-2">
      <div class="form-group"><label class="form-label">Capacity</label><input class="form-control" id="ee-cap" type="number" value="${
        event.capacity
      }"></div>
      <div class="form-group"><label class="form-label">Price (₹)</label><input class="form-control" id="ee-price" type="number" value="${
        event.price
      }"></div>
    </div>
    <div class="form-group"><label class="form-label">Status</label>
      <select class="form-control" id="ee-status">${['upcoming', 'full', 'completed']
        .map(s => `<option value="${s}"${event.status === s ? ' selected' : ''}>${s}</option>`)
        .join('')}</select>
    </div>
    <div class="form-group"><label class="form-label">Description</label><textarea class="form-control" id="ee-desc">${
      event.description || ''
    }</textarea></div>
  `,
    [
      {
        lbl: 'Save Changes',
        cls: 'btn-primary',
        fn: `saveEditEvent('${id}')`,
      },
    ]
  );
}
function saveEditEvent(id) {
  const event = DB.events.find(currentEvent => String(currentEvent.id) === String(id));
  if (!event) return;
  if (isBookedClientEvent(event)) {
    toast('Booked event details cannot be edited.', 'info');
    return;
  }
  const newTitle = v('ee-title') || event.title;
  const newDate = v('ee-date') || event.date;
  const newTime = v('ee-time') || event.time;
  const newVenue = v('ee-venue') || event.venue;
  const newCap = parseInt(v('ee-cap')) || event.capacity;
  const newPrice = parseFloat(v('ee-price')) || 0;
  const newStatus = v('ee-status') || event.status;
  const newDesc = v('ee-desc');
  const backendId = event.eventId || id;
  apiUpdateEvent(backendId, {
    name: newTitle,
    date: newDate,
    time: newTime,
    location: newVenue,
    capacity: newCap,
    ticketPrice: newPrice,
    status: newStatus,
    description: newDesc,
  })
    .then(function () {
      event.title = newTitle;
      event.date = newDate;
      event.time = newTime;
      event.venue = newVenue;
      event.capacity = newCap;
      event.price = newPrice;
      event.status = newStatus;
      event.description = newDesc;
      closeModal();
      renderPage('events');
      toast('Event updated successfully', 'success');
    })
    .catch(function () {
      event.title = newTitle;
      event.date = newDate;
      event.time = newTime;
      event.venue = newVenue;
      event.capacity = newCap;
      event.price = newPrice;
      event.status = newStatus;
      event.description = newDesc;
      saveDB();
      closeModal();
      renderPage('events');
      toast('Event updated (local)', 'success');
    });
}
function deleteEvent(id) {
  if (window.event) window.event.stopPropagation();
  confirm2(
    'Delete Event',
    'This will permanently delete the event and all registrations for it.',
    () => {
      const event = DB.events.find(currentEvent => String(currentEvent.id) === String(id));
      const backendId = event ? event.eventId || id : id;
      apiDeleteEvent(backendId)
        .then(function () {
          const index = DB.events.findIndex(currentEvent => String(currentEvent.id) === String(id));
          if (index > -1) {
            DB.events.splice(index, 1);
          }
          DB.registrations = DB.registrations.filter(
            registration => String(registration.eventId) !== String(id)
          );
          renderPage(_currentPage);
          toast('Event deleted', 'info');
        })
        .catch(function () {
          const index = DB.events.findIndex(currentEvent => String(currentEvent.id) === String(id));
          if (index > -1) {
            DB.events.splice(index, 1);
            saveDB();
          }
          DB.registrations = DB.registrations.filter(
            registration => String(registration.eventId) !== String(id)
          );
          renderPage(_currentPage);
          toast('Event deleted (local)', 'info');
        });
    }
  );
}
function openViewEventDrawer(id) {
  const event = DB.events.find(currentEvent => String(currentEvent.id) === String(id));
  if (!event) return;
  const regs = DB.registrations.filter(registration => String(registration.eventId) === String(id));
  const eventId = event.eventId || id;
  const eventReviews = DB.clientOrganizerReviews || [];
  const submittedReview = eventReviews.find(review => String(review.eventId) === String(eventId));
  const clientOwnsEvent =
    CU.role === 'client' &&
    event.status === 'completed' &&
    [CU.id, CU.userId]
      .filter(Boolean)
      .some(userId => String(event.clientUserId || event.clientId || '') === String(userId));
  const reviewAction =
    clientOwnsEvent && !submittedReview
      ? `<section style="margin-top:18px;padding:16px;background:var(--surface2);border:1px solid var(--border);border-radius:10px">
            <h3 style="margin:0 0 12px">Review the Organizer</h3>
            <div class="form-group"><label class="form-label" for="event-review-rating">Rating</label><select class="form-control" id="event-review-rating"><option value="">Choose stars</option><option value="5">★★★★★ - Excellent</option><option value="4">★★★★ - Good</option><option value="3">★★★ - Average</option><option value="2">★★ - Poor</option><option value="1">★ - Very poor</option></select></div>
            <div class="form-group"><label class="form-label" for="event-review-comment">Written review</label><textarea class="form-control" id="event-review-comment" rows="3" required></textarea></div>
            <button class="btn btn-primary w-full" onclick="submitCompletedEventReview('${eventId}')">Submit Review</button>
          </section>`
      : submittedReview
      ? '<p style="margin-top:16px;color:var(--green);font-weight:600">Your review has been submitted and published on the organizer profile.</p>'
      : '';
  const bannerHTML = event.image
    ? `
        <div style="height:140px;border-radius:12px;overflow:hidden;margin-bottom:16px;position:relative;background:${
          event.color || 'var(--accent)'
        }18">
          <img src="${event.image}" alt="${
        event.title || 'Event'
      }" style="width:100%;height:100%;object-fit:cover" onerror="this.parentElement.innerHTML='<div style=\'font-size:52px;text-align:center;padding:30px 0\'>${
        event.emoji || '📅'
      }</div>'">
        </div>
      `
    : `<div style="font-size:52px;text-align:center;margin-bottom:16px">${
        event.emoji || '📅'
      }</div>`;
  openDrawer(
    event.title,
    `
    ${bannerHTML}
    <span class="badge badge-${evStatBadge(event.status)} mb-16">${event.status}</span>
    <div style="display:flex;flex-direction:column;gap:2px;margin-bottom:20px">
      <div class="info-row"><span class="info-label">Category</span><span class="info-value">${
        event.category
      }</span></div>
      <div class="info-row"><span class="info-label">Date & Time</span><span class="info-value">${
        event.date
      } · ${event.time}</span></div>
      <div class="info-row"><span class="info-label">Venue</span><span class="info-value" style="max-width:200px;text-align:right">${
        event.venue
      }</span></div>
      <div class="info-row"><span class="info-label">City</span><span class="info-value">${
        event.city || '—'
      }</span></div>
      <div class="info-row"><span class="info-label">Capacity</span><span class="info-value">${
        event.registered
      } / ${event.capacity}</span></div>
      <div class="info-row"><span class="info-label">Price</span><span class="info-value" style="color:var(--green)">${
        event.price === 0 ? 'Free' : '₹' + event.price
      }</span></div>
      <div class="info-row"><span class="info-label">Registrations</span><span class="info-value">${
        regs.length
      }</span></div>

    </div>
    ${
      event.description
        ? `<div class="label mb-8">Description</div><p class="muted" style="font-size:13px;line-height:1.7">${event.description}</p>`
        : ''
    }
    ${
      (event.tags || []).length
        ? `<div class="label mt-16 mb-8">Tags</div><div class="tag-list">${event.tags
            .map(tag => `<span class="tag">${tag}</span>`)
            .join('')}</div>`
        : ''
    }
    ${reviewAction}
    ${
      CU.role === 'organizer' && !isBookedClientEvent(event)
        ? `<div class="flex gap-8 mt-20"><button class="btn btn-primary w-full" onclick="closeDrawer();openEditEventModal('${id}')">✏️ Edit Event</button></div>`
        : ''
    }
  `
  );
}
function submitCompletedEventReview(eventId) {
  const rating = Number(v('event-review-rating'));
  const comment = v('event-review-comment');
  if (!rating || rating < 1 || rating > 5 || !comment.trim()) {
    toast('Choose a 1–5 star rating and enter a written review.', 'error');
    return;
  }
  runWorkflowAction(
    () =>
      apiSubmitPrivateOrganizerReview({
        eventId,
        rating,
        comment: comment.trim(),
      }),
    'Review submitted and published to the organizer profile'
  );
}
function viewPublicEventDetails(id) {
  const event = DB.events.find(currentEvent => currentEvent.id === id);
  if (!event) return;
  const regs = DB.registrations.filter(registration => registration.eventId === id);
  const org = DB.users.find(user => user.id === event.organizer) || {
    name: '—',
    avatar: '?',
  };
  const bannerHTML = event.image
    ? `
        <div style="height:140px;border-radius:12px;overflow:hidden;margin-bottom:16px;position:relative;background:${
          event.color || 'var(--accent)'
        }18">
          <img src="${event.image}" alt="${
        event.title || 'Event'
      }" style="width:100%;height:100%;object-fit:cover" onerror="this.parentElement.innerHTML='<div style=\'font-size:52px;text-align:center;padding:30px 0\'>${
        event.emoji || '📅'
      }</div>'">
        </div>
      `
    : `<div style="font-size:52px;text-align:center;margin-bottom:16px">${
        event.emoji || '📅'
      }</div>`;
  const orgAvHTML = org.avatarImage
    ? `
        <div style="width:40px;height:40px;border-radius:50%;overflow:hidden;background:var(--accent-dim);flex-shrink:0;position:relative">
          <img src="${org.avatarImage}" alt="${
        org.name
      }" style="width:100%;height:100%;object-fit:cover" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
          <div style="display:none;width:100%;height:100%;align-items:center;justify-content:center;color:var(--accent);font-weight:700">${
            org.avatar || org.name?.[0] || 'O'
          }</div>
        </div>
      `
    : `<div style="width:40px;height:40px;border-radius:50%;background:var(--accent-dim);color:var(--accent);display:flex;align-items:center;justify-content:center;font-weight:700;flex-shrink:0">${
        org.avatar || org.name?.[0] || 'O'
      }</div>`;
  openDrawer(
    event.title,
    `
    ${bannerHTML}
    <span class="badge badge-${evStatBadge(event.status)} mb-16">${event.status}</span>
    <div style="display:flex;flex-direction:column;gap:2px;margin-bottom:20px">
      <div class="info-row"><span class="info-label">Category</span><span class="info-value">${
        event.category
      }</span></div>
      <div class="info-row"><span class="info-label">Date & Time</span><span class="info-value">${
        event.date
      } · ${event.time}</span></div>
      <div class="info-row"><span class="info-label">Venue</span><span class="info-value" style="max-width:200px;text-align:right">${
        event.venue
      }</span></div>
      <div class="info-row"><span class="info-label">City</span><span class="info-value">${
        event.city || '—'
      }</span></div>
      <div class="info-row"><span class="info-label">Capacity</span><span class="info-value">${
        event.registered
      } / ${event.capacity}</span></div>
      <div class="info-row"><span class="info-label">Price</span><span class="info-value" style="color:var(--green)">${
        event.price === 0 ? 'Free' : '₹' + event.price
      }</span></div>
    </div>
    ${
      event.description
        ? `<div class="label mb-8">Description</div><p style="font-size:13px;line-height:1.7;color:var(--text);margin-bottom:16px">${event.description}</p>`
        : ''
    }
    <div class="label mb-8">Organizer</div>
    <div style="display:flex;align-items:center;gap:12px;padding:12px;background:var(--surface2);border-radius:8px;margin-bottom:16px">
      ${orgAvHTML}
      <div style="flex:1;min-width:0">
        <div style="font-weight:600">${org.name}</div>
        <div class="small" style="color:var(--text2)">${
          org.service || org.bio || 'Professional Event Organizer'
        }</div>
      </div>
    </div>
    ${
      (event.tags || []).length
        ? `<div class="label mb-8">Tags</div><div class="tag-list">${event.tags
            .map(tag => `<span class="tag">${tag}</span>`)
            .join('')}</div>`
        : ''
    }
  `
  );
}
function viewEventReport(eventId) {
  const event = DB.events.find(currentEvent => currentEvent.id == eventId);
  if (!event) return;
  const regs = DB.registrations.filter(registration => registration.eventId == eventId);
  const checkedIn = regs.filter(registration => registration.checkedIn).length;
  const totalRevenue = regs.reduce((sum, registration) => sum + registration.amount, 0);
  const avgRating = 4.5;
  const reportThumb = event.image
    ? `
        <div style="width:64px;height:64px;border-radius:10px;overflow:hidden;flex-shrink:0;background:${
          event.color || 'var(--accent)'
        }20;position:relative">
          <img src="${event.image}" alt="${
        event.title || 'Event'
      }" style="width:100%;height:100%;object-fit:cover" onerror="this.parentElement.innerHTML='<div style=\'font-size:48px\'>${
        event.emoji || '📅'
      }</div>'">
        </div>
      `
    : `<div style="font-size:48px">${event.emoji || '📅'}</div>`;
  openModal(
    `Event Report - ${event.title}`,
    `
    <div style="background:linear-gradient(135deg,${event.color}20,${
      event.color
    }05);border-radius:12px;padding:16px;margin-bottom:20px;border:1px solid ${event.color}30">
      <div style="display:flex;gap:14px;align-items:center">
        ${reportThumb}
        <div style="flex:1">
          <div style="font-weight:700;font-size:18px;margin-bottom:4px">${event.title}</div>
          <div style="font-size:13px;color:var(--text2)">📅 ${event.date} · 📍 ${event.venue}</div>
          <div style="font-size:12px;color:var(--text3);margin-top:6px">${
            event.category
          } • Status: Completed</div>
        </div>
      </div>
    </div>
    
    ${renderWorkflowFileReports(event.eventId || event.id)}
    <div class="grid-2" style="gap:12px;margin-bottom:20px">
      <div style="background:var(--surface2);padding:14px;border-radius:8px;border-left:3px solid var(--green)">
        <div style="font-size:11px;color:var(--text3);margin-bottom:4px">TOTAL REGISTRATIONS</div>
        <div style="font-size:24px;font-weight:800;color:var(--green)">${regs.length}</div>
        <div style="font-size:12px;color:var(--text2);margin-top:4px">Attendees registered</div>
      </div>
      <div style="background:var(--surface2);padding:14px;border-radius:8px;border-left:3px solid var(--blue)">
        <div style="font-size:11px;color:var(--text3);margin-bottom:4px">CHECK-INS</div>
        <div style="font-size:24px;font-weight:800;color:var(--blue)">${checkedIn}</div>
        <div style="font-size:12px;color:var(--text2);margin-top:4px">${Math.round(
          (checkedIn / regs.length) * 100
        )}% attendance rate</div>
      </div>
      <div style="background:var(--surface2);padding:14px;border-radius:8px;border-left:3px solid var(--green)">
        <div style="font-size:11px;color:var(--text3);margin-bottom:4px">TOTAL REVENUE</div>
        <div style="font-size:24px;font-weight:800;color:var(--green)">₹${totalRevenue.toLocaleString()}</div>
        <div style="font-size:12px;color:var(--text2);margin-top:4px">From ticket sales</div>
      </div>
      <div style="background:var(--surface2);padding:14px;border-radius:8px;border-left:3px solid var(--yellow)">
        <div style="font-size:11px;color:var(--text3);margin-bottom:4px">RATING</div>
        <div style="font-size:24px;font-weight:800;color:var(--yellow)">⭐ ${avgRating}</div>
        <div style="font-size:12px;color:var(--text2);margin-top:4px">Based on attendee reviews</div>
      </div>
    </div>
    
    <div style="margin-bottom:16px">
      <div style="font-weight:700;font-size:14px;margin-bottom:12px">Event Details Summary</div>
      <div style="display:flex;flex-direction:column;gap:8px;font-size:13px">
        <div style="display:flex;justify-content:space-between;padding:8px;background:var(--surface3);border-radius:6px">
          <span>Event Capacity:</span>
          <span style="font-weight:600">${event.capacity} attendees</span>
        </div>
        <div style="display:flex;justify-content:space-between;padding:8px;background:var(--surface3);border-radius:6px">
          <span>Occupancy:</span>
          <span style="font-weight:600;color:var(--green)">${Math.round(
            (regs.length / event.capacity) * 100
          )}%</span>
        </div>
        <div style="display:flex;justify-content:space-between;padding:8px;background:var(--surface3);border-radius:6px">
          <span>Ticket Price:</span>
          <span style="font-weight:600">₹${event.price}</span>
        </div>
        <div style="display:flex;justify-content:space-between;padding:8px;background:var(--surface3);border-radius:6px">
          <span>Duration:</span>
          <span style="font-weight:600">${event.time} onwards</span>
        </div>
      </div>
    </div>
    
    <div style="background:var(--surface3);padding:12px;border-radius:8px;border-left:2px solid var(--accent)">
      <div style="font-size:12px;color:var(--text2);line-height:1.6">
        <strong>Report Generated:</strong> ${new Date().toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
        })} at ${new Date().toLocaleTimeString()}<br>
        <strong>Event Status:</strong> Successfully Completed ✓<br>
        <strong>Next Step:</strong> Share this report with stakeholders or export as PDF
      </div>
    </div>
  `,
    [
      {
        lbl: '📥 Export PDF',
        cls: 'btn-ghost',
        fn: 'toast("PDF export feature coming soon","info")',
      },
      {
        lbl: 'Close',
        cls: 'btn-primary',
        fn: 'closeModal()',
      },
    ],
    false
  );
}

// ════════════════════════════════════════════════
//  BROWSE EVENTS (Attendee)
// ════════════════════════════════════════════════
function pageBrowseEvents() {
  const avail = DB.events.filter(event => event.status !== 'completed');
  return `
  <div class="page-hd">
    <div class="page-hd-left"><div class="page-title">Browse Events</div><div class="page-sub">Discover and register for upcoming events.</div></div>
  </div>
  <div class="filter-row">
    <div class="search-box input-group"><span class="input-icon">🔍</span><input class="form-control" id="be-q" placeholder="Search events…" oninput="refreshBrowse()"></div>
    <select class="form-control filter-select" id="be-cat" onchange="refreshBrowse()">
      <option value="">All Categories</option><option>Conference</option><option>Corporate</option><option>Concert</option><option>Workshop</option><option>Networking</option>
    </select>
    <select class="form-control filter-select" id="be-price" onchange="refreshBrowse()">
      <option value="">Any Price</option><option value="free">Free Only</option><option value="paid">Paid Only</option>
    </select>
    <select class="form-control filter-select" id="be-city" onchange="refreshBrowse()">
      <option value="">Any City</option>
      ${[...new Set(DB.events.map(event => event.city).filter(Boolean))]
        .map(c => `<option>${c}</option>`)
        .join('')}
    </select>
  </div>
  <div class="events-grid" id="browse-grid">${avail
    .map(e => evCard(e, 'attendee'))
    .join('')}</div>`;
}
function refreshBrowse() {
  const q = (g('be-q') || {}).value?.toLowerCase() || '';
  const cat = (g('be-cat') || {}).value || '';
  const price = (g('be-price') || {}).value || '';
  const city = (g('be-city') || {}).value || '';
  const list = DB.events.filter(event => {
    if (event.status === 'completed') return false;
    return (
      (!q || event.title.toLowerCase().includes(q)) &&
      (!cat || event.category === cat) &&
      (!price ||
        (price === 'free' && event.price === 0) ||
        (price === 'paid' && event.price > 0)) &&
      (!city || event.city === city)
    );
  });
  globalThis.window?.EventFlowClientPages?.clear(g('browse-grid'));
  g('browse-grid').innerHTML =
    list.map(e => evCard(e, 'attendee')).join('') ||
    `<div class="empty" style="grid-column:1/-1"><div class="empty-icon">🔍</div><div class="empty-title">No events match</div><p class="empty-desc">Try adjusting your filters.</p></div>`;
}
function regForEvent(eventId) {
  const event = DB.events.find(currentEvent => String(currentEvent.id) === String(eventId));
  if (!event || event.status === 'full') {
    toast(event ? 'Sorry, this event is full' : 'Event not found', 'error');
    return;
  }
  const existing = DB.registrations.find(
    registration =>
      String(registration.attendeeId) === String(CU.id) &&
      String(registration.eventId) === String(eventId)
  );
  if (existing) {
    openViewTicketModal(existing.id);
    return;
  }
  const regThumb = event.image
    ? `
        <div style="width:48px;height:48px;border-radius:8px;overflow:hidden;flex-shrink:0;background:${
          event.color || 'var(--accent)'
        }20;position:relative">
          <img src="${event.image}" alt="${
        event.title || 'Event'
      }" style="width:100%;height:100%;object-fit:cover" onerror="this.parentElement.innerHTML='<span style=\'font-size:32px\'>${
        event.emoji || '📅'
      }</span>'">
        </div>
      `
    : `<span style="font-size:32px">${event.emoji || '📅'}</span>`;

  // Show registration flow
  openModal(
    `Register — ${event.title}`,
    `
    <div style="background:${event.color}12;border:1px solid ${
      event.color
    }30;border-radius:var(--r-lg);padding:16px;margin-bottom:20px">
      <div class="flex items-center gap-12">
        ${regThumb}
        <div>
          <div style="font-weight:700;font-size:15px">${event.title}</div>
          <div class="small">📅 ${event.date} · ${event.time}</div>
          <div class="small">📍 ${event.venue}</div>
        </div>
      </div>
    </div>
    <div class="info-row" style="padding:8px 0"><span class="info-label">Attendee</span><span class="info-value">${
      CU.name
    }</span></div>
    <div class="info-row" style="padding:8px 0"><span class="info-label">Email</span><span class="info-value">${
      CU.email
    }</span></div>
    <div class="info-row" style="padding:8px 0 16px"><span class="info-label">Ticket Price</span><span class="info-value" style="color:var(--green);font-size:16px;font-weight:700">${
      event.price === 0 ? 'FREE' : '₹' + event.price
    }</span></div>
    ${
      event.price > 0
        ? `
    <div style="background:var(--surface3);border-radius:var(--r);padding:16px;border:1px solid var(--border)">
      <div class="h4 mb-12">💳 Payment Information</div>
      <div class="form-group"><label class="form-label">Cardholder Name</label><input class="form-control" id="pay-name" placeholder="Name on card" autocomplete="off"></div>
      <div class="form-group"><label class="form-label">Card Number *</label><input class="form-control" id="pay-card" placeholder="1234 5678 9012 3456" maxlength="19" oninput="fmtCard(this)"></div>
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Expiry *</label><input class="form-control" id="pay-exp" placeholder="MM/YY" maxlength="5" oninput="fmtExp(this)"></div>
        <div class="form-group"><label class="form-label">CVV *</label><input class="form-control" id="pay-cvv" placeholder="123" maxlength="3" inputmode="numeric" pattern="[0-9]{3}" oninput="this.value=this.value.replace(/[^0-9]/g,'')" autocomplete="cc-csc"></div>
      </div>
    </div>`
        : `<div style="text-align:center;padding:12px;background:var(--green-dim);border-radius:var(--r);color:var(--green);font-weight:500;font-size:13.5px">✓ This is a free event — no payment required!</div>`
    }
  `,
    [
      {
        lbl: event.price === 0 ? 'Confirm Registration' : 'Pay & Register',
        cls: 'btn-success',
        fn: `confirmReg('${eventId}')`,
      },
    ]
  );
}
function fmtCard(element) {
  element.value = element.value
    .replace(/\D/g, '')
    .replace(/(.{4})/g, '$1 ')
    .trim();
}
function fmtExp(element) {
  let v = element.value.replace(/\D/g, '');
  if (v.length >= 2) v = v.slice(0, 2) + '/' + v.slice(2);
  element.value = v;
}
function confirmReg(eventId) {
  const event = DB.events.find(currentEvent => String(currentEvent.id) === String(eventId));
  if (!event) return;
  if (event.price > 0) {
    const card = v('pay-card').replace(/\s/g, '');
    if (!card || card.length < 16) {
      toast('Enter a valid 16-digit card number', 'error');
      return;
    }
    const exp = v('pay-exp');
    if (!exp || exp.length < 5) {
      toast('Enter expiry date (MM/YY)', 'error');
      return;
    }
    const cvvVal = v('pay-cvv');
    if (!cvvVal || cvvVal.length < 3 || !/^[0-9]{3}$/.test(cvvVal)) {
      toast('CVV must be exactly 3 digits (numbers only)', 'error');
      return;
    }
  }

  // Call backend registration API
  const backendEventId = event.eventId || String(eventId);
  const attendeeId = CU.userId || CU.id;
  apiRegisterForEvent({
    attendeeId: String(attendeeId),
    eventId: backendEventId,
    ticketType: event.price === 0 ? 'free' : 'standard',
  })
    .then(function (regData) {
      // If paid event, also create payment
      if (event.price > 0) {
        apiMakePayment({
          registrationId: regData.registrationId,
          amount: event.price,
          paymentMethod: 'DEMO_PROVIDER',
          paymentDate: new Date().toISOString().split('T')[0],
        }).catch(function () {}); // payment fire-and-forget
      }
      // Update local DB
      const n = DB._nextId.regs++;
      const ticketId = regData.ticketId || `TKT-2026-${String(n).padStart(3, '0')}`;
      const seat =
        event.category === 'Conference'
          ? `A-${Math.floor(Math.random() * 200 + 1)
              .toString()
              .padStart(3, '0')}`
          : 'GA';
      DB.registrations.push({
        id: n,
        attendeeId: CU.id,
        eventId: event.id,
        date: today(),
        ticketId,
        status: 'confirmed',
        payment: event.price === 0 ? 'free' : 'paid',
        amount: event.price,
        checkedIn: false,
        seat,
        verificationId: regData.verificationId || ticketId,
      });
      event.registered = Math.min(event.registered + 1, event.capacity);
      if (event.registered >= event.capacity) event.status = 'full';
      saveDB();
      closeModal();
      toast('🎉 Registration confirmed! Check your tickets.', 'success');
      goNav('my-tickets');
    })
    .catch(function (error) {
      // Fallback: create locally if backend fails
      const n = DB._nextId.regs++;
      const ticketId = `TKT-2026-${String(n).padStart(3, '0')}`;
      const seat =
        event.category === 'Conference'
          ? `A-${Math.floor(Math.random() * 200 + 1)
              .toString()
              .padStart(3, '0')}`
          : 'GA';
      DB.registrations.push({
        id: n,
        attendeeId: CU.id,
        eventId: event.id,
        date: today(),
        ticketId,
        status: 'confirmed',
        payment: event.price === 0 ? 'free' : 'paid',
        amount: event.price,
        checkedIn: false,
        seat,
      });
      event.registered = Math.min(event.registered + 1, event.capacity);
      if (event.registered >= event.capacity) event.status = 'full';
      saveDB();
      closeModal();
      toast(
        error.message || '🎉 Registration confirmed (local)!',
        error.status === 409 ? 'warning' : 'success'
      );
      goNav('my-tickets');
    });
}
function cancelTicket(regId) {
  const registration = DB.registrations.find(eventRegistration => eventRegistration.id == regId);
  if (!registration) return;
  const event = DB.events.find(currentEvent => currentEvent.id === registration.eventId);
  confirm2(
    'Cancel Ticket',
    'Are you sure you want to cancel this ticket? You will receive a refund within 5-7 business days.',
    () => {
      if (event) event.registered = Math.max(0, event.registered - 1);
      const index = DB.registrations.indexOf(registration);
      if (index > -1) DB.registrations.splice(index, 1);
      saveDB();
      renderPage(_currentPage);
      toast('Ticket cancelled. Refund initiated.', 'success');
    }
  );
}

// ════════════════════════════════════════════════
//  MY TICKETS
// ════════════════════════════════════════════════
function pageMyTickets() {
  const regs = DB.registrations.filter(registration => registration.attendeeId === CU.id);
  if (!regs.length)
    return `<div class="page-hd"><div class="page-hd-left"><div class="page-title">My Tickets</div></div></div><div class="empty"><div class="empty-icon">🎟️</div><div class="empty-title">No tickets yet</div><p class="empty-desc">Browse events and register to get your tickets here.</p><button class="btn btn-primary mt-16" onclick="goNav('browse-events')">Browse Events</button></div>`;
  return `
  <div class="page-hd">
    <div class="page-hd-left"><div class="page-title">My Tickets</div><div class="page-sub">${
      regs.length
    } ticket(s)</div></div>
  </div>
  <div style="display:flex;flex-direction:column;gap:16px">
    ${regs
      .map(registration => {
        const eventRegistration = DB.events.find(event => event.id === registration.eventId) || {
          title: 'Unknown',
          emoji: '🎟️',
          color: '#7c6ff7',
          venue: '',
          date: '',
          time: '',
        };
        return ticketCard(registration, eventRegistration);
      })
      .join('')}
  </div>`;
}
function ticketCard(r, e) {
  const qr = renderTicketQRCode(r.verificationId || r.ticketId);
  return `<div class="ticket">
    <div class="ticket-top">
      <div class="flex justify-between items-start">
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
            <span style="font-size:28px">${e.emoji}</span>
            <span class="badge badge-${evStatBadge(e.status)}">${e.status}</span>
          </div>
          <div style="font-family:var(--font-head);font-size:17px;font-weight:700;line-height:1.3;margin-bottom:8px">${
            e.title
          }</div>
          <div class="small" style="margin-bottom:2px">📅 ${e.date} · ${e.time}</div>
          <div class="small">📍 ${e.venue}</div>
        </div>
        <div class="qr-box ticket-qr" style="margin-left:16px">${qr}</div>
      </div>
    </div>
    <div class="ticket-divider"><div class="ticket-notch-l"></div><div class="ticket-notch-r"></div></div>
    <div class="ticket-bot">
      <div class="grid-2" style="gap:8px">
        <div><div class="label mb-4">Attendee</div><div style="font-weight:500;font-size:13.5px">${
          CU.name
        }</div></div>
        <div><div class="label mb-4">Ticket ID</div><div class="mono">${r.ticketId}</div></div>
        <div><div class="label mb-4">Seat / Zone</div><div style="font-weight:500;font-size:13.5px">${
          r.seat || 'GA'
        }</div></div>
        <div><div class="label mb-4">Amount</div><div style="font-weight:700;font-size:15px;color:var(--green)">${
          r.amount === 0 ? 'Free' : '₹' + r.amount
        }</div></div>
      </div>
      <div class="flex justify-between items-center mt-12">
        <span class="badge badge-${r.checkedIn ? 'green' : 'purple'}">${
    r.checkedIn ? '✅ Checked In' : '⏳ Not Yet Checked In'
  }</span>
        <span class="badge badge-green">✓ ${
          r.payment === 'free' ? 'Free Ticket' : 'Payment Confirmed'
        }</span>
      </div>
    </div>
  </div>`;
}
function makeQR() {
  const cells = Array.from(
    {
      length: 25,
    },
    () => Math.random() > 0.5
  );
  return cells.map(on => `<div class="qr-cell${on ? ' on' : ''}"></div>`).join('');
}
function openViewTicketModal(regId) {
  const r = DB.registrations.find(registration => registration.id == regId);
  if (!r) return;
  const e = DB.events.find(event => event.id === r.eventId) || {
    title: 'Event',
    emoji: '🎟️',
    venue: '',
    date: '',
    time: '',
  };
  openModal('Your Ticket', ticketCard(r, e), [], false);
}

// ════════════════════════════════════════════════
//  ATTENDEE MANAGEMENT
// ════════════════════════════════════════════════
function pageAttendees() {
  const myEvents = DB.events.filter(event => event.organizer === CU.id);
  const selectedEventId = parseInt(
    sessionStorage.getItem('org_attendees_event') || myEvents[0]?.id || ''
  );
  const selectedEvent = DB.events.find(event => event.id === selectedEventId);
  const isPrivateEvent =
    selectedEvent &&
    (selectedEvent.category === 'Wedding' || selectedEvent.tags?.includes('Private'));
  const regs =
    CU.role === 'organizer'
      ? DB.registrations.filter(registration =>
          selectedEventId
            ? registration.eventId === selectedEventId
            : selectedEvent && registration.eventId === selectedEvent.id
        )
      : CU.role === 'superuser'
      ? DB.registrations
      : DB.registrations.filter(registration => {
          const event = DB.events.find(currentEvent => currentEvent.id === registration.eventId);
          return event && event.organizer === CU.id;
        });
  const checkedIn = regs.filter(registration => registration.checkedIn).length;
  const approved = regs.filter(
    registration => registration.approved || registration.status === 'confirmed'
  ).length;
  if (CU.role === 'organizer' && myEvents.length > 0) {
    return `
    <div class="page-hd">
      <div class="page-hd-left"><div class="page-title">Attendee Management</div><div class="page-sub">${
        regs.length
      } total · ${approved} approved</div></div>
      <div class="page-hd-right">
      </div>
    </div>
    <div class="card mb-16" style="padding:16px">
      <label class="label mb-8">Select Event</label>
      <select class="form-control" onchange="switchOrganizerEvent(this.value)">
        ${myEvents
          .map(
            event =>
              `<option value="${event.id}" ${event.id === selectedEventId ? 'selected' : ''}>${
                event.title
              } (${event.registered} registered)</option>`
          )
          .join('')}
      </select>
      ${
        isPrivateEvent
          ? `<div class="badge badge-blue mt-8" style="display:inline-block">🔒 Private Event</div>`
          : ''
      } 
    </div>
    <div class="filter-row">
      <div class="search-box input-group"><span class="input-icon">🔍</span><input class="form-control" id="at-q" placeholder="Search attendees…" oninput="refreshAttendees()"></div>
      ${
        isPrivateEvent
          ? `<select class="form-control filter-select" id="at-status" onchange="refreshAttendees()">
        <option value="">All Status</option>
        <option value="approved">Approved</option>
        <option value="pending">Pending Review</option>
        <option value="rejected">Rejected</option>
      </select>`
          : ``
      }
    </div>
    <div id="attendees-tbl">${buildOrganizerAttendeesTbl(regs, selectedEvent, isPrivateEvent)}</div>
    `;
  }
  const checkedIn2 = regs.filter(registration => registration.checkedIn).length;
  return `
  <div class="page-hd">
    <div class="page-hd-left"><div class="page-title">Attendee Management</div><div class="page-sub">${
      regs.length
    } total · ${checkedIn2} checked in</div></div>
    <div class="page-hd-right">
      <button class="btn btn-ghost" onclick="toast('Exported to CSV','success')">📥 Export CSV</button>
    </div>
  </div>
  <div class="filter-row">
    <div class="search-box input-group"><span class="input-icon">🔍</span><input class="form-control" id="at-q" placeholder="Search attendees…" oninput="refreshAttendees()"></div>
    <select class="form-control filter-select" id="at-ev" onchange="refreshAttendees()">
      <option value="">All Events</option>
      ${DB.events.map(event => `<option value="${event.id}">${event.title}</option>`).join('')}
    </select>
    <select class="form-control filter-select" id="at-ci" onchange="refreshAttendees()">
      <option value="">All</option><option value="in">Checked In</option><option value="out">Not Checked In</option>
    </select>
  </div>
  <div id="attendees-tbl">${buildAttendeesTbl(regs)}</div>`;
}
function switchOrganizerEvent(eventId) {
  sessionStorage.setItem('org_attendees_event', eventId);
  renderPage('attendees');
}
function buildOrganizerAttendeesTbl(registrations, event, isPrivate) {
  const q = (g('at-q') || {}).value?.toLowerCase() || '';
  const status = (g('at-status') || {}).value || '';
  const filtered = registrations.filter(registration => {
    const eventRegistration = DB.users.find(
      user => String(user.id) === String(registration.attendeeId)
    ) || {
      name: '',
      email: '',
    };
    const matchesSearch =
      !q ||
      (eventRegistration.name + eventRegistration.email + registration.ticketId)
        .toLowerCase()
        .includes(q);
    const matchesStatus =
      !status ||
      (status === 'approved' && (registration.approved || registration.status === 'confirmed')) ||
      (status === 'pending' && !registration.approved && registration.status !== 'rejected') ||
      (status === 'rejected' && registration.status === 'rejected');
    return matchesSearch && matchesStatus;
  });
  if (!filtered.length)
    return `<div class="empty"><div class="empty-icon">👥</div><div class="empty-title">No attendees found</div></div>`;
  return `<div class="table-wrap"><table>
    <thead><tr><th>Attendee</th><th>Email</th><th>Ticket ID</th><th>Amount</th><th>${
      isPrivate ? 'Approval Status' : 'Arrival'
    }</th><th>Actions</th></tr></thead>
    <tbody>${filtered
      .map(r => {
        const u = DB.users.find(user => String(user.id) === String(r.attendeeId)) || {
          name: 'Unknown',
          email: '',
          avatar: '?',
          phone: '',
        };
        const status = r.approved ? 'Approved' : r.status === 'rejected' ? 'Rejected' : 'Pending';
        return `<tr>
        <td><div class="flex items-center gap-8"><div class="av av-xs">${
          u.avatar || u.name[0]
        }</div><div><div style="font-weight:500">${u.name}</div><div class="small">${
          u.phone || '—'
        }</div></div></div></td>
        <td class="small">${u.email}</td>
        <td><code class="mono" style="background:var(--surface3);padding:2px 6px;border-radius:5px">${
          r.ticketId
        }</code></td>
        <td style="color:var(--green);font-weight:600">${
          r.amount === 0 ? 'Free' : '₹' + r.amount
        }</td>
        <td><span class="badge badge-${
          status === 'Approved' ? 'green' : status === 'Rejected' ? 'red' : 'yellow'
        }">${status}</span></td>
        <td><div class="actions">
          ${
            status === 'Pending'
              ? `<button class="btn btn-success btn-xs" onclick="organiserApproveAttendee('${r.id}')">✓ Approve</button><button class="btn btn-danger btn-xs" onclick="organiserRejectAttendee('${r.id}')">✕ Reject</button>`
              : `<button class="btn btn-ghost btn-xs" onclick="viewAttendeeProfile('${u.id}','${u.name}','${u.email}','${u.phone}')">Profile</button>`
          }
        </div></td>
      </tr>`;
      })
      .join('')}</tbody>
  </table></div>`;
}
function organiserApproveAttendee(regId) {
  const r = DB.registrations.find(registration => String(registration.id) === String(regId));
  if (r) {
    r.approved = true;
    r.status = 'confirmed';
    saveDB();
    renderPage('attendees');
    toast('Attendee approved!', 'success');
  }
}
function organiserRejectAttendee(regId) {
  confirm2('Reject Attendee', 'Are you sure you want to reject and remove this attendee?', () => {
    const i = DB.registrations.findIndex(registration => String(registration.id) === String(regId));
    if (i > -1) {
      const ev = DB.events.find(event => String(event.id) === String(DB.registrations[i].eventId));
      if (ev && ev.registered > 0) {
        ev.registered--;
        if (ev.status === 'full') ev.status = 'upcoming';
      }
      DB.registrations.splice(i, 1);
      saveDB();
      renderPage('attendees');
      toast('Attendee rejected and removed', 'info');
    }
  });
}
function viewAttendeeProfile(userId, name, email, phone) {
  const u = DB.users.find(user => String(user.id) === String(userId)) || {};
  openDrawer(
    `${name} - Attendee Profile`,
    `
    <div style="display:flex;flex-direction:column;gap:16px">
      <div class="av av-lg" style="width:80px;height:80px;font-size:32px">${
        u.avatar || name[0]
      }</div>
      <div>
        <div class="label">Name</div>
        <div style="font-weight:500">${name}</div>
      </div>
      <div>
        <div class="label">Email</div>
        <div class="small">${email}</div>
      </div>
      <div>
        <div class="label">Phone</div>
        <div class="small">${phone || '—'}</div>
      </div>
      ${
        u.bio
          ? `<div>
        <div class="label">Bio</div>
        <p class="small" style="color:var(--text2)">${u.bio}</p>
      </div>`
          : ''
      }
    </div>
  `
  );
}
function buildAttendeesTbl(registrations) {
  if (!registrations.length)
    return `<div class="empty"><div class="empty-icon">👥</div><div class="empty-title">No registrations found</div></div>`;
  return `<div class="table-wrap"><table>
    <thead><tr><th>Attendee</th><th>Event</th><th>Ticket ID</th><th>Seat</th><th>Amount</th><th>Check-In</th><th>Actions</th></tr></thead>
    <tbody>${registrations
      .map(registration => {
        const eventRegistration = DB.users.find(user => user.id === registration.attendeeId) || {
          name: 'Unknown',
          email: '',
          avatar: '?',
        };
        const e = DB.events.find(event => event.id === registration.eventId) || {
          title: '—',
        };
        return `<tr>
        <td><div class="flex items-center gap-8"><div class="av av-xs">${
          eventRegistration.avatar || eventRegistration.name[0]
        }</div><div><div style="font-weight:500">${
          eventRegistration.name
        }</div><div class="small">${eventRegistration.email}</div></div></div></td>
        <td class="truncate" style="max-width:160px;font-size:13px">${e.title}</td>
        <td><code class="mono" style="background:var(--surface3);padding:2px 6px;border-radius:5px">${
          registration.ticketId
        }</code></td>
        <td class="muted">${registration.seat || 'GA'}</td>
        <td style="color:var(--green);font-weight:600">${
          registration.amount === 0 ? 'Free' : '₹' + registration.amount
        }</td>
        <td><span class="badge badge-${registration.checkedIn ? 'green' : 'gray'}">${
          registration.checkedIn ? '✓ In' : 'Pending'
        }</span></td>
        <td><div class="actions">
          ${
            !registration.checkedIn
              ? `<button class="btn btn-success btn-xs" onclick="scanQR(${registration.id},'${registration.ticketId}')">📱 Scan QR</button>`
              : '<span class="small" style="color:var(--text3)">Verified</span>'
          }
          <button class="btn btn-xs btn-danger" onclick="cancelReg('${
            registration.id
          }')">🗑️</button>
        </div></td>
      </tr>`;
      })
      .join('')}</tbody>
  </table></div>`;
}
function refreshAttendees() {
  if (CU.role === 'organizer') {
    const q = (g('at-q') || {}).value?.toLowerCase() || '';
    const status = (g('at-status') || {}).value || '';
    const selectedEventId = parseInt(sessionStorage.getItem('org_attendees_event') || '');
    const selectedEvent = DB.events.find(event => event.id === selectedEventId);
    const isPrivate =
      selectedEvent &&
      (selectedEvent.category === 'Wedding' || selectedEvent.tags?.includes('Private'));
    let regs = DB.registrations.filter(registration =>
      selectedEventId
        ? registration.eventId === selectedEventId
        : selectedEvent && registration.eventId === selectedEvent.id
    );
    regs = regs.filter(registration => {
      const eventRegistration = DB.users.find(user => user.id === registration.attendeeId) || {
        name: '',
        email: '',
      };
      const matchesSearch =
        !q ||
        (eventRegistration.name + eventRegistration.email + registration.ticketId)
          .toLowerCase()
          .includes(q);
      const matchesStatus =
        !status ||
        (status === 'approved' && (registration.approved || registration.status === 'confirmed')) ||
        (status === 'pending' && !registration.approved && registration.status !== 'rejected') ||
        (status === 'rejected' && registration.status === 'rejected');
      return matchesSearch && matchesStatus;
    });
    globalThis.window?.EventFlowClientPages?.clear(g('attendees-tbl'));
    g('attendees-tbl').innerHTML = buildOrganizerAttendeesTbl(regs, selectedEvent, isPrivate);
  } else {
    const q = (g('at-q') || {}).value?.toLowerCase() || '';
    const evId = parseInt((g('at-ev') || {}).value) || 0;
    const ci = (g('at-ci') || {}).value || '';
    const regs = (
      CU.role === 'superuser'
        ? DB.registrations
        : DB.registrations.filter(registration => {
            const event = DB.events.find(currentEvent => currentEvent.id === registration.eventId);
            return event && event.organizer === CU.id;
          })
    ).filter(r => {
      const u = DB.users.find(user => user.id === r.attendeeId) || {
        name: '',
        email: '',
      };
      return (
        (!q || (u.name + u.email + r.ticketId).toLowerCase().includes(q)) &&
        (!evId || r.eventId === evId) &&
        (!ci || (ci === 'in' && r.checkedIn) || (ci === 'out' && !r.checkedIn))
      );
    });
    globalThis.window?.EventFlowClientPages?.clear(g('attendees-tbl'));
    g('attendees-tbl').innerHTML = buildAttendeesTbl(regs);
  }
}
function scanQR(regId, ticketId) {
  const r = DB.registrations.find(registration => registration.id == regId);
  if (r) {
    r.checkedIn = true;
    saveDB();
    openModal(
      'QR Code Verified',
      `
      <div style="text-align:center;padding:20px">
        <div style="font-size:48px;margin-bottom:16px">✅</div>
        <div style="font-weight:700;font-size:18px;margin-bottom:8px">Check-in Successful</div>
        <div style="color:var(--text2);margin-bottom:20px">Ticket: <code class="mono" style="background:var(--surface3);padding:4px 8px;border-radius:5px">${ticketId}</code></div>
        <div style="background:var(--green-dim);border-radius:8px;padding:12px;color:var(--green);font-weight:500">Attendee verified and checked in</div>
      </div>
    `,
      [
        {
          lbl: 'Close',
          cls: 'btn-primary',
          fn: 'closeModal()',
        },
      ]
    );
    refreshAttendees();
    toast('✅ Attendee verified via QR scan', 'success');
  }
}

// Quick verify: marks checkedIn + rerenders page (no modal, instant list move)
function quickVerify(regId) {
  const registration = DB.registrations.find(eventRegistration => eventRegistration.id == regId);
  if (!registration) {
    toast('Registration not found', 'error');
    return;
  }
  if (registration.checkedIn) {
    toast('Already verified!', 'warning');
    return;
  }
  registration.checkedIn = true;
  saveDB();
  renderPage('attendeeVerification');
  toast('✅ Attendee verified and moved to checked-in!', 'success');
}
function cancelReg(regId) {
  confirm2('Cancel Registration', 'Cancel this registration? This cannot be undone.', () => {
    const i = DB.registrations.findIndex(registration => registration.id == regId);
    if (i > -1) {
      const ev = DB.events.find(event => event.id === DB.registrations[i].eventId);
      if (ev && ev.registered > 0) {
        ev.registered--;
        if (ev.status === 'full') ev.status = 'upcoming';
      }
      DB.registrations.splice(i, 1);
      saveDB();
      refreshAttendees();
      toast('Registration cancelled', 'info');
    }
  });
}
function generateReport() {
  const regs =
    CU.role === 'superuser'
      ? DB.registrations
      : DB.registrations.filter(registration => {
          const event = DB.events.find(currentEvent => currentEvent.id === registration.eventId);
          return event && event.organizer === CU.id;
        });
  const checkedIn = regs.filter(registration => registration.checkedIn);
  const report = `
    <div style="background:var(--surface2);border-radius:12px;padding:20px;margin-bottom:16px">
      <div class="h4 mb-12">📊 Attendance Report</div>
      <div class="grid-2" style="gap:12px;margin-bottom:16px">
        <div><div class="label mb-4">Total Registrations</div><div style="font-size:24px;font-weight:800;color:var(--accent)">${
          regs.length
        }</div></div>
        <div><div class="label mb-4">Checked In</div><div style="font-size:24px;font-weight:800;color:var(--green)">${
          checkedIn.length
        }</div></div>
        <div><div class="label mb-4">No-Show</div><div style="font-size:24px;font-weight:800;color:var(--red)">${
          regs.length - checkedIn.length
        }</div></div>
        <div><div class="label mb-4">Attendance Rate</div><div style="font-size:24px;font-weight:800;color:var(--blue)">${Math.round(
          (checkedIn.length / Math.max(regs.length, 1)) * 100
        )}%</div></div>
      </div>
    </div>
    <div class="h4 mb-12">📋 Attendee List</div>
    <div style="display:flex;flex-direction:column;gap:8px;max-height:400px;overflow-y:auto">
      ${regs
        .map(registration => {
          const eventRegistration = DB.users.find(user => user.id === registration.attendeeId) || {
            name: 'Unknown',
            email: '',
          };
          return `<div style="display:flex;justify-content:space-between;padding:8px;background:var(--surface3);border-radius:8px;align-items:center">
          <div>
            <div style="font-weight:500;font-size:13px">${eventRegistration.name}</div>
            <div class="small" style="color:var(--text3)">${eventRegistration.email}</div>
          </div>
          <span class="badge badge-${registration.checkedIn ? 'green' : 'gray'}">${
            registration.checkedIn ? 'OK Present' : 'Absent'
          }</span>
        </div>`;
        })
        .join('')}
    </div>
  `;
  openDrawer('Attendance Report', report);
}

// ════════════════════════════════════════════════
// ════════════════════════════════════════════════

// ════════════════════════════════════════════════

// ════════════════════════════════════════════════

// ════════════════════════════════════════════════

// ════════════════════════════════════════════════
//  EVENT REQUESTS
// ════════════════════════════════════════════════
function pageEventRequests() {
  return `
  <div class="page-hd"><div class="page-hd-left"><div class="page-title">Event Requests</div><div class="page-sub">Review and manage client event requests.</div></div></div>
  <div class="table-wrap">
    <table><thead><tr><th>Client</th><th>Event</th><th>Type</th><th>Date</th><th>Guests</th><th>Budget</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>${DB.eventRequests
      .map(request => {
        const cl = DB.users.find(user => String(user.id) === String(request.clientId)) ||
          DB.users.find(user => user.role === 'client') || {
            name: 'Michael Torres',
            avatar: 'MT',
            avatarImage: '/assets/images/avatars/user-michael-torres.jpg',
          };
        const clientAv = cl.avatarImage
          ? `
          <div class="av av-xs">
            <img src="${cl.avatarImage}" alt="${
              cl.name
            }" onerror="this.style.display='none';this.nextElementSibling.style.display='block'">
            <span style="display:none">${cl.avatar || cl.name?.[0] || 'C'}</span>
          </div>
        `
          : `<div class="av av-xs">${cl.avatar || cl.name?.[0] || 'C'}</div>`;
        return `<tr>
        <td><div class="flex items-center gap-8">${clientAv}<strong>${cl.name}</strong></div></td>
        <td><strong>${request.title}</strong></td><td>${request.type}</td><td>${
          request.date
        }</td><td>${request.guests}</td>
        <td style="color:var(--green);font-weight:600">₹${request.budget.toLocaleString()}</td>
        <td><span class="badge badge-${reqBadge(request.status)}">${request.status}</span></td>
        <td><div class="actions">
          <button class="btn btn-ghost btn-xs" onclick="viewRequestDrawer('${
            request.id
          }')">View</button>
          ${
            request.status === 'pending'
              ? `<button class="btn btn-success btn-xs" onclick="approveReq('${request.id}')">Accept</button><button class="btn btn-xs btn-danger" onclick="rejectReq('${request.id}')">Decline</button>`
              : ''
          }
        </div></td>
      </tr>`;
      })
      .join('')}
    </tbody></table>
  </div>`;
}
function workflowPayload(response) {
  return response && Object.prototype.hasOwnProperty.call(response, 'data')
    ? response.data
    : response;
}
function syncWorkflowFileReports(reports) {
  DB.eventFileReports = reports;
  reports.forEach(report => {
    if (report.clientUserId) {
      const user = DB.users.find(item => String(item.id) === String(report.clientUserId));
      const contact = {
        id: report.clientUserId,
        clientId: report.clientId,
        name: report.clientName || 'Requesting client',
        email: report.clientEmail || '',
        role: 'client',
      };
      if (user) Object.assign(user, contact);
      else DB.users.push(contact);
    }
  });
  DB.reports = (DB.reports || [])
    .filter(report => !report.backendManaged)
    .concat(
      reports.map(report => ({
        ...report,
        id: report.eventReportId,
        fileName: report.documentName || report.reportTitle,
        submittedBy: report.organizerUserId,
        recipientId: report.clientUserId,
        submittedAt: report.createdAt,
        backendManaged: true,
      }))
    );
}
function renderWorkflowFileReports(eventId) {
  const reports = (DB.eventFileReports || []).filter(
    report => String(report.eventId) === String(eventId)
  );
  return reports.length
    ? `<section style="margin-top:16px"><h3>Reports from the Organizer</h3>${reports
        .map(
          report =>
            `<div style="padding:12px;border:1px solid var(--border);margin-top:8px"><strong>${workflowHtml(
              report.reportTitle
            )}</strong><p style="white-space:pre-wrap;color:var(--text2)">${workflowHtml(
              report.reportDetails
            )}</p>${
              report.documentFileName
                ? `<button class="btn btn-ghost btn-sm" onclick="downloadWorkflowEventReport('${workflowHtml(
                    report.eventReportId
                  )}')">Download ${workflowHtml(report.documentName)}</button>`
                : ''
            }</div>`
        )
        .join('')}</section>`
    : '';
}
async function downloadWorkflowEventReport(reportId) {
  try {
    const response = await fetch(
      `${API_BASE_URL}/reports/events/${encodeURIComponent(reportId)}/file`,
      {
        headers: getAuthHeader()
          ? {
              Authorization: getAuthHeader(),
            }
          : {},
      }
    );
    if (!response.ok) throw new Error('Unable to download this event report');
    const report = (DB.eventFileReports || []).find(item => item.eventReportId === reportId);
    const objectUrl = URL.createObjectURL(await response.blob());
    const link = document.createElement('a');
    link.href = objectUrl;
    link.download = report?.documentName || 'event-report';
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000);
  } catch (error) {
    toast(error.message || 'Unable to download the report', 'error');
  }
}
let workflowEventPolicy = null;
async function loadWorkflowEventPolicy(request) {
  if (request?.policySnapshot) return request.policySnapshot;
  workflowEventPolicy = workflowPayload(await apiGetEventPolicy());
  return workflowEventPolicy;
}
const workflowPolicyDocuments = new Map();
let workflowPolicyDocument = null;
function renderWorkflowEventPolicy(policy, checkboxId) {
  if (!policy)
    return '<p role="alert">Event policies could not be loaded. Refresh before continuing.</p>';
  workflowPolicyDocuments.set(policy.version, policy);
  return `<section style="margin:16px 0;padding:16px;border:1px solid var(--border);background:var(--surface2)">
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <button type="button" class="btn btn-ghost" data-policy-version="${workflowHtml(
            policy.version
          )}" onclick="openWorkflowPolicyDocument('policies', this.dataset.policyVersion)">Event Policies &amp; Rules</button>
          <button type="button" class="btn btn-ghost" data-policy-version="${workflowHtml(
            policy.version
          )}" onclick="openWorkflowPolicyDocument('terms', this.dataset.policyVersion)">Terms and Conditions</button>
        </div>
        <p class="small" style="margin:12px 0 0;line-height:1.6">Cancellation requires at least ${
          policy.cancellation.minimumNoticeDays
        } days' notice. The cancellation fee is ${
    policy.cancellation.feePercent
  }% of the amount actually paid.</p>
        <p class="small" style="margin:8px 0 0">Policy version: ${workflowHtml(policy.version)}</p>
        ${
          checkboxId
            ? `<label for="${checkboxId}" style="display:flex;align-items:flex-start;gap:10px;margin-top:16px;cursor:pointer"><input id="${checkboxId}" type="checkbox" required style="width:auto;margin-top:4px;flex-shrink:0"><span style="font-size:13px;line-height:1.6">I have read and agree to the Event Rules, Cancellation Policy, and Terms and Conditions.</span></label>`
            : ''
        }
      </section>`;
}
function openWorkflowPolicyDocument(kind, version) {
  const policy = workflowPolicyDocuments.get(version);
  if (!policy || !['policies', 'terms'].includes(kind)) {
    toast('Event policies could not be loaded. Refresh before continuing.', 'error');
    return;
  }
  closeWorkflowPolicyDocument();
  const previousFocus = document.activeElement;
  const title = kind === 'terms' ? 'Terms and Conditions' : 'Event Policies & Rules';
  const sections = policy.sections.filter(
    section => (section.title.toLowerCase() === 'terms and conditions') === (kind === 'terms')
  );
  const overlay = document.createElement('div');
  overlay.id = 'workflow-policy-document';
  overlay.className = 'overlay open';
  overlay.style.zIndex = '1100';
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.setAttribute('aria-labelledby', 'workflow-policy-title');
  globalThis.window?.EventFlowClientPages?.clear(overlay);
  overlay.innerHTML = `<div class="modal-box" style="max-width:760px">
        <div class="modal-head"><span class="modal-title" id="workflow-policy-title">${workflowHtml(
          title
        )}</span><button type="button" class="modal-close-btn" aria-label="Back to event form" onclick="closeWorkflowPolicyDocument()">&times;</button></div>
        <div class="modal-body">
          ${sections
            .map(
              section =>
                `<section style="margin-bottom:18px"><h3 style="margin:0 0 10px">${workflowHtml(
                  section.title
                )}</h3><ul style="margin:0;padding-left:20px;color:var(--text2);font-size:13px;line-height:1.8">${section.items
                  .map(item => `<li>${workflowHtml(item)}</li>`)
                  .join('')}</ul></section>`
            )
            .join('')}
          <p class="small">Policy version: ${workflowHtml(policy.version)}</p>
        </div>
        <div class="modal-foot"><button type="button" class="btn btn-ghost" onclick="closeWorkflowPolicyDocument()">Back</button></div>
      </div>`;
  overlay.addEventListener('click', event => {
    if (event.target === overlay) closeWorkflowPolicyDocument();
  });
  overlay.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      event.preventDefault();
      event.stopPropagation();
      closeWorkflowPolicyDocument();
    } else if (event.key === 'Tab') {
      const buttons = overlay.querySelectorAll('button');
      const first = buttons[0];
      const last = buttons[buttons.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
  });
  workflowPolicyDocument = {
    overlay,
    previousFocus,
  };
  document.body.appendChild(overlay);
  overlay.querySelector('.modal-close-btn').focus();
}
function closeWorkflowPolicyDocument() {
  if (!workflowPolicyDocument) return;
  const { overlay, previousFocus } = workflowPolicyDocument;
  workflowPolicyDocument = null;
  overlay.remove();
  if (previousFocus?.isConnected) previousFocus.focus();
}
function workflowPolicyAcknowledgement(policy, checkboxId) {
  if (!policy || !g(checkboxId)?.checked) {
    toast('Read and accept the event rules, policies, and terms before continuing.', 'error');
    return null;
  }
  return {
    policyAccepted: true,
    acceptedPolicyVersion: policy.version,
  };
}
function workflowMoney(value) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(Number(value) || 0);
}
function workflowPolicyDate(value) {
  const date = new Date(value);
  return value && !Number.isNaN(date.getTime())
    ? date.toLocaleString('en-IN', {
        timeZone: 'Asia/Kolkata',
      }) + ' IST'
    : 'Not recorded';
}
function renderWorkflowCancellation(cancellation, request = {}, compact = false) {
  const event = (DB.events || []).find(
    item => request.eventId && String(item.eventId || item.id) === String(request.eventId)
  );
  const record = cancellation || event?.cancellation;
  if (!record && request.status !== 'cancelled') return '';
  const c = record || {};
  const actor = (DB.users || []).find(
    user => c.cancelledBy && String(user.userId || user.id) === String(c.cancelledBy)
  );
  const role = c.cancelledByRole || actor?.role || actor?.userRole;
  const matchesActor = id =>
    id != null && c.cancelledBy != null && String(id) === String(c.cancelledBy);
  const organizer =
    ['organizer', 'event_organizer'].includes(role) ||
    [
      request.organizerUserId,
      request.organizer,
      request.organizerId,
      request.backendOrganizerId,
    ].some(matchesActor);
  const client =
    role === 'client' ||
    [request.clientUserId, request.clientId, request.backendClientId, CU?.id].some(matchesActor);
  const heading = organizer
    ? 'Cancelled by organizer'
    : client
    ? 'Cancelled by you'
    : ['super_admin', 'superuser'].includes(role)
    ? 'Cancelled by administrator'
    : 'Event cancelled';
  const actorName =
    c.cancelledByName ||
    actor?.name ||
    (organizer ? request.organizerName : client ? CU?.name : '');
  const reason =
    c.reason ||
    request.cancelReason ||
    request.cancellationReason ||
    event?.cancellationReason ||
    'A cancellation reason was not recorded. Contact the organizer for details.';
  const explanation = c.explanation || request.cancelExplanation;
  const hasAmounts = ['paidAmount', 'cancellationFee', 'refundAmount'].every(
    key => c[key] != null && c[key] !== '' && Number.isFinite(Number(c[key])) && Number(c[key]) >= 0
  );
  const refundAmount = hasAmounts ? Number(c.refundAmount) : null;
  const refundStatus = c.refundStatus || request.refundStatus;
  const simulatedRefund = c.refundSimulated === true;
  const refunded = ['completed', 'refunded'].includes(refundStatus);
  const refundTitle = !hasAmounts
    ? 'Payment and refund details not recorded'
    : refundAmount === 0
    ? Number(c.paidAmount) === 0
      ? 'No payment was taken; no refund is needed.'
      : 'No refund due under the recorded policy'
    : refunded
    ? 'Refund completed'
    : refundStatus === 'pending'
    ? simulatedRefund
      ? 'Simulated refund pending provider confirmation'
      : 'Refund pending review'
    : refundStatus === 'processing'
    ? 'Refund processing'
    : 'Refund due — status not recorded';
  const nextStep = !hasAmounts
    ? 'Contact your organizer for the payment and refund details.'
    : refundAmount === 0
    ? 'There is no refund to wait for.'
    : refunded
    ? 'Your refund is marked as completed. Contact the organizer if you need help checking it.'
    : refundStatus === 'pending'
    ? simulatedRefund
      ? 'This demo refund is simulated and awaiting provider confirmation; no payment has been sent yet.'
      : 'Your refund is recorded and awaiting review. It has not been paid yet. Contact the organizer if you need an update.'
    : 'Contact your organizer for an update on the refund.';
  const policy = request.policySnapshot || event?.policySnapshot;
  const processing =
    refundAmount > 0 && refundStatus === 'pending' && policy?.cancellation?.processingTimeline;
  const feeLabel =
    c.cancellationFeePercent != null && Number.isFinite(Number(c.cancellationFeePercent))
      ? `Cancellation fee (${Number(c.cancellationFeePercent)}%)`
      : 'Cancellation fee';
  return `<section class="client-cancellation${
    compact ? ' client-cancellation-compact' : ''
  }" aria-label="Cancellation details">
        <div class="client-cancellation-heading"><div><h3>${workflowHtml(heading)}</h3><p>${
    actorName ? `${workflowHtml(actorName)} &middot; ` : ''
  }${workflowHtml(
    workflowPolicyDate(c.cancelledAt || request.cancelledAt)
  )}</p></div><span class="badge badge-red">Booking closed</span></div>
        <div class="client-cancellation-reason"><strong>Reason for cancellation</strong><p>${workflowHtml(
          reason
        )}</p>${explanation ? `<p>${workflowHtml(explanation)}</p>` : ''}</div>
        ${
          hasAmounts
            ? `<div class="client-cancellation-amounts"><div><span>Amount paid</span><strong>${workflowMoney(
                c.paidAmount
              )}</strong></div><div><span>${workflowHtml(feeLabel)}</span><strong>${workflowMoney(
                c.cancellationFee
              )}</strong></div><div><span>${
                organizer &&
                Number(c.cancellationFee) === 0 &&
                refundAmount === Number(c.paidAmount) &&
                refundAmount > 0
                  ? 'Full refund due'
                  : 'Refund due'
              }</span><strong>${workflowMoney(c.refundAmount)}</strong></div></div>`
            : ''
        }
        <ol class="client-cancellation-progress" aria-label="Cancellation progress"><li class="complete">Cancellation recorded</li><li class="${
          refunded || refundAmount === 0 ? 'complete' : 'pending'
        }">${workflowHtml(refundTitle)}</li></ol>
        <p class="client-cancellation-next"><strong>No further booking payments are due.</strong> ${workflowHtml(
          nextStep
        )}${
    processing ? `<br>Estimated processing after review: ${workflowHtml(processing)}.` : ''
  }</p>
      </section>`;
}
function mapWorkflowRequest(request) {
  return {
    ...request,
    id: request.requestId,
    workflowManaged: true,
    backendClientId: request.clientId,
    backendOrganizerId: request.organizerId,
    clientId: request.clientUserId || (CU.role === 'client' ? CU.id : request.clientId),
    organizer: request.organizerUserId || (CU.role === 'organizer' ? CU.id : request.organizerId),
    organizerId: request.organizerId,
    title: request.eventName,
    type: request.eventType || 'Event',
    date: request.eventDate,
    guests: request.capacity,
    desc: request.requirements || '',
    created: request.createdAt,
    proposals: request.proposals || [],
    negotiations: request.negotiations || [],
    clarifications: request.clarifications || [],
    auditHistory: request.auditHistory || [],
  };
}
async function syncWorkflowData() {
  const [
    requestResponse,
    planResponse,
    eventResponse,
    notificationResponse,
    reportResponse,
    reviewResponse,
    policyResponse,
    fileReportResponse,
  ] = await Promise.all([
    apiGetEventRequests(),
    apiGetEventPlans(),
    apiGetWorkflowEvents(),
    apiGetNotifications(),
    apiGetCompletionReports(),
    CU.role === 'client' ? apiGetPrivateOrganizerReviews() : Promise.resolve([]),
    apiGetEventPolicy(),
    apiGetEventReports(),
  ]);
  workflowEventPolicy = workflowPayload(policyResponse);
  const requests = workflowPayload(requestResponse) || [];
  const plans = workflowPayload(planResponse) || [];
  const events = workflowPayload(eventResponse) || [];
  const notifications = workflowPayload(notificationResponse) || [];
  DB.eventCompletionReports = workflowPayload(reportResponse) || [];
  DB.clientOrganizerReviews = workflowPayload(reviewResponse) || [];
  DB.eventRequests = requests.map(mapWorkflowRequest);
  DB.eventPlans = plans;
  syncWorkflowFileReports(workflowPayload(fileReportResponse) || []);
  DB.notifications = notifications.map(notification => ({
    ...notification,
    id: notification.notificationId,
    title: notification.title || String(notification.type || 'notification').replaceAll('_', ' '),
    msg: notification.message || notification.msg || '',
    time: new Date(notification.dateTime || notification.createdAt).toLocaleString(),
    date: notification.dateTime || notification.createdAt,
  }));
  const relatedEventIds = new Set(
    DB.eventRequests.filter(request => request.eventId).map(request => request.eventId)
  );
  DB.events = DB.events.filter(event => !relatedEventIds.has(event.eventId || event.id));
  const ownEvents = events.filter(
    event =>
      relatedEventIds.has(event.eventId) ||
      (CU.role === 'organizer' ? event.organizerUserId === CU.id : event.clientUserId === CU.id)
  );
  const ownEventIds = new Set(ownEvents.map(event => event.eventId));
  DB.events = DB.events.filter(event => !ownEventIds.has(event.eventId || event.id));
  ownEvents.forEach(event => {
    DB.events.push({
      ...event,
      id: event.eventId,
      title: event.name || event.title,
      date: event.date,
      venue: event.location || event.venue,
      organizer: event.organizerUserId || (CU.role === 'organizer' ? CU.id : event.organizerId),
      clientId: CU.role === 'client' ? CU.id : event.clientId,
    });
  });
  return DB.eventRequests;
}
async function syncOrganizerDirectory() {
  const organizers = workflowPayload(await apiGetEventOrganizers()) || [];
  // Enrich organizer profiles with role-specific metadata not available from the backend
  const ORGANIZER_META = {
    'org-001': {
      city: 'Mumbai',
      bio: 'Premier corporate event specialist with a track record of flawless large-scale conferences and product launches across India.',
      specializations: ['Corporate Events', 'Product Launches', 'Conferences'],
      packages: [
        {
          name: 'Silver',
          price: '₹50,000',
          desc: 'Up to 100 guests, basic décor & coordination',
        },
        {
          name: 'Gold',
          price: '₹1,20,000',
          desc: 'Up to 300 guests, full décor, catering coordination',
        },
        {
          name: 'Platinum',
          price: '₹2,50,000',
          desc: '500+ guests, end-to-end management, dedicated team',
        },
      ],
      color: '#7c3aed',
      avatar: 'SC',
    },
    'org-002': {
      city: 'New Delhi',
      bio: 'Conference and operations specialist delivering seamless multi-day summits and international conventions throughout India.',
      specializations: ['Conferences', 'Workshops', 'Corporate Events'],
      packages: [
        {
          name: 'Basic',
          price: '₹40,000',
          desc: 'Up to 80 guests, venue & logistics',
        },
        {
          name: 'Standard',
          price: '₹90,000',
          desc: 'Up to 200 guests, AV & tech setup',
        },
        {
          name: 'Enterprise',
          price: '₹2,00,000',
          desc: '500+ guests, international-grade production',
        },
      ],
      color: '#0891b2',
      avatar: 'MV',
    },
    'org-003': {
      city: 'Bangalore',
      bio: 'Specialist in luxury weddings and high-profile social events, crafting unforgettable moments with meticulous attention to detail.',
      specializations: ['Weddings & Social Events', 'Galas', 'Anniversary Celebrations'],
      packages: [
        {
          name: 'Intimate',
          price: '₹75,000',
          desc: 'Up to 50 guests, curated experience',
        },
        {
          name: 'Grand',
          price: '₹1,80,000',
          desc: 'Up to 200 guests, full decoration & catering',
        },
        {
          name: 'Royal',
          price: '₹4,00,000',
          desc: '500+ guests, themed experience, bridal coordination',
        },
      ],
      color: '#db2777',
      avatar: 'ER',
    },
    'org-004': {
      city: 'Hyderabad',
      bio: "Festival and stage production expert behind some of India's most vibrant cultural events, concerts, and entertainment shows.",
      specializations: ['Festivals', 'Concerts', 'Cultural Shows', 'Product Launches'],
      packages: [
        {
          name: 'Stage Essentials',
          price: '₹60,000',
          desc: 'Basic stage setup, sound & lights',
        },
        {
          name: 'Festival Pro',
          price: '₹1,50,000',
          desc: 'Full stage production, 300 guests',
        },
        {
          name: 'Mega Show',
          price: '₹3,50,000',
          desc: 'Large-scale production, crowd management',
        },
      ],
      color: '#d97706',
      avatar: 'AK',
    },
    'org-005': {
      city: 'Chennai',
      bio: 'Expert event logistics coordinator ensuring smooth operations for corporate and government events across South India.',
      specializations: ['Corporate Events', 'Workshops', 'Government Events'],
      packages: [
        {
          name: 'Starter',
          price: '₹35,000',
          desc: 'Up to 60 guests, coordination',
        },
        {
          name: 'Professional',
          price: '₹85,000',
          desc: 'Up to 150 guests, full logistics',
        },
        {
          name: 'Corporate',
          price: '₹1,80,000',
          desc: '350+ guests, project management',
        },
      ],
      color: '#059669',
      avatar: 'ML',
    },
  };
  DB.users = DB.users
    .filter(user => user.role !== 'organizer')
    .concat(
      organizers.map(organizer => {
        const meta = ORGANIZER_META[organizer.organizerId] || {};
        return {
          id: organizer.userId,
          userId: organizer.userId,
          organizerId: organizer.organizerId,
          name: organizer.name,
          email: organizer.email,
          phone: organizer.phoneNo,
          role: 'organizer',
          service: organizer.businessName || 'Event Organizer',
          rating: organizer.rating,
          reviewCount: organizer.reviewCount,
          yearsExperience: organizer.yearsExperience || 1,
          completedEvents: organizer.completedEvents || 0,
          verified: organizer.verified !== false,
          city: meta.city || 'India',
          bio: meta.bio || 'Professional event organizer with extensive industry experience.',
          specializations: meta.specializations || [],
          packages: meta.packages || [],
          color: meta.color || 'var(--accent)',
          avatar: meta.avatar || organizer.name?.[0] || 'O',
        };
      })
    );
}
async function runWorkflowAction(action, successMessage, requestId) {
  try {
    const response = await action();
    await syncWorkflowData();
    closeModal();
    closeDrawer();
    toast(successMessage || workflowPayload(response)?.message || 'Workflow updated', 'success');
    await renderPage(_currentPage);
  } catch (error) {
    toast(error.message || 'Unable to update this event request', 'error');
  }
}
function workflowHtml(value) {
  return escapeHtml(String(value ?? ''));
}
function isBookedClientEvent(event) {
  return (
    Boolean(event.clientId || event.backendClientId) ||
    (DB.eventRequests || []).some(
      request => request.eventId && String(request.eventId) === String(event.eventId || event.id)
    )
  );
}
function getClientAcceptedProposal(request) {
  const accepted = (request.proposals || []).filter(proposal => proposal.status === 'accepted');
  return (
    accepted.find(
      proposal => Number(proposal.version) === Number(request.currentProposalVersion)
    ) ||
    accepted.sort((left, right) => Number(right.version) - Number(left.version))[0] ||
    null
  );
}
function getClientBookingAmounts(request, plan) {
  const acceptedProposal = getClientAcceptedProposal(request);
  const totalAmount = Number(acceptedProposal?.amount ?? plan?.budget ?? request.budget ?? 0);
  const payments = (DB.eventWorkflowPayments || []).filter(
    payment =>
      payment.status === 'completed' &&
      (!payment.clientId || payment.clientId === request.clientId) &&
      (payment.requestId === (request.requestId || request.id) ||
        (request.eventId && payment.eventId === request.eventId))
  );
  const depositRequired =
    acceptedProposal?.depositRequired !== undefined
      ? Number(acceptedProposal.depositRequired)
      : Math.round(totalAmount * 0.3);
  const paidAmount =
    request.paymentStatus === 'fully_paid'
      ? totalAmount
      : payments.length
      ? payments.reduce((sum, payment) => sum + Number(payment.amount || 0), 0)
      : request.paymentStatus === 'deposit_paid'
      ? depositRequired
      : 0;
  return {
    acceptedProposal,
    totalAmount,
    depositRequired,
    paidAmount: Math.min(totalAmount, paidAmount),
    amountPayableNow: Math.max(0, depositRequired - paidAmount),
    remainingAmount: Math.max(0, totalAmount - paidAmount),
  };
}
async function openEventPlanPdf(planId, fileName, preview, version) {
  const previewWindow = preview ? window.open('about:blank', '_blank') : null;
  try {
    const vParam = version ? `?version=${encodeURIComponent(version)}` : '';
    let url = `${API_BASE_URL}/event-plans/${encodeURIComponent(planId)}/document${vParam}`;
    let response = await fetch(url, {
      headers: getAuthHeader()
        ? {
            Authorization: getAuthHeader(),
          }
        : {},
    });
    if (response.status === 404) {
      url = `${API_BASE_URL}/event-requests/${encodeURIComponent(planId)}/document${vParam}`;
      response = await fetch(url, {
        headers: getAuthHeader()
          ? {
              Authorization: getAuthHeader(),
            }
          : {},
      });
    }
    if (response.status === 403) {
      throw new Error('You are not authorized to view or download this document.');
    }
    if (response.status === 404) {
      throw new Error('The requested event plan file was not found.');
    }
    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      const message = Array.isArray(data.message) ? data.message.join(', ') : data.message;
      throw new Error(message || `PDF request failed (${response.status})`);
    }
    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    if (preview && previewWindow) {
      previewWindow.opener = null;
      previewWindow.location.href = objectUrl;
    } else {
      if (previewWindow) previewWindow.close();
      const link = document.createElement('a');
      link.href = objectUrl;
      link.download = decodeURIComponent(fileName) || 'event-plan.pdf';
      document.body.appendChild(link);
      link.click();
      link.remove();
    }
    setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000);
  } catch (error) {
    if (previewWindow) previewWindow.close();
    toast(error.message || 'Unable to open the event plan PDF', 'error');
  }
}
async function openEventCompletionPhoto(eventId, fileName) {
  const previewWindow = window.open('about:blank', '_blank');
  try {
    const response = await fetch(
      `${API_BASE_URL}/reports/events/${encodeURIComponent(
        eventId
      )}/completion/photos/${encodeURIComponent(fileName)}`,
      {
        headers: getAuthHeader()
          ? {
              Authorization: getAuthHeader(),
            }
          : {},
      }
    );
    if (!response.ok) throw new Error('Unable to load this report photo');
    const objectUrl = URL.createObjectURL(await response.blob());
    if (previewWindow) {
      previewWindow.opener = null;
      previewWindow.location.href = objectUrl;
    }
    setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000);
  } catch (error) {
    if (previewWindow) previewWindow.close();
    toast(error.message || 'Unable to open the report photo', 'error');
  }
}
function payWorkflowEvent(eventId, requestId, amount) {
  const request = DB.eventRequests.find(
    item => String(item.requestId) === String(requestId) || String(item.id) === String(requestId)
  );
  if (!window.EventFlowCheckout) {
    toast('Payment checkout could not be loaded. Please refresh and try again.', 'error');
    return;
  }
  window.EventFlowCheckout.open({
    event: {
      title: request?.eventName || request?.title || 'Event balance',
      date: request?.eventDate || request?.date,
      venue: request?.venue,
    },
    amount: Number(amount),
    paymentLabel: 'Remaining event balance',
    doneLabel: 'View Booking',
    successMessage: 'Your remaining event balance has been paid.',
    onAuthorize: async () => {
      const response = await apiPayForWorkflowEvent(eventId);
      await syncWorkflowData();
      await syncClientEventRequests();
      return workflowPayload(response);
    },
    onDone: () => viewClientPaidBooking(requestId),
  });
}
function submitClientOrganizerReview(eventId, requestId) {
  const rating = Number(v('workflow-review-rating'));
  const comment = v('workflow-review-comment');
  if (!rating || rating < 1 || rating > 5 || !comment) {
    toast('Choose a 1–5 star rating and enter a written review.', 'error');
    return;
  }
  runWorkflowAction(
    () =>
      apiSubmitPrivateOrganizerReview({
        eventId,
        rating,
        comment,
      }),
    'Review submitted and published to the organizer profile',
    requestId
  );
}
function isClientOwner(request, currentUser) {
  if (!currentUser || currentUser.role !== 'client') return true;
  if (!request) return false;
  const ids = new Set(
    [
      String(currentUser.id || ''),
      String(currentUser.userId || ''),
      String(currentUser.clientId || ''),
    ].filter(Boolean)
  );
  (DB.clients || []).forEach(client => {
    if (
      ids.has(String(client.clientId)) ||
      ids.has(String(client.userId)) ||
      ids.has(String(client.id))
    ) {
      if (client.clientId) ids.add(String(client.clientId));
      if (client.userId) ids.add(String(client.userId));
    }
  });
  const reqClientIds = [
    request.clientId,
    request.clientUserId,
    request.userId,
    request.client,
    request.backendClientId,
  ]
    .filter(Boolean)
    .map(String);
  if (reqClientIds.length === 0) return true; // Demo unassigned
  return reqClientIds.some(id => ids.has(id));
}
if (typeof window !== 'undefined') window.isClientOwner = isClientOwner;
function openClientPaymentModal(requestId, eventId) {
  const r = DB.eventRequests.find(
    request =>
      String(request.id) === String(requestId) ||
      String(request.requestId) === String(requestId) ||
      (eventId && String(request.eventId) === String(eventId))
  );
  if (!r) {
    openModal(
      'Payment Unavailable',
      `
          <div class="empty" style="padding:24px 8px;text-align:center">
            <div class="empty-icon">⚠️</div>
            <div class="empty-title">Booking Record Not Found</div>
            <p class="empty-desc">The requested event proposal or booking record could not be found.</p>
          </div>
        `,
      [
        {
          lbl: 'Close',
          cls: 'btn-ghost',
          fn: 'closeModal()',
        },
      ]
    );
    return;
  }
  if (
    CU &&
    CU.role === 'client' &&
    (typeof isClientOwner === 'function' ? !isClientOwner(r, CU) : false)
  ) {
    openModal(
      'Access Restricted',
      `
          <div class="alert alert-danger" style="margin:16px 0;padding:12px;border-radius:8px">
            <strong>Access Denied:</strong> You are not authorized to make payments for this event request.
          </div>
        `,
      [
        {
          lbl: 'Close',
          cls: 'btn-ghost',
          fn: 'closeModal()',
        },
      ]
    );
    return;
  }
  const s = (r.status || '').toLowerCase();
  if (['withdrawn', 'cancelled', 'rejected', 'expired'].includes(s)) {
    openModal(
      'Payment Unavailable',
      `
          <div class="alert alert-warning" style="margin:16px 0;padding:12px;border-radius:8px">
            <strong>Payment Unavailable:</strong> This request has already been ${s}. Payment and booking confirmation are no longer available.
          </div>
        `,
      [
        {
          lbl: 'Close',
          cls: 'btn-ghost',
          fn: 'closeModal()',
        },
      ]
    );
    return;
  }
  if (
    [
      'submitted',
      'pending',
      'under_review',
      'in_review',
      'info_requested',
      'proposal_sent',
      'changes_requested',
      'counteroffer_received',
      'plan_submitted',
      'plan_revision_requested',
    ].includes(s) ||
    (s === 'planning' &&
      r.paymentStatus !== 'deposit_pending' &&
      !(r.proposals || []).some(p => p.status === 'accepted'))
  ) {
    if (s === 'proposal_sent') {
      openModal(
        'Acceptance Required',
        `
            <div class="alert alert-info" style="margin:16px 0;padding:14px;border-radius:8px">
              <strong>Proposal Review Required:</strong> Please review and accept the organizer's proposed terms before proceeding to payment and booking confirmation.
            </div>
          `,
        [
          {
            lbl: 'Close',
            cls: 'btn-ghost',
            fn: 'closeModal()',
          },
          {
            lbl: 'Review Proposal',
            cls: 'btn-primary',
            fn: `closeModal();openClientPlanReview('${r.id}')`,
          },
        ]
      );
      return;
    }
    openModal(
      'Payment Unavailable',
      `
          <div class="alert alert-warning" style="margin:16px 0;padding:12px;border-radius:8px">
            <strong>Payment Unavailable:</strong> Payment requires an accepted proposal. Current status: <strong>${
              typeof clientStatusReadable === 'function'
                ? clientStatusReadable(s)
                : String(s || '')
                    .replace(/_/g, ' ')
                    .toUpperCase()
            }</strong>.
          </div>
        `,
      [
        {
          lbl: 'Close',
          cls: 'btn-ghost',
          fn: 'closeModal()',
        },
      ]
    );
    return;
  }
  const org = (DB.organizers || []).find(
    o => String(o.organizerId || o.id) === String(r.organizerId || r.organizer)
  ) ||
    (DB.users || []).find(
      user => String(user.id || user.userId) === String(r.organizerId || r.organizer)
    ) || {
      name: r.organizerName || 'Assigned Organizer',
    };
  const proposal = getClientAcceptedProposal(r);
  const approvedPlan = (DB.eventPlans || []).find(
    plan =>
      plan.requestId === (r.requestId || r.id) &&
      (!r.activeEventPlanId || plan.eventPlanId === r.activeEventPlanId) &&
      plan.approvalStatus === 'approved'
  );
  if (s === 'awaiting_client' && !proposal && !approvedPlan) {
    openModal(
      'Payment Unavailable',
      '<p>Accept the final event plan or proposal before proceeding to payment.</p>',
      [
        {
          lbl: 'Close',
          cls: 'btn-ghost',
          fn: 'closeModal()',
        },
      ]
    );
    return;
  }
  const proposalVersion = proposal?.version || approvedPlan?.revision || 1;
  const amounts = getClientBookingAmounts(r, approvedPlan);
  const totalAmount = amounts.totalAmount;
  const depositRequired = amounts.depositRequired;
  const amountPayableNow = amounts.amountPayableNow;
  const isAlreadyPaid = r.paymentStatus === 'fully_paid';
  const isDepositPaid = r.paymentStatus === 'deposit_paid' || isAlreadyPaid;
  const isConfirmed = ['confirmed', 'approved', 'ongoing', 'completed'].includes(r.status);
  const bookingId = r.eventId
    ? `BKG-${r.eventId.toUpperCase()}`
    : `BKG-${(r.requestId || r.id).toUpperCase()}`;
  const outstandingBalance = amounts.remainingAmount;
  if (isDepositPaid || isConfirmed) {
    openModal(
      isConfirmed ? 'Booking Payment' : 'Payment & Booking Confirmation',
      `
          <div style="background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.3);border-radius:8px;padding:14px;text-align:center;color:var(--green);font-weight:700;margin-bottom:16px">
            ${
              isConfirmed
                ? isAlreadyPaid
                  ? '✅ Booking Fully Paid'
                  : '✅ Booking Confirmed'
                : 'Deposit Paid — Booking Confirmation Required'
            }
          </div>
          <div style="background:var(--surface2);border-radius:10px;padding:14px;margin-bottom:16px;border:1px solid var(--border);font-size:13px">
            <div style="display:flex;justify-content:space-between;margin-bottom:8px"><span style="color:var(--text3)">BOOKING ID</span><strong style="font-family:monospace">${bookingId}</strong></div>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px"><span style="color:var(--text3)">EVENT TITLE</span><strong>${escapeHtml(
              r.eventName || r.title || 'Event'
            )}</strong></div>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px"><span style="color:var(--text3)">ORGANIZER</span><strong>${escapeHtml(
              org.name || 'Organizer'
            )}</strong></div>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px"><span style="color:var(--text3)">TOTAL PROPOSAL AMOUNT</span><strong style="color:var(--green)">₹${totalAmount.toLocaleString()}</strong></div>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px"><span style="color:var(--text3)">AMOUNT PAID</span><strong style="color:var(--accent)">₹${amounts.paidAmount.toLocaleString()}</strong></div>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px"><span style="color:var(--text3)">REMAINING BALANCE</span><strong style="color:var(--yellow)">₹${(isAlreadyPaid
              ? 0
              : outstandingBalance
            ).toLocaleString()}</strong></div>
            <div style="display:flex;justify-content:space-between"><span style="color:var(--text3)">BOOKING STATUS</span><span class="badge ${
              isConfirmed ? 'badge-green' : 'badge-yellow'
            }">${isConfirmed ? 'Confirmed' : 'Awaiting Confirmation'}</span></div>
          </div>
          <div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:12px">
            <div style="font-size:12px;font-weight:700;margin-bottom:8px">📜 Transaction History & Receipts</div>
            <div style="font-size:12px;color:var(--text2)">
              ${
                (r.auditHistory || [])
                  .filter(
                    entry =>
                      String(entry.action).toLowerCase().includes('deposit') ||
                      String(entry.action).toLowerCase().includes('payment') ||
                      String(entry.action).toLowerCase().includes('confirmed')
                  )
                  .map(
                    entry => `
                <div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--border2)">
                  <span>${escapeHtml(entry.action)}</span>
                  <strong style="color:var(--green)">Verified</strong>
                </div>
              `
                  )
                  .join('') || '<div>No payment transactions recorded.</div>'
              }
            </div>
          </div>
        `,
      [
        ...(outstandingBalance > 0 && isConfirmed && r.eventId
          ? [
              {
                lbl: 'Pay Remaining Amount',
                cls: 'btn-success',
                fn: `payWorkflowEvent('${escapeHtml(r.eventId)}', '${escapeHtml(
                  r.requestId || r.id
                )}', ${outstandingBalance})`,
              },
            ]
          : []),
        ...(!isConfirmed && r.status === 'awaiting_client'
          ? [
              {
                lbl: 'Confirm Booking',
                cls: 'btn-success',
                fn: `submitClientMockPayment('${escapeHtml(r.requestId || r.id)}')`,
              },
            ]
          : []),
        {
          lbl: 'View Booking',
          cls: 'btn-primary',
          fn: `viewClientPaidBooking('${escapeHtml(r.requestId || r.id)}')`,
        },
        {
          lbl: 'Close',
          cls: 'btn-ghost',
          fn: 'closeModal()',
        },
      ]
    );
    return;
  }
  openModal(
    'Payment & Booking Confirmation',
    `
        <div id="payment-modal-container">
          <div style="background:rgba(59,130,246,0.1);border:1px solid rgba(59,130,246,0.3);padding:10px 14px;border-radius:8px;font-size:12px;color:var(--accent);font-weight:700;display:flex;align-items:center;gap:8px;margin-bottom:16px">
            <span>🛡️</span> DEMO PAYMENT PROVIDER · SIMULATED TRANSACTION
          </div>

          <div style="background:var(--surface2);border-radius:10px;padding:14px;margin-bottom:16px;border:1px solid var(--border);font-size:13px">
            <div style="display:flex;justify-content:space-between;margin-bottom:8px">
              <span style="color:var(--text3)">BOOKING ID</span>
              <strong style="font-family:monospace">${bookingId}</strong>
            </div>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px">
              <span style="color:var(--text3)">EVENT TITLE</span>
              <strong>${escapeHtml(r.eventName || r.title || 'Event')}</strong>
            </div>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px">
              <span style="color:var(--text3)">ORGANIZER</span>
              <strong>${escapeHtml(org.name || 'Organizer')}</strong>
            </div>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px">
              <span style="color:var(--text3)">${
                proposal ? 'ACCEPTED PROPOSAL' : 'APPROVED EVENT PLAN'
              }</span>
              <strong>Version ${proposalVersion}</strong>
            </div>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px">
              <span style="color:var(--text3)">TOTAL AGREED PRICE / TOTAL PROPOSAL AMOUNT</span>
              <strong style="color:var(--green);font-size:14px">₹${totalAmount.toLocaleString()}</strong>
            </div>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px">
              <span style="color:var(--text3)">ADVANCE DEPOSIT REQUIRED</span>
              <strong style="color:var(--accent);font-size:14px">₹${depositRequired.toLocaleString()}</strong>
            </div>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px">
              <span style="color:var(--text3)">AMOUNT PAYABLE NOW</span>
              <strong style="color:var(--accent);font-size:15px;font-weight:800">₹${amountPayableNow.toLocaleString()}</strong>
            </div>
            <div style="display:flex;justify-content:space-between">
              <span style="color:var(--text3)">OUTSTANDING BALANCE</span>
              <strong style="color:var(--yellow);font-size:14px">₹${outstandingBalance.toLocaleString()}</strong>
            </div>
          </div>

          <!-- PAYMENT TERMS & CANCELLATION POLICY -->
          <div style="background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:12px;margin-bottom:14px;font-size:12.5px;line-height:1.5">
            <div style="font-weight:700;color:var(--text);margin-bottom:4px">Payment Terms &amp; Cancellation Policy</div>
            <div>• <strong>Payment Terms:</strong> ${escapeHtml(
              proposal?.paymentSchedule ||
                proposal?.paymentTerms ||
                'Advance deposit payable now; remaining balance is due under the accepted agreement.'
            )}</div>
            <div>• <strong>Cancellation Policy:</strong> ${escapeHtml(
              proposal?.cancellationTerms ||
                proposal?.cancellationPolicy?.cancellation?.additionalTerms ||
                'The accepted agreement cancellation policy applies.'
            )}</div>
            <label style="display:flex;align-items:flex-start;gap:8px;margin-top:10px;cursor:pointer;font-weight:600;color:var(--accent)">
              <input type="checkbox" id="client-agree-terms" ${
                r.agreementStatus === 'agreed' ? 'checked disabled' : 'checked'
              }>
              <span>I acknowledge and agree to the event plan, pricing, and cancellation terms. *</span>
            </label>
          </div>

          <p class="small muted">Continue to checkout to choose Card or UPI. Card payments require a demo OTP; UPI checkout displays a QR code.</p>

          <div id="pay-modal-err" role="alert" style="color:var(--red);font-size:12.5px;display:none;margin-top:6px;margin-bottom:8px"></div>
        </div>
      `,
    [
      {
        lbl: 'Cancel',
        cls: 'btn-ghost',
        fn: 'closeModal()',
      },
      {
        lbl: `Pay Now (₹${amountPayableNow.toLocaleString()})`,
        cls: 'btn-success',
        fn: `submitClientMockPayment('${escapeHtml(r.id)}', '${escapeHtml(r.eventId || '')}')`,
      },
    ]
  );
}
async function submitClientMockPayment(requestId, eventId) {
  const request = DB.eventRequests.find(
    item => String(item.requestId) === String(requestId) || String(item.id) === String(requestId)
  );
  if (!request || request.status !== 'awaiting_client' || !isClientOwner(request, CU)) {
    openClientPaymentModal(requestId, eventId);
    return;
  }
  const agree = g('client-agree-terms');
  const error = g('pay-modal-err');
  if (agree && !agree.checked) {
    if (error) {
      error.textContent =
        'Please acknowledge and agree to the payment and cancellation terms to proceed.';
      error.style.display = 'block';
    }
    return;
  }
  if (!window.EventFlowCheckout) {
    toast('Payment checkout could not be loaded. Please refresh and try again.', 'error');
    return;
  }
  const plan = (DB.eventPlans || []).find(
    item =>
      item.requestId === (request.requestId || request.id) &&
      item.approvalStatus === 'approved' &&
      (!request.activeEventPlanId || item.eventPlanId === request.activeEventPlanId)
  );
  const amounts = getClientBookingAmounts(request, plan);
  const paid = ['deposit_paid', 'fully_paid'].includes(request.paymentStatus);
  const amount = paid ? 0 : amounts.amountPayableNow;
  if (paid) return processClientDepositPayment(requestId, eventId, 'Already paid');
  window.EventFlowCheckout.open({
    event: {
      title: request.eventName || request.title || 'Event booking',
      date: request.eventDate || request.date,
      venue: request.venue,
    },
    amount,
    paymentLabel: 'Advance booking deposit',
    onAuthorize: ({ method }) =>
      processClientDepositPayment(requestId, eventId, method === 'upi' ? 'UPI' : 'Card'),
  });
}
async function processClientDepositPayment(requestId, eventId, method) {
  const agreeEl = g('client-agree-terms');
  const errEl = g('pay-modal-err');
  if (agreeEl && !agreeEl.checked) {
    if (errEl) {
      errEl.textContent =
        'Please acknowledge and agree to the payment and cancellation terms to proceed.';
      errEl.style.display = 'block';
    }
    return;
  }
  if (errEl) errEl.style.display = 'none';
  const r = DB.eventRequests.find(
    request =>
      String(request.id) === String(requestId) || String(request.requestId) === String(requestId)
  );
  const effectiveReqId = r ? r.requestId || r.id : requestId;
  const simulateFailure = method === 'FAIL';

  // Show processing feedback
  const container = g('payment-modal-container') || g('modal-body');
  if (container) {
    globalThis.window?.EventFlowClientPages?.clear(container);
    container.innerHTML = `
          <div style="padding:32px 16px;text-align:center">
            <div class="spinner" style="width:40px;height:40px;margin:0 auto 16px;border:3px solid var(--border);border-top-color:var(--accent);border-radius:50%;animation:spin 1s linear infinite"></div>
            <div style="font-size:16px;font-weight:700;color:var(--text);margin-bottom:6px">Processing Payment...</div>
            <div style="font-size:13px;color:var(--text2)">Connecting to simulated payment provider gateway and verifying authorization…</div>
          </div>
        `;
  }
  const foot = g('modal-foot');
  if (foot) {
    globalThis.window?.EventFlowClientPages?.clear(foot);
    foot.innerHTML = '';
    foot.style.display = '';
  }
  try {
    if (r && r.agreementStatus !== 'agreed') {
      await apiUpdateAgreementStatus(effectiveReqId, 'agreed');
      r.agreementStatus = 'agreed';
    }
    const payPayload = {
      paymentMethod: 'DEMO_PROVIDER',
      methodDetails: simulateFailure ? 'Simulated Failure' : method,
      simulateFailure,
    };
    const res = await apiPayDeposit(effectiveReqId, payPayload);
    const resData = workflowPayload(res);
    if (res?.success === false || resData?.paymentStatus === 'failed') {
      throw new Error(res?.message || 'Payment verification failed. Please retry.');
    }
    await syncWorkflowData();
    await syncClientEventRequests();
    const refreshedRequest = DB.eventRequests.find(
      item => String(item.requestId || item.id) === String(effectiveReqId)
    );
    const bookingStatus = resData?.bookingStatus || resData?.status || refreshedRequest?.status;
    if (bookingStatus !== 'confirmed')
      throw new Error(
        'Payment is not confirmed yet. Review the current payment status before retrying.'
      );
    const paymentPlan =
      r &&
      (DB.eventPlans || []).find(
        plan => plan.requestId === effectiveReqId && plan.approvalStatus === 'approved'
      );
    const bookingAmounts = r ? getClientBookingAmounts(r, paymentPlan) : null;
    const depositPaid = Number(
      resData?.amountCharged ?? resData?.amountPaid ?? bookingAmounts?.depositRequired ?? 0
    );
    const balanceRem = Number(
      resData?.outstandingBalance ??
        (refreshedRequest?.paymentStatus === 'fully_paid'
          ? 0
          : Math.max(0, Number(r?.budget || 0) - depositPaid))
    );
    const txnId = resData?.paymentId || resData?.receipt?.receiptNumber || 'TXN-' + Date.now();
    const bkgId = resData?.bookingId || 'BKG-' + String(effectiveReqId).toUpperCase();
    if (container) {
      globalThis.window?.EventFlowClientPages?.clear(container);
      container.innerHTML = `
            <div style="padding:16px 8px;text-align:center">
              <div style="width:52px;height:52px;background:rgba(34,197,94,0.12);color:var(--green);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:26px;margin:0 auto 12px">✓</div>
              <div style="font-size:18px;font-weight:800;color:var(--green);margin-bottom:6px">Payment Verified &amp; Booking Confirmed!</div>
              <div style="font-size:13px;color:var(--text2);margin-bottom:16px">Your deposit payment was successfully processed. Your event is officially booked!</div>
              <div style="background:var(--surface2);border:1px solid var(--border);border-radius:10px;padding:12px;text-align:left;font-size:13px;margin-bottom:14px">
                <div style="display:flex;justify-content:space-between;margin-bottom:6px"><span style="color:var(--text3)">Transaction / Reference ID:</span><strong style="font-family:monospace">${escapeHtml(
                  txnId
                )}</strong></div>
                <div style="display:flex;justify-content:space-between;margin-bottom:6px"><span style="color:var(--text3)">Booking Reference:</span><strong style="font-family:monospace">${escapeHtml(
                  bkgId
                )}</strong></div>
                <div style="display:flex;justify-content:space-between;margin-bottom:6px"><span style="color:var(--text3)">Deposit Paid Now:</span><strong style="color:var(--green)">₹${depositPaid.toLocaleString()}</strong></div>
                <div style="display:flex;justify-content:space-between"><span style="color:var(--text3)">Remaining Balance:</span><strong style="color:var(--yellow)">₹${balanceRem.toLocaleString()}</strong></div>
              </div>
              <div class="alert alert-success" style="font-size:12.5px;padding:10px;border-radius:8px;margin-bottom:8px">
                📅 This booking is now available in <strong>My Events</strong>.
              </div>
            </div>
          `;
    }
    if (foot) {
      globalThis.window?.EventFlowClientPages?.clear(foot);
      foot.innerHTML = `
            <button class="btn btn-primary" onclick="viewClientPaidBooking('${escapeHtml(
              effectiveReqId
            )}')">View Booking</button>
            <button class="btn btn-ghost" onclick="closeModal();renderPage('request-status')">Done</button>
          `;
    }
    toast('Deposit payment verified and booking confirmed!', 'success');
  } catch (err) {
    if (container) {
      globalThis.window?.EventFlowClientPages?.clear(container);
      container.innerHTML = `
            <div style="padding:16px 8px;text-align:center">
              <div style="width:52px;height:52px;background:rgba(239,68,68,0.12);color:var(--red);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:26px;margin:0 auto 12px">✕</div>
              <div style="font-size:18px;font-weight:800;color:var(--red);margin-bottom:6px">Payment Transaction Failed</div>
              <div style="font-size:13px;color:var(--text2);margin-bottom:16px">${escapeHtml(
                err.message || 'Payment simulation failed. Gateway declined authorization.'
              )}</div>
              <div class="alert alert-danger" style="font-size:12.5px;padding:10px;border-radius:8px;text-align:left;margin-bottom:10px">
                Payment or booking confirmation could not be completed. Check the current payment status before retrying.
              </div>
            </div>
          `;
    }
    if (foot) {
      globalThis.window?.EventFlowClientPages?.clear(foot);
      foot.innerHTML = `
            <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
            <button class="btn btn-primary" onclick="openClientPaymentModal('${escapeHtml(
              effectiveReqId
            )}')">Retry Payment</button>
          `;
    }
  }
}
function viewClientPaidBooking(requestId) {
  const booking = getClientWorkflowEvents().all.find(
    item => String(item.requestId) === String(requestId)
  );
  closeModal();
  setWorkflowEventTab(booking?.tab || 'upcoming');
}
if (typeof window !== 'undefined') {
  window.openClientPaymentModal = openClientPaymentModal;
  window.submitClientMockPayment = submitClientMockPayment;
}
function openUpdateConfirmedEventModal(requestId, eventId) {
  const r = DB.eventRequests.find(
    request =>
      String(request.id) === String(requestId) || String(request.eventId) === String(eventId)
  );
  if (!r) return;
  if (r.eventId || ['confirmed', 'approved', 'ongoing', 'completed'].includes(r.status)) {
    toast('Booked event details cannot be edited.', 'info');
    return;
  }
  const ev =
    DB.events.find(event => String(event.id || event.eventId) === String(eventId || r.eventId)) ||
    {};
  const currentDate = r.eventDate || r.date || ev.date || '2026-11-20';
  const currentVenue = r.venue || ev.location || '';
  const currentCapacity = r.capacity || r.guests || ev.capacity || 50;
  const currentBudget = r.budget || ev.budget || 50000;
  const currentReqs = r.requirements || r.desc || ev.description || '';
  openModal(
    'Update Confirmed Event',
    `
        <div style="font-size:12.5px;color:var(--text2);margin-bottom:14px">
          Submit requested changes to this confirmed booking. Changes affecting dates, attendee count, or scope require organizer approval.
        </div>
        <div class="form-group mb-12">
          <label class="form-label">Event Date *</label>
          <input type="date" class="form-control" id="mod-date" value="${currentDate}">
        </div>
        <div class="form-group mb-12">
          <label class="form-label">Venue / Location</label>
          <input type="text" class="form-control" id="mod-venue" value="${escapeHtml(
            currentVenue
          )}">
        </div>
        <div class="form-group mb-12">
          <label class="form-label">Expected Attendee Count</label>
          <input type="number" class="form-control" id="mod-capacity" value="${currentCapacity}" min="1" oninput="calculateModCostClient(${currentCapacity}, ${currentBudget})">
          <div id="mod-cost-hint-client" style="font-size:11.5px;color:var(--accent);margin-top:4px">Current budget: ₹${currentBudget.toLocaleString()}</div>
        </div>
        <div class="form-group mb-12">
          <label class="form-label">Requirements / Scope Changes</label>
          <textarea class="form-control" id="mod-reqs" rows="3">${escapeHtml(
            currentReqs
          )}</textarea>
        </div>
        <div class="form-group mb-12">
          <label class="form-label">Reason for Change (Mandatory) *</label>
          <textarea class="form-control" id="mod-reason" rows="2" placeholder="Explain why this change is requested (e.g. Schedule adjustment, increased team size)..."></textarea>
        </div>
        <div id="mod-err-msg-client" style="color:var(--red);font-size:12px;display:none;margin-top:6px"></div>
      `,
    [
      {
        lbl: 'Cancel',
        cls: 'btn-ghost',
        fn: 'closeModal()',
      },
      {
        lbl: 'Submit Update Request',
        cls: 'btn-primary',
        fn: `submitEventModificationClient('${r.id}')`,
      },
    ]
  );
}
function calculateModCostClient(oldCap, oldBudget) {
  const newCap = parseInt(g('mod-capacity')?.value, 10);
  const hint = g('mod-cost-hint-client');
  if (!hint) return;
  if (newCap && oldCap && oldBudget) {
    const recalc = Math.round((oldBudget / oldCap) * newCap);
    globalThis.window?.EventFlowClientPages?.clear(hint);
    hint.innerHTML = `Recalculated estimated cost: <strong>₹${recalc.toLocaleString()}</strong> (was ₹${oldBudget.toLocaleString()})`;
  }
}
async function submitEventModificationClient(requestId) {
  const date = v('mod-date');
  const venue = v('mod-venue');
  const capacity = parseInt(v('mod-capacity'), 10);
  const requirements = v('mod-reqs');
  const reason = v('mod-reason');
  const errEl = g('mod-err-msg-client');
  if (capacity && (!Number.isInteger(capacity) || capacity < 1 || capacity > 50000)) {
    if (errEl) {
      errEl.textContent =
        capacity > 50000
          ? 'Maximum event capacity is 50,000.'
          : 'Attendee capacity must be between 1 and 50,000.';
      errEl.style.display = 'block';
    }
    return;
  }
  if (!reason || !reason.trim()) {
    if (errEl) {
      errEl.textContent = 'A reason for the modification is mandatory.';
      errEl.style.display = 'block';
    }
    return;
  }
  try {
    await apiRequestEventModification(requestId, {
      date,
      venue,
      capacity,
      requirements,
      reason: reason.trim(),
    });
    closeModal();
    await syncWorkflowData();
    toast('Modification request submitted for organizer review!', 'success');
    if (typeof _workflowRequestId !== 'undefined') renderWorkflowRequestDetails(_workflowRequestId);
    else renderPage('request-status');
  } catch (err) {
    if (errEl) {
      errEl.textContent = err.message || 'Unable to submit update request.';
      errEl.style.display = 'block';
    } else toast(err.message, 'error');
  }
}
async function respondToEventModificationClient(requestId, modId, action) {
  let reason = '';
  if (action === 'reject') {
    reason = prompt('Enter a reason for declining the modification:') || 'Declined';
    if (!reason.trim()) return;
  }
  try {
    await apiRespondToEventModification(requestId, modId, {
      action,
      reason,
    });
    await syncWorkflowData();
    toast(
      `Modification ${action === 'approve' ? 'approved' : 'declined'} successfully!`,
      'success'
    );
    if (typeof _workflowRequestId !== 'undefined') renderWorkflowRequestDetails(_workflowRequestId);
    else renderPage('request-status');
  } catch (err) {
    toast(err.message || 'Unable to respond to modification.', 'error');
  }
}
function viewWorkflowRequestDrawer(id) {
  _workflowRequestId = String(id);
  _workflowReturnPage = [
    'event-requests',
    'request-status',
    'dashboard',
    'my-events',
    'ongoing-events',
    'completed-events',
  ].includes(_currentPage)
    ? _currentPage
    : 'request-status';
  goNav('request-details');
}
async function openClientCancellationNotification(notificationId) {
  const notification = visibleNotifications().find(
    item => String(item.id || item.notificationId) === String(notificationId)
  );
  if (
    !notification ||
    (notification.userId && String(notification.userId) !== String(CU.userId || CU.id))
  ) {
    toast('This cancellation notification is unavailable.', 'error');
    return;
  }
  const findRequest = () =>
    DB.eventRequests.find(
      item =>
        (notification.requestId &&
          String(item.requestId || item.id) === String(notification.requestId)) ||
        (notification.eventId && String(item.eventId) === String(notification.eventId))
    );
  let request = findRequest();
  if (!request) {
    try {
      await syncWorkflowData();
      request = findRequest();
    } catch (error) {
      toast(error.message, 'error');
      return;
    }
  }
  if (!request || !isClientOwner(request, CU)) {
    toast('Cancellation details are unavailable for this booking.', 'error');
    return;
  }
  await markNotifRead(notificationId);
  viewWorkflowRequestDrawer(request.id || request.requestId);
}
function viewWorkflowEventDetails(eventId) {
  const request = DB.eventRequests.find(item => String(item.eventId) === String(eventId));
  if (request) viewWorkflowRequestDrawer(request.id);
  else openViewEventDrawer(eventId);
}
function viewWorkflowEventReport(eventId) {
  if (DB.eventRequests.some(item => String(item.eventId) === String(eventId))) {
    viewWorkflowEventDetails(eventId);
  } else {
    viewEventReport(eventId);
  }
}
function renderWorkflowRequestDetails(id) {
  if (globalThis.window?.EventFlowClientPages?.hasPage('request-details')) {
    window.EventFlowClientPages.render(
      g('page-content'),
      'request-details',
      window.EventFlowClientRuntime.snapshot({
        id: id,
      })
    );
    return;
  }
  const r = DB.eventRequests.find(
    request =>
      String(request.id) === String(id) ||
      String(request.requestId) === String(id) ||
      (request.eventId && String(request.eventId) === String(id))
  );
  if (r && CU && CU.role === 'client' && !isClientOwner(r, CU)) {
    const el = g('page-content');
    if (el) {
      globalThis.window?.EventFlowClientPages?.clear(el);
      el.innerHTML =
        '<div class="alert alert-danger" style="margin:24px 0;padding:16px;border-radius:8px"><strong>Access Denied:</strong> You are not authorized to view the details of this event request.<br><button class="btn btn-primary mt-16" onclick="goNav(\'request-status\')">Back to requests</button></div>';
    }
    return;
  }
  const element = g('page-content');
  if (!r || !element) {
    if (element) {
      globalThis.window?.EventFlowClientPages?.clear(element);
      element.innerHTML =
        '<div class="empty"><div class="empty-title">Request not found</div><button class="btn btn-primary mt-16" onclick="goNav(\'request-status\')">Back to requests</button></div>';
    }
    return;
  }
  const plan =
    (DB.eventPlans || []).find(item => item.eventPlanId === r.activeEventPlanId) ||
    (DB.eventPlans || [])
      .filter(item => item.requestId === r.requestId)
      .sort((a, b) => (b.revision || 0) - (a.revision || 0))[0];
  const organizerRole = CU.role === 'organizer';
  const isNegotiating =
    ['counteroffer_received', 'changes_requested', 'plan_revision_requested'].includes(r.status) ||
    (r.negotiations && r.negotiations.length > 0);
  const isAccepted =
    ['awaiting_client', 'confirmed', 'completed'].includes(r.status) ||
    (r.proposals && r.proposals.some(proposal => proposal.status === 'accepted'));
  const isPaymentPending =
    ['awaiting_client'].includes(r.status) ||
    r.paymentStatus === 'deposit_pending' ||
    r.paymentStatus === 'deposit_paid';
  const isConfirmed = ['confirmed', 'completed'].includes(r.status);
  const isCompleted = r.status === 'completed';
  const timeline = [
    ['1. Submitted', true],
    ['2. Under Review', !['submitted', 'pending'].includes(r.status)],
    [
      '3. Proposal Sent',
      ['proposal_sent', 'planning', 'awaiting_client', 'confirmed', 'completed'].includes(
        r.status
      ) ||
        (r.proposals && r.proposals.length > 0),
    ],
    ['4. Negotiation', isNegotiating],
    ['5. Accepted', isAccepted],
    ['6. Payment Pending', isPaymentPending || isConfirmed],
    ['7. Confirmed', isConfirmed],
    ['8. Completed', isCompleted],
  ];
  const currentChange = [...(r.negotiations || [])]
    .reverse()
    .find(item => item.action === 'changes_requested');
  const plans = (DB.eventPlans || [])
    .filter(item => item.requestId === r.requestId)
    .sort((a, b) => (b.revision || 0) - (a.revision || 0));
  const latestProposal =
    r.proposals && r.proposals.length > 0 ? r.proposals[r.proposals.length - 1] : null;
  const agreedProposal = getClientAcceptedProposal(r) || latestProposal;
  const planDeposit = Number(
    agreedProposal?.depositRequired ?? Math.round(Number(plan?.budget || r.budget || 0) * 0.3)
  );
  const planBalance = Math.max(
    0,
    Number(plan?.budget || agreedProposal?.amount || r.budget || 0) - planDeposit
  );
  const organizer =
    (DB.organizers || []).find(
      item => String(item.organizerId || item.id) === String(r.organizerId || r.organizer)
    ) ||
    (DB.users || []).find(
      item => String(item.id || item.userId) === String(r.organizerId || r.organizer)
    );
  const organizerActions = ['submitted', 'pending', 'under_review', 'info_requested'].includes(
    r.status
  )
    ? `<div style="display:flex;gap:10px;margin-top:16px"><button class="btn btn-success w-full" onclick="acceptWorkflowRequest('${r.id}')">Accept</button><button class="btn btn-danger w-full" onclick="openWorkflowRejectModal('${r.id}')">Reject</button></div>`
    : r.status === 'counteroffer_received'
    ? `<div style="display:flex;gap:10px;margin-top:16px"><button class="btn btn-success w-full" onclick="acceptWorkflowCounteroffer('${r.id}')">Accept Counteroffer</button><button class="btn btn-danger w-full" onclick="openWorkflowRejectModal('${r.id}')">Reject / Propose Changes</button></div>`
    : ['planning', 'plan_revision_requested'].includes(r.status)
    ? `<button class="btn btn-primary w-full" style="margin-top:16px" onclick="openWorkflowPlanModal('${
        r.id
      }')">${
        r.status === 'plan_revision_requested' ? 'Edit and Resubmit Plan' : 'Create Event Plan'
      }</button>`
    : '';
  const clientCancelBtn =
    CU.role === 'client' &&
    !['cancelled', 'withdrawn', 'rejected', 'completed'].includes(r.status) &&
    !r.eventId
      ? `<button class="btn btn-danger btn-sm" onclick="openClientCancelRequestModal('${r.id}')">Cancel Request</button>`
      : '';
  const clientActions = ['cancelled', 'withdrawn', 'rejected', 'expired', 'completed'].includes(
    r.status
  )
    ? ''
    : r.status === 'changes_requested'
    ? `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:16px"><button class="btn btn-success" onclick="respondToWorkflowChanges('${r.id}','accept_changes')">Accept Changes</button><button class="btn btn-danger" onclick="respondToWorkflowChanges('${r.id}','reject_changes')">Reject Changes</button><button class="btn btn-primary" onclick="openWorkflowCounterofferModal('${r.id}')">Send Counteroffer</button>${clientCancelBtn}</div>`
    : r.status === 'plan_submitted' && plan?.approvalStatus === 'pending'
    ? `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:16px"><button class="btn btn-success" onclick="openWorkflowPlanAcceptanceModal('${plan.eventPlanId}','${r.id}')">Accept Plan</button><button class="btn btn-primary" onclick="openWorkflowPlanRevisionModal('${plan.eventPlanId}','${r.id}')">Request Changes</button><button class="btn btn-danger" onclick="openWorkflowPlanRejectionModal('${plan.eventPlanId}','${r.id}')">Reject Plan</button></div>`
    : (r.status === 'awaiting_client' ||
        (r.paymentStatus === 'deposit_pending' &&
          (r.proposals || []).some(proposal => proposal.status === 'accepted'))) &&
      (plan?.approvalStatus === 'approved' ||
        (r.proposals || []).some(proposal => proposal.status === 'accepted'))
    ? `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:16px"><button class="btn btn-success" onclick="openClientPaymentModal('${workflowHtml(
        r.id
      )}')">Proceed to Payment &amp; Confirmation</button>${clientCancelBtn}</div>`
    : clientCancelBtn
    ? `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:16px">${clientCancelBtn}</div>`
    : '';
  const negotiationHtml = (r.negotiations || [])
    .map(
      item =>
        `<div style="padding:10px;border-left:3px solid var(--accent);background:var(--surface2);border-radius:6px;margin-top:8px"><strong>${workflowHtml(
          String(item.action || '').replaceAll('_', ' ')
        )}</strong><div style="font-size:12px;color:var(--text2);margin-top:4px">${workflowHtml(
          item.reason
        )}${item.budget ? ` · Budget ₹${Number(item.budget).toLocaleString()}` : ''}${
          item.eventDate ? ` · Date ${workflowHtml(item.eventDate)}` : ''
        }</div></div>`
    )
    .join('');
  const planDocFileName = plan?.documentFileName || latestProposal?.documentFileName;
  const planDocName = plan?.documentName || latestProposal?.documentName || planDocFileName;
  const planDocType = plan?.documentType || latestProposal?.documentType || 'application/pdf';
  const planDocSize = plan?.documentSize || latestProposal?.documentSize;
  const planDocDate =
    plan?.uploadedAt || latestProposal?.uploadedAt || plan?.createdAt || latestProposal?.sentAt;
  const planDocUploader = plan?.uploaderName || latestProposal?.uploaderName || 'Organizer';
  const planTargetId = plan?.eventPlanId || r.requestId || r.id;
  const planDocCard = planDocFileName
    ? `
        <div style="margin-top:12px;padding:14px;border:1px solid var(--border);border-radius:8px;background:var(--surface)">
          <div style="font-weight:700;font-size:13.5px;color:var(--text)">📎 ${escapeHtml(
            planDocName || 'event-plan.pdf'
          )}</div>
          <div style="font-size:12px;color:var(--text2);margin-top:4px">
            <span>${escapeHtml(planDocType)}</span>${
        planDocSize ? ` · ${(Number(planDocSize) / 1024).toFixed(1)} KB` : ''
      } &middot;
            <span>Uploaded ${
              planDocDate ? new Date(planDocDate).toLocaleString() : 'Recently'
            }</span> &middot;
            <span>Revision ${plan?.revision || latestProposal?.version || 1}</span> &middot;
            <span>By ${escapeHtml(planDocUploader)}</span>
          </div>
          <div style="display:flex;gap:8px;margin-top:10px">
            <button class="btn btn-ghost btn-sm" onclick="openEventPlanPdf('${planTargetId}','${encodeURIComponent(
        planDocName || 'event-plan.pdf'
      )}',true${
        latestProposal?.version ? ',' + latestProposal.version : ''
      })">👁️ View PDF / Preview</button>
            <button class="btn btn-primary btn-sm" onclick="openEventPlanPdf('${planTargetId}','${encodeURIComponent(
        planDocName || 'event-plan.pdf'
      )}',false${
        latestProposal?.version ? ',' + latestProposal.version : ''
      })">⬇️ Download PDF</button>
          </div>
        </div>`
    : `
        <div style="margin-top:12px;padding:12px 14px;border:1px dashed var(--border);border-radius:8px;background:var(--surface2)">
          <div style="font-size:12.5px;color:var(--text2)">📝 <strong>Text-only plan proposal</strong> — no file attached by organizer. Proposal deliverables and terms are detailed above.</div>
        </div>`;
  const planRevisionHistoryHtml =
    plans.length > 1
      ? `
        <details style="margin-top:12px">
          <summary style="cursor:pointer;font-weight:600;font-size:13px">Plan revision history (${
            plans.length
          } versions, newest first)</summary>
          <div style="display:flex;flex-direction:column;gap:8px;margin-top:8px">
            ${plans
              .map(
                item => `
              <div style="font-size:12px;padding:8px 10px;background:var(--surface);border:1px solid var(--border);border-radius:6px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px">
                <div>
                  <strong>Revision ${item.revision || 1}:</strong> ${workflowHtml(
                  item.title
                )} — <span class="badge badge-${
                  item.approvalStatus === 'approved'
                    ? 'green'
                    : item.approvalStatus === 'revision_requested'
                    ? 'yellow'
                    : 'blue'
                }">${workflowHtml(
                  String(item.approvalStatus || 'pending').replaceAll('_', ' ')
                )}</span>
                  ${
                    item.uploadedAt || item.createdAt
                      ? `<div class="small" style="color:var(--text3)">Uploaded ${new Date(
                          item.uploadedAt || item.createdAt
                        ).toLocaleString()}</div>`
                      : ''
                  }
                </div>
                ${
                  item.documentFileName
                    ? `
                  <div style="display:flex;gap:6px">
                    <button class="btn btn-ghost btn-xs" onclick="openEventPlanPdf('${
                      item.eventPlanId
                    }','${encodeURIComponent(
                        item.documentName || item.documentFileName
                      )}',true)">Preview</button>
                    <button class="btn btn-ghost btn-xs" onclick="openEventPlanPdf('${
                      item.eventPlanId
                    }','${encodeURIComponent(
                        item.documentName || item.documentFileName
                      )}',false)">Download</button>
                  </div>
                `
                    : ''
                }
              </div>
            `
              )
              .join('')}
          </div>
        </details>`
      : r.proposals && r.proposals.length > 1
      ? `
        <details style="margin-top:12px">
          <summary style="cursor:pointer;font-weight:600;font-size:13px">Proposal version history (${
            r.proposals.length
          } versions, newest first)</summary>
          <div style="display:flex;flex-direction:column;gap:8px;margin-top:8px">
            ${[...r.proposals]
              .sort((proposal, b) => (b.version || 0) - (proposal.version || 0))
              .map(
                proposal => `
              <div style="font-size:12px;padding:8px 10px;background:var(--surface);border:1px solid var(--border);border-radius:6px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px">
                <div>
                  <strong>Version ${proposal.version || 1}:</strong> ₹${Number(
                  proposal.amount || 0
                ).toLocaleString()} — <span class="badge badge-gray">${escapeHtml(
                  proposal.status || 'draft'
                )}</span>
                  ${
                    proposal.uploadedAt || proposal.sentAt
                      ? `<div class="small" style="color:var(--text3)">${new Date(
                          proposal.uploadedAt || proposal.sentAt
                        ).toLocaleString()}</div>`
                      : ''
                  }
                </div>
                ${
                  proposal.documentFileName || proposal.documentName
                    ? `
                  <div style="display:flex;gap:6px">
                    <button class="btn btn-ghost btn-xs" onclick="openEventPlanPdf('${
                      r.requestId || r.id
                    }','${encodeURIComponent(
                        proposal.documentName || proposal.documentFileName
                      )}',true,${proposal.version})">Preview</button>
                    <button class="btn btn-ghost btn-xs" onclick="openEventPlanPdf('${
                      r.requestId || r.id
                    }','${encodeURIComponent(
                        proposal.documentName || proposal.documentFileName
                      )}',false,${proposal.version})">Download</button>
                  </div>
                `
                    : ''
                }
              </div>
            `
              )
              .join('')}
          </div>
        </details>`
      : '';
  const planHtml = plan
    ? `<div style="margin-top:12px;padding:14px;background:var(--surface2);border-radius:10px">
        <div style="display:flex;justify-content:space-between;gap:8px"><strong>${workflowHtml(
          plan.title
        )} · Revision ${plan.revision || 1}</strong><span class="badge badge-${
        plan.approvalStatus === 'approved'
          ? 'green'
          : plan.approvalStatus === 'revision_requested'
          ? 'yellow'
          : 'blue'
      }">${workflowHtml(String(plan.approvalStatus || 'pending').replaceAll('_', ' '))}</span></div>
        <p style="font-size:13px;color:var(--text2);line-height:1.6">${workflowHtml(
          plan.description
        )}</p>
        <div class="info-row"><span class="info-label">Total proposal amount</span><span class="info-value">₹${Number(
          plan.budget || 0
        ).toLocaleString()}</span></div>
        <div class="info-row"><span class="info-label">Advance deposit</span><span class="info-value">₹${planDeposit.toLocaleString()}</span></div>
        <div class="info-row"><span class="info-label">Remaining balance</span><span class="info-value">₹${planBalance.toLocaleString()}</span></div>
        ${
          plan.budgetBreakdown
            ? `<div style="margin-top:10px"><strong>Itemized cost breakdown</strong><p style="white-space:pre-wrap;color:var(--text2)">${workflowHtml(
                plan.budgetBreakdown
              )}</p></div>`
            : ''
        }
        ${
          plan.services
            ? `<div style="margin-top:10px"><strong>Proposed services & deliverables</strong><p style="white-space:pre-wrap;color:var(--text2)">${workflowHtml(
                plan.services
              )}</p></div>`
            : ''
        }
        ${
          plan.arrangements
            ? `<div style="margin-top:10px"><strong>Venue & execution arrangements</strong><p style="white-space:pre-wrap;color:var(--text2)">${workflowHtml(
                plan.arrangements
              )}</p></div>`
            : ''
        }
        ${
          plan.schedule
            ? `<div style="margin-top:10px"><strong>Event schedule & execution timeline</strong><p style="white-space:pre-wrap;color:var(--text2)">${workflowHtml(
                plan.schedule
              )}</p></div>`
            : ''
        }
        <div style="margin-top:10px"><strong>Payment terms</strong><p style="color:var(--text2)">${workflowHtml(
          agreedProposal?.paymentSchedule ||
            agreedProposal?.paymentTerms ||
            'Advance deposit payable now; remaining balance follows the accepted agreement.'
        )}</p></div>
        <div style="margin-top:10px"><strong>Cancellation policy</strong><p style="color:var(--text2)">${workflowHtml(
          agreedProposal?.cancellationTerms ||
            agreedProposal?.cancellationPolicy ||
            'The event agreement cancellation policy applies.'
        )}</p></div>
        <div class="small" style="color:var(--text3);margin-top:8px">Submitted ${workflowPolicyDate(
          plan.createdAt || plan.uploadedAt
        )} · Revision ${plan.revision || 1}</div>
        ${planDocCard}
        ${
          plan.revisionReason
            ? `<div style="font-size:12px;color:var(--yellow);margin-top:8px">Requested revision: ${workflowHtml(
                plan.revisionReason
              )}</div>`
            : ''
        }
        ${planRevisionHistoryHtml}
      </div>`
    : latestProposal
    ? `<div style="margin-top:12px;padding:14px;background:var(--surface2);border-radius:10px">
        <div style="display:flex;justify-content:space-between;gap:8px"><strong>Event Proposal · Version ${
          latestProposal.version || 1
        }</strong><span class="badge badge-blue">${workflowHtml(
        String(latestProposal.status || 'pending_client').replaceAll('_', ' ')
      )}</span></div>
        <p style="font-size:13px;color:var(--text2);line-height:1.6;margin-top:6px">${workflowHtml(
          latestProposal.eventPlan || latestProposal.terms || 'Event proposal details.'
        )}</p>
        <div class="info-row"><span class="info-label">Proposed Price</span><span class="info-value">₹${Number(
          latestProposal.amount || 0
        ).toLocaleString()}</span></div>
        <div class="info-row"><span class="info-label">Advance Deposit</span><span class="info-value">₹${Number(
          latestProposal.depositRequired || Math.round((latestProposal.amount || 0) * 0.3)
        ).toLocaleString()}</span></div>
        ${planDocCard}
        ${planRevisionHistoryHtml}
      </div>`
    : `<p style="color:var(--text3);font-size:13px">The organizer has not submitted an event plan yet.</p>`;
  const eventId = r.eventId;
  const event =
    eventId && DB.events.find(item => String(item.eventId || item.id) === String(eventId));
  const completionReport = (DB.eventCompletionReports || []).find(item => item.eventId === eventId);
  const submittedReview = (DB.clientOrganizerReviews || []).find(item => item.eventId === eventId);
  const isPaid = r.paymentStatus === 'fully_paid';
  const bookingAmounts = getClientBookingAmounts(r, plan);
  const reportPhotos = (completionReport?.photos || [])
    .map(
      photo =>
        `<button class="btn btn-ghost btn-xs" onclick="openEventCompletionPhoto('${eventId}','${encodeURIComponent(
          photo.fileName
        )}')">View ${workflowHtml(photo.originalName)}</button>`
    )
    .join(' ');
  const completionReportHtml = completionReport
    ? `<div style="margin-top:16px;padding:16px;border:1px solid var(--border);border-radius:10px">
        <h3 style="margin:0 0 10px">Event Completion Report</h3>
        <div class="info-row"><span class="info-label">Event</span><span class="info-value">${workflowHtml(
          completionReport.eventName
        )} · ${workflowHtml(completionReport.eventDate)}</span></div>
        <div class="info-row"><span class="info-label">Venue</span><span class="info-value">${workflowHtml(
          completionReport.venue || '—'
        )}</span></div>
        <div style="margin-top:10px"><strong>Services provided</strong><p style="white-space:pre-wrap;color:var(--text2)">${workflowHtml(
          completionReport.servicesProvided
        )}</p></div>
        <div style="margin-top:10px"><strong>Expenses</strong><p style="white-space:pre-wrap;color:var(--text2)">${workflowHtml(
          completionReport.expenses
        )}</p></div>
        <div style="margin-top:10px"><strong>Completion notes</strong><p style="white-space:pre-wrap;color:var(--text2)">${workflowHtml(
          completionReport.completionNotes
        )}</p></div>
        ${
          reportPhotos
            ? `<div style="margin-top:10px"><strong>Photos</strong><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">${reportPhotos}</div></div>`
            : ''
        }
      </div>`
    : '';
  const reviewHtml =
    completionReport && !submittedReview
      ? `<div style="margin-top:14px;padding:16px;background:var(--surface2);border-radius:10px">
        <h3 style="margin:0 0 10px">Review the Organizer</h3>
        <div class="form-group"><label class="form-label" for="workflow-review-rating">Rating</label><select class="form-control" id="workflow-review-rating"><option value="">Choose stars</option><option value="5">★★★★★ - Excellent</option><option value="4">★★★★ - Good</option><option value="3">★★★ - Average</option><option value="2">★★ - Poor</option><option value="1">★ - Very poor</option></select></div>
        <div class="form-group"><label class="form-label" for="workflow-review-comment">Written review</label><textarea class="form-control" id="workflow-review-comment" rows="3" required></textarea></div>
        <button class="btn btn-primary" onclick="submitClientOrganizerReview('${eventId}','${r.id}')">Submit Review</button>
      </div>`
      : submittedReview
      ? '<div style="margin-top:14px;color:var(--green);font-weight:600">Thank you. Your review has been published to the organizer profile.</div>'
      : '';
  const lifecycleHtml =
    eventId && event && r.status !== 'cancelled'
      ? `<section style="margin-top:18px;padding:16px;background:var(--surface2);border-radius:10px">
        <h3 style="margin:0 0 10px">Ongoing Event Workflow</h3>
        <div class="info-row"><span class="info-label">Event status</span><span class="info-value">${workflowHtml(
          event.status
        )}</span></div>
        <div class="info-row"><span class="info-label">Payment status</span><span class="info-value" style="color:${
          isPaid ? 'var(--green)' : 'var(--yellow)'
        }">${
          isPaid ? 'Paid' : r.paymentStatus === 'deposit_paid' ? 'Deposit Paid' : 'Unpaid'
        }</span></div>
        ${
          event.status === 'ongoing' && !isPaid && bookingAmounts.remainingAmount > 0
            ? `<div style="margin-top:10px"><strong>Final agreed amount: ₹${bookingAmounts.totalAmount.toLocaleString()}</strong><div style="margin-top:6px">Remaining amount: ₹${bookingAmounts.remainingAmount.toLocaleString()}</div><div style="display:flex;gap:10px;margin-top:8px"><button class="btn btn-primary" onclick="openClientPaymentModal('${escapeHtml(
                r.id
              )}', '${escapeHtml(eventId || '')}')">💳 Pay Remaining Amount</button></div></div>`
            : ''
        }
        ${
          isPaid
            ? `<div style="margin-top:10px"><button class="btn btn-ghost btn-sm" onclick="openClientPaymentModal('${escapeHtml(
                r.id
              )}', '${escapeHtml(
                eventId || ''
              )}')">📜 View Payment Receipt & Transactions</button></div>`
            : ''
        }
        <div style="display:flex;gap:10px;margin-top:14px;flex-wrap:wrap">
          ${
            event.status === 'ongoing' && CU.role === 'client'
              ? `<button class="btn btn-danger btn-sm" onclick="openClientCancelRequestModal('${workflowHtml(
                  r.requestId || r.id
                )}')">Cancel Event</button>`
              : ''
          }
        </div>
        ${
          r.eventModifications && r.eventModifications.length > 0
            ? `
          <div style="background:var(--surface);border-radius:10px;padding:14px;border:1px solid var(--border);margin-top:14px">
            <div style="font-weight:700;font-size:13px;margin-bottom:8px">📝 Event Modifications (${
              r.eventModifications.length
            })</div>
            ${r.eventModifications
              .map(
                mod => `
              <div style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:10px;margin-bottom:8px;font-size:12px">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                  <span style="font-weight:600">Requested by ${
                    mod.requesterRole === 'client' ? 'Client' : 'Organizer'
                  }</span>
                  <span class="badge badge-${
                    mod.status === 'approved'
                      ? 'green'
                      : mod.status === 'rejected'
                      ? 'red'
                      : 'yellow'
                  }">${mod.status.replace('_', ' ')}</span>
                </div>
                <div style="color:var(--text2);margin-bottom:4px"><strong>Reason:</strong> ${escapeHtml(
                  mod.reason || '—'
                )}</div>
                <div style="font-size:11px;color:var(--text3);margin-bottom:6px">Date: ${
                  mod.newValues?.date || '—'
                } · Capacity: ${mod.newValues?.capacity || '—'} · Budget: ₹${(
                  mod.newValues?.budget || 0
                ).toLocaleString()}</div>
                ${
                  mod.status === 'pending_approval'
                    ? '<div style="font-size:11px;color:var(--text3)">Booked event details are locked.</div>'
                    : ''
                }
              </div>
            `
              )
              .join('')}
          </div>
        `
            : ''
        }
        ${
          r.status !== 'cancelled'
            ? renderWorkflowCancellation(r.cancellation || event.cancellation, r)
            : ''
        }
        ${renderWorkflowFileReports(eventId)}
        ${completionReportHtml}
        ${reviewHtml}
      </section>`
      : '';
  globalThis.window?.EventFlowClientPages?.clear(element);
  element.innerHTML = `<div class="page-hd">
        <div class="page-hd-left"><button class="btn btn-ghost btn-sm" onclick="goNav('${_workflowReturnPage}')">← Back to ${
    _workflowReturnPage === 'my-events'
      ? 'Events'
      : _workflowReturnPage === 'ongoing-events'
      ? 'Ongoing Events'
      : _workflowReturnPage === 'completed-events'
      ? 'Completed Events'
      : _workflowReturnPage === 'event-requests'
      ? 'Event Requests'
      : _workflowReturnPage === 'dashboard'
      ? 'Dashboard'
      : 'Request Status'
  }</button><div class="page-title" style="margin-top:12px">${
    r.status === 'plan_submitted' ? 'Event Plan Review — ' : ''
  }${workflowHtml(
    r.title
  )}</div><div class="page-sub">Original request details, organizer submission, pricing, terms, attachment, and history</div></div>
      </div>
      <div class="card" style="max-width:1000px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
          <span class="badge badge-${reqBadge(
            r.status
          )}" style="text-transform:capitalize">${String(r.status).replaceAll('_', ' ')}</span>
          <span style="font-size:12px;color:var(--text3)">Request ID: ${workflowHtml(
            r.requestId
          )}</span>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin:16px 0">
          ${timeline
            .map(
              ([label, complete]) =>
                `<div style="flex:1;min-width:105px;padding:8px;border-radius:8px;background:${
                  complete ? 'var(--accent-dim)' : 'var(--surface2)'
                };color:${
                  complete ? 'var(--accent)' : 'var(--text3)'
                };font-size:11px;font-weight:600">${complete ? '✓ ' : '○ '}${label}</div>`
            )
            .join('')}
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
          <div class="info-row"><span class="info-label">Event date</span><span class="info-value">${workflowHtml(
            r.eventDate || r.date
          )}</span></div>
          <div class="info-row"><span class="info-label">Budget</span><span class="info-value">₹${Number(
            r.budget || 0
          ).toLocaleString()}</span></div>
          <div class="info-row"><span class="info-label">Ticket price per attendee</span><span class="info-value">${
            Number(r.ticketPrice || 0) === 0
              ? 'Free'
              : '₹' + Number(r.ticketPrice).toLocaleString('en-IN')
          }</span></div>
          <div class="info-row"><span class="info-label">Event access</span><span class="info-value">${
            r.visibility === 'private'
              ? 'Private — approval before payment'
              : 'Public — direct registration'
          }</span></div>
          <div class="info-row"><span class="info-label">Guests</span><span class="info-value">${
            r.capacity || r.guests
          }</span></div>
          <div class="info-row"><span class="info-label">Event type</span><span class="info-value">${workflowHtml(
            r.eventType || r.type
          )}</span></div>
          <div class="info-row"><span class="info-label">Organizer</span><span class="info-value">${workflowHtml(
            organizer?.name || organizer?.businessName || r.organizerName || 'Assigned Organizer'
          )}</span></div>
        </div>
        ${r.status === 'cancelled' ? renderWorkflowCancellation(r.cancellation, r) : ''}
        <div style="margin:12px 0"><strong>Event details</strong><p style="white-space:pre-wrap;color:var(--text2);line-height:1.6">${workflowHtml(
          r.requirements || r.desc || '—'
        )}</p></div>
        ${
          r.status === 'rejected' && r.rejectionReason
            ? `<div style="padding:12px;background:var(--red-dim);margin:12px 0;border-radius:8px"><strong style="color:var(--red)">&#10005; Reason for declining</strong><p style="margin:6px 0 0;white-space:pre-wrap;overflow-wrap:anywhere">${workflowHtml(
                r.rejectionReason
              )}</p>${
                r.rejectionComments
                  ? `<p style="margin:6px 0 0;font-size:12px;color:var(--text2)"><strong>Additional comments:</strong> ${workflowHtml(
                      r.rejectionComments
                    )}</p>`
                  : ''
              }</div>`
            : ''
        }
        ${
          currentChange
            ? `<div style="padding:12px;border-radius:8px;background:rgba(245,158,11,.1);margin:12px 0"><strong>Organizer requested changes</strong><div style="font-size:13px;margin-top:5px">${workflowHtml(
                currentChange.reason
              )}</div>${
                currentChange.budget
                  ? `<div>Proposed budget: ₹${Number(currentChange.budget).toLocaleString()}</div>`
                  : ''
              }${
                currentChange.eventDate
                  ? `<div>Proposed date: ${workflowHtml(currentChange.eventDate)}</div>`
                  : ''
              }</div>`
            : ''
        }
        <div style="margin-top:16px"><strong>Event plan</strong>${planHtml}</div>
        ${renderWorkflowEventPolicy(r.policySnapshot || workflowEventPolicy)}
        <p class="small">Client acknowledgement: ${workflowHtml(
          workflowPolicyDate(r.clientPolicyAcceptedAt)
        )}<br>Organizer acknowledgement: ${workflowHtml(
    workflowPolicyDate(r.organizerPolicyAcceptedAt)
  )}</p>
        ${organizerRole ? organizerActions : clientActions}
        ${lifecycleHtml}
        ${
          negotiationHtml
            ? `<div style="margin-top:18px"><strong>Negotiation history</strong>${negotiationHtml}</div>`
            : ''
        }
        <div style="margin-top:18px"><strong>Progress history</strong>${
          (r.auditHistory || [])
            .slice()
            .reverse()
            .map(
              entry =>
                `<div style="padding:8px 0;border-bottom:1px solid var(--border2);font-size:12px"><strong>${workflowHtml(
                  entry.action
                )}</strong><div style="color:var(--text3)">${
                  entry.timestamp
                    ? workflowHtml(String(entry.timestamp).replace('T', ' ').slice(0, 16))
                    : ''
                } · ${workflowHtml(entry.role)}</div></div>`
            )
            .join('') ||
          '<div style="font-size:12px;color:var(--text3)">No workflow actions yet.</div>'
        }</div>
      </div>`;
}
let workflowResponsePolicy = null;
async function openWorkflowRejectModal(id) {
  try {
    workflowResponsePolicy = await loadWorkflowEventPolicy(
      DB.eventRequests.find(item => String(item.id) === String(id))
    );
  } catch (error) {
    toast(error.message || 'Unable to load event policies', 'error');
    return;
  }
  openModal(
    'Reject Request',
    `<div class="form-group"><label class="form-label">Choose a response</label><select class="form-control" id="workflow-reject-type" onchange="toggleWorkflowRejectFields()"><option value="budget">Budget Increase</option><option value="date">Date Change</option><option value="both">Both Budget and Date Change</option><option value="other">Other Reason</option><option value="permanent">Permanently Reject Request</option></select></div>
      <div class="form-group" id="workflow-reject-budget"><label class="form-label">New budget (must be higher)</label><input class="form-control" id="workflow-new-budget" type="number" min="1"></div>
      <div class="form-group" id="workflow-reject-date" style="display:none"><label class="form-label">New event date</label><input class="form-control" id="workflow-new-date" type="date"></div>
      <div class="form-group"><label class="form-label">Reason</label><textarea class="form-control" id="workflow-reject-reason" rows="3" required></textarea></div>
      <div id="workflow-reject-policy">${renderWorkflowEventPolicy(
        workflowResponsePolicy,
        'workflow-change-policy'
      )}</div>
      <div id="workflow-reject-error" style="color:var(--red);font-size:12px"></div>`,
    [
      {
        lbl: 'Cancel',
        cls: 'btn-ghost',
        fn: 'closeModal()',
      },
      {
        lbl: 'Send Response',
        cls: 'btn-primary',
        fn: `submitWorkflowReject('${id}')`,
      },
    ]
  );
  toggleWorkflowRejectFields();
}
function toggleWorkflowRejectFields() {
  const type = v('workflow-reject-type');
  const budget = g('workflow-reject-budget');
  const date = g('workflow-reject-date');
  if (budget) budget.style.display = ['budget', 'both'].includes(type) ? '' : 'none';
  if (date) date.style.display = ['date', 'both'].includes(type) ? '' : 'none';
  const policy = g('workflow-reject-policy');
  if (policy) policy.style.display = type === 'permanent' ? 'none' : '';
}
function submitWorkflowReject(id) {
  const type = v('workflow-reject-type');
  const reason = v('workflow-reject-reason').trim();
  if (!reason) {
    g('workflow-reject-error').textContent = 'Please enter a reason.';
    return;
  }
  const payload = {
    reason,
    reasonType: type,
  };
  if (type !== 'permanent') {
    const acknowledgement = workflowPolicyAcknowledgement(
      workflowResponsePolicy,
      'workflow-change-policy'
    );
    if (!acknowledgement) return;
    Object.assign(payload, acknowledgement);
  }
  if (['budget', 'both'].includes(type)) payload.proposedBudget = Number(v('workflow-new-budget'));
  if (['date', 'both'].includes(type)) payload.proposedDate = v('workflow-new-date');
  runWorkflowAction(
    () => apiRejectEventRequest(id, payload),
    type === 'permanent' ? 'Request permanently rejected' : 'Changes sent to client',
    id
  );
}
let workflowAcceptance = null;
async function openWorkflowAcceptance(id, counteroffer) {
  try {
    const policy = await loadWorkflowEventPolicy(
      DB.eventRequests.find(item => String(item.id) === String(id))
    );
    workflowAcceptance = {
      id,
      counteroffer,
      policy,
    };
    openModal(
      counteroffer ? 'Accept Client Counteroffer' : 'Accept Event Request',
      '<p>Review and accept the same event rules, policies, and terms provided to the client before starting planning.</p>' +
        renderWorkflowEventPolicy(policy, 'workflow-accept-policy'),
      [
        {
          lbl: 'Back',
          cls: 'btn-ghost',
          fn: 'closeModal()',
        },
        {
          lbl: counteroffer ? 'Accept Counteroffer' : 'Accept Request',
          cls: 'btn-success',
          fn: `submitWorkflowAcceptance('${id}')`,
        },
      ]
    );
  } catch (error) {
    toast(error.message || 'Unable to load event policies', 'error');
  }
}
function acceptWorkflowRequest(id) {
  return openWorkflowAcceptance(id, false);
}
function acceptWorkflowCounteroffer(id) {
  return openWorkflowAcceptance(id, true);
}
function submitWorkflowAcceptance(id) {
  if (!workflowAcceptance || String(workflowAcceptance.id) !== String(id)) return;
  const acknowledgement = workflowPolicyAcknowledgement(
    workflowAcceptance.policy,
    'workflow-accept-policy'
  );
  if (!acknowledgement) return;
  return runWorkflowAction(
    () =>
      workflowAcceptance.counteroffer
        ? apiAcceptCounteroffer(id, acknowledgement)
        : apiAcceptEventRequest(id, acknowledgement),
    'Request accepted; event planning can begin',
    id
  );
}
let workflowCancellationPreview = null;
let workflowCancellationSubmitting = false;
async function openWorkflowCancellation(eventId) {
  if (workflowCancellationSubmitting) return;
  workflowCancellationPreview = null;
  try {
    const preview = workflowPayload(await apiPreviewClientEventCancellation(eventId));
    workflowCancellationPreview = preview;
    const event = DB.events.find(item => String(item.eventId || item.id) === String(eventId));
    const quote = `<p>Event: <strong>${workflowHtml(
      event?.name || event?.title || eventId
    )}</strong></p>
          <div class="info-row"><span class="info-label">Amount paid</span><strong>${workflowMoney(
            preview.paidAmount
          )}</strong></div>
          <div class="info-row"><span class="info-label">Cancellation fee (${
            preview.cancellationFeePercent
          }%)</span><strong>${workflowMoney(preview.cancellationFee)}</strong></div>
          <div class="info-row"><span class="info-label">Refund due</span><strong>${workflowMoney(
            preview.refundAmount
          )}</strong></div>
          <p class="small">Cancellation deadline: ${workflowHtml(
            workflowPolicyDate(preview.cancellationDeadline)
          )}. At least ${preview.minimumNoticeDays} days must remain before the event starts.</p>
          <p class="small"><strong>Refund conditions:</strong> ${
            preview.refundEligible === false
              ? 'This accepted policy is non-refundable.'
              : `${
                  preview.approvalMode === 'automatic'
                    ? 'Automatically evaluated under the policy'
                    : 'Manual organizer approval required'
                }; demo refunds are recorded as Pending.`
          }</p>
          ${
            preview.additionalTerms
              ? `<p class="small"><strong>Additional terms:</strong> ${workflowHtml(
                  preview.additionalTerms
                )}</p>`
              : ''
          }`;
    if (!preview.canCancel) {
      openModal(
        'Cancellation unavailable',
        quote + `<p role="alert">${workflowHtml(preview.unavailableReason)}</p>`,
        [
          {
            lbl: 'Close',
            cls: 'btn-ghost',
            fn: 'closeModal()',
          },
        ],
        false
      );
      return;
    }
    openModal(
      'Cancel Event',
      quote +
        `<p class="small">${
          preview.paidAmount > 0
            ? 'The refund due will be recorded as pending review.'
            : 'No payment was taken, so the cancellation fee is zero.'
        }</p>
          <div class="form-group"><label class="form-label" for="workflow-cancel-reason">Cancellation reason *</label><textarea class="form-control" id="workflow-cancel-reason" rows="3" minlength="10" maxlength="1000" placeholder="Explain why you need to cancel (at least 10 characters)." required></textarea></div>
          ${renderWorkflowEventPolicy(preview.policy, 'workflow-cancel-policy')}
          <p>This will cancel the event and notify the organizer.</p><div id="workflow-cancel-error" role="alert" style="color:var(--red);font-size:13px"></div>`,
      [
        {
          lbl: 'Keep Event',
          cls: 'btn-ghost',
          fn: 'closeModal()',
        },
        {
          lbl: 'Confirm Cancellation',
          cls: 'btn-danger',
          fn: `submitWorkflowCancellation('${eventId}')`,
        },
      ],
      false
    );
  } catch (error) {
    toast(error.message || 'Unable to load cancellation details', 'error');
  }
}
async function submitWorkflowCancellation(eventId) {
  const preview = workflowCancellationPreview;
  if (
    workflowCancellationSubmitting ||
    !preview?.canCancel ||
    String(preview.eventId) !== String(eventId)
  )
    return;
  const reason = v('workflow-cancel-reason').trim();
  const errorElement = g('workflow-cancel-error');
  if (reason.length < 10 || reason.length > 1000) {
    if (errorElement)
      errorElement.textContent = 'Enter a cancellation reason of 10 to 1000 characters.';
    return;
  }
  const acknowledgement = workflowPolicyAcknowledgement(preview.policy, 'workflow-cancel-policy');
  if (!acknowledgement) return;
  workflowCancellationSubmitting = true;
  const buttons = g('modal-foot')?.querySelectorAll('button') || [];
  buttons.forEach(button => {
    button.disabled = true;
  });
  if (errorElement) errorElement.textContent = '';
  try {
    await apiCancelClientEvent(eventId, {
      reason,
      expectedPaidAmount: preview.paidAmount,
      ...acknowledgement,
    });
    workflowCancellationPreview = null;
    closeModal();
    closeDrawer();
    toast(
      preview.refundAmount > 0
        ? 'Event cancelled. Refund due is pending review.'
        : 'Event cancelled. No payment was taken.',
      'success'
    );
    await syncWorkflowData();
    const request = DB.eventRequests.find(item => String(item.eventId) === String(eventId));
    if (request) viewWorkflowRequestDrawer(request.id);
    else renderPage(_currentPage);
  } catch (error) {
    if (workflowCancellationPreview && errorElement)
      errorElement.textContent = error.message || 'Unable to cancel the event. Please try again.';
    else toast('The event was cancelled. Refresh to load its updated details.', 'info');
  } finally {
    workflowCancellationSubmitting = false;
    buttons.forEach(button => {
      button.disabled = false;
    });
  }
}
function respondToWorkflowChanges(id, decision) {
  if (decision === 'accept_changes') return submitClientPlanDecision(id, decision);
  return runWorkflowAction(
    () =>
      apiRespondToEventRequest(id, {
        decision,
      }),
    'Changes rejected',
    id
  );
}
function openWorkflowCounterofferModal(id) {
  const request = DB.eventRequests.find(item => String(item.id) === String(id));
  if (!request) return;
  openModal(
    'Change Event Details / Send Counteroffer',
    `<div class="form-group"><label class="form-label">Event name</label><input class="form-control" id="workflow-counter-name" value="${workflowHtml(
      request.eventName || request.title
    )}"></div>
      <div class="form-group"><label class="form-label">Event type</label><input class="form-control" id="workflow-counter-type" value="${workflowHtml(
        request.eventType || request.type
      )}"></div>
      <div class="form-group"><label class="form-label">Budget</label><input class="form-control" id="workflow-counter-budget" type="number" min="1" value="${
        request.budget || ''
      }"></div>
      <div class="form-group"><label class="form-label">Event date</label><input class="form-control" id="workflow-counter-date" type="date" value="${workflowHtml(
        request.eventDate || request.date
      )}"></div>
      <div class="form-group"><label class="form-label">Guest capacity</label><input class="form-control" id="workflow-counter-capacity" type="number" min="1" step="1" value="${
        request.capacity || request.guests || ''
      }"></div>
      <div class="form-group"><label class="form-label">Preferred venue</label><input class="form-control" id="workflow-counter-venue" value="${workflowHtml(
        request.venue || ''
      )}"></div>
      <div class="form-group"><label class="form-label">Event requirements / details</label><textarea class="form-control" id="workflow-counter-requirements" rows="4">${workflowHtml(
        request.requirements || request.desc || ''
      )}</textarea></div>
      <div class="form-group"><label class="form-label">Notes</label><textarea class="form-control" id="workflow-counter-notes" rows="3"></textarea></div>
      <div id="workflow-counter-error" style="color:var(--red);font-size:12px"></div>`,
    [
      {
        lbl: 'Cancel',
        cls: 'btn-ghost',
        fn: 'closeModal()',
      },
      {
        lbl: 'Send Counteroffer',
        cls: 'btn-primary',
        fn: `submitWorkflowCounteroffer('${id}')`,
      },
    ]
  );
}
function submitWorkflowCounteroffer(id) {
  const request = DB.eventRequests.find(item => String(item.id) === String(id));
  if (!request) return;
  const budgetValue = v('workflow-counter-budget');
  const date = v('workflow-counter-date');
  const capacityValue = v('workflow-counter-capacity');
  if (
    !v('workflow-counter-name').trim() ||
    !v('workflow-counter-type').trim() ||
    !budgetValue ||
    !date ||
    !capacityValue
  ) {
    g('workflow-counter-error').textContent =
      'Event name, type, budget, date, and guest capacity are required.';
    return;
  }
  if (date <= today()) {
    g('workflow-counter-error').textContent = 'Event date must be in the future.';
    return;
  }
  const payload = {
    decision: 'counteroffer',
    notes: v('workflow-counter-notes'),
  };
  const changed = (fieldId, currentValue) =>
    v(fieldId).trim() !== String(currentValue ?? '').trim();
  if (changed('workflow-counter-name', request.eventName || request.title))
    payload.counterofferEventName = v('workflow-counter-name').trim();
  if (changed('workflow-counter-type', request.eventType || request.type))
    payload.counterofferEventType = v('workflow-counter-type').trim();
  if (budgetValue && Number(budgetValue) !== Number(request.budget))
    payload.counterofferBudget = Number(budgetValue);
  if (date && date !== String(request.eventDate || request.date)) payload.counterofferDate = date;
  if (capacityValue && Number(capacityValue) !== Number(request.capacity || request.guests))
    payload.counterofferCapacity = Number(capacityValue);
  if (changed('workflow-counter-venue', request.venue))
    payload.counterofferVenue = v('workflow-counter-venue').trim();
  if (changed('workflow-counter-requirements', request.requirements || request.desc))
    payload.counterofferRequirements = v('workflow-counter-requirements').trim();
  if (!Object.keys(payload).some(key => key.startsWith('counteroffer'))) {
    g('workflow-counter-error').textContent = 'Change at least one event detail before sending.';
    return;
  }
  if (
    payload.counterofferBudget !== undefined &&
    (!Number.isFinite(payload.counterofferBudget) ||
      payload.counterofferBudget < 1000 ||
      payload.counterofferBudget > 10000000)
  ) {
    g('workflow-counter-error').textContent =
      payload.counterofferBudget > 10000000
        ? 'Event budget cannot exceed ₹1,00,00,000.'
        : 'Budget must be between ₹1,000 and ₹1,00,00,000.';
    return;
  }
  if (
    payload.counterofferCapacity !== undefined &&
    (!Number.isInteger(payload.counterofferCapacity) ||
      payload.counterofferCapacity < 1 ||
      payload.counterofferCapacity > 50000)
  ) {
    g('workflow-counter-error').textContent =
      payload.counterofferCapacity > 50000
        ? 'Maximum event capacity is 50,000.'
        : 'Guest capacity must be between 1 and 50,000.';
    return;
  }
  runWorkflowAction(
    () => apiRespondToEventRequest(id, payload),
    'Counteroffer sent to organizer',
    id
  );
}
function openWorkflowPlanModal(id) {
  const request = DB.eventRequests.find(item => String(item.id) === String(id));
  const existing = (DB.eventPlans || [])
    .filter(item => item.requestId === request.requestId)
    .sort((a, b) => (b.revision || 0) - (a.revision || 0))[0];
  openModal(
    existing ? 'Revise Event Plan' : 'Create Event Plan',
    `<div class="form-group"><label class="form-label">Plan title</label><input class="form-control" id="workflow-plan-title" value="${workflowHtml(
      existing?.title || request.title
    )}"></div>
      <div class="form-group"><label class="form-label">Overview</label><textarea class="form-control" id="workflow-plan-description" rows="3">${workflowHtml(
        existing?.description || request.desc || ''
      )}</textarea></div>
      <div class="form-group"><label class="form-label">Schedule</label><textarea class="form-control" id="workflow-plan-schedule" rows="4">${workflowHtml(
        existing?.schedule || ''
      )}</textarea></div>
      <div class="form-group"><label class="form-label">Services</label><textarea class="form-control" id="workflow-plan-services" rows="3">${workflowHtml(
        existing?.services || ''
      )}</textarea></div>
      <div class="form-group"><label class="form-label">Arrangements</label><textarea class="form-control" id="workflow-plan-arrangements" rows="3">${workflowHtml(
        existing?.arrangements || ''
      )}</textarea></div>
      <div class="form-group"><label class="form-label">Budget breakdown (item and amount per line)</label><textarea class="form-control" id="workflow-plan-breakdown" rows="4">${workflowHtml(
        existing?.budgetBreakdown || ''
      )}</textarea></div>
      <div class="info-row"><span class="info-label">Agreed budget</span><span class="info-value">₹${Number(
        request.budget
      ).toLocaleString()}</span></div>`,
    [
      {
        lbl: 'Cancel',
        cls: 'btn-ghost',
        fn: 'closeModal()',
      },
      {
        lbl: existing ? 'Resubmit Plan' : 'Submit Plan',
        cls: 'btn-primary',
        fn: `submitWorkflowPlan('${id}')`,
      },
    ]
  );
}
function submitWorkflowPlan(id) {
  const request = DB.eventRequests.find(item => String(item.id) === String(id));
  const payload = {
    requestId: request.requestId,
    title: v('workflow-plan-title').trim(),
    description: v('workflow-plan-description').trim(),
    budget: Number(request.budget),
    capacity: Number(request.capacity),
    schedule: v('workflow-plan-schedule').trim(),
    services: v('workflow-plan-services').trim(),
    arrangements: v('workflow-plan-arrangements').trim(),
    budgetBreakdown: v('workflow-plan-breakdown').trim(),
  };
  if (Object.values(payload).some(value => value === '' || value === 0)) {
    toast('Complete every plan section before submitting', 'error');
    return;
  }
  runWorkflowAction(
    () => apiCreateEventPlan(payload),
    'Event plan submitted for client review',
    id
  );
}
function openWorkflowPlanRevisionModal(planId, requestId) {
  openModal(
    'Request Changes',
    `<div class="form-group"><label class="form-label">Required changes</label><textarea class="form-control" id="workflow-plan-reason" rows="4" placeholder="Explain exactly what the organizer should revise" required></textarea></div><div id="workflow-plan-error" style="color:var(--red);font-size:12px"></div>`,
    [
      {
        lbl: 'Cancel',
        cls: 'btn-ghost',
        fn: 'closeModal()',
      },
      {
        lbl: 'Submit Change Request',
        cls: 'btn-primary',
        fn: `submitWorkflowPlanRevision('${planId}','${requestId}')`,
      },
    ]
  );
}
function submitWorkflowPlanRevision(planId, requestId) {
  const reason = v('workflow-plan-reason').trim();
  if (!reason) {
    g('workflow-plan-error').textContent = 'A reason is required.';
    return;
  }
  runWorkflowAction(
    () => apiApproveEventPlan(planId, 'revision_requested', reason),
    'New plan requested',
    requestId
  );
}
function openWorkflowPlanAcceptanceModal(planId, requestId) {
  const request = DB.eventRequests.find(
    item => String(item.id || item.requestId) === String(requestId)
  );
  const plan = (DB.eventPlans || []).find(item => String(item.eventPlanId) === String(planId));
  if (
    !request ||
    !plan ||
    request.activeEventPlanId !== plan.eventPlanId ||
    request.status !== 'plan_submitted'
  ) {
    toast('The active submitted plan could not be loaded.', 'error');
    return;
  }
  const acceptedProposal = getClientAcceptedProposal(request);
  const deposit = Number(
    acceptedProposal?.depositRequired ?? Math.round(Number(plan.budget || 0) * 0.3)
  );
  const policy =
    acceptedProposal?.cancellationPolicy ||
    request.policySnapshot ||
    (typeof workflowEventPolicy !== 'undefined' ? workflowEventPolicy : null);
  const cancellation = policy?.cancellation || {};
  openModal(
    'Accept Event Plan',
    `
        <p>Review and explicitly accept the submitted plan before continuing to payment.</p>
        <div style="padding:12px;background:var(--surface2);border:1px solid var(--border);border-radius:8px;font-size:13px;margin-bottom:12px">
          <div><strong>${workflowHtml(plan.title)}</strong> · Revision ${plan.revision || 1}</div>
          <div style="margin-top:6px">Total: ${workflowMoney(
            plan.budget
          )} · Advance deposit: ${workflowMoney(deposit)}</div>
          <div style="margin-top:6px"><strong>Payment terms:</strong> ${workflowHtml(
            acceptedProposal?.paymentSchedule ||
              'Advance deposit is payable now; the remaining balance follows the accepted agreement.'
          )}</div>
          <div style="margin-top:6px"><strong>Cancellation terms:</strong> ${workflowHtml(
            acceptedProposal?.cancellationTerms ||
              'The event agreement cancellation policy applies.'
          )}</div>
          <div style="margin-top:6px"><strong>Policy:</strong> ${Number(
            cancellation.minimumNoticeDays || 0
          )} days notice; ${Number(cancellation.feePercent || 0)}% of actual payments; ${
      cancellation.refundEligible === false ? 'non-refundable' : 'net refund eligible'
    }; ${workflowHtml(cancellation.approvalMode || 'manual')} processing.</div>
          <div style="margin-top:6px"><strong>Additional terms:</strong> ${workflowHtml(
            cancellation.additionalTerms || 'No additional terms'
          )}</div>
        </div>
        <label style="display:flex;gap:8px;align-items:flex-start"><input id="workflow-plan-accept-ack" type="checkbox"><span>I have reviewed the plan, pricing, event rules, payment terms and cancellation policy, and I agree to proceed.</span></label>
        <div id="workflow-plan-accept-error" style="color:var(--red);font-size:12px;margin-top:8px"></div>`,
    [
      {
        lbl: 'Back',
        cls: 'btn-ghost',
        fn: 'closeModal()',
      },
      {
        lbl: 'Accept & Proceed to Payment',
        cls: 'btn-success',
        fn: `acceptWorkflowPlanAndPay('${planId}','${requestId}')`,
      },
    ]
  );
}
async function acceptWorkflowPlanAndPay(planId, requestId) {
  if (!g('workflow-plan-accept-ack')?.checked) {
    g('workflow-plan-accept-error').textContent =
      'You must explicitly agree to the plan and applicable terms.';
    return;
  }
  try {
    const request = DB.eventRequests.find(
      item => String(item.id || item.requestId) === String(requestId)
    );
    const policy =
      getClientAcceptedProposal(request)?.cancellationPolicy ||
      request?.policySnapshot ||
      (typeof workflowEventPolicy !== 'undefined' ? workflowEventPolicy : null);
    await apiApproveEventPlan(planId, 'approved', undefined, undefined, {
      policyAccepted: true,
      acceptedPolicyVersion: policy?.version,
    });
    await syncWorkflowData();
    closeModal();
    toast('Event plan accepted. Continue with agreement and payment.', 'success');
    openClientPaymentModal(requestId);
  } catch (error) {
    const target = g('workflow-plan-accept-error');
    if (target) target.textContent = error.message || 'Unable to accept this plan.';
    else toast(error.message || 'Unable to accept this plan.', 'error');
  }
}
function openWorkflowPlanRejectionModal(planId, requestId) {
  openModal(
    'Reject Event Plan',
    `
        <div class="form-group"><label class="form-label">Rejection reason *</label><textarea class="form-control" id="workflow-plan-reject-reason" rows="3" required></textarea></div>
        <div class="form-group"><label class="form-label">Additional explanation (optional)</label><textarea class="form-control" id="workflow-plan-reject-comments" rows="3"></textarea></div>
        <div id="workflow-plan-reject-error" style="color:var(--red);font-size:12px"></div>`,
    [
      {
        lbl: 'Cancel',
        cls: 'btn-ghost',
        fn: 'closeModal()',
      },
      {
        lbl: 'Confirm Rejection',
        cls: 'btn-danger',
        fn: `submitWorkflowPlanRejection('${planId}','${requestId}')`,
      },
    ]
  );
}
function submitWorkflowPlanRejection(planId, requestId) {
  const reason = v('workflow-plan-reject-reason').trim();
  const comments = v('workflow-plan-reject-comments').trim();
  if (!reason) {
    g('workflow-plan-reject-error').textContent = 'A rejection reason is required.';
    return;
  }
  runWorkflowAction(
    () => apiApproveEventPlan(planId, 'rejected', reason, comments),
    'Event plan rejected and request closed',
    requestId
  );
}
function viewRequestDrawer(id) {
  const r = DB.eventRequests.find(
    request =>
      String(request.id) === String(id) ||
      String(request.requestId) === String(id) ||
      (request.eventId && String(request.eventId) === String(id))
  );
  if (!r) {
    openDrawer(
      'Request Details',
      `
          <div class="empty" style="padding:28px 12px;text-align:center">
            <div class="empty-icon">⚠️</div>
            <div class="empty-title">Request Record Not Found</div>
            <p class="empty-desc">The requested event request could not be located in stored records.</p>
            <button class="btn btn-primary btn-sm mt-16" onclick="closeDrawer()">Close Drawer</button>
          </div>
        `
    );
    return;
  }
  if (
    CU &&
    CU.role === 'client' &&
    (typeof isClientOwner === 'function' ? !isClientOwner(r, CU) : false)
  ) {
    openDrawer(
      'Access Restricted',
      `
          <div class="alert alert-danger" style="margin:20px 0;padding:14px;border-radius:8px">
            <strong>Access Denied:</strong> You are not authorized to view this event request.
          </div>
          <button class="btn btn-ghost btn-sm" onclick="closeDrawer()">Close Drawer</button>
        `
    );
    return;
  }
  if (
    (r.workflowManaged || r.status === 'plan_submitted' || r.activeEventPlanId) &&
    typeof viewWorkflowRequestDrawer === 'function'
  ) {
    return viewWorkflowRequestDrawer(r.id);
  }
  const org = (DB.organizers || []).find(
    o => String(o.organizerId || o.id) === String(r.organizerId || r.organizer)
  ) ||
    (DB.users || []).find(
      user => String(user.id || user.userId) === String(r.organizerId || r.organizer)
    ) || {
      name: r.organizerName || 'Assigned Organizer',
    };
  const s = (r.status || '').toLowerCase();
  const title = r.eventName || r.title || 'Event Request';
  const type = r.eventType || r.type || 'Standard Event';
  const date = r.eventDate || r.date || '—';
  const time = r.eventTime || r.time || '—';
  const venue = r.venue || '—';
  const city = r.city || 'India';
  const guests = r.capacity || r.guests || 0;
  const budget = Number(r.budget || 0);
  const description = r.requirements || r.desc || '—';
  const submittedDate = r.createdAt ? String(r.createdAt).slice(0, 10) : r.created || '—';
  const statusExplanations = {
    submitted: 'Request submitted and queued for organizer review.',
    pending: 'Request received and awaiting organizer response.',
    under_review: 'Organizer is currently reviewing your event requirements.',
    in_review: 'Organizer is reviewing event scope and feasibility.',
    info_requested: 'Organizer requested additional clarification from you.',
    proposal_sent: 'Organizer sent a formal proposal. Review and accept to proceed.',
    changes_requested: 'You requested proposal revisions from the organizer.',
    counteroffer_received: 'Counteroffer is currently being negotiated.',
    awaiting_client: 'Proposal accepted! Awaiting advance deposit payment to confirm booking.',
    confirmed: 'Deposit paid and booking confirmed. Event is active.',
    approved: 'Booking confirmed and event scheduled.',
    completed: 'Event successfully completed.',
    withdrawn: 'Request was withdrawn by the client before booking confirmation.',
    cancelled: 'Event booking was cancelled.',
    rejected: 'Event request was declined by the organizer.',
    expired: 'Proposal expired because validity period ended without acceptance.',
  };
  const plainExplanation =
    statusExplanations[s] || 'Status: ' + (clientStatusReadable ? clientStatusReadable(s) : s);

  // Build status-specific detail block for drawer
  let statusDetail = '';
  if (s === 'rejected' && (r.rejectionReason || r.rejectionComments)) {
    statusDetail = `<div style="margin-top:12px;padding:10px 14px;background:var(--red-dim);border-radius:8px;font-size:13px"><strong style="color:var(--red)">Declined Reason:</strong> ${escapeHtml(
      r.rejectionReason || ''
    )}${
      r.rejectionComments
        ? `<div class="small mt-4" style="color:var(--text2)">${escapeHtml(
            r.rejectionComments
          )}</div>`
        : ''
    }</div>`;
  } else if (s === 'withdrawn' && (r.withdrawReason || r.withdrawalReason)) {
    statusDetail = `<div style="margin-top:12px;padding:10px 14px;background:var(--surface2);border-radius:8px;font-size:13px"><strong>Withdrawal Reason:</strong> ${escapeHtml(
      r.withdrawReason || r.withdrawalReason
    )}</div>`;
  } else if (s === 'cancelled') {
    statusDetail = renderWorkflowCancellation(r.cancellation, r);
  } else if (s === 'expired') {
    statusDetail = `<div style="margin-top:12px;padding:10px 14px;background:var(--red-dim);border-radius:8px;font-size:13px"><strong style="color:var(--red)">Proposal Expired:</strong> The proposal was not accepted within the validity window.</div>`;
  } else if (['confirmed', 'approved'].includes(s)) {
    const pol = r.cancellationPolicy || {};
    statusDetail =
      `<div style="margin-top:12px;padding:10px 14px;background:var(--green-dim);border-radius:8px;font-size:13px">` +
      `<div style="font-weight:700;color:var(--green);margin-bottom:6px">✓ Booking Confirmed</div>` +
      (r.depositAmount
        ? `<div><strong>Deposit Paid:</strong> ₹${Number(r.depositAmount).toLocaleString()}</div>`
        : '') +
      (r.budget
        ? `<div><strong>Agreed Budget:</strong> ₹${Number(r.budget).toLocaleString()}</div>`
        : '') +
      (pol.deadlineText
        ? `<div class="small mt-4" style="color:var(--text2)">Cancellation deadline: ${escapeHtml(
            pol.deadlineText
          )}</div>`
        : '') +
      `</div>`;
  } else if (
    ['changes_requested', 'counteroffer_received'].includes(s) &&
    (r.clientFeedback || (r.negotiations && r.negotiations.length > 0))
  ) {
    const lastNeg =
      r.negotiations && r.negotiations.length > 0
        ? r.negotiations[r.negotiations.length - 1]
        : null;
    statusDetail =
      `<div style="margin-top:12px;padding:10px 14px;background:var(--yellow-dim);border-radius:8px;font-size:13px">` +
      `<strong>Feedback Sent:</strong> ${escapeHtml(
        r.clientFeedback || lastNeg?.reason || 'Requested changes'
      )}` +
      (lastNeg?.budget ? ` · Proposed Budget: ₹${Number(lastNeg.budget).toLocaleString()}` : '') +
      `</div>`;
  } else if (
    ['proposal_sent', 'awaiting_client'].includes(s) &&
    r.proposals &&
    r.proposals.length
  ) {
    const prop = r.proposals[r.proposals.length - 1];
    const propHasDoc = Boolean(prop.documentFileName || prop.documentName);
    const propDocName = prop.documentName || prop.documentFileName;
    statusDetail =
      `<div style="margin-top:12px;padding:12px 14px;background:var(--accent-dim);border-radius:8px;font-size:13px">` +
      `<div style="font-weight:700;color:var(--accent);margin-bottom:6px">📄 Latest Proposal (Version ${
        prop.version || 1
      })</div>` +
      `<div><strong>Total Price:</strong> ₹${Number(
        prop.amount || 0
      ).toLocaleString()} &nbsp; <strong>Deposit:</strong> ₹${Number(
        prop.depositRequired || Math.round((prop.amount || 0) * 0.3)
      ).toLocaleString()}</div>` +
      (prop.validUntil
        ? `<div class="small mt-4" style="color:var(--text2)">Valid Until: ${escapeHtml(
            prop.validUntil
          )}</div>`
        : '') +
      (prop.terms
        ? `<div class="small mt-4" style="color:var(--text2)">Terms: ${escapeHtml(
            prop.terms
          )}</div>`
        : '') +
      (propHasDoc
        ? `
            <div style="margin-top:10px;padding:10px;background:var(--surface);border:1px solid var(--border);border-radius:6px">
              <div style="font-weight:700;font-size:12.5px;color:var(--text)">📎 ${escapeHtml(
                propDocName
              )}</div>
              <div style="font-size:11.5px;color:var(--text2);margin-top:2px">
                <span>${escapeHtml(prop.documentType || 'application/pdf')}</span>${
            prop.documentSize ? ' · ' + (Number(prop.documentSize) / 1024).toFixed(1) + ' KB' : ''
          } &middot;
                <span>Uploaded ${
                  prop.uploadedAt ? new Date(prop.uploadedAt).toLocaleString() : 'Recently'
                }</span> &middot;
                <span>Version ${prop.version || 1}</span> &middot;
                <span>By ${escapeHtml(prop.uploaderName || 'Organizer')}</span>
              </div>
              <div style="display:flex;gap:6px;margin-top:8px">
                <button class="btn btn-ghost btn-xs" onclick="openEventPlanPdf('${
                  r.requestId || r.id
                }','${encodeURIComponent(propDocName)}',true,${
            prop.version
          })">👁️ Preview PDF</button>
                <button class="btn btn-primary btn-xs" onclick="openEventPlanPdf('${
                  r.requestId || r.id
                }','${encodeURIComponent(propDocName)}',false,${
            prop.version
          })">⬇️ Download PDF</button>
              </div>
            </div>`
        : `
            <div style="margin-top:8px;font-size:12px;color:var(--text3)">📝 Text-only plan proposal — no file attached by organizer.</div>`) +
      `</div>`;
  }

  // Proposal versions section if multiple exist
  let proposalHistoryHtml = '';
  if (r.proposals && r.proposals.length > 1) {
    const sortedVersions = [...r.proposals].sort(
      (proposal, b) => (b.version || 0) - (proposal.version || 0)
    );
    proposalHistoryHtml = `
          <div style="margin-top:14px;border:1px solid var(--border);border-radius:8px;padding:10px;font-size:12px">
            <div style="font-weight:700;margin-bottom:6px">Proposal History (${
              r.proposals.length
            } versions, newest first)</div>
            ${sortedVersions
              .map(
                p => `
              <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border2);flex-wrap:wrap;gap:4px">
                <div>
                  <strong>Version ${p.version || 1}</strong> (${escapeHtml(
                  p.status || 'draft'
                )}) — ₹${Number(p.amount || 0).toLocaleString()}
                  ${
                    p.uploadedAt || p.sentAt
                      ? `<div class="small" style="color:var(--text3)">${new Date(
                          p.uploadedAt || p.sentAt
                        ).toLocaleString()}</div>`
                      : ''
                  }
                </div>
                ${
                  p.documentFileName || p.documentName
                    ? `
                  <div style="display:flex;gap:4px">
                    <button class="btn btn-ghost btn-xs" onclick="openEventPlanPdf('${
                      r.requestId || r.id
                    }','${encodeURIComponent(p.documentName || p.documentFileName)}',true,${
                        p.version
                      })">Preview</button>
                    <button class="btn btn-ghost btn-xs" onclick="openEventPlanPdf('${
                      r.requestId || r.id
                    }','${encodeURIComponent(p.documentName || p.documentFileName)}',false,${
                        p.version
                      })">Download</button>
                  </div>
                `
                    : ''
                }
              </div>
            `
              )
              .join('')}
          </div>
        `;
  }

  // Build drawer action buttons based strictly on status
  let drawerActions = '';
  if (CU.role === 'client') {
    if (['submitted', 'pending', 'under_review', 'in_review', 'info_requested'].includes(s)) {
      drawerActions = `<div class="flex gap-8 mt-20"><button class="btn btn-danger w-full" onclick="closeDrawer();openClientCancelRequestModal('${r.id}')">Withdraw Request</button></div>`;
    } else if (s === 'proposal_sent') {
      drawerActions = `<div class="flex gap-8 mt-20 flex-wrap">
            <button class="btn btn-danger" onclick="closeDrawer();openClientCancelRequestModal('${r.id}')">Withdraw Request</button>
            <button class="btn btn-ghost" onclick="closeDrawer();openClientDeclineModal('${r.id}')">Decline</button>
            <button class="btn btn-ghost" onclick="closeDrawer();openReproposalReasonModal('${r.id}')">Request Changes</button>
            <button class="btn btn-success" onclick="closeDrawer();openClientPlanReview('${r.id}')">Review Proposal</button>
          </div>`;
    } else if (s === 'awaiting_client') {
      drawerActions = `<div class="flex gap-8 mt-20 flex-wrap">
            <button class="btn btn-danger" onclick="closeDrawer();openClientCancelRequestModal('${r.id}')">Withdraw Request</button>
            <button class="btn btn-success" onclick="closeDrawer();openClientPaymentModal('${r.id}')">Proceed to Payment &amp; Confirmation</button>
          </div>`;
    } else if (['changes_requested', 'counteroffer_received'].includes(s)) {
      drawerActions = `<div class="flex gap-8 mt-20">
            <button class="btn btn-danger" onclick="closeDrawer();openClientCancelRequestModal('${r.id}')">Withdraw Request</button>
            <button class="btn btn-primary" onclick="closeDrawer();openClientPlanReview('${r.id}')">View &amp; Respond</button>
          </div>`;
    } else if (['confirmed', 'approved'].includes(s)) {
      drawerActions = `<div class="mt-20"><button class="btn btn-danger w-full" onclick="closeDrawer();openClientCancelRequestModal('${r.id}')">Cancel Event</button></div>`;
    } else {
      drawerActions = `<div class="mt-20"><button class="btn btn-ghost w-full" onclick="closeDrawer()">Close Drawer</button></div>`;
    }
  } else if (s === 'pending' || s === 'submitted') {
    drawerActions = `<div class="flex gap-8 mt-20"><button class="btn btn-success w-full" onclick="closeDrawer();approveReq(${r.id})">✓ Accept Event</button><button class="btn btn-danger w-full" onclick="closeDrawer();rejectReq(${r.id})">✕ Decline</button></div>`;
  } else {
    drawerActions = `<div class="mt-20"><button class="btn btn-ghost w-full" onclick="closeDrawer()">Close Drawer</button></div>`;
  }
  openDrawer(
    `Request: ${escapeHtml(title)}`,
    `
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
          <span class="badge badge-${reqBadge(r.status)}">${
      clientStatusReadable ? clientStatusReadable(r.status) : r.status
    }</span>
          <span style="font-size:12px;color:var(--text3);font-family:monospace">ID: ${escapeHtml(
            r.requestId || r.id
          )}</span>
        </div>
        <div class="alert alert-info" style="font-size:12.5px;padding:8px 12px;border-radius:6px;margin-bottom:14px;background:var(--surface2)">
          ℹ️ ${escapeHtml(plainExplanation)}
        </div>
        <div style="display:flex;flex-direction:column;gap:4px;margin-bottom:18px">
          <div class="info-row"><span class="info-label">Assigned Organizer</span><span class="info-value"><strong>${escapeHtml(
            org.name || 'Organizer'
          )}</strong></span></div>
          ${
            org.email
              ? `<div class="info-row"><span class="info-label">Organizer Email</span><span class="info-value">${escapeHtml(
                  org.email
                )}</span></div>`
              : ''
          }
          ${
            org.phone
              ? `<div class="info-row"><span class="info-label">Organizer Phone</span><span class="info-value">${escapeHtml(
                  org.phone
                )}</span></div>`
              : ''
          }
          <div class="info-row"><span class="info-label">Event Type</span><span class="info-value">${escapeHtml(
            type
          )}</span></div>
          <div class="info-row"><span class="info-label">Preferred Date</span><span class="info-value">${escapeHtml(
            date
          )}</span></div>
          <div class="info-row"><span class="info-label">Event Time</span><span class="info-value">${escapeHtml(
            time
          )}</span></div>
          <div class="info-row"><span class="info-label">City</span><span class="info-value">${escapeHtml(
            city
          )}</span></div>
          <div class="info-row"><span class="info-label">Preferred Venue</span><span class="info-value">${escapeHtml(
            venue
          )}</span></div>
          <div class="info-row"><span class="info-label">Expected Guests</span><span class="info-value">${guests} attendees</span></div>
          <div class="info-row"><span class="info-label">Budget</span><span class="info-value" style="color:var(--green);font-weight:700">₹${budget.toLocaleString()}</span></div>
          <div class="info-row"><span class="info-label">Agreement Status</span><span class="info-value"><span class="badge badge-${
            r.agreementStatus === 'agreed' ? 'green' : 'yellow'
          }">${escapeHtml(r.agreementStatus || 'not_sent')}</span></span></div>
          <div class="info-row"><span class="info-label">Payment Status</span><span class="info-value"><span class="badge badge-${
            r.paymentStatus === 'fully_paid'
              ? 'green'
              : r.paymentStatus === 'deposit_paid'
              ? 'blue'
              : 'yellow'
          }">${escapeHtml(r.paymentStatus || 'unpaid')}</span></span></div>
          <div class="info-row"><span class="info-label">Submitted On</span><span class="info-value">${escapeHtml(
            submittedDate
          )}</span></div>
        </div>
        <div class="label mb-6">Requirements &amp; Scope</div>
        <p style="font-size:13px;color:var(--text2);line-height:1.6;background:var(--surface2);padding:10px 12px;border-radius:6px;border:1px solid var(--border)">${escapeHtml(
          description
        )}</p>
        ${statusDetail}
        ${proposalHistoryHtml}
        ${drawerActions}
      `
  );
}
/* __DRAWER_END__ */
function approveReq(id) {
  const r = DB.eventRequests.find(request => String(request.id) === String(id));
  if (r) {
    r.status = 'approved';
    r.organizer = CU.id;

    // Create new event from request
    const newEvent = {
      id: DB._nextId.events++,
      title: r.title,
      category: r.type,
      date: r.date,
      time: '10:00',
      endTime: '18:00',
      venue: r.venue || 'TBD',
      city: r.city || 'India',
      capacity: r.guests || 100,
      registered: 0,
      price: 0,
      status: 'ongoing',
      organizer: CU.id,
      clientId: r.clientId,
      description: r.desc,
      color: '#7c6ff7',
      emoji: r.type === 'Wedding' ? '💒' : r.type === 'Corporate' ? '🥂' : '📅',
      tags: [r.type],
    };
    DB.events.push(newEvent);
    saveDB();
    renderPage(_currentPage);
    toast('Event request accepted — event created!', 'success');
  }
}
function rejectReq(id) {
  confirm2('Decline Request', 'Mark this event request as declined?', () => {
    const r = DB.eventRequests.find(request => String(request.id) === String(id));
    if (r) {
      r.status = 'rejected';
      renderPage(_currentPage);
      toast('Request declined', 'info');
    }
  });
}

// ════════════════════════════════════════════════
//  UNIFIED REQUEST STATUS (CLIENT & ORGANIZER)
// ════════════════════════════════════════════════
async function syncClientEventRequests() {
  const response = await apiGetClientRequests();
  const requests = Array.isArray(response) ? response : response?.data || [];
  if (!Array.isArray(requests)) throw new Error('Invalid event requests response');
  DB.eventRequests = requests.map(request => ({
    ...request,
    id: request.requestId,
    clientId: CU.id,
    backendClientId: request.clientId,
    organizer: request.organizerId,
    title: request.eventName,
    type: request.eventType || 'Event',
    date: request.eventDate,
    time: request.eventTime,
    guests: request.capacity,
    desc: request.requirements || '',
    created: request.createdAt,
  }));
}
function pageRequestStatus() {
  const isOrganizer = CU.role === 'organizer';
  if (isOrganizer) {
    const tab = sessionStorage.getItem('reqstat_tab') || 'pending';
    const myOrgId = CU.id;
    const pendingReqs = DB.eventRequests
      .filter(request => request.status === 'pending' || request.status === 'in_review')
      .sort((leftRequest, rightRequest) => {
        const tA = Math.max(
          leftRequest.updatedAt ? new Date(leftRequest.updatedAt).getTime() : 0,
          leftRequest.createdAt ? new Date(leftRequest.createdAt).getTime() : 0,
          leftRequest.created ? new Date(leftRequest.created).getTime() : 0
        );
        const tB = Math.max(
          rightRequest.updatedAt ? new Date(rightRequest.updatedAt).getTime() : 0,
          rightRequest.createdAt ? new Date(rightRequest.createdAt).getTime() : 0,
          rightRequest.created ? new Date(rightRequest.created).getTime() : 0
        );
        if (tB !== tA) return tB - tA;
        return String(rightRequest.id || '').localeCompare(String(leftRequest.id || ''));
      });
    const myEvents = DB.events
      .filter(
        event =>
          event.organizer === myOrgId &&
          (event.status === 'upcoming' ||
            event.status === 'ongoing' ||
            event.status === 'confirmed')
      )
      .sort((leftEvent, rightEvent) => {
        const tA = leftEvent.date ? new Date(leftEvent.date).getTime() : 0;
        const tB = rightEvent.date ? new Date(rightEvent.date).getTime() : 0;
        if (tB !== tA) return tB - tA;
        return String(rightEvent.id || '').localeCompare(String(leftEvent.id || ''));
      });
    const pendingHtml =
      pendingReqs.length === 0
        ? '<div class="empty"><div class="empty-icon">&#128203;</div><div class="empty-title">No pending requests</div><p class="empty-desc">New client event requests will appear here.</p></div>'
        : pendingReqs
            .map(request => {
              const cl = DB.users.find(user => String(user.id) === String(request.clientId)) ||
                DB.users.find(user => user.role === 'client') || {
                  name: 'Michael Torres',
                };
              return `<div style="background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:20px 24px;display:flex;justify-content:space-between;align-items:center;gap:16px;border-left:4px solid var(--yellow)">
          <div style="flex:1">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
              <div style="font-size:17px;font-weight:700;color:var(--text)">${request.title}</div>
              <span style="background:#FEF3C7;color:#92400E;font-size:11px;font-weight:600;padding:2px 8px;border-radius:6px">Pending</span>
            </div>
            <div style="display:flex;gap:24px;font-size:13px;color:var(--text2);flex-wrap:wrap">
              <span>👤 ${cl.name}</span>
              <span>📅 ${request.date}</span>
              <span>📍 ${request.venue || 'TBD'}${request.city ? ', ' + request.city : ''}</span>
              <span>👥 ${request.guests} expected attendees</span>
            </div>
          </div>
          <button class="btn btn-primary" onclick="viewRequestDetail('${
            request.id
          }')" style="white-space:nowrap;border-radius:8px;padding:10px 20px">Review Request</button>
        </div>`;
            })
            .join('');
    const ongoingHtml =
      myEvents.length === 0
        ? '<div class="empty"><div class="empty-icon">&#128197;</div><div class="empty-title">No ongoing events</div><p class="empty-desc">Confirmed events will appear here once requests are approved.</p></div>'
        : `<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:20px">${myEvents
            .map(event => {
              const attendees = DB.registrations.filter(
                registration => registration.eventId === event.id
              ).length;
              const isPrivate = event.access === 'private' || event.access === 'Private';
              return `<div style="background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:20px;display:flex;flex-direction:column;gap:12px">
            <div style="display:flex;gap:8px;flex-wrap:wrap">
              <span style="background:rgba(34,197,94,0.15);color:var(--green);font-size:11px;font-weight:600;padding:3px 10px;border-radius:6px">Confirmed</span>
              ${
                isPrivate
                  ? '<span style="background:var(--surface2);color:var(--text2);font-size:11px;font-weight:600;padding:3px 10px;border-radius:6px">Private</span>'
                  : ''
              }
            </div>
            <div>
              <div style="font-size:16px;font-weight:700;color:var(--text);margin-bottom:3px">${
                event.title
              }</div>
              <div style="font-size:12px;color:var(--text3)">${
                event.type || event.category || 'Event'
              }</div>
            </div>
            <div style="display:flex;flex-direction:column;gap:6px;font-size:13px;color:var(--text2)">
              <span>&#128197; ${event.date}</span>
              <span>&#128205; ${event.venue || event.location || 'TBD'}</span>
              <span>&#128101; ${attendees || event.capacity || 0} attendees</span>
            </div>
            <button class="btn btn-ghost" onclick="viewOngoingEventDetail('${
              event.id
            }')" style="width:100%;justify-content:center;border-radius:8px;font-size:13px">&#128065; View Details</button>
          </div>`;
            })
            .join('')}</div>`;
    return `<div style="padding:28px;background:var(--bg)">
      <div style="margin-bottom:28px">
        <div style="font-size:22px;font-weight:700;color:var(--text);margin-bottom:4px">${
          tab === 'pending' ? 'Pending Requests' : 'Ongoing Events'
        }</div>
        <div style="font-size:14px;color:var(--text2)">${
          tab === 'pending'
            ? 'Review and accept or decline incoming event requests.'
            : 'Manage and track your confirmed and active events.'
        }</div>
      </div>
      <div style="display:flex;gap:0;margin-bottom:28px;background:var(--surface2);border-radius:10px;padding:4px;width:fit-content">
        <button onclick="switchReqStatTab('pending')" style="padding:8px 20px;border-radius:8px;border:none;font-size:13px;font-weight:600;cursor:pointer;background:${
          tab === 'pending' ? 'var(--accent)' : 'transparent'
        };color:${
      tab === 'pending' ? '#fff' : 'var(--text2)'
    }">Pending Requests <span style="background:${
      tab === 'pending' ? 'rgba(255,255,255,0.25)' : 'var(--border2)'
    };color:${
      tab === 'pending' ? '#fff' : 'var(--text2)'
    };padding:1px 7px;border-radius:10px;font-size:11px;margin-left:4px">${
      pendingReqs.length
    }</span></button>
        <button onclick="switchReqStatTab('ongoing')" style="padding:8px 20px;border-radius:8px;border:none;font-size:13px;font-weight:600;cursor:pointer;background:${
          tab === 'ongoing' ? 'var(--accent)' : 'transparent'
        };color:${
      tab === 'ongoing' ? '#fff' : 'var(--text2)'
    }">Ongoing Events <span style="background:${
      tab === 'ongoing' ? 'rgba(255,255,255,0.25)' : 'var(--border2)'
    };color:${
      tab === 'ongoing' ? '#fff' : 'var(--text2)'
    };padding:1px 7px;border-radius:10px;font-size:11px;margin-left:4px">${
      myEvents.length
    }</span></button>
      </div>
      <div style="display:flex;flex-direction:column;gap:16px">
        ${tab === 'pending' ? pendingHtml : ongoingHtml}
      </div>
    </div>`;
  } else {
    // CLIENT VIEW -- Status-filter dropdown
    // ─ Label map (readable labels for all backend status values) ─────
    const CLIENT_STATUS_LABELS = {
      all: 'All',
      submitted: 'Submitted / Pending',
      pending: 'Submitted / Pending',
      under_review: 'Under Review',
      in_review: 'Under Review',
      info_requested: 'Under Review',
      proposal_sent: 'Awaiting Client Response',
      awaiting_client: 'Awaiting Client Response',
      changes_requested: 'Changes Requested / Counteroffer',
      counteroffer_received: 'Changes Requested / Counteroffer',
      confirmed: 'Confirmed',
      approved: 'Confirmed',
      withdrawn: 'Withdrawn',
      cancelled: 'Cancelled',
      rejected: 'Rejected',
      expired: 'Expired',
    };
    const CLIENT_STATUS_GROUPS = [
      {
        value: 'all',
        label: 'All Requests',
      },
      {
        value: 'submitted',
        label: 'Submitted / Pending',
      },
      {
        value: 'under_review',
        label: 'Under Review',
      },
      {
        value: 'proposal_sent',
        label: 'Awaiting Client Response',
      },
      {
        value: 'changes_requested',
        label: 'Changes Requested / Counteroffer',
      },
      {
        value: 'confirmed',
        label: 'Confirmed',
      },
      {
        value: 'withdrawn',
        label: 'Withdrawn',
      },
      {
        value: 'cancelled',
        label: 'Cancelled',
      },
      {
        value: 'rejected',
        label: 'Rejected',
      },
      {
        value: 'expired',
        label: 'Expired',
      },
    ];
    function clientStatusGroup(status) {
      const s = (status || '').toLowerCase();
      if (['submitted', 'pending'].includes(s)) return 'submitted';
      if (['under_review', 'in_review', 'info_requested'].includes(s)) return 'under_review';
      if (['proposal_sent', 'awaiting_client'].includes(s)) return 'proposal_sent';
      if (['changes_requested', 'counteroffer_received'].includes(s)) return 'changes_requested';
      if (['confirmed', 'approved'].includes(s)) return 'confirmed';
      return s || 'submitted';
    }
    function clientStatusReadable(status) {
      return (
        CLIENT_STATUS_LABELS[status] ||
        (status || 'Unknown').replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())
      );
    }
    function clientRequestActions(r) {
      const id = r.id;
      const s = (r.status || '').toLowerCase();
      const closed = ['cancelled', 'withdrawn', 'rejected', 'expired', 'completed'].includes(s);
      const parts = [
        s === 'cancelled'
          ? `<button class="btn btn-primary btn-sm" onclick="viewWorkflowRequestDrawer('${id}')">View Cancellation Details</button>`
          : `<button class="btn btn-ghost btn-sm" onclick="viewRequestDrawer('${id}')">View Details</button>`,
      ];
      if (['submitted', 'pending', 'under_review', 'in_review', 'info_requested'].includes(s))
        parts.push(
          `<button class="btn btn-danger btn-sm" onclick="openClientCancelRequestModal('${id}')">Withdraw Request</button>`
        );
      if (s === 'proposal_sent')
        parts.push(
          `<button class="btn btn-primary btn-sm" onclick="openClientPlanReview('${id}')">Review Plan</button>`
        );
      if (s === 'plan_submitted')
        parts.push(
          `<button class="btn btn-primary btn-sm" onclick="viewWorkflowRequestDrawer('${id}')">View Plan</button>`
        );
      if (
        !closed &&
        (s === 'awaiting_client' ||
          (r.paymentStatus === 'deposit_pending' &&
            (r.proposals || []).some(proposal => proposal.status === 'accepted')))
      )
        parts.push(
          `<button class="btn btn-success btn-sm" onclick="openClientPaymentModal('${id}')">Proceed to Payment &amp; Confirmation</button>`
        );
      if (['changes_requested', 'counteroffer_received'].includes(s))
        parts.push(
          `<button class="btn btn-primary btn-sm" onclick="openClientPlanReview('${id}')">View &amp; Respond</button>`
        );
      if (['confirmed', 'approved'].includes(s))
        parts.push(
          `<button class="btn btn-danger btn-sm" onclick="openClientCancelRequestModal('${id}')">Cancel Event</button>`
        );
      return parts.join(' ');
    }
    function clientRequestHistory(r) {
      const s = (r.status || '').toLowerCase();
      if (s === 'rejected' && r.rejectionReason)
        return `<div style="margin-top:8px;padding:8px 12px;background:var(--red-dim);border-radius:6px;font-size:12.5px"><strong style="color:var(--red)">Declined:</strong> ${escapeHtml(
          r.rejectionReason
        )}${
          r.rejectionComments
            ? `<div class="small mt-4" style="color:var(--text2)">${escapeHtml(
                r.rejectionComments
              )}</div>`
            : ''
        }</div>`;
      if (s === 'withdrawn' && (r.withdrawalReason || r.withdrawReason))
        return `<div style="margin-top:8px;padding:8px 12px;background:var(--surface2);border-radius:6px;font-size:12.5px"><strong>Withdrawn:</strong> ${escapeHtml(
          r.withdrawalReason || r.withdrawReason
        )}</div>`;
      if (s === 'cancelled') return renderWorkflowCancellation(r.cancellation, r, true);
      if (s === 'expired')
        return `<div style="margin-top:8px;padding:8px 12px;background:var(--red-dim);border-radius:6px;font-size:12.5px"><strong style="color:var(--red)">Proposal Expired:</strong> The organizer's proposal was not accepted in time.</div>`;
      if (['changes_requested', 'counteroffer_received'].includes(s) && r.clientFeedback)
        return `<div style="margin-top:8px;padding:8px 12px;background:var(--yellow-dim);border-radius:6px;font-size:12.5px"><strong>Your feedback:</strong> ${escapeHtml(
          r.clientFeedback
        )}</div>`;
      if (['confirmed', 'approved'].includes(s) && r.cancellationPolicy) {
        const pol = r.cancellationPolicy;
        return `<div style="margin-top:8px;padding:8px 12px;background:var(--green-dim);border-radius:6px;font-size:12.5px"><strong style="color:var(--green)">\u2713 Booking Confirmed</strong>${
          r.depositAmount
            ? ` \u00b7 Deposit paid \u20b9${Number(r.depositAmount).toLocaleString()}`
            : ''
        }${
          pol.deadlineText
            ? `<div class="small mt-4" style="color:var(--text2)">Cancellation deadline: ${escapeHtml(
                pol.deadlineText
              )}</div>`
            : ''
        }</div>`;
      }
      if (['proposal_sent', 'awaiting_client'].includes(s) && r.proposals && r.proposals.length) {
        const p = r.proposals[r.proposals.length - 1];
        return `<div style="margin-top:8px;padding:8px 12px;background:var(--accent-dim);border-radius:6px;font-size:12.5px"><strong style="color:var(--accent)">\ud83d\udcc4 Proposal v${
          p.version || 1
        }:</strong> \u20b9${Number(p.amount || 0).toLocaleString()} total${
          p.validUntil ? ` &middot; Valid until ${escapeHtml(p.validUntil)}` : ''
        }</div>`;
      }
      return '';
    }
    function getReqTimestamp(item) {
      const times = [
        item.updatedAt ? new Date(item.updatedAt).getTime() : 0,
        item.createdAt ? new Date(item.createdAt).getTime() : 0,
        item.created ? new Date(item.created).getTime() : 0,
        item.sentAt ? new Date(item.sentAt).getTime() : 0,
      ];
      if (Array.isArray(item.proposals) && item.proposals.length > 0) {
        item.proposals.forEach(proposal => {
          if (proposal.sentAt) times.push(new Date(proposal.sentAt).getTime());
          if (proposal.createdAt) times.push(new Date(proposal.createdAt).getTime());
          if (proposal.uploadedAt) times.push(new Date(proposal.uploadedAt).getTime());
        });
      }
      return Math.max(...times.filter(t => !isNaN(t) && t > 0), 0);
    }
    const allReqs = DB.eventRequests
      .filter(request => String(request.clientId) === String(CU.id))
      .sort((leftRequest, rightRequest) => {
        const diff = getReqTimestamp(rightRequest) - getReqTimestamp(leftRequest);
        if (diff !== 0) return diff;
        return String(rightRequest.id || rightRequest.requestId || '').localeCompare(
          String(leftRequest.id || leftRequest.requestId || '')
        );
      });
    const filterStatus = sessionStorage.getItem('client_req_filter') || 'all';
    const reqs =
      filterStatus === 'all'
        ? allReqs
        : allReqs.filter(request => clientStatusGroup(request.status) === filterStatus);
    const groupCounts = {};
    allReqs.forEach(request => {
      const eventRequest = clientStatusGroup(request.status);
      groupCounts[eventRequest] = (groupCounts[eventRequest] || 0) + 1;
    });
    const dropdownOptions = CLIENT_STATUS_GROUPS.map(sg => {
      const cnt = sg.value === 'all' ? allReqs.length : groupCounts[sg.value] || 0;
      return `<option value="${sg.value}" ${filterStatus === sg.value ? 'selected' : ''}>${
        sg.label
      } (${cnt})</option>`;
    }).join('');
    return `
    <div class="page-hd">
      <div class="page-hd-left"><div class="page-title">Request Status</div><div class="page-sub">${
        allReqs.length
      } event request${allReqs.length !== 1 ? 's' : ''} total</div></div>
      <div class="page-hd-right" style="display:flex;gap:10px;align-items:center">
        <select id="client-req-status-filter" class="form-control" style="width:270px;font-size:13px" onchange="sessionStorage.setItem('client_req_filter',this.value);renderPage('request-status')" aria-label="Filter requests by status">${dropdownOptions}</select>
        <button class="btn btn-primary" onclick="goNav('find-organizers')">+ New Request</button>
      </div>
    </div>
    ${
      reqs.length === 0
        ? `<div class="empty"><div class="empty-icon">&#128203;</div><div class="empty-title">No requests${
            filterStatus !== 'all' ? ' with this status' : ' yet'
          }</div><p class="empty-desc">${
            filterStatus === 'all'
              ? 'Browse organizers and send them an event request to get started.'
              : 'Try a different status filter or create a new request.'
          }</p>${
            filterStatus === 'all'
              ? '<button class="btn btn-primary mt-16" onclick="goNav(\'find-organizers\')">Find Organizers</button>'
              : "<button class=\"btn btn-ghost mt-16\" onclick=\"sessionStorage.setItem('client_req_filter','all');renderPage('request-status')\">Show All Requests</button>"
          }</div>`
        : `<div style="display:flex;flex-direction:column;gap:14px">${reqs
            .map(
              request => `<div class="card">
      <div class="flex justify-between items-start">
        <div style="flex:1">
          <div style="font-size:16px;font-weight:700;margin-bottom:5px">${escapeHtml(
            request.title
          )}</div>
          <div class="small mb-8">${escapeHtml(request.type || 'Event')} &middot; ${
                request.guests
              } guests &middot; ${request.date}</div>
          <p style="font-size:13px;color:var(--text2);line-height:1.6;margin-bottom:12px">${escapeHtml(
            request.desc || ''
          )}</p>
          <span class="badge badge-${reqBadge(request.status)}">${clientStatusReadable(
                request.status
              )}</span>
          ${clientRequestHistory(request)}
        </div>
        <div style="text-align:right;flex-shrink:0;margin-left:20px">
          <div style="font-size:22px;font-weight:800;color:var(--green)">&#8377;${(
            request.budget || 0
          ).toLocaleString()}</div>
          <div class="small">Budget</div>
        </div>
      </div>
      <div class="flex gap-8 mt-14">${clientRequestActions(request)}</div>
    </div>`
            )
            .join('')}</div>`
    }`;
  }
}
function openClientPlanReview(id) {
  const request = DB.eventRequests.find(
    item => String(item.id) === String(id) || String(item.requestId) === String(id)
  );
  if (!request) {
    toast('Event request could not be found.', 'error');
    return;
  }

  // Check ownership
  if (
    CU &&
    CU.role === 'client' &&
    request.clientId &&
    String(request.clientId) !== String(CU.id) &&
    String(request.backendClientId) !== String(CU.id)
  ) {
    toast('You are not authorized to view this proposal.', 'error');
    return;
  }
  const s = (request.status || '').toLowerCase();

  // If organizer requested changes or sent counteroffer, show changes review modal
  if (['changes_requested', 'counteroffer_received'].includes(s)) {
    const latestChange =
      [...(request.negotiations || [])].reverse().find(n => n.action === 'changes_requested') || {};
    openModal(
      'Review Organizer Proposed Changes',
      `
          <div style="font-size:13px;color:var(--text2);margin-bottom:14px">
            The organizer has proposed changes to <strong>${escapeHtml(
              request.title || request.eventName || 'Event Request'
            )}</strong>.
          </div>
          <div style="background:var(--surface2);border-radius:10px;padding:14px;margin-bottom:14px;border:1px solid var(--border)">
            <div style="font-size:11px;font-weight:700;color:var(--accent);text-transform:uppercase;margin-bottom:8px">Proposed Changes</div>
            ${
              latestChange.eventDate
                ? `<div class="mb-8"><strong>Proposed Date:</strong> ${escapeHtml(
                    latestChange.eventDate
                  )}</div>`
                : ''
            }
            ${
              latestChange.budget
                ? `<div class="mb-8"><strong>Proposed Budget:</strong> ₹${Number(
                    latestChange.budget
                  ).toLocaleString()}</div>`
                : ''
            }
            <div><strong>Organizer Notes:</strong><br>${escapeHtml(
              latestChange.reason ||
                request.organizerFeedback ||
                'Please review the requested changes.'
            )}</div>
          </div>
        `,
      [
        {
          lbl: 'Withdraw Request',
          cls: 'btn-ghost',
          fn: `closeModal();openClientCancelRequestModal('${request.id}')`,
        },
        {
          lbl: 'Reject Changes',
          cls: 'btn-danger',
          fn: `closeModal();submitClientPlanDecision('${request.id}', 'reject_changes')`,
        },
        {
          lbl: 'Send Counteroffer',
          cls: 'btn-ghost',
          fn: `closeModal();openWorkflowCounterofferModal('${request.id}')`,
        },
        {
          lbl: 'Accept Changes',
          cls: 'btn-success',
          fn: `submitClientPlanDecision('${request.id}', 'accept_changes')`,
        },
      ]
    );
    return;
  }
  const proposals = Array.isArray(request.proposals) ? request.proposals : [];
  let proposal = proposals.length > 0 ? proposals[proposals.length - 1] : null;
  if (!proposal) {
    if (request.budget || request.desc) {
      proposal = {
        version: request.currentProposalVersion || 1,
        amount: request.budget || 25000,
        depositRequired: Math.round((request.budget || 25000) * 0.3),
        status: 'pending_client',
        terms: request.desc || 'Standard event terms apply.',
        cancellationTerms:
          '14+ days notice: 10% cancellation fee, 90% net refund. Less than 14 days: Non-refundable.',
        paymentSchedule: '30% Advance Deposit on Approval, 70% Final Balance upon Completion',
      };
    } else {
      toast('No proposal record found for this request.', 'warning');
      return;
    }
  }
  if (!proposal.eventPlan && proposal.terms) {
    proposal.eventPlan = proposal.terms;
  }
  const totalAmount = Number(proposal.amount || request.budget || 0);
  const depositRequired =
    proposal.depositRequired !== undefined
      ? Number(proposal.depositRequired)
      : Math.round(totalAmount * 0.3);
  const balance = Math.max(0, totalAmount - depositRequired);
  const fee = Number(proposal.organizerFee || Math.round(totalAmount * 0.2));
  const taxes = Number(proposal.taxes || Math.round(totalAmount * 0.18));
  const proposalPolicy = proposal.cancellationPolicy ||
    request.policySnapshot || {
      version: '2026-10-17.1',
      cancellation: {
        minimumNoticeDays: 14,
        feePercent: 10,
        refundEligible: true,
        approvalMode: 'manual',
        additionalTerms: 'Default EventFlow cancellation terms apply.',
        isDefault: true,
      },
    };
  const cancellation = proposalPolicy.cancellation || {};
  const eventDate = proposal.proposedDate || request.eventDate || request.date;
  const deadlineDate = eventDate ? new Date(`${eventDate}T00:00:00`) : null;
  if (deadlineDate && !Number.isNaN(deadlineDate.getTime()))
    deadlineDate.setDate(deadlineDate.getDate() - Number(cancellation.minimumNoticeDays || 0));
  const estimatedRefund =
    cancellation.refundEligible === false
      ? 0
      : Math.max(0, depositRequired * (1 - Number(cancellation.feePercent || 0) / 100));

  // Proposal state evaluation
  const isExpired =
    proposal.status === 'expired' ||
    s === 'expired' ||
    (proposal.validUntil &&
      new Date(proposal.validUntil + 'T23:59:59') < new Date() &&
      proposal.status === 'pending_client');
  const isWithdrawn = s === 'withdrawn' || proposal.status === 'withdrawn';
  const isRejected = s === 'rejected' || proposal.status === 'rejected';
  const isRevisionRequested = proposal.status === 'revision_requested' || s === 'under_review';
  const isAccepted = proposal.status === 'accepted' || s === 'awaiting_client' || s === 'confirmed';
  const isActive =
    !isExpired &&
    !isWithdrawn &&
    !isRejected &&
    !isRevisionRequested &&
    !isAccepted &&
    (proposal.status === 'pending_client' || s === 'proposal_sent');
  let bannerHtml = '';
  if (isExpired) {
    bannerHtml = `<div class="alert alert-warning mb-12" style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);color:var(--red);border-radius:8px;padding:10px 14px;font-size:12.5px;line-height:1.5"><strong>⏰ Proposal Expired:</strong> This proposal expired on ${escapeHtml(
      proposal.validUntil || 'the validity date'
    )}. It can no longer be accepted. You may request a revised proposal or withdraw the request.</div>`;
  } else if (isWithdrawn) {
    bannerHtml = `<div class="alert alert-info mb-12" style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:10px 14px;font-size:12.5px"><strong>ℹ️ Request Withdrawn:</strong> This request was withdrawn. ${escapeHtml(
      request.withdrawalReason || ''
    )}</div>`;
  } else if (isRejected) {
    bannerHtml = `<div class="alert alert-danger mb-12" style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);color:var(--red);border-radius:8px;padding:10px 14px;font-size:12.5px"><strong>✕ Proposal Declined:</strong> This proposal was declined. ${escapeHtml(
      request.rejectionReason || proposal.clientNotes || ''
    )}</div>`;
  } else if (isRevisionRequested) {
    bannerHtml = `<div class="alert alert-warning mb-12" style="background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.3);color:var(--yellow);border-radius:8px;padding:10px 14px;font-size:12.5px"><strong>📝 Revision Requested:</strong> Awaiting revised proposal from organizer. Your feedback: <em>${escapeHtml(
      proposal.clientNotes || request.clientFeedback || 'Modifications requested.'
    )}</em></div>`;
  } else if (isAccepted) {
    bannerHtml = `<div class="alert alert-success mb-12" style="background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.3);color:var(--green);border-radius:8px;padding:10px 14px;font-size:12.5px"><strong>✓ Proposal Accepted:</strong> You accepted proposal v${
      proposal.version || 1
    }. Proceed with agreement terms and deposit payment to confirm your booking.</div>`;
  }
  const modalButtons = [];
  if (isActive) {
    modalButtons.push({
      lbl: 'Withdraw Request',
      cls: 'btn-ghost',
      fn: `closeModal();openClientCancelRequestModal('${request.id}')`,
    });
    modalButtons.push({
      lbl: 'Decline',
      cls: 'btn-danger',
      fn: `openClientDeclineModal('${request.id}')`,
    });
    modalButtons.push({
      lbl: 'Request Revision',
      cls: 'btn-ghost',
      fn: `openReproposalReasonModal('${request.id}')`,
    });
    modalButtons.push({
      lbl: 'Accept & Proceed to Payment',
      cls: 'btn-success',
      fn: `acceptAndProceedToPayment('${request.id}')`,
    });
  } else if (isExpired) {
    modalButtons.push({
      lbl: 'Withdraw Request',
      cls: 'btn-ghost',
      fn: `closeModal();openClientCancelRequestModal('${request.id}')`,
    });
    modalButtons.push({
      lbl: 'Request Revision',
      cls: 'btn-primary',
      fn: `openReproposalReasonModal('${request.id}')`,
    });
    modalButtons.push({
      lbl: 'Close',
      cls: 'btn-ghost',
      fn: 'closeModal()',
    });
  } else if (isAccepted && s !== 'confirmed') {
    modalButtons.push({
      lbl: 'Close',
      cls: 'btn-ghost',
      fn: 'closeModal()',
    });
    modalButtons.push({
      lbl: 'Proceed to Payment & Confirmation',
      cls: 'btn-success',
      fn: `closeModal();openClientPaymentModal('${request.id}')`,
    });
  } else {
    modalButtons.push({
      lbl: 'Close',
      cls: 'btn-ghost',
      fn: 'closeModal()',
    });
  }
  openModal(
    `Review Proposed Plan (v${proposal.version || 1})`,
    `
        <div style="max-height:65vh;overflow-y:auto;padding-right:6px">
          ${bannerHtml}

          <!-- PRICE, DEPOSIT & BALANCE BREAKDOWN -->
          <div style="background:var(--surface2);border-radius:10px;padding:14px;margin-bottom:14px;border:1px solid var(--border)">
            <div style="font-size:11px;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:8px">Cost & Payment Breakdown</div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:13px;margin-bottom:10px">
              <div><div class="small">TOTAL PROPOSAL PRICE</div><strong style="color:var(--green);font-size:16px">&#8377;${totalAmount.toLocaleString()}</strong></div>
              <div><div class="small">REQUIRED ADVANCE DEPOSIT</div><strong style="color:var(--accent);font-size:16px">&#8377;${depositRequired.toLocaleString()}</strong></div>
              <div><div class="small">ORGANIZER FEE</div><strong>&#8377;${fee.toLocaleString()}</strong></div>
              <div><div class="small">TAXES & GST</div><strong>&#8377;${taxes.toLocaleString()}</strong></div>
            </div>
            <div style="font-size:12.5px;color:var(--text2);margin-bottom:8px"><strong>OUTSTANDING BALANCE:</strong> <strong style="color:var(--yellow);font-size:15px">&#8377;${balance.toLocaleString()}</strong></div>
            ${
              proposal.itemizedCosts
                ? `<div style="font-size:12px;color:var(--text2);padding-top:8px;border-top:1px solid var(--border2)"><strong>Itemized Costs:</strong> ${escapeHtml(
                    proposal.itemizedCosts
                  )}</div>`
                : ''
            }
          </div>

          <!-- DELIVERABLES & SERVICES -->
          <div style="background:var(--surface2);border-radius:10px;padding:14px;margin-bottom:14px;border:1px solid var(--border);font-size:13px;line-height:1.6">
            <div style="font-size:11px;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:8px">Event Scope & Timeline</div>
            <div style="margin-bottom:8px"><strong>Event Plan:</strong><br>${escapeHtml(
              proposal.eventPlan ||
                proposal.deliverables ||
                proposal.terms ||
                'Standard deliverables apply.'
            )}</div>
            <div style="margin-bottom:8px"><strong>Execution Timeline:</strong><br>${escapeHtml(
              proposal.timeline ||
                '09:00 Setup; 11:00 Registration; 13:00 Main event; 17:00 Wrap-up'
            )}</div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:8px;font-size:12px">
              <div style="background:var(--surface);padding:8px 10px;border-radius:6px"><strong>Included Services:</strong><br>${escapeHtml(
                proposal.includedServices ||
                  proposal.services ||
                  'Venue coordination, event operations, schedules'
              )}</div>
              <div style="background:var(--surface);padding:8px 10px;border-radius:6px"><strong>Excluded Services:</strong><br>${escapeHtml(
                proposal.excludedServices || 'None specified'
              )}</div>
            </div>
          </div>

          <!-- CAPACITY & CONSTRAINTS -->
          <div style="background:var(--surface2);border-radius:10px;padding:14px;margin-bottom:14px;border:1px solid var(--border);font-size:12.5px">
            <div style="font-size:11px;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:8px">Capacity & Venue Constraints</div>
            <div><strong>Attendee Limit:</strong> ${
              proposal.attendeeCapacity || request.capacity || request.guests || 'Standard capacity'
            } guests</div>
            ${
              proposal.constraints
                ? `<div style="margin-top:4px"><strong>Constraints:</strong> ${escapeHtml(
                    proposal.constraints
                  )}</div>`
                : ''
            }
          </div>

          <!-- PAYMENT TERMS & CANCELLATION POLICY -->
          <div style="background:var(--surface2);border-radius:10px;padding:14px;margin-bottom:14px;border:1px solid var(--border);font-size:12.5px">
            <div style="font-size:11px;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:8px">Payment Schedule & Cancellation Terms</div>
            <div style="margin-bottom:6px"><strong>Payment Schedule:</strong> ${escapeHtml(
              proposal.paymentSchedule ||
                proposal.paymentTerms ||
                '30% Advance Deposit on Approval, 70% Final Balance upon Completion'
            )}</div>
            <div style="margin-bottom:6px"><strong>Cancellation Terms:</strong> ${escapeHtml(
              proposal.cancellationTerms ||
                proposal.cancellationPolicy?.cancellation?.additionalTerms ||
                '14+ days notice: 10% fee, 90% net refund. Less than 14 days: Non-refundable.'
            )}</div>
            <div style="margin-bottom:6px"><strong>Cancellation deadline:</strong> ${
              deadlineDate && !Number.isNaN(deadlineDate.getTime())
                ? escapeHtml(deadlineDate.toLocaleDateString())
                : 'Calculated from the confirmed event date'
            } (${Number(cancellation.minimumNoticeDays || 0)} days' notice)</div>
            <div style="margin-bottom:6px"><strong>Fee:</strong> ${Number(
              cancellation.feePercent || 0
            )}% of successful payments · <strong>Estimated refund if only the deposit has been paid:</strong> ₹${estimatedRefund.toLocaleString()}</div>
            <div style="margin-bottom:6px"><strong>Refund:</strong> ${
              cancellation.refundEligible === false
                ? 'Not eligible under this proposal'
                : `${
                    cancellation.approvalMode === 'automatic'
                      ? 'Automatically evaluated'
                      : 'Organizer approval required'
                  }; demo refunds remain Pending`
            }</div>
            <div style="margin-bottom:6px"><strong>Additional terms:</strong> ${escapeHtml(
              cancellation.additionalTerms || proposal.cancellationTerms || 'No additional terms'
            )}</div>
            ${
              cancellation.isDefault
                ? '<div class="small" style="color:var(--yellow)">Organizer did not configure a custom policy; documented EventFlow defaults apply.</div>'
                : ''
            }
            <div><strong>Proposal Valid Until:</strong> ${escapeHtml(
              proposal.validUntil || '14 days from issue'
            )}</div>
          </div>
          ${
            isActive
              ? `<label style="display:flex;gap:8px;align-items:flex-start;margin-bottom:14px"><input id="client-proposal-policy-ack" type="checkbox"><span>I explicitly accept cancellation policy version ${escapeHtml(
                  proposalPolicy.version
                )}, including its deadline, fee, refund eligibility and additional terms.</span></label><div id="client-proposal-policy-error" style="color:var(--red);font-size:12px;margin:-8px 0 12px"></div>`
              : ''
          }

          <!-- ATTACHED EVENT PLAN DOCUMENT -->
          <div style="background:var(--surface2);border-radius:10px;padding:14px;margin-bottom:14px;border:1px solid var(--border);font-size:13px">
            <div style="font-size:11px;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:8px">Organizer Event Plan Document</div>
            ${
              proposal.documentFileName || proposal.documentName
                ? `
              <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;flex-wrap:wrap">
                <div>
                  <div style="font-weight:700;font-size:13.5px">📎 ${escapeHtml(
                    proposal.documentName || proposal.documentFileName
                  )}</div>
                  <div style="font-size:12px;color:var(--text2);margin-top:4px">
                    <span>${escapeHtml(proposal.documentType || 'application/pdf')}</span>
                    ${
                      proposal.documentSize
                        ? ' · ' + (Number(proposal.documentSize) / 1024).toFixed(1) + ' KB'
                        : ''
                    } &middot;
                    <span>Uploaded ${
                      proposal.uploadedAt
                        ? new Date(proposal.uploadedAt).toLocaleString()
                        : 'Recently'
                    }</span> &middot;
                    <span>Version ${proposal.version || 1}</span> &middot;
                    <span>By ${escapeHtml(proposal.uploaderName || 'Organizer')}</span>
                  </div>
                </div>
                <div style="display:flex;gap:8px;margin-top:6px">
                  <button class="btn btn-ghost btn-sm" onclick="openEventPlanPdf('${
                    request.requestId || request.id
                  }','${encodeURIComponent(
                    proposal.documentName || proposal.documentFileName
                  )}',true,${proposal.version})">👁️ Preview</button>
                  <button class="btn btn-primary btn-sm" onclick="openEventPlanPdf('${
                    request.requestId || request.id
                  }','${encodeURIComponent(
                    proposal.documentName || proposal.documentFileName
                  )}',false,${proposal.version})">⬇️ Download</button>
                </div>
              </div>
            `
                : `
              <div style="font-size:12.5px;color:var(--text2)">
                📝 <strong>Text-only plan proposal</strong> — no file attached by organizer. Proposal deliverables and terms are detailed below.
              </div>
            `
            }
          </div>

          ${
            proposals.length > 1
              ? `
            <details style="font-size:12px;color:var(--text3);margin-bottom:12px">
              <summary style="cursor:pointer;font-weight:600">Proposal Version History (${
                proposals.length - 1
              } prior versions, newest first)</summary>
              <div style="display:flex;flex-direction:column;gap:6px;margin-top:6px">
                ${[...proposals.slice(0, -1)]
                  .sort((a, b) => (b.version || 0) - (a.version || 0))
                  .map(
                    p => `
                  <div style="background:var(--surface);padding:8px 10px;border-radius:6px;display:flex;justify-content:space-between;align-items:center;flex-wrap:gap:6px">
                    <div>
                      <span><strong>v${p.version}:</strong> ₹${Number(
                      p.amount || 0
                    ).toLocaleString()} (Deposit ₹${Number(
                      p.depositRequired || 0
                    ).toLocaleString()})</span>
                      <span class="badge badge-gray" style="margin-left:6px">${escapeHtml(
                        p.status || 'draft'
                      )}</span>
                      ${
                        p.uploadedAt || p.sentAt
                          ? `<div class="small" style="color:var(--text3)">${new Date(
                              p.uploadedAt || p.sentAt
                            ).toLocaleString()}</div>`
                          : ''
                      }
                    </div>
                    ${
                      p.documentFileName || p.documentName
                        ? `
                      <div style="display:flex;gap:4px">
                        <button class="btn btn-ghost btn-xs" onclick="openEventPlanPdf('${
                          request.requestId || request.id
                        }','${encodeURIComponent(p.documentName || p.documentFileName)}',true,${
                            p.version
                          })">Preview</button>
                        <button class="btn btn-ghost btn-xs" onclick="openEventPlanPdf('${
                          request.requestId || request.id
                        }','${encodeURIComponent(p.documentName || p.documentFileName)}',false,${
                            p.version
                          })">Download</button>
                      </div>
                    `
                        : ''
                    }
                  </div>
                `
                  )
                  .join('')}
              </div>
            </details>
          `
              : ''
          }
        </div>
      `,
    modalButtons
  );
}
function confirmWithdrawRequest(id) {
  confirm2(
    'Withdraw Request',
    'Are you sure you want to withdraw this event request before booking? This will cancel the workflow.',
    () => {
      submitClientPlanDecision(id, 'withdraw');
    }
  );
}
function openClientDeclineModal(id) {
  openModal(
    'Decline Event Proposal',
    `
        <div class="form-group mb-12">
          <label class="form-label" style="font-weight:700">Reason for Declining Proposal (Mandatory) *</label>
          <textarea id="client-decline-reason" class="form-control" rows="4" placeholder="Explain why the proposal is declined (e.g. Budget constraints, deliverables don't meet needs, scheduled date change)..."></textarea>
          <div id="client-decline-error" style="display:none;color:var(--red);font-size:12px;margin-top:6px"></div>
        </div>
      `,
    [
      {
        lbl: 'Back',
        cls: 'btn-ghost',
        fn: `openClientPlanReview('${id}')`,
      },
      {
        lbl: 'Decline Proposal',
        cls: 'btn-danger',
        fn: `submitClientDeclineProposal('${id}')`,
      },
    ]
  );
}
async function submitClientDeclineProposal(id) {
  const reason = (v('client-decline-reason') || '').trim();
  const errEl = g('client-decline-error');
  if (!reason) {
    if (errEl) {
      errEl.textContent = 'Please provide a reason for declining.';
      errEl.style.display = 'block';
    }
    return;
  }
  try {
    await apiRespondToEventProposal(id, 'reject', reason);
    closeModal();
    await syncClientEventRequests();
    renderPage('request-status');
    toast('Proposal declined with feedback.', 'success');
  } catch (err) {
    if (errEl) {
      errEl.textContent = err.message;
      errEl.style.display = 'block';
    } else toast(err.message, 'error');
  }
}
async function acceptAndProceedToPayment(id) {
  try {
    const request = DB.eventRequests.find(item => String(item.id || item.requestId) === String(id));
    const proposal = request?.proposals?.[request.proposals.length - 1];
    const policy = proposal?.cancellationPolicy || request?.policySnapshot;
    if (!g('client-proposal-policy-ack')?.checked) {
      const error = g('client-proposal-policy-error');
      if (error) error.textContent = 'Accept the displayed cancellation policy before proceeding.';
      return;
    }
    await apiRespondToEventProposal(id, 'accept', 'Accepted proposal and proceeding to payment.', {
      policyAccepted: true,
      acceptedPolicyVersion: policy?.version,
    });
    await syncClientEventRequests();
    closeModal();
    toast('Proposal accepted! Opening payment confirmation...', 'success');
    openClientPaymentModal(id);
  } catch (err) {
    toast(err.message || 'Unable to accept proposal', 'error');
  }
}
function openReproposalReasonModal(id) {
  openModal(
    'Request Proposal Revision',
    `
        <div class="form-group">
          <label class="form-label">Requested Changes & Counter-terms <span style="color:var(--red)">*</span></label>
          <textarea id="client-reproposal-reason" class="form-control" rows="4" placeholder="Detail the modifications required (e.g. Reduce total price by 10%, change date to next Friday, include lighting package)..."></textarea>
          <div id="client-reproposal-error" style="display:none;color:var(--red);font-size:12px;margin-top:6px"></div>
        </div>
      `,
    [
      {
        lbl: 'Back',
        cls: 'btn-ghost',
        fn: `openClientPlanReview('${id}')`,
      },
      {
        lbl: 'Submit Revision Request',
        cls: 'btn-primary',
        fn: `submitClientPlanDecision('${id}', 'request_revision')`,
      },
    ]
  );
}
async function submitClientPlanDecision(id, decision) {
  const reason =
    decision === 'request_revision' ? (v('client-reproposal-reason') || '').trim() : '';
  const errorEl = g('client-reproposal-error');
  if (decision === 'request_revision' && !reason) {
    if (errorEl) {
      errorEl.textContent = 'Please provide a reason for the requested changes.';
      errorEl.style.display = 'block';
    }
    return;
  }
  try {
    await apiRespondToEventProposal(id, decision, reason);
    closeModal();
    await syncClientEventRequests();
    if (decision === 'accept_changes') setWorkflowEventTab('ongoing');
    else renderPage('request-status');
    const message =
      decision === 'accept_changes'
        ? 'Changes accepted. Event planning is now in Ongoing Events.'
        : decision === 'reject_changes'
        ? 'Changes rejected.'
        : decision === 'accept'
        ? 'Plan approved.'
        : decision === 'withdraw'
        ? 'Request withdrawn.'
        : 'Your revision request was sent to the organizer.';
    toast(message, 'success');
  } catch (error) {
    const message = error?.message || 'Unable to save your plan decision.';
    if (errorEl) {
      errorEl.textContent = message;
      errorEl.style.display = 'block';
    } else toast(message, 'error');
  }
}
function switchReqStatTab(tab) {
  sessionStorage.setItem('reqstat_tab', tab);
  renderPage('request-status');
}
function viewRequestDetail(reqId) {
  const r = DB.eventRequests.find(request => String(request.id) === String(reqId));
  if (!r) return;
  const cl = DB.users.find(user => String(user.id) === String(r.clientId)) ||
    DB.users.find(user => user.role === 'client') || {
      name: 'Michael Torres',
      email: 'client@example.com',
      phone: '+91 9876543203',
    };
  const element = document.getElementById('page-content');
  if (!element) return;
  globalThis.window?.EventFlowClientPages?.clear(element);
  element.innerHTML = `<div style="padding:28px;background:var(--bg);min-height:100vh">
    <button onclick="renderPage('request-status')" style="display:inline-flex;align-items:center;gap:6px;border:none;background:none;color:var(--text2);font-size:13px;cursor:pointer;margin-bottom:24px;padding:0">&larr; Back to Pending Requests</button>
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:6px">
      <div style="font-size:22px;font-weight:700;color:var(--text)">${r.title}</div>
      <span style="background:#FEF9C3;color:#92400E;font-size:12px;font-weight:600;padding:3px 12px;border-radius:6px">Pending Review</span>
    </div>
    <div style="font-size:13px;color:var(--text2);margin-bottom:28px">Review the details below and accept or decline this request.</div>
    <div style="display:flex;flex-direction:column;gap:20px;max-width:720px">

      <div style="background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:24px">
        <div style="font-weight:700;font-size:15px;margin-bottom:18px">&#128100; Client Information</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
          <div>
            <div style="font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:5px">CLIENT NAME</div>
            <div style="font-size:14px;font-weight:600;color:var(--text)">${cl.name}</div>
          </div>
          <div>
            <div style="font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:5px">CONTACT</div>
            <div style="font-size:13px;color:var(--text2)">${cl.email || 'â€”'}</div>
            <div style="font-size:13px;color:var(--text2)">${cl.phone || ''}</div>
          </div>
        </div>
      </div>

      <div style="background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:24px">
        <div style="font-weight:700;font-size:15px;margin-bottom:18px">&#128197; Event Details</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
          <div>
            <div style="font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:5px">DATE</div>
            <div style="font-size:14px;font-weight:500;color:var(--text)">${r.date}</div>
          </div>
          <div>
            <div style="font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:5px">EVENT TYPE</div>
            <div style="font-size:14px;font-weight:500;color:var(--text)">${
              r.type || 'Corporate Event'
            }</div>
          </div>
          <div>
            <div style="font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:5px">VENUE</div>
            <div style="font-size:14px;font-weight:500;color:var(--text)">${
              r.venue || 'To be decided'
            }</div>
          </div>
          <div>
            <div style="font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:5px">EXPECTED ATTENDEES</div>
            <div style="font-size:14px;font-weight:500;color:var(--text)">${r.guests}</div>
          </div>
          <div>
            <div style="font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:5px">CITY</div>
            <div style="font-size:14px;font-weight:500;color:var(--text)">${r.city || 'â€”'}</div>
          </div>
          <div>
            <div style="font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:5px">BUDGET</div>
            <div style="font-size:14px;font-weight:600;color:var(--green)">&#8377;${
              r.budget ? r.budget.toLocaleString() : 'â€”'
            }</div>
          </div>
        </div>
      </div>

      <div style="background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:24px">
        <div style="font-weight:700;font-size:15px;margin-bottom:6px">&#128203; Event Requirements</div>
        <div style="font-size:13px;color:var(--text2);margin-bottom:14px">Services and setup requested by the client</div>
        <div style="background:var(--surface2);border-radius:10px;padding:16px;font-size:13px;color:var(--text);line-height:1.7">${
          r.desc || 'Standard event requirements. No special requests.'
        }</div>
      </div>

      <div style="display:flex;justify-content:flex-end;gap:12px;padding-top:8px">
        <button class="btn btn-danger" onclick="rejectReq('${
          r.id
        }');renderPage('request-status')" style="border-radius:8px;padding:10px 24px">&#x2715; Decline</button>
        <button class="btn btn-success" onclick="approveReq('${
          r.id
        }');renderPage('request-status')" style="border-radius:8px;padding:10px 24px;background:var(--green);border-color:var(--green)">&#x2713; Accept Event</button>
      </div>
    </div>
  </div>`;
}
function viewOngoingEventDetail(eventId) {
  if (window.EventFlowAccountPolicy.isSupportExecutiveAccount(CU))
    return openViewEventDrawer(eventId);
  const event = DB.events.find(currentEvent => String(currentEvent.id) === String(eventId));
  if (!event) return;
  const attendees = DB.registrations.filter(
    registration => String(registration.eventId) === String(eventId)
  );
  const element = document.getElementById('page-content');
  if (!element) return;
  globalThis.window?.EventFlowClientPages?.clear(element);
  element.innerHTML = `<div style="padding:28px;background:var(--bg)">
    <button onclick="renderPage('request-status')" style="display:flex;align-items:center;gap:6px;border:none;background:none;color:var(--text2);font-size:13px;cursor:pointer;margin-bottom:20px;padding:0">â† Back to Ongoing Events</button>
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:6px">
      <div style="font-size:22px;font-weight:700;color:var(--text)">${event.title}</div>
      <span style="background:rgba(34,197,94,0.15);color:var(--green);font-size:12px;font-weight:600;padding:3px 10px;border-radius:6px">Confirmed</span>
    </div>
    <div style="font-size:13px;color:var(--text2);margin-bottom:28px">${
      event.description || 'Active event under management.'
    }</div>
    <div style="display:grid;grid-template-columns:1fr 320px;gap:24px">
      <div style="display:flex;flex-direction:column;gap:20px">
        <div style="background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:24px">
          <div style="font-weight:700;font-size:15px;margin-bottom:18px">ðŸ“… Event Details</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
            <div><div style="font-size:10px;color:var(--text3);text-transform:uppercase;margin-bottom:5px">DATE</div><div style="font-size:14px;font-weight:500">${
              event.date
            }</div></div>
            <div><div style="font-size:10px;color:var(--text3);text-transform:uppercase;margin-bottom:5px">TYPE</div><div style="font-size:14px;font-weight:500">${
              event.type || event.category || 'Event'
            }</div></div>
            <div><div style="font-size:10px;color:var(--text3);text-transform:uppercase;margin-bottom:5px">VENUE</div><div style="font-size:14px;font-weight:500">${
              event.venue || 'TBD'
            }</div></div>
            <div><div style="font-size:10px;color:var(--text3);text-transform:uppercase;margin-bottom:5px">ATTENDEES</div><div style="font-size:14px;font-weight:500">${
              attendees.length
            }</div></div>
          </div>
        </div>

      </div>
      <div style="display:flex;flex-direction:column;gap:16px">
        <div style="background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:20px">
          <div style="font-weight:700;font-size:14px;margin-bottom:16px">Timeline &amp; Milestones</div>
          <div style="display:flex;flex-direction:column;gap:14px">
            ${[
              {
                label: 'Event Accepted',
                sub: 'Event approved',
                done: true,
              },
              {
                label: 'Approved by Client',
                sub: 'Event plan approved',
                done: true,
              },
              {
                label: 'Event Day',
                sub: event.date,
                done: false,
              },
            ]
              .map(
                m => `
            <div style="display:flex;gap:12px;align-items:flex-start">
              <div style="width:18px;height:18px;border-radius:50%;border:2px solid ${
                m.done ? 'var(--green)' : 'var(--border)'
              };background:${
                  m.done ? 'rgba(34,197,94,0.1)' : 'transparent'
                };display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:2px">
                ${
                  m.done
                    ? '<div style="width:8px;height:8px;border-radius:50%;background:var(--green)"></div>'
                    : ''
                }
              </div>
              <div>
                <div style="font-size:13px;font-weight:600;color:var(--text)">${m.label}</div>
                <div style="font-size:11px;color:var(--text3)">${m.sub}</div>
              </div>
            </div>`
              )
              .join('')}
          </div>
        </div>
      </div>
    </div>
  </div>`;
}
async function openNewRequestForm() {
  try {
    await Promise.all([syncOrganizerDirectory(), loadWorkflowEventPolicy()]);
  } catch (error) {
    toast(error.message || 'Unable to load organizers', 'error');
    return;
  }
  openDrawer(
    'New Event Request',
    `
    <div class="form-group"><label class="form-label">Organizer *</label><select class="form-control" id="nr-organizer">${DB.users
      .filter(user => user.role === 'organizer')
      .map(
        user =>
          `<option value="${workflowHtml(user.id)}">${workflowHtml(user.name)} · ${workflowHtml(
            user.service || 'Event Organizer'
          )}</option>`
      )
      .join('')}</select></div>
    <div class="form-group"><label class="form-label">Event Title *</label><input class="form-control" id="nr-title" placeholder="e.g. Annual Client Dinner"></div>
    <div class="grid-2"><div class="form-group"><label class="form-label">Event Type *</label><select class="form-control" id="nr-type"><option>Corporate</option><option>Conference</option><option>Wedding</option><option>Concert</option><option>Workshop</option><option>Other</option></select></div><div class="form-group"><label class="form-label">Preferred Date *</label><input class="form-control" id="nr-date" type="date"></div></div>
    <div class="grid-2"><div class="form-group"><label class="form-label">Expected Guests *</label><input class="form-control" id="nr-guests" type="number" placeholder="100"></div><div class="form-group"><label class="form-label">Budget (₹) *</label><input class="form-control" id="nr-budget" type="number" placeholder="10000"></div></div>
    <div class="form-group"><label class="form-label" for="nr-ticket-price">Ticket Price per Attendee (₹)</label><input class="form-control" id="nr-ticket-price" type="number" min="0" step="0.01" value="0"><p class="small muted">Set 0 for free admission.</p></div>
    <div class="form-group"><label class="form-label" for="nr-visibility">Event Access</label><select class="form-control" id="nr-visibility"><option value="public" selected>Public — direct registration</option><option value="private">Private — organizer approval required</option></select><p class="small muted">Public events allow direct payment and registration. Private events require approval before payment.</p></div>
    <div class="form-group"><label class="form-label">Preferred Venue (optional)</label><input class="form-control" id="nr-venue" placeholder="Grand Ballroom, Downtown"></div>
    <div class="form-group"><label class="form-label">Description & Requirements *</label><textarea class="form-control" id="nr-desc" style="min-height:100px" placeholder="Describe the event, theme, requirements…"></textarea></div>
    ${renderWorkflowEventPolicy(workflowEventPolicy, 'nr-policy')}
    <div class="flex gap-8 mt-20"><button class="btn btn-success w-full" onclick="submitRequest()">Submit Request</button><button class="btn btn-ghost w-full" onclick="closeDrawer()">Cancel</button></div>
  `
  );
}
let _clientCancelPreview = null;
let _clientCancelReason = '';
let _clientCancelExplanation = '';
let _clientCancelSubmitting = false;
async function openClientCancelRequestModal(requestId) {
  if (_clientCancelSubmitting) return;
  _clientCancelPreview = null;
  _clientCancelReason = '';
  _clientCancelExplanation = '';
  const request = DB.eventRequests.find(
    eventRequest =>
      String(eventRequest.id) === String(requestId) ||
      String(eventRequest.requestId) === String(requestId)
  );
  if (!request) {
    toast('Event request not found.', 'error');
    return;
  }

  // Check ownership
  if (
    CU &&
    CU.role === 'client' &&
    (typeof isClientOwner === 'function' ? !isClientOwner(request, CU) : false)
  ) {
    toast('You are not authorized to cancel this request.', 'error');
    return;
  }
  const s = (request.status || '').toLowerCase();
  if (['cancelled', 'withdrawn', 'rejected', 'expired', 'completed'].includes(s)) {
    toast(`This request has already been ${s}.`, 'warning');
    return;
  }
  const isConfirmed = s === 'confirmed' || s === 'approved';

  // ─────────────────────────────────────────────────────────────────
  // UNCONFIRMED REQUESTS: WITHDRAW REQUEST (NO FEES, NO REFUND WINDOW)
  // ─────────────────────────────────────────────────────────────────
  if (!isConfirmed) {
    const org = (DB.organizers || []).find(
      o => String(o.organizerId || o.id) === String(request.organizerId || request.organizer)
    ) ||
      (DB.users || []).find(
        user => String(user.id || user.userId) === String(request.organizerId || request.organizer)
      ) || {
        name: 'Assigned Organizer',
      };
    openModal(
      'Withdraw Event Request',
      `
          <div style="max-height:65vh;overflow-y:auto;padding-right:4px">
            <div style="margin-bottom:14px">
              <div style="font-size:16px;font-weight:700;color:var(--text);margin-bottom:4px">${escapeHtml(
                request.title || request.eventName || 'Event Request'
              )}</div>
              <div><span class="badge badge-${reqBadge(request.status)}">${
        typeof clientStatusReadable === 'function'
          ? clientStatusReadable(request.status)
          : String(request.status || '')
              .replace(/_/g, ' ')
              .toUpperCase()
      }</span></div>
            </div>

            <div style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:12px;margin-bottom:14px;font-size:12.5px;line-height:1.6">
              <div style="font-weight:700;color:var(--text);margin-bottom:4px">Request Details</div>
              <div><strong>Organizer:</strong> ${escapeHtml(org.name || 'Organizer')}</div>
              <div><strong>Preferred Date:</strong> ${escapeHtml(
                request.date || request.eventDate || '—'
              )}</div>
              <div><strong>Guests:</strong> ${
                request.guests || request.capacity || 0
              } attendees</div>
              <div><strong>Budget:</strong> ₹${Number(request.budget || 0).toLocaleString()}</div>
            </div>

            <div class="alert alert-info mb-14" style="background:rgba(59,130,246,0.08);border:1px solid rgba(59,130,246,0.25);border-radius:8px;padding:12px;color:var(--text);font-size:12.5px;line-height:1.5">
              <strong>ℹ️ Pre-Booking Withdrawal Notice:</strong> Withdrawal ends this event request and stops any further negotiation. No cancellation fees apply and no payments have been charged.
            </div>

            <div class="form-group mb-12">
              <label class="form-label" style="font-weight:600" for="client-withdraw-reason">Reason for Withdrawal <span style="color:var(--red)">*</span></label>
              <select class="form-control" id="client-withdraw-reason" required>
                <option value="">Select a reason (Required)...</option>
                <option value="Changed Plans">Changed Plans</option>
                <option value="Budget Changes">Budget Changes</option>
                <option value="Date/Venue Changes">Date/Venue Changes</option>
                <option value="Found Another Organizer">Found Another Organizer</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div class="form-group mb-12">
              <label class="form-label" style="font-weight:600" for="client-withdraw-explanation">Additional Explanation (Optional)</label>
              <textarea class="form-control" id="client-withdraw-explanation" rows="2" placeholder="Provide any additional comments..."></textarea>
            </div>
            <div id="client-withdraw-error" role="alert" style="display:none;color:var(--red);font-size:12.5px;margin-top:6px;margin-bottom:8px"></div>
          </div>
        `,
      [
        {
          lbl: 'Keep Request',
          cls: 'btn-ghost',
          fn: 'closeModal()',
        },
        {
          lbl: 'Confirm Withdrawal',
          cls: 'btn-danger',
          fn: `submitClientWithdrawal('${escapeHtml(request.requestId || request.id)}')`,
        },
      ],
      false
    );
    return;
  }

  // ─────────────────────────────────────────────────────────────────
  // CONFIRMED BOOKINGS: 2-STEP CANCELLATION MODAL WITH FEES & POLICY
  // ─────────────────────────────────────────────────────────────────
  const effectiveRequestId = request.requestId || request.id;
  openModal(
    'Cancel Event',
    `
        <div style="padding:24px 0;text-align:center">
          <div class="small" style="color:var(--text2)">Loading cancellation details…</div>
        </div>
      `,
    [
      {
        lbl: 'Keep Event',
        cls: 'btn-ghost',
        fn: 'closeModal()',
      },
      {
        lbl: 'Cancel Event',
        cls: 'btn-danger',
        fn: 'void 0',
        disabled: true,
        title: 'Loading cancellation details',
      },
    ],
    false
  );
  try {
    const res = await apiPreviewClientRequestCancellation(effectiveRequestId);
    const preview = workflowPayload(res);
    if (!preview || typeof preview.canCancel !== 'boolean')
      throw new Error('Unable to load the cancellation policy. Please try again.');
    _clientCancelPreview = preview;
    const eventName = preview.eventName || request.title || request.eventName || 'Event';
    const currentStatus = preview.status || request.status || 'Confirmed';
    const isPermitted = Boolean(preview.canCancel);
    const paidAmount = Number(preview.paidAmount || 0);
    const feePercent = Number(
      preview.cancellationFeePercent ?? preview.policy?.cancellation?.feePercent ?? 0
    );
    const cancellationFee = Number(preview.cancellationFee || 0);
    const refundAmount = Number(preview.refundAmount || 0);
    const timeline =
      preview.refundProcessingTimeline ||
      (paidAmount > 0
        ? '5–7 business days (pending review)'
        : 'Not applicable (no payment charged)');
    const deadlineText = preview.cancellationDeadline
      ? workflowPolicyDate(preview.cancellationDeadline)
      : '14 days prior to event start';
    const noticeDays = Number(
      preview.minimumNoticeDays ?? preview.policy?.cancellation?.minimumNoticeDays ?? 14
    );
    if (!isPermitted) {
      const unavailableReason = preview.unavailableReason || 'The cancellation window has closed.';
      openModal(
        'Cancel Event',
        `<div class="client-cancel-dialog">
            <h3>${workflowHtml(eventName)}</h3>
            <div class="client-cancel-unavailable" role="alert"><strong>Cancellation unavailable</strong><p>${workflowHtml(
              unavailableReason
            )}</p></div>
            <p>Cancellation requires at least ${noticeDays} days' notice.</p>
            ${
              preview.cancellationDeadline
                ? `<div class="info-row"><span class="info-label">Cancellation deadline</span><strong>${workflowHtml(
                    deadlineText
                  )}</strong></div>`
                : ''
            }
            ${
              preview.paidAmount != null && Number.isFinite(paidAmount)
                ? `<div class="info-row"><span class="info-label">Amount already paid</span><strong>₹${paidAmount.toLocaleString(
                    'en-IN',
                    {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    }
                  )}</strong></div>`
                : ''
            }
            <p>Your event has not been cancelled. No cancellation fee or refund has been applied.</p>
            <p class="small">Contact your organizer if you need help with this event.</p>
          </div>`,
        [
          {
            lbl: 'Close',
            cls: 'btn-ghost',
            fn: 'closeModal()',
          },
          {
            lbl: 'Cancel Event',
            cls: 'btn-danger',
            fn: 'void 0',
            disabled: true,
            title: unavailableReason,
          },
        ],
        false
      );
      return;
    }
    if (
      !preview.policy?.version ||
      !Number.isFinite(feePercent) ||
      feePercent < 0 ||
      feePercent > 100 ||
      ['paidAmount', 'cancellationFee', 'refundAmount'].some(
        key =>
          preview[key] == null || !Number.isFinite(Number(preview[key])) || Number(preview[key]) < 0
      )
    ) {
      throw new Error(
        'The cancellation policy or payment amounts are unavailable. Please try again.'
      );
    }
    const modalBody = `
          <div class="client-cancel-dialog">
            <div style="margin-bottom:14px">
              <div style="font-size:16px;font-weight:700;color:var(--text);margin-bottom:4px">${workflowHtml(
                eventName
              )}</div>
              <div><span class="badge badge-${reqBadge(currentStatus)}">${workflowHtml(
      currentStatus
    )}</span></div>
              <p class="small mt-8">You are cancelling this event as the client. The organizer will be notified after you confirm.</p>
            </div>

            <!-- CANCELLATION POLICY & WINDOW -->
            <div style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:12px;margin-bottom:14px;font-size:12.5px;line-height:1.6">
              <div style="font-weight:700;color:var(--text);margin-bottom:4px">Cancellation Policy & Window</div>
              <div><strong>Notice window:</strong> At least ${noticeDays} days before scheduled event start.</div>
              <div><strong>Cancellation deadline:</strong> ${workflowHtml(deadlineText)}</div>
              <div><strong>Policy terms:</strong> ${
                paidAmount > 0
                  ? `${feePercent}% fee applies to the amount actually paid. Any refund is recorded as pending review.`
                  : 'No payment was made, so no cancellation fee or refund applies.'
              }</div>
            </div>

            <!-- PERMITTED STATUS -->
            <div style="padding:8px 12px;border-radius:6px;background:rgba(34,197,94,0.12);color:var(--green);font-size:13px;font-weight:600;margin-bottom:14px">✓ You can cancel this event before the deadline shown above.</div>

            <!-- FINANCIAL BREAKDOWN -->
            <div style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:12px;margin-bottom:14px;display:grid;grid-template-columns:1fr 1fr;gap:10px;font-size:13px">
              <div><div class="small" style="color:var(--text2)">AMOUNT PAID</div><strong>₹${paidAmount.toLocaleString(
                undefined,
                {
                  minimumFractionDigits: 2,
                }
              )}</strong></div>
              <div><div class="small" style="color:var(--text2)">CANCELLATION FEE (${feePercent}%)</div><strong style="color:var(--red)">₹${cancellationFee.toLocaleString(
      undefined,
      {
        minimumFractionDigits: 2,
      }
    )}</strong></div>
              <div><div class="small" style="color:var(--text2)">ESTIMATED REFUND</div><strong style="color:var(--green)">₹${refundAmount.toLocaleString(
                undefined,
                {
                  minimumFractionDigits: 2,
                }
              )}</strong></div>
              <div><div class="small" style="color:var(--text2)">REFUND TIMELINE</div><span>${workflowHtml(
                timeline
              )}</span></div>
            </div>

            <!-- REQUIRED REASON DROPDOWN -->
            <div class="form-group mb-12">
              <label class="form-label" style="font-weight:600" for="client-cancel-reason">Cancellation Reason *</label>
              <select class="form-control" id="client-cancel-reason" required>
                <option value="">Select a cancellation reason (Required)...</option>
                <option value="Change of Plans">Change of Plans</option>
                <option value="Budget Constraints">Budget Constraints</option>
                <option value="Event Postponed">Event Postponed</option>
                <option value="Organizer Issue">Organizer Issue</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <!-- OPTIONAL EXPLANATION -->
            <div class="form-group mb-12">
              <label class="form-label" style="font-weight:600" for="client-cancel-explanation">Additional Explanation (Optional)</label>
              <textarea class="form-control" id="client-cancel-explanation" rows="2" placeholder="Provide any additional explanation or details..."></textarea>
            </div>
            <div id="client-cancel-error" role="alert" style="display:none;color:var(--red);font-size:12.5px;margin-top:6px;margin-bottom:8px"></div>
          </div>
        `;
    const modalActions = [
      {
        lbl: 'Keep Event',
        cls: 'btn-ghost',
        fn: 'closeModal()',
      },
      {
        lbl: 'Cancel Event',
        cls: 'btn-danger',
        fn: `proceedClientCancelStep2('${escapeHtml(effectiveRequestId)}')`,
      },
    ];
    openModal('Cancel Event', modalBody, modalActions, false);
  } catch (err) {
    _clientCancelPreview = null;
    openModal(
      'Cancellation Error',
      `
          <div style="padding:16px 0;color:var(--red)">
            <p>${workflowHtml(err.message || 'Unable to load cancellation details.')}</p>
          </div>
        `,
      [
        {
          lbl: 'Close',
          cls: 'btn-ghost',
          fn: 'closeModal()',
        },
      ],
      false
    );
  }
}
if (typeof window !== 'undefined')
  window.openClientCancelRequestModal = openClientCancelRequestModal;
async function submitClientWithdrawal(requestId) {
  if (_clientCancelSubmitting) return;
  const reasonSelect = g('client-withdraw-reason');
  const reason = reasonSelect ? reasonSelect.value.trim() : '';
  const explanationInput = g('client-withdraw-explanation');
  const explanation = explanationInput ? explanationInput.value.trim() : '';
  const errEl = g('client-withdraw-error');
  if (!reason) {
    if (errEl) {
      errEl.textContent = 'Please select a reason for withdrawal.';
      errEl.style.display = 'block';
    }
    return;
  }
  if (errEl) errEl.style.display = 'none';
  _clientCancelSubmitting = true;
  const buttons = g('modal-foot')?.querySelectorAll('button') || [];
  buttons.forEach(b => {
    b.disabled = true;
  });
  try {
    const r = DB.eventRequests.find(
      request =>
        String(request.id) === String(requestId) || String(request.requestId) === String(requestId)
    );
    const effectiveReqId = r ? r.requestId || r.id : requestId;
    const payload = {
      reason,
      explanation,
    };
    await apiCancelClientRequest(effectiveReqId, payload);
    closeModal();
    closeDrawer();
    toast('Event request withdrawn successfully.', 'success');
    await syncClientEventRequests();
    await syncWorkflowData();
    renderPage('request-status');
  } catch (err) {
    if (errEl) {
      errEl.textContent = err.message || 'Unable to withdraw request.';
      errEl.style.display = 'block';
    } else {
      toast(err.message || 'Unable to withdraw request', 'error');
    }
  } finally {
    _clientCancelSubmitting = false;
    buttons.forEach(b => {
      b.disabled = false;
    });
  }
}
if (typeof window !== 'undefined') window.submitClientWithdrawal = submitClientWithdrawal;
function proceedClientCancelStep2(requestId) {
  const preview = _clientCancelPreview;
  if (!preview || !preview.canCancel) return;
  const reasonSelect = g('client-cancel-reason');
  const reason = reasonSelect ? reasonSelect.value.trim() : '';
  const explanationInput = g('client-cancel-explanation');
  const explanation = explanationInput ? explanationInput.value.trim() : '';
  const errEl = g('client-cancel-error');
  if (!reason) {
    if (errEl) {
      errEl.textContent = 'Please select a required cancellation reason from the dropdown.';
      errEl.style.display = 'block';
    }
    return;
  }
  if (errEl) errEl.style.display = 'none';
  _clientCancelReason = reason;
  _clientCancelExplanation = explanation;
  const paidAmount = Number(preview.paidAmount || 0);
  const cancellationFee = Number(preview.cancellationFee || 0);
  const refundAmount = Number(preview.refundAmount || 0);
  const confirmBody = `
          <div class="client-cancel-dialog">
          <div class="alert alert-warning mb-14" style="background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.4);border-radius:8px;padding:12px;color:var(--text);font-size:13px;line-height:1.5">
            <strong>Final confirmation:</strong> You are cancelling this event. This action cannot be undone.
          </div>
          <div style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:14px;margin-bottom:14px;font-size:13px;line-height:1.7">
            <div style="font-weight:700;color:var(--accent);text-transform:uppercase;font-size:11px;letter-spacing:0.05em;margin-bottom:6px">Summary of Consequences</div>
            <div><strong>Event:</strong> ${workflowHtml(preview.eventName)}</div>
            <div><strong>Current Status:</strong> <span class="badge badge-${reqBadge(
              preview.status
            )}">${workflowHtml(preview.status)}</span></div>
            <div><strong>Selected Reason:</strong> ${workflowHtml(reason)}</div>
            ${
              explanation
                ? `<div><strong>Explanation:</strong> ${workflowHtml(explanation)}</div>`
                : ''
            }
            <div style="border-top:1px solid var(--border2);margin-top:8px;padding-top:8px">
              <div>Amount Actually Paid: <strong>₹${paidAmount.toFixed(2)}</strong></div>
              <div>Cancellation Fee Deducted: <strong>₹${cancellationFee.toFixed(2)}</strong></div>
              <div>Estimated Refund: <strong style="color:var(--green)">₹${refundAmount.toFixed(
                2
              )}</strong></div>
              <div class="small" style="color:var(--text2);margin-top:4px">Refund Timeline: <em>${workflowHtml(
                preview.refundProcessingTimeline ||
                  (refundAmount > 0 ? 'Pending review' : 'No refund applicable')
              )}</em></div>
            </div>
          </div>
          <p style="font-size:12.5px;color:var(--text2)">By confirming, you accept the cancellation fee and refund shown above. The organizer will be notified, and any refund due will be recorded as pending review.</p>
          <div id="client-cancel-final-error" role="alert" style="display:none;color:var(--red);font-size:12.5px;margin-top:8px"></div>
        </div>
      `;
  openModal(
    'Confirm Event Cancellation',
    confirmBody,
    [
      {
        lbl: 'Keep Event',
        cls: 'btn-ghost',
        fn: 'closeModal()',
      },
      {
        lbl: 'Yes, Cancel Event',
        cls: 'btn-danger',
        fn: `submitClientFinalCancellation('${escapeHtml(requestId)}')`,
      },
    ],
    false
  );
}
if (typeof window !== 'undefined') window.proceedClientCancelStep2 = proceedClientCancelStep2;
async function submitClientFinalCancellation(requestId) {
  const preview = _clientCancelPreview;
  if (_clientCancelSubmitting || !preview?.canCancel) return;
  _clientCancelSubmitting = true;
  const buttons = g('modal-foot')?.querySelectorAll('button') || [];
  buttons.forEach(b => {
    b.disabled = true;
  });
  const errEl = g('client-cancel-final-error');
  if (errEl) errEl.style.display = 'none';
  try {
    const payload = {
      reason: _clientCancelReason,
      explanation: _clientCancelExplanation,
      expectedPaidAmount: preview.paidAmount,
      policyAccepted: true,
      acceptedPolicyVersion: preview.policy.version,
    };
    const res = await apiCancelClientRequest(requestId, payload);
    _clientCancelPreview = null;
    closeModal();
    closeDrawer();
    const successMsg =
      res?.message ||
      (preview.refundAmount > 0
        ? `Event cancelled. Refund of ₹${preview.refundAmount.toFixed(2)} is pending review.`
        : 'Event cancelled successfully.');
    toast(successMsg, 'success');
    await syncClientEventRequests();
    await syncWorkflowData();
    loadClientRecentActivity();
    renderPage(_currentPage);
  } catch (err) {
    if (errEl) {
      errEl.textContent = err.message || 'Unable to cancel this event. Please try again.';
      errEl.style.display = 'block';
    }
    toast(err.message || 'Unable to cancel this event', 'error');
  } finally {
    _clientCancelSubmitting = false;
    buttons.forEach(b => {
      b.disabled = false;
    });
  }
}
if (typeof window !== 'undefined')
  window.submitClientFinalCancellation = submitClientFinalCancellation;
function cancelReq(id) {
  openClientCancelRequestModal(id);
}
if (typeof window !== 'undefined') window.cancelReq = cancelReq;
async function submitRequest() {
  const title = v('nr-title');
  const date = v('nr-date');
  const guests = v('nr-guests');
  const budget = v('nr-budget');
  const desc = v('nr-desc');
  const ticketPrice = Number(v('nr-ticket-price') || 0);
  const visibility = v('nr-visibility') || 'public';
  if (!['public', 'private'].includes(visibility)) {
    toast('Choose Public or Private event access.', 'error');
    return;
  }
  if (!title) {
    toast('Event title is required', 'error');
    return;
  }
  if (!date) {
    toast('Preferred date is required', 'error');
    return;
  }
  const guestsNum = Number(guests);
  if (!guests || !Number.isInteger(guestsNum) || guestsNum < 1 || guestsNum > 50000) {
    toast(
      guestsNum > 50000
        ? 'Maximum event capacity is 50,000'
        : 'Event capacity must be between 1 and 50,000 guests',
      'error'
    );
    return;
  }
  const budgetNum = Number(budget);
  if (
    !budget ||
    !Number.isFinite(budgetNum) ||
    budgetNum < 1000 ||
    budgetNum > 10000000 ||
    Math.abs(budgetNum * 100 - Math.round(budgetNum * 100)) > 0.000001
  ) {
    toast(
      budgetNum > 10000000
        ? 'Event budget cannot exceed ₹1,00,00,000'
        : 'Event budget must be between ₹1,000 and ₹1,00,00,000',
      'error'
    );
    return;
  }
  if (
    !Number.isFinite(ticketPrice) ||
    ticketPrice < 0 ||
    ticketPrice > 100000 ||
    Math.abs(ticketPrice * 100 - Math.round(ticketPrice * 100)) > 0.000001
  ) {
    toast(
      ticketPrice > 100000
        ? 'Ticket price cannot exceed ₹1,00,000'
        : 'Enter a ticket price between ₹0 and ₹1,00,000, with up to 2 decimal places.',
      'error'
    );
    return;
  }
  if (!desc || desc.length < 10) {
    toast('Please provide a detailed description', 'error');
    return;
  }
  const organizerId = v('nr-organizer');
  if (!organizerId) {
    toast('Select an organizer', 'error');
    return;
  }
  const acknowledgement = workflowPolicyAcknowledgement(workflowEventPolicy, 'nr-policy');
  if (!acknowledgement) return;
  await runWorkflowAction(
    () =>
      apiCreateEventRequest({
        ...acknowledgement,
        clientId: CU.id,
        organizerId,
        eventName: title.trim(),
        eventType: v('nr-type'),
        eventDate: date,
        capacity: parseInt(guests, 10),
        budget: Number(budget),
        ticketPrice,
        visibility,
        venue: v('nr-venue').trim(),
        requirements: desc.trim(),
      }),
    'Event request submitted'
  );
}
function submitPlan(id) {
  const r = DB.eventRequests.find(request => String(request.id) === String(id));
  if (r) {
    r.status = 'in_review';
    r.organizer = CU.id;
    renderPage('request-status');
    toast('Plan submitted to client for review!', 'success');
  }
}

// ════════════════════════════════════════════════
//  REPORTS
// ════════════════════════════════════════════════
function operationalReportBadge(status) {
  return (
    {
      Draft: 'yellow',
      Submitted: 'purple',
      Reviewed: 'green',
    }[status] || 'gray'
  );
}
function pageOperationalReports() {
  const reports = DB.operationalReports || [];
  return `<div class="page-hd"><div class="page-hd-left"><div class="page-title">Reports</div><div class="page-sub">Submit support, finance, and combined operational reports to Super Admin.</div></div><div class="page-hd-right"><button class="btn btn-primary" onclick="openSubmitOperationalReportModal()">📤 Submit Report</button></div></div><div class="grid-3 mb-20">${[
    'Support Report',
    'Finance Report',
    'Combined Operational Report',
  ]
    .map(
      type =>
        `<div class="stat-card"><div class="stat-icon">${
          type === 'Support Report' ? '📩' : type === 'Finance Report' ? '💳' : '📊'
        }</div><div class="stat-value">${
          reports.filter(item => item.type === type).length
        }</div><div class="stat-label">${type}s</div></div>`
    )
    .join(
      ''
    )}</div><div class="card"><div class="h4 mb-12">Operational Reports</div><div class="table-wrap"><table><thead><tr><th>Report</th><th>Type</th><th>Owner</th><th>Status</th><th>Updated</th><th>Action</th></tr></thead><tbody>${reports
    .map(
      item =>
        `<tr><td><strong>${item.title}</strong></td><td>${item.type}</td><td>${
          item.owner
        }</td><td><span class="badge badge-${operationalReportBadge(item.status)}">${
          item.status
        }</span></td><td>${item.updated}</td><td>${
          item.status === 'Draft'
            ? `<button class="btn btn-primary btn-xs" onclick="submitOperationalReport('${item.id}')">Submit</button>`
            : '<span class="small">Tracked</span>'
        }</td></tr>`
    )
    .join('')}</tbody></table></div></div>`;
}
function openOperationalReportModal() {
  openModal(
    'Prepare Operational Report',
    `<div class="form-group"><label class="form-label">Report Type</label><select class="form-control" id="op-report-type"><option>Support Report</option><option>Finance Report</option><option>Combined Operational Report</option></select></div><div class="form-group"><label class="form-label">Report Title</label><input class="form-control" id="op-report-title" placeholder="e.g. September support review"></div>`,
    [
      {
        lbl: 'Save Draft',
        cls: 'btn-primary',
        fn: 'saveOperationalReport()',
      },
    ]
  );
}
function saveOperationalReport() {
  const title = v('op-report-title');
  if (!title) {
    toast('Enter a report title', 'error');
    return;
  }
  DB.operationalReports.push({
    id: `OPR-${Date.now()}`,
    type: v('op-report-type'),
    title,
    owner: CU.name,
    status: 'Draft',
    updated: 'Just now',
  });
  saveDB();
  closeModal();
  renderPage('reports');
  toast('Report saved as draft', 'success');
}
function openSubmitOperationalReportModal() {
  openModal(
    'Submit Operational Report',
    `<div class="form-group"><label class="form-label">Report Type</label><select class="form-control" id="op-submit-type"><option>Support Report</option><option>Finance Report</option><option>Combined Operational Report</option></select></div><div class="form-group"><label class="form-label">Report Title</label><input class="form-control" id="op-submit-title" placeholder="e.g. September support review"></div>`,
    [
      {
        lbl: 'Submit Report',
        cls: 'btn-primary',
        fn: 'submitNewOperationalReport()',
      },
    ]
  );
}
function submitNewOperationalReport() {
  const title = v('op-submit-title');
  if (!title) {
    toast('Enter a report title', 'error');
    return;
  }
  DB.operationalReports.push({
    id: `OPR-${Date.now()}`,
    type: v('op-submit-type'),
    title,
    owner: CU.name,
    status: 'Submitted',
    updated: 'Just now',
  });
  saveDB();
  closeModal();
  renderPage('reports');
  toast('Report submitted to Super Admin', 'success');
}
function submitOperationalReport(id) {
  const report = DB.operationalReports.find(item => item.id === id);
  if (!report) return;
  report.status = 'Submitted';
  report.updated = 'Just now';
  saveDB();
  renderPage('reports');
  toast('Report submitted to Super Admin', 'success');
}
function eventOpsReportBadge(status) {
  if (status === 'Submitted') return 'purple';
  if (status === 'Pending Review' || status === 'Pending') return 'orange';
  if (status === 'Reviewed') return 'green';
  if (status === 'Draft') return 'yellow';
  return 'gray';
}
function pageEventOpsReports() {
  const reports = DB.eventOpsReports || [];
  const searchQuery = (sessionStorage.getItem('eor_search') || '').toLowerCase();
  const typeFilter = sessionStorage.getItem('eor_type') || '';
  const statusFilter = sessionStorage.getItem('eor_status') || '';
  const perfCount = reports.filter(report => report.type === 'Event Performance Report').length;
  const opsCount = reports.filter(report => report.type === 'Event Operations Report').length;
  const actCount = reports.filter(report => report.type === 'Event Activity Report').length;
  const submittedCount = reports.filter(report => report.status === 'Submitted').length;
  const pendingReviewCount = reports.filter(
    report => report.status === 'Pending Review' || report.status === 'Pending'
  ).length;
  const reviewedCount = reports.filter(report => report.status === 'Reviewed').length;
  const filtered = reports.filter(report => {
    const titleStr = (report.title || '').toLowerCase();
    const idStr = (report.id || '').toLowerCase();
    const scopeStr = (report.scope || '').toLowerCase();
    const matchesQuery =
      !searchQuery ||
      titleStr.includes(searchQuery) ||
      idStr.includes(searchQuery) ||
      scopeStr.includes(searchQuery);
    const matchesType = !typeFilter || report.type === typeFilter;
    const matchesStatus =
      !statusFilter ||
      report.status === statusFilter ||
      (statusFilter === 'Pending Review' && report.status === 'Pending');
    return matchesQuery && matchesType && matchesStatus;
  });
  return `
        <div class="page-hd">
          <div class="page-hd-left">
            <div class="page-title">Event Operations Reports</div>
            <div class="page-sub">Submit, view, and track operational performance, logistics, and activity reports for Super Admin review.</div>
          </div>
          <div class="page-hd-right">
            <button class="btn btn-primary" onclick="openCreateEventOpsReportModal()">📤 Submit Report</button>
          </div>
        </div>

        <div class="grid-3 mb-20">
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--accent-dim);color:var(--accent)">📈</div>
            <div class="stat-value" style="color:var(--accent)">${perfCount}</div>
            <div class="stat-label">Performance Reports</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--purple-dim);color:var(--purple)">⚙️</div>
            <div class="stat-value" style="color:var(--purple)">${opsCount}</div>
            <div class="stat-label">Operations Reports</div>
          </div>
          <div class="stat-card">
            <div class="stat-icon" style="background:var(--blue-dim);color:var(--blue)">📄</div>
            <div class="stat-value" style="color:var(--blue)">${actCount}</div>
            <div class="stat-label">Activity Reports</div>
          </div>
        </div>

        <div class="grid-3 mb-20">
          <div class="card" style="padding:14px 18px;display:flex;align-items:center;justify-content:space-between;background:var(--surface2)">
            <div>
              <div class="small muted" style="font-weight:600">Submitted Reports</div>
              <div style="font-size:20px;font-weight:800;color:var(--purple);margin-top:2px">${submittedCount}</div>
            </div>
            <span class="badge badge-purple">Submitted</span>
          </div>
          <div class="card" style="padding:14px 18px;display:flex;align-items:center;justify-content:space-between;background:var(--surface2)">
            <div>
              <div class="small muted" style="font-weight:600">Pending Review</div>
              <div style="font-size:20px;font-weight:800;color:var(--orange);margin-top:2px">${pendingReviewCount}</div>
            </div>
            <span class="badge badge-orange">In Review</span>
          </div>
          <div class="card" style="padding:14px 18px;display:flex;align-items:center;justify-content:space-between;background:var(--surface2)">
            <div>
              <div class="small muted" style="font-weight:600">Reviewed Reports</div>
              <div style="font-size:20px;font-weight:800;color:var(--green);margin-top:2px">${reviewedCount}</div>
            </div>
            <span class="badge badge-green">Approved</span>
          </div>
        </div>

        <div class="card">
          <div class="filter-row mb-16" style="display:flex;gap:12px;flex-wrap:wrap">
            <div class="search-box input-group" style="flex:1;min-width:240px">
              <span class="input-icon">🔍</span>
              <input class="form-control" id="eor-search" placeholder="Search reports by title, scope, or ID..." value="${
                sessionStorage.getItem('eor_search') || ''
              }" oninput="refreshEorPage()">
            </div>
            <select class="form-control filter-select" id="eor-type-filter" onchange="refreshEorPage()" style="width:220px">
              <option value="">All Report Types</option>
              <option value="Event Performance Report" ${
                typeFilter === 'Event Performance Report' ? 'selected' : ''
              }>Event Performance Report</option>
              <option value="Event Operations Report" ${
                typeFilter === 'Event Operations Report' ? 'selected' : ''
              }>Event Operations Report</option>
              <option value="Event Activity Report" ${
                typeFilter === 'Event Activity Report' ? 'selected' : ''
              }>Event Activity Report</option>
            </select>
            <select class="form-control filter-select" id="eor-status-filter" onchange="refreshEorPage()" style="width:170px">
              <option value="">All Statuses</option>
              <option value="Draft" ${statusFilter === 'Draft' ? 'selected' : ''}>Draft</option>
              <option value="Submitted" ${
                statusFilter === 'Submitted' ? 'selected' : ''
              }>Submitted</option>
              <option value="Pending Review" ${
                statusFilter === 'Pending Review' ? 'selected' : ''
              }>Pending Review</option>
              <option value="Reviewed" ${
                statusFilter === 'Reviewed' ? 'selected' : ''
              }>Reviewed</option>
            </select>
          </div>

          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Report</th>
                  <th>Report Type</th>
                  <th>Event / Scope</th>
                  <th>Attached File</th>
                  <th>Status</th>
                  <th>Last Updated</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                ${
                  filtered.length
                    ? filtered
                        .map(
                          r => `
                  <tr>
                    <td>
                      <div style="font-weight:700;color:var(--text);font-size:13.5px">${
                        r.title
                      }</div>
                      <div class="small muted">ID: ${r.id} · Submitted By: ${
                            r.owner || 'Elena Rostova'
                          }</div>
                    </td>
                    <td>
                      <span class="badge badge-${
                        r.type === 'Event Performance Report'
                          ? 'purple'
                          : r.type === 'Event Operations Report'
                          ? 'blue'
                          : 'orange'
                      }">${r.type}</span>
                    </td>
                    <td class="small" style="font-weight:600;color:var(--text2)">${
                      r.scope || '—'
                    }</td>
                    <td>
                      ${
                        r.fileName
                          ? `<span style="font-weight:600;color:var(--accent);font-size:12.5px">📄 ${r.fileName}</span>`
                          : `<span class="small muted">No file attached</span>`
                      }
                    </td>
                    <td>
                      <span class="badge badge-${eventOpsReportBadge(r.status)}">${r.status}</span>
                    </td>
                    <td class="small muted">${r.updated}</td>
                    <td>
                      <div class="flex gap-6">
                        <button class="btn btn-ghost btn-xs" onclick="viewEventOpsReportModal('${
                          r.id
                        }')">View Details</button>
                        ${
                          r.status === 'Draft'
                            ? `<button class="btn btn-primary btn-xs" onclick="submitDraftEventOpsReport('${r.id}')">📤 Submit</button>`
                            : ''
                        }
                      </div>
                    </td>
                  </tr>
                `
                        )
                        .join('')
                    : '<tr><td colspan="7" class="text-center py-20 muted">No operational reports found matching your criteria.</td></tr>'
                }
              </tbody>
            </table>
          </div>
        </div>
      `;
}
function refreshEorPage() {
  sessionStorage.setItem('eor_search', v('eor-search'));
  sessionStorage.setItem('eor_type', v('eor-type-filter'));
  sessionStorage.setItem('eor_status', v('eor-status-filter'));
  renderPage('reports');
}
function submitDraftEventOpsReport(reportId) {
  const r = (DB.eventOpsReports || []).find(item => item.id === reportId);
  if (!r) return;
  r.status = 'Submitted';
  r.updated = 'Just now';
  saveDB();
  renderPage('reports');
  toast('Report submitted to Super Admin for review!', 'success');
}
function viewEventOpsReportModal(reportId) {
  const r = (DB.eventOpsReports || []).find(item => item.id === reportId);
  if (!r) return;
  openModal(
    `Report: ${r.title}`,
    `
        <div class="info-row"><span class="info-label">Report ID</span><span class="info-value mono">${
          r.id
        }</span></div>
        <div class="info-row"><span class="info-label">Report Type</span><span class="info-value"><span class="badge badge-purple">${
          r.type
        }</span></span></div>
        <div class="info-row"><span class="info-label">Event / Scope</span><span class="info-value"><strong>${
          r.scope || '—'
        }</strong></span></div>
        <div class="info-row"><span class="info-label">Reporting Period</span><span class="info-value">${
          r.period || '—'
        }</span></div>
        <div class="info-row"><span class="info-label">Submitted By</span><span class="info-value">${
          r.owner || 'Elena Rostova'
        }</span></div>
        <div class="info-row"><span class="info-label">Status</span><span class="info-value"><span class="badge badge-${eventOpsReportBadge(
          r.status
        )}">${r.status}</span></span></div>
        <div class="info-row"><span class="info-label">Last Updated</span><span class="info-value">${
          r.updated
        }</span></div>
        <div class="info-row"><span class="info-label">Attached File</span><span class="info-value" style="color:var(--accent);font-weight:700">${
          r.fileName ? '📄 ' + r.fileName : 'No file attached'
        }</span></div>
        <div class="mt-12" style="padding:12px;background:var(--surface2);border-radius:8px;font-size:12.5px;color:var(--text2)">
          ℹ️ <strong>Workflow:</strong> Submitted reports are routed to Super Admin for review and operational audit.
        </div>
      `,
    r.status === 'Draft'
      ? [
          {
            lbl: '📤 Submit to Super Admin',
            cls: 'btn-primary',
            fn: `closeModal();submitDraftEventOpsReport('${r.id}')`,
          },
        ]
      : []
  );
}
window.handleReportFileSelect = function (input) {
  const preview = document.getElementById('eor-file-preview');
  if (input.files && input.files[0]) {
    const f = input.files[0];
    if (preview) {
      globalThis.window?.EventFlowClientPages?.clear(preview);
      preview.innerHTML = `
            <div class="flex items-center justify-between" style="background:var(--accent-dim);border-radius:8px;padding:10px 14px">
              <div style="font-weight:600;color:var(--accent);font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">📄 ${
                f.name
              } (${(f.size / 1024).toFixed(1)} KB)</div>
              <button type="button" class="btn btn-danger btn-xs" onclick="event.stopPropagation();resetReportFileSelect()">✕ Remove</button>
            </div>
          `;
    }
  }
};
window.resetReportFileSelect = function () {
  const input = document.getElementById('eor-file');
  if (input) input.value = '';
  const preview = document.getElementById('eor-file-preview');
  if (preview) {
    globalThis.window?.EventFlowClientPages?.clear(preview);
    preview.innerHTML = `
          <div style="font-size:24px;margin-bottom:6px">📁</div>
          <div style="font-weight:600;font-size:13.5px">Click to browse or upload report file</div>
          <div class="small muted">Supported formats: PDF, DOC, DOCX, XLS, XLSX</div>
        `;
  }
};
function openCreateEventOpsReportModal() {
  const eventsOptions = (DB.events || [])
    .map(
      event => `<option value="${event.title || event.name}">${event.title || event.name}</option>`
    )
    .join('');
  openModal(
    '📤 Submit Operational Report',
    `
        <div class="form-group">
          <label class="form-label">Report Type *</label>
          <select class="form-control" id="eor-type">
            <option value="Event Performance Report">Event Performance Report</option>
            <option value="Event Operations Report">Event Operations Report</option>
            <option value="Event Activity Report">Event Activity Report</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Report Title *</label>
          <input class="form-control" id="eor-title" placeholder="e.g. Event Performance Summary — Q3 2026">
        </div>
        <div class="form-group">
          <label class="form-label">Event / Scope *</label>
          <select class="form-control" id="eor-scope">
            <option value="Platform Wide">Platform Wide</option>
            <option value="All Q3 Events">All Q3 Events</option>
            <option value="Main Convention Center">Main Convention Center</option>
            ${eventsOptions}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Reporting Period *</label>
          <input class="form-control" id="eor-period" placeholder="e.g. August 2026, Q3 2026, Week 34">
        </div>
        <div class="form-group">
          <label class="form-label">Upload Report *</label>
          <div class="file-upload-box" style="border:2px dashed var(--border);border-radius:10px;padding:20px;text-align:center;background:var(--surface2);cursor:pointer" onclick="document.getElementById('eor-file').click()">
            <input type="file" id="eor-file" accept=".pdf,.doc,.docx,.xls,.xlsx" style="display:none" onchange="handleReportFileSelect(this)">
            <div id="eor-file-preview">
              <div style="font-size:24px;margin-bottom:6px">📁</div>
              <div style="font-weight:600;font-size:13.5px">Click to browse or upload report file</div>
              <div class="small muted">Supported formats: PDF, DOC, DOCX, XLS, XLSX</div>
            </div>
          </div>
        </div>
      `,
    [
      {
        lbl: 'Cancel',
        cls: 'btn-ghost',
        fn: 'closeModal()',
      },
      {
        lbl: '📤 Submit Report',
        cls: 'btn-primary',
        fn: 'saveEventOpsReportSubmit()',
      },
    ]
  );
}
function saveEventOpsReportSubmit() {
  const type = v('eor-type');
  const title = v('eor-title');
  const scope = v('eor-scope');
  const period = v('eor-period');
  const fileInput = document.getElementById('eor-file');
  if (!title) {
    toast('Please enter a report title', 'error');
    return;
  }
  if (!period) {
    toast('Please specify a reporting period', 'error');
    return;
  }
  if (!fileInput || !fileInput.files || !fileInput.files.length) {
    toast('Please upload a report file', 'error');
    return;
  }
  const file = fileInput.files[0];
  const newReport = {
    id: `EOR-${Date.now().toString().slice(-4)}`,
    type: type,
    title: title,
    scope: scope,
    period: period,
    fileName: file.name,
    owner: CU.name || 'Elena Rostova',
    status: 'Submitted',
    updated: 'Just now',
  };
  if (!DB.eventOpsReports) DB.eventOpsReports = [];
  DB.eventOpsReports.unshift(newReport);
  saveDB();
  closeModal();
  renderPage('reports');
  toast('Report submitted to Super Admin for review!', 'success');
}
function pageReports() {
  if (!DB.reports) DB.reports = [];
  if (CU.role === 'employee' && CU.employeeType === 'SUPPORT_FINANCE')
    return pageOperationalReports();
  if (CU.role === 'employee' && CU.employeeType === 'EVENT_OPERATIONS')
    return pageEventOpsReports();

  // Super Admin gets dedicated analytics dashboard
  if (CU.role === 'superuser') {
    const tab = sessionStorage.getItem('admin_reports_tab') || 'users';

    // ── USER STATISTICS DATA ──────────────────────────────
    const allUsers = DB.users;
    const activeUsers = allUsers.filter(u => u.status === 'active').length;
    const inactiveUsers = allUsers.filter(u => u.status !== 'active').length;
    const attendees = allUsers.filter(u => u.role === 'attendee').length;
    const organizers = allUsers.filter(u => u.role === 'organizer').length;
    const clients = allUsers.filter(u => u.role === 'client').length;
    const employeeCount = allUsers.filter(u => u.role === 'employee').length;
    const admins = allUsers.filter(u => u.role === 'superuser').length;

    // Monthly registrations (last 6 months based on joinedAt / joined)
    const now = new Date();
    const monthNames = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    const monthData = {};
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      monthData[key] = {
        label: monthNames[d.getMonth()],
        count: 0,
      };
    }
    allUsers
      .filter(u => u.role === 'attendee')
      .forEach(u => {
        const joined = u.joined || u.joinedAt || '';
        const key = joined.slice(0, 7);
        if (monthData[key]) monthData[key].count++;
      });
    const months = Object.values(monthData);
    const maxMonthCount = Math.max(...months.map(m => m.count), 1);

    // Role breakdown bar widths
    const maxRole = Math.max(attendees, organizers, clients, employeeCount, admins, 1);
    const roleBar = n => Math.round((n / maxRole) * 100);
    const userStatsContent = `
  <div class="grid-4 mb-24" style="gap:14px">
    <div class="stat-card" style="border-left:4px solid var(--accent)">
      <div class="stat-icon" style="background:var(--accent-dim);color:var(--accent)">👥</div>
      <div class="stat-value" style="color:var(--accent)">${allUsers.length}</div>
      <div class="stat-label">Total Users</div>
      <div class="stat-sub neutral">Platform-wide</div>
    </div>
    <div class="stat-card" style="border-left:4px solid var(--green)">
      <div class="stat-icon" style="background:var(--green-dim);color:var(--green)">✅</div>
      <div class="stat-value" style="color:var(--green)">${activeUsers}</div>
      <div class="stat-label">Active Users</div>
      <div class="stat-sub up">↑ ${Math.round(
        (activeUsers / Math.max(allUsers.length, 1)) * 100
      )}% active rate</div>
    </div>
    <div class="stat-card" style="border-left:4px solid var(--red)">
      <div class="stat-icon" style="background:var(--red-dim);color:var(--red)">⚠️</div>
      <div class="stat-value" style="color:var(--red)">${inactiveUsers}</div>
      <div class="stat-label">Inactive Users</div>
      <div class="stat-sub neutral">Need attention</div>
    </div>
    <div class="stat-card" style="border-left:4px solid var(--blue)">
      <div class="stat-icon" style="background:var(--blue-dim);color:var(--blue)">🎟️</div>
      <div class="stat-value" style="color:var(--blue)">${attendees}</div>
      <div class="stat-label">Attendees</div>
      <div class="stat-sub neutral">Registered attendees</div>
    </div>
  </div>

  <div class="grid-2 mb-24" style="gap:20px">
    <!-- Role Breakdown Card -->
    <div class="card card-lg">
      <div style="font-family:var(--font-head);font-size:16px;font-weight:700;margin-bottom:20px;display:flex;align-items:center;gap:8px">
        <span style="background:var(--accent-dim);color:var(--accent);padding:6px 8px;border-radius:8px;font-size:14px">🏷️</span>
        User Role Breakdown
      </div>
      <div style="display:flex;flex-direction:column;gap:14px">
        ${[
          {
            role: 'Attendees',
            count: attendees,
            color: 'var(--blue)',
            icon: '🎟️',
          },
          {
            role: 'Organizers',
            count: organizers,
            color: 'var(--accent)',
            icon: '🎯',
          },
          {
            role: 'Clients',
            count: clients,
            color: 'var(--yellow)',
            icon: '💼',
          },
          {
            role: 'Employees',
            count: employeeCount,
            color: 'var(--green)',
            icon: '👷',
          },
          {
            role: 'Super Admins',
            count: admins,
            color: 'var(--red)',
            icon: '🛡️',
          },
        ]
          .map(
            r => `
        <div>
          <div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:13px">
            <span style="display:flex;align-items:center;gap:6px"><span>${
              r.icon
            }</span><span style="font-weight:500">${r.role}</span></span>
            <span style="font-weight:700;color:${r.color}">${r.count}</span>
          </div>
          <div style="height:8px;background:var(--surface3);border-radius:99px;overflow:hidden">
            <div style="height:100%;width:${roleBar(r.count)}%;background:${
              r.color
            };border-radius:99px;transition:width 0.6s ease"></div>
          </div>
        </div>`
          )
          .join('')}
      </div>
      <div style="margin-top:20px;padding-top:16px;border-top:1px solid var(--border);display:grid;grid-template-columns:1fr 1fr;gap:8px">
        <div style="background:var(--surface2);border-radius:8px;padding:10px;text-align:center">
          <div style="font-size:20px;font-weight:800;color:var(--green)">${activeUsers}</div>
          <div style="font-size:11px;color:var(--text2);margin-top:2px">Active</div>
        </div>
        <div style="background:var(--surface2);border-radius:8px;padding:10px;text-align:center">
          <div style="font-size:20px;font-weight:800;color:var(--red)">${inactiveUsers}</div>
          <div style="font-size:11px;color:var(--text2);margin-top:2px">Inactive</div>
        </div>
      </div>
    </div>

    <!-- Monthly Registrations Chart -->
    <div class="card card-lg">
      <div style="font-family:var(--font-head);font-size:16px;font-weight:700;margin-bottom:20px;display:flex;align-items:center;gap:8px">
        <span style="background:var(--green-dim);color:var(--green);padding:6px 8px;border-radius:8px;font-size:14px">📅</span>
        Monthly Attendee Registrations
      </div>
      <div style="display:flex;align-items:flex-end;gap:8px;height:160px;padding-bottom:4px">
        ${months
          .map(
            m => `
        <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;height:100%;justify-content:flex-end">
          <div style="font-size:11px;font-weight:700;color:var(--green)">${m.count || ''}</div>
          <div style="width:100%;background:linear-gradient(180deg,var(--green),var(--accent));border-radius:6px 6px 0 0;height:${
            m.count ? Math.max(Math.round((m.count / maxMonthCount) * 130), 8) : 4
          }px;opacity:${m.count ? 1 : 0.2};transition:height 0.5s ease"></div>
          <div style="font-size:10px;color:var(--text3);font-weight:600">${m.label}</div>
        </div>`
          )
          .join('')}
      </div>
      <div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--border);font-size:12px;color:var(--text2)">
        Total attendees registered: <strong style="color:var(--green)">${attendees}</strong>
      </div>
    </div>
  </div>

  <!-- All Users Table -->
  <div class="card">
    <div style="font-family:var(--font-head);font-size:15px;font-weight:700;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between">
      <div style="display:flex;align-items:center;gap:8px"><span style="background:var(--blue-dim);color:var(--blue);padding:5px 7px;border-radius:8px">📋</span> All Users Overview</div>
      <span class="badge badge-blue">${allUsers.length} total</span>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>User</th><th>Role</th><th>Status</th><th>Joined</th></tr></thead>
        <tbody>
          ${allUsers
            .map(
              u => `<tr>
            <td><div class="flex items-center gap-10"><div class="av av-sm">${
              u.avatar || u.name[0]
            }</div><div><div style="font-weight:500">${u.name}</div><div class="small">${
                u.email
              }</div></div></div></td>
            <td><span class="badge badge-${ROLE_COLORS[u.role]}">${u.role}</span></td>
            <td><span class="badge badge-${u.status === 'active' ? 'green' : 'red'}">${
                u.status || 'active'
              }</span></td>
            <td class="small">${u.joined || u.joinedAt || '—'}</td>
          </tr>`
            )
            .join('')}
        </tbody>
      </table>
    </div>
  </div>`;

    // ── EVENT STATISTICS DATA ──────────────────────────────
    const allEvents = DB.events;
    const allRegs = DB.registrations;
    const totalRevenue = allRegs.reduce(
      (total, registration) => total + (registration.amount || 0),
      0
    );
    const checkedIn = allRegs.filter(registration => registration.checkedIn).length;
    const upcomingEvs = allEvents.filter(event => event.status === 'upcoming').length;
    const completedEvs = allEvents.filter(event => event.status === 'completed').length;

    // Category breakdown
    const catMap = {};
    allEvents.forEach(event => {
      if (!catMap[event.category])
        catMap[event.category] = {
          count: 0,
          regs: 0,
          revenue: 0,
        };
      catMap[event.category].count++;
      const registrations = allRegs.filter(registration => registration.eventId === event.id);
      catMap[event.category].regs += registrations.length;
      catMap[event.category].revenue += registrations.reduce(
        (total, registration) => total + (registration.amount || 0),
        0
      );
    });
    const cats = Object.entries(catMap).sort((a, b) => b[1].regs - a[1].regs);
    const maxCatRegs = Math.max(...cats.map(c => c[1].regs), 1);
    const catColors = [
      'var(--accent)',
      'var(--green)',
      'var(--blue)',
      'var(--yellow)',
      'var(--orange)',
      'var(--red)',
    ];

    // Top events by registration
    const topEvents = [...allEvents]
      .sort((leftEvent, rightEvent) => rightEvent.registered - leftEvent.registered)
      .slice(0, 5);

    // Monthly revenue (last 6 months)
    const revMonthData = {};
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      revMonthData[key] = {
        label: monthNames[d.getMonth()],
        revenue: 0,
        regs: 0,
      };
    }
    allRegs.forEach(registration => {
      const key = (registration.date || '').slice(0, 7);
      if (revMonthData[key]) {
        revMonthData[key].revenue += registration.amount || 0;
        revMonthData[key].regs++;
      }
    });
    const revMonths = Object.values(revMonthData);
    const maxRev = Math.max(...revMonths.map(m => m.revenue), 1);
    const eventStatsContent = `
  <div class="grid-4 mb-24" style="gap:14px">
    <div class="stat-card" style="border-left:4px solid var(--green)">
      <div class="stat-icon" style="background:var(--green-dim);color:var(--green)">💰</div>
      <div class="stat-value" style="color:var(--green)">₹${totalRevenue.toLocaleString()}</div>
      <div class="stat-label">Total Revenue</div>
      <div class="stat-sub up">From all ticket sales</div>
    </div>
    <div class="stat-card" style="border-left:4px solid var(--accent)">
      <div class="stat-icon" style="background:var(--accent-dim);color:var(--accent)">🗓️</div>
      <div class="stat-value" style="color:var(--accent)">${allEvents.length}</div>
      <div class="stat-label">Total Events</div>
      <div class="stat-sub neutral">${upcomingEvs} upcoming · ${completedEvs} completed</div>
    </div>
    <div class="stat-card" style="border-left:4px solid var(--blue)">
      <div class="stat-icon" style="background:var(--blue-dim);color:var(--blue)">🎟️</div>
      <div class="stat-value" style="color:var(--blue)">${allRegs.length}</div>
      <div class="stat-label">Total Registrations</div>
      <div class="stat-sub neutral">Across all events</div>
    </div>
    <div class="stat-card" style="border-left:4px solid var(--yellow)">
      <div class="stat-icon" style="background:var(--yellow-dim);color:var(--yellow)">✅</div>
      <div class="stat-value" style="color:var(--yellow)">${checkedIn}</div>
      <div class="stat-label">Checked In</div>
      <div class="stat-sub up">${Math.round(
        (checkedIn / Math.max(allRegs.length, 1)) * 100
      )}% attendance rate</div>
    </div>
  </div>

  <div class="grid-2 mb-24" style="gap:20px">
    <!-- Revenue Bar Chart -->
    <div class="card card-lg">
      <div style="font-family:var(--font-head);font-size:16px;font-weight:700;margin-bottom:20px;display:flex;align-items:center;gap:8px">
        <span style="background:var(--green-dim);color:var(--green);padding:6px 8px;border-radius:8px;font-size:14px">📈</span>
        Monthly Revenue (₹)
      </div>
      <div style="display:flex;align-items:flex-end;gap:8px;height:160px;padding-bottom:4px">
        ${revMonths
          .map(
            m => `
        <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;height:100%;justify-content:flex-end">
          <div style="font-size:10px;font-weight:700;color:var(--green)">${
            m.revenue > 0 ? '₹' + m.revenue : ''
          }</div>
          <div style="width:100%;background:linear-gradient(180deg,#22d3a5,#4299e1);border-radius:6px 6px 0 0;height:${
            m.revenue ? Math.max(Math.round((m.revenue / maxRev) * 130), 8) : 4
          }px;opacity:${m.revenue ? 1 : 0.2}"></div>
          <div style="font-size:10px;color:var(--text3);font-weight:600">${m.label}</div>
        </div>`
          )
          .join('')}
      </div>
      <div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--border);font-size:12px;color:var(--text2)">
        Total platform revenue: <strong style="color:var(--green)">₹${totalRevenue.toLocaleString()}</strong>
      </div>
    </div>

    <!-- Category Popularity -->
    <div class="card card-lg">
      <div style="font-family:var(--font-head);font-size:16px;font-weight:700;margin-bottom:20px;display:flex;align-items:center;gap:8px">
        <span style="background:var(--accent-dim);color:var(--accent);padding:6px 8px;border-radius:8px;font-size:14px">🏆</span>
        Popular Event Categories
      </div>
      ${
        cats.length === 0
          ? `<div class="empty"><div class="empty-icon">📊</div><div class="empty-title">No data yet</div></div>`
          : `<div style="display:flex;flex-direction:column;gap:14px">
        ${cats
          .map(
            ([cat, data], i) => `
        <div>
          <div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:13px">
            <span style="font-weight:600;color:${catColors[i % catColors.length]}">${cat}</span>
            <span style="display:flex;gap:12px">
              <span style="color:var(--text2)">${data.regs} attendees</span>
              <span style="color:var(--green);font-weight:600">₹${data.revenue.toLocaleString()}</span>
            </span>
          </div>
          <div style="height:8px;background:var(--surface3);border-radius:99px;overflow:hidden">
            <div style="height:100%;width:${Math.round(
              (data.regs / maxCatRegs) * 100
            )}%;background:${catColors[i % catColors.length]};border-radius:99px"></div>
          </div>
        </div>`
          )
          .join('')}
      </div>`
      }
    </div>
  </div>

  <!-- Top Events Table -->
  <div class="card mb-24">
    <div style="font-family:var(--font-head);font-size:15px;font-weight:700;margin-bottom:16px;display:flex;align-items:center;gap:8px">
      <span style="background:var(--yellow-dim);color:var(--yellow);padding:5px 7px;border-radius:8px">🏅</span> Top Events by Attendance
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>#</th><th>Event</th><th>Category</th><th>Registered</th><th>Capacity</th><th>Revenue</th><th>Status</th></tr></thead>
        <tbody>
          ${topEvents
            .map((event, index) => {
              const evRev = allRegs
                .filter(registration => registration.eventId === event.id)
                .reduce((total, registration) => total + (registration.amount || 0), 0);
              return `<tr>
              <td><span style="font-weight:700;color:var(--text3)">${index + 1}</span></td>
              <td><div style="display:flex;align-items:center;gap:8px"><span style="font-size:18px">${
                event.emoji || '🎪'
              }</span><div><div style="font-weight:600;font-size:13.5px">${
                event.title
              }</div><div class="small">${event.date}</div></div></div></td>
              <td><span class="badge badge-purple">${event.category}</span></td>
              <td><strong style="color:var(--blue)">${event.registered}</strong></td>
              <td class="small">${event.capacity}</td>
              <td><strong style="color:var(--green)">₹${evRev.toLocaleString()}</strong></td>
              <td><span class="badge badge-${evStatBadge(event.status)}">${event.status}</span></td>
            </tr>`;
            })
            .join('')}
        </tbody>
      </table>
    </div>
  </div>

  <!-- All Events Revenue breakdown -->
  <div class="card">
    <div style="font-family:var(--font-head);font-size:15px;font-weight:700;margin-bottom:16px;display:flex;align-items:center;gap:8px">
      <span style="background:var(--green-dim);color:var(--green);padding:5px 7px;border-radius:8px">📊</span> All Events Revenue Breakdown
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Event</th><th>Price</th><th>Registrations</th><th>Revenue</th><th>Occupancy</th></tr></thead>
        <tbody>
          ${allEvents
            .map(event => {
              const evRegs = allRegs.filter(registration => registration.eventId === event.id);
              const evRev2 = evRegs.reduce(
                (total, registration) => total + (registration.amount || 0),
                0
              );
              const occ = Math.round((event.registered / Math.max(event.capacity, 1)) * 100);
              return `<tr>
              <td><div style="font-weight:500">${event.title}</div></td>
              <td>${
                event.price === 0
                  ? '<span class="badge badge-green">Free</span>'
                  : '₹' + event.price
              }</td>
              <td><strong>${evRegs.length}</strong></td>
              <td style="color:var(--green);font-weight:700">₹${evRev2.toLocaleString()}</td>
              <td>
                <div style="display:flex;align-items:center;gap:8px">
                  <div style="flex:1;height:6px;background:var(--surface3);border-radius:99px;overflow:hidden">
                    <div style="height:100%;width:${occ}%;background:${
                occ >= 80 ? 'var(--green)' : occ >= 50 ? 'var(--yellow)' : 'var(--red)'
              };border-radius:99px"></div>
                  </div>
                  <span style="font-size:12px;font-weight:600;color:var(--text2);min-width:32px">${occ}%</span>
                </div>
              </td>
            </tr>`;
            })
            .join('')}
        </tbody>
      </table>
    </div>
  </div>`;
    return `
  <div class="page-hd">
    <div class="page-hd-left"><div class="page-title">Reports & Analytics</div><div class="page-sub">Platform-wide statistics for super administration</div></div>
    <div class="page-hd-right">
      <button class="btn btn-ghost" onclick="toast('Export feature coming soon','info')">📥 Export</button>
    </div>
  </div>

  <div style="display:flex;gap:4px;background:var(--surface2);border-radius:12px;padding:4px;margin-bottom:28px;border:1px solid var(--border)">
    <button onclick="switchReportTab('users')" style="flex:1;padding:10px 20px;border-radius:9px;font-weight:600;font-size:13.5px;transition:all 0.2s;border:none;cursor:pointer;background:${
      tab === 'users' ? 'var(--accent)' : 'transparent'
    };color:${tab === 'users' ? '#fff' : 'var(--text2)'}">
      👥 User Statistics
    </button>
    <button onclick="switchReportTab('events')" style="flex:1;padding:10px 20px;border-radius:9px;font-weight:600;font-size:13.5px;transition:all 0.2s;border:none;cursor:pointer;background:${
      tab === 'events' ? 'var(--accent)' : 'transparent'
    };color:${tab === 'events' ? '#fff' : 'var(--text2)'}">
      📊 Event Analytics
    </button>
  </div>


  ${tab === 'users' ? userStatsContent : eventStatsContent}
`;
  }

  // ── NON-SUPERUSER: original client report view ──────
  const tab = sessionStorage.getItem('reports_tab') || 'client';
  const myEvents =
    CU.role === 'organizer' ? DB.events.filter(event => event.organizer === CU.id) : DB.events;
  const completedEvents = myEvents.filter(event => event.status === 'completed').length;
  const pendingReports = myEvents.filter(
    event => event.status === 'completed' && !DB.reports.find(report => report.eventId === event.id)
  ).length;
  const submittedReports = DB.reports.filter(report =>
    myEvents.map(event => event.id).includes(report.eventId)
  ).length;
  const clientReportContent = `
    <div class="grid-3 mb-24">
      <div class="stat-card" style="border: 1px solid var(--blue-dim); background: rgba(66, 153, 225, 0.05); padding: 16px;">
        <div class="small" style="color:var(--blue); font-weight:600; margin-bottom: 12px">Total Completed</div>
        <div style="display:flex; align-items:center; gap: 12px;">
          <div class="stat-icon" style="background:var(--blue);color:#fff;margin:0;font-size:16px;border-radius:50%">✓</div>
          <div>
            <div class="stat-value" style="color:var(--text);font-size:24px;margin:0">${completedEvents}</div>
            <div class="small" style="color:var(--text2)">Total events</div>
          </div>
        </div>
      </div>
      <div class="stat-card" style="border: 1px solid var(--green-dim); background: rgba(34, 211, 165, 0.05); padding: 16px;">
        <div class="small" style="color:var(--green); font-weight:600; margin-bottom: 12px">Reports Submitted</div>
        <div style="display:flex; align-items:center; gap: 12px;">
          <div class="stat-icon" style="background:var(--green);color:#fff;margin:0;font-size:15px;border-radius:8px">📄</div>
          <div>
            <div class="stat-value" style="color:var(--text);font-size:24px;margin:0">${submittedReports}</div>
            <div class="small" style="color:var(--text2)">Reports submitted</div>
          </div>
        </div>
      </div>
      <div class="stat-card" style="border: 1px solid var(--orange-dim); background: rgba(237, 137, 54, 0.05); padding: 16px;">
        <div class="small" style="color:var(--orange); font-weight:600; margin-bottom: 12px">Pending Submissions</div>
        <div style="display:flex; align-items:center; gap: 12px;">
          <div class="stat-icon" style="background:var(--orange);color:#fff;margin:0;font-size:16px;border-radius:50%">🕒</div>
          <div>
            <div class="stat-value" style="color:var(--text);font-size:24px;margin:0">${pendingReports}</div>
            <div class="small" style="color:var(--text2)">Reports pending</div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="h4 mb-16" style="display:flex;align-items:center;gap:8px"><span style="color:var(--orange);font-size:18px">⭕</span> Pending Submissions</div>
    <div style="display:flex;flex-direction:column;gap:16px">
      ${myEvents
        .filter(
          event =>
            event.status === 'completed' && !DB.reports.find(report => report.eventId === event.id)
        )
        .map(
          event => `
        <div class="card" style="background:var(--surface); border:1px solid var(--border); padding:20px; border-radius:12px;">
          <div style="font-weight:700;font-size:16px;margin-bottom:12px;color:var(--text)">${
            event.title
          }</div>
          <div style="display:flex;flex-wrap:wrap;gap:24px;margin-bottom:16px;color:var(--text2);font-size:13px">
            <div style="display:flex;align-items:center;gap:6px"><span>📅</span> ${event.date}</div>
            <div style="display:flex;align-items:center;gap:6px"><span>📍</span> ${
              event.venue || event.city || 'Location'
            }</div>
            <div style="display:flex;align-items:center;gap:6px"><span>👥</span> ${
              DB.registrations.filter(registration => registration.eventId === event.id).length
            } Attendees</div>
                      </div>
          <div class="flex gap-12">
            <button class="btn btn-primary" onclick="openSubmitReportModal('${
              event.id
            }')" style="gap:6px; background:var(--accent); border-radius:8px">📤 Submit Report</button>
            <button class="btn btn-ghost" onclick="openViewEventDrawer('${
              event.id
            }')" style="color:var(--accent);border-color:var(--accent-dim);background:var(--accent-dim);gap:6px; border-radius:8px">👁 View Event Details</button>
          </div>
        </div>
      `
        )
        .join('')}
      ${
        pendingReports === 0
          ? `<div class="empty"><div class="empty-icon">✓</div><div class="empty-title">All Reports Submitted</div><p class="empty-desc">Great job! All your completed events have reports.</p></div>`
          : ''
      }
    </div>
  `;
  const employeeReportContent = `
    <div class="page-hd">
      <div class="page-hd-left"><div class="page-title">Submitted Event Reports</div><div class="page-sub">View who submitted each report. Reports cannot be submitted or edited here.</div></div>
    </div>
    <div class="table-wrap">
      ${
        DB.reports.filter(report =>
          myEvents.some(event => String(event.id) === String(report.eventId))
        ).length === 0
          ? `<div class="empty"><div class="empty-icon">📄</div><div class="empty-title">No reports submitted</div><p class="empty-desc">Submitted event reports will appear here.</p></div>`
          : `<table><thead><tr><th>Event</th><th>File</th><th>Submitted By</th><th>Submitted At</th><th>Actions</th></tr></thead><tbody>
        ${DB.reports
          .filter(report => myEvents.some(event => String(event.id) === String(report.eventId)))
          .map(report => {
            const event = myEvents.find(item => String(item.id) === String(report.eventId));
            const submitter = DB.users.find(user => String(user.id) === String(report.submittedBy));
            return `<tr><td><strong>${event ? event.title : 'Unknown Event'}</strong></td><td>${
              report.fileName || 'Report file'
            }</td><td>${
              submitter
                ? `${submitter.name}<div class="small">${submitter.email || ''}</div>`
                : 'Unknown user'
            }</td><td>${
              report.submittedAt || '—'
            }</td><td><button class="btn btn-xs btn-danger" onclick="deleteEventReport('${
              report.id
            }')">Remove</button></td></tr>`;
          })
          .join('')}
      </tbody></table>`
      }
    </div>
  `;
  return `
  <div style="padding:24px;background:var(--bg);">
    <div class="page-hd" style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: flex-start;">
      <div class="page-hd-left">
        <div class="page-title">Event Reports</div>
        <div class="page-sub">${
          CU.role === 'organizer'
            ? 'Review submitted reports and remove them when needed'
            : 'Manage client reports and review event submissions'
        }</div>
      </div>
      <div class="page-hd-right">
        <button class="btn" style="background:var(--surface2);border:1px solid var(--border);color:var(--text);font-weight:600;padding:8px 16px;border-radius:8px;gap:8px" onclick="toast('${completedEvents} Completed Events','info')"><span style="font-size:16px;color:var(--accent)">📄</span> ${completedEvents} Completed Events</button>
      </div>
    </div>
    
    ${
      isEmployeeAccount()
        ? employeeReportContent
        : `<div style="display:flex;gap:24px;border-bottom:1px solid var(--border);margin-bottom:24px">
      <div style="padding-bottom:12px;border-bottom:2px solid ${
        tab === 'client' ? 'var(--accent)' : 'transparent'
      };color:${tab === 'client' ? 'var(--accent)' : 'var(--text2)'};font-weight:${
            tab === 'client' ? '600' : '500'
          };cursor:pointer;font-size:14px;transition:all 0.2s" onclick="switchReportTab('client')">Client Reports</div>

    </div>

    ${clientReportContent}`
    }
  </div>
  `;
}
function switchReportTab(t) {
  if (CU && CU.role === 'superuser') sessionStorage.setItem('admin_reports_tab', t);
  else sessionStorage.setItem('reports_tab', t);
  renderPage('reports');
}
function openSubmitReportModal(eventId) {
  const event = DB.events.find(currentEvent => currentEvent.id == eventId);
  if (!event) return;
  openModal(
    'Submit Event Report',
    `
    <div class="form-group" style="text-align:center; padding: 40px; border: 2px dashed var(--border); border-radius: 8px;">
      <div style="font-size: 32px; margin-bottom: 12px;">📁</div>
      <label class="form-label" style="font-size:16px">Upload Report File</label>
      <div class="small" style="color:var(--text2); margin-bottom: 16px;">PDF, DOCX, XLSX (Max 10MB)</div>
      <input type="file" id="report-file" style="display:none" onchange="document.getElementById('file-name').textContent = this.files[0] ? this.files[0].name : ''">
      <button class="btn btn-ghost" onclick="document.getElementById('report-file').click()">Select File</button>
      <div id="file-name" style="margin-top:12px; font-weight: 500; color: var(--accent);"></div>
    </div>
  `,
    [
      {
        lbl: 'Submit File',
        cls: 'btn-primary',
        fn: `submitEventReport('${eventId}')`,
      },
    ]
  );
}
function submitEventReport(eventId) {
  const fileInput = document.getElementById('report-file');
  if (!fileInput || !fileInput.files.length) {
    toast('Please select a file to submit', 'error');
    return;
  }
  const fileName = fileInput.files[0].name;
  const report = {
    id: Date.now(),
    eventId,
    fileName,
    submittedBy: CU.id,
    submittedAt: new Date().toLocaleString(),
  };
  DB.reports.push(report);
  saveDB();
  closeModal();

  // Notify organizer if not submitted by them
  const event = DB.events.find(currentEvent => currentEvent.id == eventId);
  if (event && CU.id !== event.organizer) {
    DB.notifications.push({
      id: DB._nextId.notifs++,
      userId: event.organizer,
      type: 'info',
      title: 'Event Report Received',
      msg: `A report file for ${event.title} has been submitted by ${CU.name}.`,
      read: false,
      time: new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      }),
    });
    saveDB();
    updateNotifDot();
  }
  renderPage(_currentPage);
  toast('Report file submitted successfully!', 'success');
}
function deleteEventReport(reportId) {
  const report = DB.reports.find(item => String(item.id) === String(reportId));
  if (!report) return;
  confirm2('Remove Event Report', 'Remove this submitted report?', () => {
    const index = DB.reports.findIndex(item => String(item.id) === String(reportId));
    if (index === -1) return;
    DB.reports.splice(index, 1);
    saveDB();
    renderPage('reports');
    toast('Event report removed', 'info');
  });
}

// ════════════════════════════════════════════════

// ════════════════════════════════════════════════

function downloadReport(eventId) {
  const event = DB.events.find(currentEvent => currentEvent.id == eventId);
  const eventRegs = DB.registrations.filter(registration => registration.eventId == eventId);
  const verified = eventRegs.filter(registration => registration.checkedIn);
  let csv = 'Attendee,Email,Ticket Type,Check-In Time,Status\n';
  verified.forEach(r => {
    const u = DB.users.find(user => user.id === r.attendeeId) || {
      name: 'Unknown',
      email: '',
    };
    const ticketType = r.seat === 'VIP' ? 'VIP' : r.seat === 'Premium' ? 'Premium' : 'General';
    csv += `${u.name},${u.email},${ticketType},${r.checkInTime || 'N/A'},Verified\n`;
  });
  const blob = new Blob([csv], {
    type: 'text/csv',
  });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${event.title.replace(/\s+/g, '_')}_Report.csv`;
  a.click();
  window.URL.revokeObjectURL(url);
  toast('Report downloaded!', 'success');
}

// ════════════════════════════════════════════════
//  NOTIFICATIONS
// ════════════════════════════════════════════════
function visibleNotifications() {
  const list =
    CU?.role === 'employee' && CU.employeeType === 'SUPPORT_FINANCE'
      ? DB.notifications.filter(notification => notification.employeeType === 'SUPPORT_FINANCE')
      : DB.notifications;
  return [...(list || [])].sort((a, b) => {
    const timeA = a.createdAt
      ? new Date(a.createdAt).getTime()
      : a.dateTime
      ? new Date(a.dateTime).getTime()
      : a.time
      ? new Date(a.time).getTime()
      : 0;
    const timeB = b.createdAt
      ? new Date(b.createdAt).getTime()
      : b.dateTime
      ? new Date(b.dateTime).getTime()
      : b.time
      ? new Date(b.time).getTime()
      : 0;
    if (timeB !== timeA) return timeB - timeA;
    return String(b.id || '').localeCompare(String(a.id || ''));
  });
}
function pageNotifications() {
  const notifications = visibleNotifications();
  const unread = notifications.filter(notification => !notification.read).length;
  return `
  <div class="page-hd">
    <div class="page-hd-left"><div class="page-title">Notifications</div><div class="page-sub">${unread} unread notification${
    unread !== 1 ? 's' : ''
  }</div></div>
    <div class="page-hd-right"><button class="btn btn-ghost btn-sm" onclick="markAllRead()">✓ Mark All Read</button></div>
  </div>
  <div class="card p-0 notif-panel">
    ${
      notifications.length === 0
        ? `<div class="empty"><div class="empty-icon">🔔</div><div class="empty-title">All caught up!</div></div>`
        : `
    ${notifications
      .map(
        notification => `
      <div class="notif-item${notification.read ? '' : ' unread'}" onclick="markNotifRead('${
          notification.id
        }')">
        <div class="notif-icon" style="background:${
          notification.type === 'success'
            ? 'var(--green-dim)'
            : notification.type === 'warning'
            ? 'var(--yellow-dim)'
            : notification.type === 'error'
            ? 'var(--red-dim)'
            : 'var(--accent-dim)'
        }">${notification.icon || '🔔'}</div>
        <div class="notif-content">
          <div class="notif-title" style="${
            notification.read ? '' : 'font-weight:600'
          }">${escapeHtml(notification.title || 'Notification')}</div>
          <div class="notif-msg">${escapeHtml(notification.msg || notification.message || '')}</div>
          <div class="notif-time">${escapeHtml(notification.time || '')}</div>
          ${
            ['event_cancelled', 'booking_cancelled', 'request_cancelled'].includes(
              notification.notificationType || notification.type
            ) &&
            (notification.requestId || notification.eventId)
              ? `<button type="button" class="btn btn-ghost btn-sm mt-8" onclick="event.stopPropagation();openClientCancellationNotification('${escapeHtml(
                  String(notification.id)
                )}')">View Cancellation Details</button>`
              : ''
          }
        </div>
        ${!notification.read ? `<div class="unread-dot"></div>` : ''}
      </div>`
      )
      .join('')}`
    }
  </div>`;
}
function markNotifRead(id) {
  const n = DB.notifications.find(notification => notification.id == id);
  if (!n) return;
  n.read = true;
  saveDB();
  updateNotifDot();
  if (isDepartmentEmployee()) buildEmployeeNav(CU.employeeType);
  else buildNav(CU.role);
  renderPage('notifications');
}
function markAllRead() {
  visibleNotifications().forEach(n => (n.read = true));
  renderPage('notifications');
  updateNotifDot();
  if (isDepartmentEmployee()) buildEmployeeNav(CU.employeeType);
  else buildNav(CU.role);
  toast('All notifications marked as read', 'success');
}

// ════════════════════════════════════════════════
//  PROFILE
// ════════════════════════════════════════════════
function pageDepartmentEmployeeProfile() {
  const type = CU.employeeType;
  const profile = {
    REGISTRATION_VERIFICATION: {
      title: 'User Executive',
      purpose:
        'Protect event access by reviewing registrations, validating attendee documents, and resolving account verification issues.',
      focus: [
        'Review pending registrations and identity documents',
        'Verify attendee eligibility and ticket details',
        'Resolve account access and registration queries',
      ],
      primaryAction: "goNav('registrations')",
      primaryLabel: 'Open Registrations',
      secondaryAction: "goNav('attendees')",
      secondaryLabel: 'Manage Attendees',
    },
    EVENT_OPERATIONS: {
      title: 'Event Executive',
      purpose:
        'Coordinate event readiness and live delivery, from event information and operational plans to post-event reporting.',
      focus: [
        'Maintain event schedules, venues, and operational details',
        'Prepare and track event-operation tasks',
        'Coordinate changes with organizers and clients',
      ],
      primaryAction: "goNav('events')",
      primaryLabel: 'Manage Events',
      secondaryAction: "goNav('event-requests')",
      secondaryLabel: 'Open Operations',
    },
    SUPPORT_FINANCE: {
      title: 'Customer Support & Finance Executive',
      purpose:
        'Resolve customer requests and maintain accurate payment, refund, and service-operation records.',
      focus: [
        'Respond to customer support requests',
        'Review transactions and refund cases',
        'Maintain service and finance operational reports',
      ],
      primaryAction: "goNav('support-center')",
      primaryLabel: 'Open Support Center',
      secondaryAction: "goNav('finance')",
      secondaryLabel: 'Open Finance',
    },
  }[type];
  if (!profile) return '';
  const registrations = DB.registrations || [];
  const supportRequests = DB.supportRequests || [];
  const transactions = DB.financeTransactions || [];
  const events = DB.events || [];
  const verificationPending = registrations.filter(
    registration =>
      !registration.verified ||
      ['Pending Review', 'Flagged', 'pending'].includes(
        registration.verificationStatus || registration.status
      )
  ).length;
  const verified = registrations.filter(
    registration => registration.verified || registration.verificationStatus === 'Verified'
  ).length;
  const activeEvents = events.filter(event =>
    ['upcoming', 'ongoing'].includes(event.status)
  ).length;
  const operationalTasks = (DB.eventOperationsTasks || []).filter(
    task => !task.status || !['completed', 'done'].includes(String(task.status).toLowerCase())
  ).length;
  const openSupport = supportRequests.filter(
    request => !['Resolved', 'Closed'].includes(request.status)
  ).length;
  const refundsToReview = (DB.financeRefunds || []).filter(
    r => !['Approved', 'Completed', 'Rejected'].includes(r.status)
  ).length;
  const metrics =
    type === 'REGISTRATION_VERIFICATION'
      ? [
          ['Pending reviews', verificationPending, 'var(--yellow)'],
          ['Verified attendees', verified, 'var(--green)'],
          ['Registration records', registrations.length, 'var(--accent)'],
        ]
      : type === 'EVENT_OPERATIONS'
      ? [
          ['Active events', activeEvents, 'var(--accent)'],
          ['Open operations tasks', operationalTasks, 'var(--yellow)'],
          ['Event requests', (DB.eventRequests || []).length, 'var(--green)'],
        ]
      : [
          ['Open support requests', openSupport, 'var(--yellow)'],
          ['Transactions reviewed', transactions.length, 'var(--blue)'],
          ['Refunds awaiting review', refundsToReview, 'var(--red)'],
        ];
  return `
  <div class="page-hd"><div class="page-hd-left"><div class="page-title">My Employee Profile</div><div class="page-sub">Your department responsibilities and work overview.</div></div><div class="page-hd-right"><button class="btn btn-ghost" onclick="goNav('settings')">Edit Profile</button></div></div>
  <div class="profile-banner">
    ${
      CU.avatarImage
        ? `<div class="av av-xl"><img src="${CU.avatarImage}" alt="${
            CU.name
          }" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><span style="display:none">${
            CU.avatar || CU.name[0]
          }</span></div>`
        : `<div class="av av-xl">${CU.avatar || CU.name[0]}</div>`
    }
    <div class="profile-info">
      <div class="profile-name">${CU.name}</div>
      <div class="profile-role-tag">${profile.title}</div>
      <div class="small mt-4">${CU.service || EMPLOYEE_TYPE_LABELS[type]}</div>
      <span class="badge badge-green mt-8">Active employee account</span>
    </div>
  </div>
  <div class="grid-3 mb-20">
    ${metrics
      .map(
        ([label, value, color]) =>
          `<div class="card"><div class="label">${label}</div><div class="stat-value" style="color:${color};margin-top:10px">${value}</div></div>`
      )
      .join('')}
  </div>
  <div class="grid-2" style="align-items:start;gap:20px">
    <div class="card">
      <div class="h4 mb-14">Role & Responsibilities</div>
      <p style="font-size:13.5px;color:var(--text2);line-height:1.7;margin-bottom:16px">${
        profile.purpose
      }</p>
      <div class="label mb-8">Core responsibilities</div>
      <div style="display:flex;flex-direction:column;gap:10px">${profile.focus
        .map(
          item =>
            `<div style="display:flex;gap:9px;align-items:flex-start;color:var(--text2)"><span style="color:var(--green);font-weight:700">&#10003;</span><span>${item}</span></div>`
        )
        .join('')}</div>
    </div>
    <div style="display:flex;flex-direction:column;gap:16px">
      <div class="card">
        <div class="h4 mb-14">Employee Details</div>
        <div class="info-row"><span class="info-label">Department</span><span class="info-value">${
          EMPLOYEE_TYPE_LABELS[type]
        }</span></div>
        <div class="info-row"><span class="info-label">Email</span><span class="info-value">${
          CU.email
        }</span></div>
        <div class="info-row"><span class="info-label">Phone</span><span class="info-value">${
          CU.phone || 'Not set'
        }</span></div>
        <div class="info-row"><span class="info-label">Location</span><span class="info-value">${
          CU.city || 'Not set'
        }</span></div>
        <div class="info-row"><span class="info-label">Member since</span><span class="info-value">${
          CU.joined || 'Not set'
        }</span></div>
      </div>
      <div class="card">
        <div class="h4 mb-14">Work Tools</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          <button class="btn btn-primary w-full" onclick="${profile.primaryAction}">${
    profile.primaryLabel
  }</button>
          <button class="btn btn-ghost w-full" onclick="${profile.secondaryAction}">${
    profile.secondaryLabel
  }</button>
          <button class="btn btn-ghost w-full" onclick="goNav('reports')">View Department Reports</button>
        </div>
      </div>
    </div>
  </div>`;
}
function pageProfile() {
  if (isDepartmentEmployee()) return pageDepartmentEmployeeProfile();
  const regs =
    CU.role === 'attendee'
      ? DB.registrations.filter(registration => registration.attendeeId === CU.id)
      : [];
  const myEvs = CU.role === 'organizer' ? DB.events.filter(event => event.organizer === CU.id) : [];
  const isSF = CU.role === 'employee' && CU.employeeType === 'SUPPORT_FINANCE';
  const sfSupportHandled = (DB.supportRequests || []).length;
  const sfResolved = (DB.supportRequests || []).filter(
    r => r.status === 'Resolved' || r.status === 'Closed'
  ).length;
  const sfTxnsReviewed = (DB.financeTransactions || []).length;
  const sfReportsSubmitted = (DB.operationalReports || []).filter(
    r => r.status === 'Submitted' || r.status === 'Reviewed'
  ).length;
  return `
  <div class="page-hd"><div class="page-hd-left"><div class="page-title">My Profile</div></div><div class="page-hd-right"><button class="btn btn-ghost" onclick="goNav('settings')">✏️ Edit Profile</button></div></div>
  <div class="profile-banner">
    ${
      CU.avatarImage
        ? `<div class="av av-xl"><img src="${CU.avatarImage}" alt="${
            CU.name
          }" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><span style="display:none">${
            CU.avatar || CU.name[0]
          }</span></div>`
        : `<div class="av av-xl">${CU.avatar || CU.name[0]}</div>`
    }
    <div class="profile-info">
      <div class="profile-name">${CU.name}</div>
      <div class="profile-role-tag">${
        isSF ? 'Customer Support &amp; Finance Executive' : ROLE_LABELS[CU.role]
      }</div>
      ${CU.company ? `<div class="small mt-4">${CU.company}</div>` : ''}
      ${
        CU.specialization
          ? `<div class="small mt-4">Specialization: ${CU.specialization}</div>`
          : ''
      }
      ${CU.service ? `<div class="small mt-4">Service: ${CU.service}</div>` : ''}
      <span class="badge badge-green mt-8">Active Account</span>
    </div>
  </div>
  <div class="grid-2" style="align-items:start;gap:20px">
    <div class="card">
      <div class="h4 mb-14">Contact Information</div>
      <div class="info-row"><span class="info-label">Email</span><span class="info-value">${
        CU.email
      }</span></div>
      <div class="info-row"><span class="info-label">Phone</span><span class="info-value">${
        CU.phone || 'Not set'
      }</span></div>
      <div class="info-row"><span class="info-label">Member Since</span><span class="info-value">${
        CU.joined || '—'
      }</span></div>
      <div class="info-row"><span class="info-label">Role</span><span class="info-value"><span class="badge badge-${
        ROLE_COLORS[CU.role]
      }">${isSF ? 'Customer Support &amp; Finance Executive' : CU.role}</span></span></div>
      ${
        CU.bio
          ? `<div class="mt-14"><div class="label mb-8">Bio</div><p style="font-size:13.5px;color:var(--text2);line-height:1.7">${CU.bio}</p></div>`
          : ''
      }
    </div>
    <div>
      ${
        isSF
          ? `<div class="card mb-16">
        <div class="h4 mb-14">Work Summary</div>
        <div class="info-row"><span class="info-label">Support Requests Handled</span><span class="info-value" style="color:var(--accent);font-weight:700">${sfSupportHandled}</span></div>
        <div class="info-row"><span class="info-label">Issues Resolved</span><span class="info-value" style="color:var(--green);font-weight:700">${sfResolved}</span></div>
        <div class="info-row"><span class="info-label">Transactions Reviewed</span><span class="info-value" style="color:var(--blue);font-weight:700">${sfTxnsReviewed}</span></div>
        <div class="info-row"><span class="info-label">Reports Submitted</span><span class="info-value" style="color:var(--purple);font-weight:700">${sfReportsSubmitted}</span></div>
      </div>`
          : CU.role === 'attendee'
          ? `<div class="card mb-16">
        <div class="h4 mb-14">Activity Summary</div>
        <div class="info-row"><span class="info-label">Events Registered</span><span class="info-value">${
          regs.length
        }</span></div>
        <div class="info-row"><span class="info-label">Upcoming Events</span><span class="info-value" style="color:var(--accent)">${
          regs.filter(registration => {
            const event = DB.events.find(currentEvent => currentEvent.id === registration.eventId);
            return event && event.status === 'upcoming';
          }).length
        }</span></div>
        <div class="info-row"><span class="info-label">Events Attended</span><span class="info-value" style="color:var(--green)">${
          regs.filter(registration => registration.checkedIn).length
        }</span></div>
        <div class="info-row"><span class="info-label">Total Spent</span><span class="info-value" style="color:var(--green);font-weight:700">₹${regs.reduce(
          (total, registration) => total + registration.amount,
          0
        )}</span></div>
      </div>`
          : CU.role === 'organizer'
          ? `<div class="card mb-16">
        <div class="h4 mb-14">Event Summary</div>
        <div class="info-row"><span class="info-label">Total Events</span><span class="info-value">${
          myEvs.length
        }</span></div>
        <div class="info-row"><span class="info-label">Upcoming</span><span class="info-value" style="color:var(--accent)">${
          myEvs.filter(e => e.status === 'upcoming').length
        }</span></div>
        <div class="info-row"><span class="info-label">Completed</span><span class="info-value" style="color:var(--green)">${
          myEvs.filter(e => e.status === 'completed').length
        }</span></div>
      </div>`
          : ''
      }
      <div class="card">
        <div class="h4 mb-14">Quick Actions</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          <button class="btn btn-ghost w-full" onclick="goNav('settings')">⚙️ Account Settings</button>
          <button class="btn btn-danger w-full" onclick="doLogout()">🚪 Sign Out</button>
        </div>
      </div>
    </div>
  </div>`;
}

// ════════════════════════════════════════════════
//  SETTINGS
// ════════════════════════════════════════════════

function pageSettings() {
  return `
  <div class="page-hd"><div class="page-hd-left"><div class="page-title">Account Settings</div><div class="page-sub">Manage your personal information and account preferences.</div></div></div>
  <div class="grid-2" style="align-items:start;gap:20px">
    <div class="card card-lg">
      <div class="h4 mb-20">Personal Information</div>
      <div class="profile-banner" style="margin-bottom:20px;padding:18px">
        ${
          CU.avatarImage
            ? `<div class="av av-lg"><img src="${CU.avatarImage}" alt="${
                CU.name
              }" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><span style="display:none">${
                CU.avatar || CU.name[0]
              }</span></div>`
            : `<div class="av av-lg">${CU.avatar || CU.name[0]}</div>`
        }
        <div><div style="font-weight:700">${CU.name}</div><div class="small">${
    ROLE_LABELS[CU.role]
  }</div></div>
      </div>
      <div class="form-group"><label class="form-label">Full Name</label><input class="form-control" id="st-name" value="${
        CU.name
      }"></div>
      <div class="form-group"><label class="form-label">Email Address</label><input class="form-control" id="st-email" value="${
        CU.email
      }"></div>
      <div class="form-group"><label class="form-label">Phone Number</label><input class="form-control" id="st-phone" value="${
        CU.phone || ''
      }"></div>
      <div class="form-group"><label class="form-label">Bio</label><textarea class="form-control" id="st-bio">${
        CU.bio || ''
      }</textarea></div>
      <button class="btn btn-primary w-full" onclick="saveSettings()" style="justify-content:center">Save Changes</button>
    </div>
    <div style="display:flex;flex-direction:column;gap:20px">
      <div class="card card-lg">
        <div class="h4 mb-20">Change Password</div>
        <div class="form-group"><label class="form-label">Current Password</label><input class="form-control" id="st-cur" type="password" placeholder="Enter current password"></div>
        <div class="form-group"><label class="form-label">New Password</label><input class="form-control" id="st-new" type="password" placeholder="Min 6 characters"></div>
        <div class="form-group"><label class="form-label">Confirm New Password</label><input class="form-control" id="st-conf" type="password" placeholder="Re-enter new password"></div>
        <button class="btn btn-primary w-full" onclick="changePass()" style="justify-content:center">Update Password</button>
      </div>
      <div class="card">
        <div class="h4 mb-16">Preferences</div>
        <div class="info-row"><span class="info-label">Email Notifications</span><div class="toggle on" onclick="this.classList.toggle('on')"></div></div>
        <div class="info-row"><span class="info-label">SMS Reminders</span><div class="toggle" onclick="this.classList.toggle('on')"></div></div>
        <div class="info-row"><span class="info-label">Event Recommendations</span><div class="toggle on" onclick="this.classList.toggle('on')"></div></div>
      </div>
      <div class="card">
        <button class="btn btn-danger w-full mb-8" onclick="doLogout()" style="justify-content:center">Sign Out</button>
      </div>
    </div>
  </div>`;
}
function saveSettings() {
  const name = v('st-name');
  const email = v('st-email');
  const phone = v('st-phone');
  const bio = v('st-bio');
  if (!name) {
    toast('Name is required', 'error');
    return;
  }
  if (!email || !email.includes('@')) {
    toast('Enter a valid email', 'error');
    return;
  }
  if (window.EventFlowAccountPolicy.isEmailInUse(DB.users, email, CU.id || CU.userId)) {
    toast('Email already registered', 'error');
    return;
  }
  CU.name = name;
  CU.email = email;
  CU.phone = phone;
  CU.bio = bio;
  CU.avatar = name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
  const u = DB.users.find(user => user.id === CU.id);
  if (u) {
    Object.assign(u, {
      name,
      email,
      phone,
      bio,
      avatar: CU.avatar,
    });
  }
  g('sb-name').textContent = name;
  updateHeaderUser();
  g('sb-av').textContent = CU.avatar;
  toast('Settings saved successfully!', 'success');
}
function changePass() {
  const cur = v('st-cur');
  const nw = v('st-new');
  const conf = v('st-conf');
  if (!cur || !nw || !conf) {
    toast('Fill all password fields', 'error');
    return;
  }
  if (cur !== CU.password) {
    toast('Current password is incorrect', 'error');
    return;
  }
  if (nw.length < 6) {
    toast('Password must be at least 6 characters', 'error');
    return;
  }
  if (nw !== conf) {
    toast('Passwords do not match', 'error');
    return;
  }
  CU.password = nw;
  const u = DB.users.find(user => user.id === CU.id);
  if (u) u.password = nw;
  ['st-cur', 'st-new', 'st-conf'].forEach(id => {
    const element = g(id);
    if (element) element.value = '';
  });
  toast('Password changed successfully!', 'success');
}

// ════════════════════════════════════════════════
//  CLIENT PAGES
// ════════════════════════════════════════════════

function pageFindOrganizers() {
  const q = (sessionStorage.getItem('search_org_q') || '').trim().toLowerCase();
  const rating = sessionStorage.getItem('search_org_rating') || 'all';
  const category = sessionStorage.getItem('search_org_category') || 'all';
  const city = sessionStorage.getItem('search_org_city') || 'all';
  const pricing = sessionStorage.getItem('search_org_pricing') || 'all';
  let organizers = DB.users.filter(user => user.role === 'organizer');
  if (q) {
    organizers = organizers.filter(organizer =>
      [
        organizer.name,
        organizer.service,
        organizer.specialization,
        organizer.category,
        organizer.city,
        organizer.location,
      ]
        .filter(Boolean)
        .some(value => String(value).toLowerCase().includes(q))
    );
  }
  if (category !== 'all') {
    organizers = organizers.filter(
      organizer =>
        organizer.service === category ||
        organizer.eventTypes?.includes(category) ||
        (organizer.specializations && organizer.specializations.includes(category))
    );
  }
  if (city !== 'all') {
    organizers = organizers.filter(
      organizer =>
        (organizer.city || '').toLowerCase() === city.toLowerCase() ||
        (organizer.location || '').toLowerCase() === city.toLowerCase()
    );
  }
  if (rating !== 'all') {
    const minRating = parseFloat(rating);
    organizers = organizers.filter(organizer => (organizer.rating || 0) >= minRating);
  }
  if (pricing !== 'all') {
    organizers = organizers.filter(organizer => {
      const prices = (organizer.packages || [])
        .map(p => Number(String(p.price || '').replace(/[^0-9]/g, '')))
        .filter(n => !isNaN(n) && n > 0);
      const minPrice = prices.length ? Math.min(...prices) : 35000;
      if (pricing === 'under_50k') return minPrice < 50000;
      if (pricing === '50k_100k') return minPrice >= 50000 && minPrice <= 100000;
      if (pricing === '100k_250k') return minPrice >= 100000 && minPrice <= 250000;
      if (pricing === 'above_250k') return minPrice >= 250000;
      return true;
    });
  }
  return `
  <div class="page-hd">
    <div class="page-hd-left">
      <div class="page-title">Find Event Organisers</div>
      <div class="page-sub">Discover and connect with top-rated event organizers across India</div>
    </div>
  </div>
  
  <div class="filter-row" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px">
    <div class="search-box input-group" style="flex:1;min-width:240px;max-width:320px">
      <span class="input-icon">🔍</span>
      <input class="form-control" id="search-org-q" placeholder="Search by organizer or specialty..." value="${q}" oninput="searchOrganizers(this.value)">
    </div>
    <select class="form-control filter-select" id="search-org-category" onchange="filterOrganizers()">
      <option value="all">All Categories</option>
      <option ${category === 'Corporate Events' ? 'selected' : ''}>Corporate Events</option>
      <option ${category === 'Conferences' ? 'selected' : ''}>Conferences</option>
      <option ${
        category === 'Weddings & Social Events' ? 'selected' : ''
      }>Weddings & Social Events</option>
      <option ${category === 'Workshops' ? 'selected' : ''}>Workshops</option>
      <option ${category === 'Product Launches' ? 'selected' : ''}>Product Launches</option>
    </select>
    <select class="form-control filter-select" id="search-org-city" onchange="filterOrganizers()">
      <option value="all">All Locations</option>
      <option ${city === 'Mumbai' ? 'selected' : ''}>Mumbai</option>
      <option ${city === 'New Delhi' ? 'selected' : ''}>New Delhi</option>
      <option ${city === 'Bangalore' ? 'selected' : ''}>Bangalore</option>
      <option ${city === 'Hyderabad' ? 'selected' : ''}>Hyderabad</option>
      <option ${city === 'Chennai' ? 'selected' : ''}>Chennai</option>
    </select>
    <select class="form-control filter-select" id="search-org-rating" onchange="filterOrganizers()">
      <option value="all">All Ratings</option>
      <option value="4.5" ${rating === '4.5' ? 'selected' : ''}>4.5+ stars</option>
      <option value="4" ${rating === '4' ? 'selected' : ''}>4+ stars</option>
      <option value="3.5" ${rating === '3.5' ? 'selected' : ''}>3.5+ stars</option>
    </select>
    <select class="form-control filter-select" id="search-org-pricing" onchange="filterOrganizers()">
      <option value="all">All Pricing</option>
      <option value="under_50k" ${pricing === 'under_50k' ? 'selected' : ''}>Under ₹50,000</option>
      <option value="50k_100k" ${
        pricing === '50k_100k' ? 'selected' : ''
      }>₹50,000 – ₹1,00,000</option>
      <option value="100k_250k" ${
        pricing === '100k_250k' ? 'selected' : ''
      }>₹1,00,000 – ₹2,50,000</option>
      <option value="above_250k" ${pricing === 'above_250k' ? 'selected' : ''}>₹2,50,000+</option>
    </select>
  </div>
  
  <div style="margin-bottom:16px;color:var(--text2);font-size:13px">Showing ${
    organizers.length
  } event organiser${organizers.length !== 1 ? 's' : ''}</div>
  
  <div class="grid-3" style="gap:16px">
    ${
      organizers.length === 0
        ? `<div class="empty" style="grid-column:1/-1"><div class="empty-icon">🔍</div><div class="empty-title">No organizers found</div><p>Try adjusting your search filters</p></div>`
        : organizers
            .map(organizer => {
              const rt = Number(organizer.rating) || 0;
              const rv = Number(organizer.reviewCount) || 0;
              const prices = (organizer.packages || [])
                .map(p => Number(String(p.price || '').replace(/[^0-9]/g, '')))
                .filter(n => !isNaN(n) && n > 0);
              const startPrice = prices.length ? Math.min(...prices) : 35000;
              const orgAv = organizer.avatarImage
                ? `
          <div style="width:56px;height:56px;border-radius:50%;overflow:hidden;flex-shrink:0;border:2px solid ${
            organizer.color || 'var(--accent)'
          }40;position:relative">
            <img src="${organizer.avatarImage}" alt="${
                    organizer.name
                  }" style="width:100%;height:100%;object-fit:cover" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
            <div style="display:none;width:100%;height:100%;align-items:center;justify-content:center;background:${
              organizer.color || 'var(--accent)'
            }20;font-size:20px;font-weight:700;color:${organizer.color || 'var(--accent)'}">${
                    organizer.avatar || organizer.name[0]
                  }</div>
          </div>
        `
                : `<div style="width:56px;height:56px;border-radius:50%;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:${
                    organizer.color || 'var(--accent)'
                  }15;font-size:20px;font-weight:700;color:${
                    organizer.color || 'var(--accent)'
                  };border:2px solid ${organizer.color || 'var(--accent)'}30">${
                    organizer.avatar || organizer.name[0]
                  }</div>`;
              return `
      <div class="card" style="padding:16px;display:flex;flex-direction:column;gap:12px;transition:transform .18s,box-shadow .18s;cursor:pointer" onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 8px 28px rgba(0,0,0,0.12)'" onmouseout="this.style.transform='';this.style.boxShadow=''" onclick="viewOrganizerProfile('${
        organizer.id
      }')">
        <div style="display:flex;align-items:center;gap:12px">
          ${orgAv}
          <div style="flex:1;min-width:0">
            <div style="display:flex;align-items:center;gap:6px;margin-bottom:2px">
              <span style="font-weight:700;font-size:14.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${
                organizer.name
              }</span>
              <span style="background:var(--yellow);color:#1a1400;padding:1px 7px;border-radius:10px;font-size:10.5px;font-weight:700;flex-shrink:0">⭐ ${
                rt ? rt.toFixed(1) : '—'
              }</span>
            </div>
            <div style="font-size:12px;color:var(--accent);font-weight:500;margin-bottom:2px">${
              organizer.service || 'Event Organizer'
            }</div>
            <div style="font-size:11.5px;color:var(--text3)">📍 ${organizer.city || 'India'}</div>
          </div>
        </div>
        <p style="font-size:12px;color:var(--text2);line-height:1.5;margin:0;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">${
          organizer.bio || 'Professional event organizer with extensive industry experience.'
        }</p>
        <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;flex-wrap:wrap">
          <span style="background:var(--surface3);padding:3px 10px;border-radius:6px;font-size:11px;color:var(--text2)"><strong style="color:var(--text)">${rv}</strong> reviews</span>
          <span style="background:rgba(16,185,129,0.12);color:var(--green);padding:3px 10px;border-radius:6px;font-size:11.5px;font-weight:700">Starts at ₹${startPrice.toLocaleString()}</span>
        </div>
        <button class="btn btn-primary btn-sm w-full" onclick="event.stopPropagation();viewOrganizerProfile('${
          organizer.id
        }')" style="justify-content:center;padding:8px;font-size:12.5px">View Profile & Request Event</button>
      </div>`;
            })
            .join('')
    }
  </div>`;
}
function searchOrganizers(q) {
  sessionStorage.setItem('search_org_q', q);
  renderPage('find-organizers');
}
function filterOrganizers() {
  const rating = g('search-org-rating')?.value || 'all';
  const category = g('search-org-category')?.value || 'all';
  const city = g('search-org-city')?.value || 'all';
  const pricing = g('search-org-pricing')?.value || 'all';
  sessionStorage.setItem('search_org_rating', rating);
  sessionStorage.setItem('search_org_category', category);
  sessionStorage.setItem('search_org_city', city);
  sessionStorage.setItem('search_org_pricing', pricing);
  renderPage('find-organizers');
}
function filterOrganizerCity() {
  filterOrganizers();
}
async function viewOrganizerProfile(organizerId) {
  const organizer = DB.users.find(user => String(user.id) === String(organizerId));
  if (!organizer) return;
  let profileReviews;
  let profileReviewsError = '';
  try {
    const response = await apiGetOrganizerProfileReviews(organizer.organizerId || organizerId);
    profileReviews = response.data || response;
  } catch (error) {
    profileReviewsError = error.message || 'Unable to load organizer reviews';
    toast(profileReviewsError, 'error');
  }
  const reviews = profileReviews?.reviews || [];
  const totalReviews = Number(profileReviews?.totalReviews ?? organizer.reviewCount) || 0;
  const rating = Number(profileReviews?.averageRating ?? organizer.rating) || 0;
  const yrs = Number(organizer.yearsExperience) || 1;
  const completed = Number(organizer.completedEvents) || 0;
  const specs = organizer.specializations || [];
  const packages = organizer.packages || [];
  const orgModalAv = organizer.avatarImage
    ? `<div style="width:80px;height:80px;border-radius:14px;overflow:hidden;flex-shrink:0;border:2px solid ${
        organizer.color || 'var(--accent)'
      }40"><img src="${organizer.avatarImage}" alt="${escapeHtml(
        organizer.name
      )}" style="width:100%;height:100%;object-fit:cover" onerror="this.style.display='none'"></div>`
    : `<div style="width:80px;height:80px;display:flex;align-items:center;justify-content:center;background:${
        organizer.color || 'var(--accent)'
      }20;border-radius:14px;flex-shrink:0;font-size:32px;font-weight:700;color:${
        organizer.color || 'var(--accent)'
      }">${organizer.avatar || organizer.name[0]}</div>`;
  openModal(
    `${escapeHtml(organizer.name)} — Organizer Profile`,
    `
    <div style="background:linear-gradient(135deg,${organizer.color || 'var(--accent)'}20,${
      organizer.color || 'var(--accent)'
    }05);border-radius:14px;padding:20px;margin-bottom:20px;border:1px solid ${
      organizer.color || 'var(--accent)'
    }30">
      <div style="display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap">
        ${orgModalAv}
        <div style="flex:1;min-width:200px">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;flex-wrap:wrap">
            <div style="font-weight:700;font-size:20px">${escapeHtml(organizer.name)}</div>
            ${
              organizer.verified
                ? `<span style="background:rgba(5,150,105,0.15);color:var(--green);font-size:11px;font-weight:700;padding:3px 10px;border-radius:12px;border:1px solid rgba(5,150,105,0.3)">✓ Verified</span>`
                : ''
            }
          </div>
          <div style="color:${
            organizer.color || 'var(--accent)'
          };font-weight:600;margin-bottom:8px">${escapeHtml(
      organizer.service || 'Event Organizer'
    )}</div>
          <div style="display:flex;gap:10px;margin-bottom:10px;flex-wrap:wrap">
            <span style="background:var(--yellow);color:#1a1400;padding:2px 10px;border-radius:12px;font-size:12px;font-weight:600">⭐ ${
              rating ? rating.toFixed(1) : '—'
            }</span>
            <span style="color:var(--text2);font-size:13px">${totalReviews} reviews</span>
            <span style="color:var(--text2);font-size:13px">📍 ${escapeHtml(
              organizer.city || 'India'
            )}</span>
          </div>
          <p style="color:var(--text2);font-size:13px;line-height:1.6;margin:0 0 12px">${escapeHtml(
            organizer.bio || 'Professional event organizer.'
          )}</p>
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px">
            <div style="text-align:center;padding:10px;background:var(--surface2);border-radius:10px">
              <div style="font-size:18px;font-weight:700;color:var(--text)">${yrs}+</div>
              <div style="font-size:11px;color:var(--text3)">Years Exp.</div>
            </div>
            <div style="text-align:center;padding:10px;background:var(--surface2);border-radius:10px">
              <div style="font-size:18px;font-weight:700;color:var(--text)">${completed}</div>
              <div style="font-size:11px;color:var(--text3)">Events Done</div>
            </div>
            <div style="text-align:center;padding:10px;background:var(--surface2);border-radius:10px">
              <div style="font-size:18px;font-weight:700;color:var(--text)">${totalReviews}</div>
              <div style="font-size:11px;color:var(--text3)">Reviews</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    ${
      specs.length
        ? `<div style="margin-bottom:20px">
      <div class="h4 mb-12">🎯 Specializations</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">${specs
        .map(
          s =>
            `<span style="background:${organizer.color || 'var(--accent)'}18;color:${
              organizer.color || 'var(--accent)'
            };padding:5px 14px;border-radius:20px;font-size:12px;font-weight:500;border:1px solid ${
              organizer.color || 'var(--accent)'
            }30">${escapeHtml(s)}</span>`
        )
        .join('')}</div>
    </div>`
        : ''
    }

    ${
      packages.length
        ? `<div style="margin-bottom:20px">
      <div class="h4 mb-12">📦 Service Packages</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px">
        ${packages
          .map(
            pkg => `<div style="padding:14px;background:var(--surface2);border-radius:10px;border:1px solid var(--border);border-top:3px solid ${
              organizer.color || 'var(--accent)'
            }">
          <div style="font-weight:700;font-size:14px;margin-bottom:4px">${escapeHtml(
            pkg.name
          )}</div>
          <div style="font-size:16px;font-weight:700;color:${
            organizer.color || 'var(--accent)'
          };margin-bottom:8px">${escapeHtml(pkg.price)}</div>
          <div style="font-size:12px;color:var(--text2);line-height:1.5">${escapeHtml(
            pkg.desc
          )}</div>
        </div>`
          )
          .join('')}
      </div>
    </div>`
        : ''
    }



    <div style="margin-bottom:20px">
      <div class="h4 mb-12">💬 Client Reviews</div>
      ${
        profileReviewsError
          ? `<p style="color:var(--danger);font-size:13px">${escapeHtml(profileReviewsError)}</p>`
          : reviews.length
          ? `<div style="display:flex;flex-direction:column;gap:10px">${reviews
              .map(
                review => `
        <article style="padding:16px;background:var(--surface3);border:1px solid var(--border);border-radius:8px">
          <div style="font-size:11px;color:var(--text3);margin-bottom:4px">Event name</div>
          <div style="font-size:14px;font-weight:600;overflow-wrap:anywhere">${escapeHtml(
            review.eventName || 'Past event'
          )}</div>
          <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap;margin-top:10px">
            <span><strong style="color:var(--yellow);letter-spacing:2px">${'★'.repeat(
              Number(review.rating)
            )}${'☆'.repeat(
                  5 - Number(review.rating)
                )}</strong> <span style="font-size:12px;font-weight:600">${
                  review.rating
                }/5</span></span>
            <time style="font-size:12px;color:var(--text3)">${escapeHtml(
              String(review.createdAt || '').slice(0, 10)
            )}</time>
          </div>
          <p style="margin:10px 0 12px;color:var(--text2);font-size:13px;line-height:1.6;white-space:pre-wrap;overflow-wrap:anywhere">${escapeHtml(
            review.comment
          )}</p>
          <div style="font-size:12px;color:var(--text2)">By <strong>${escapeHtml(
            review.reviewerName || 'Client'
          )}</strong></div>
        </article>`
              )
              .join('')}</div>`
          : '<p style="color:var(--text3);font-size:13px">No client reviews yet.</p>'
      }
    </div>

    <div style="margin-bottom:20px">
      <div class="h4 mb-12">📞 Contact Information</div>
      <div style="display:flex;flex-direction:column;gap:8px">
        <div style="display:flex;align-items:center;gap:10px;padding:12px;background:var(--surface3);border-radius:8px"><span>✉️</span><div><div style="font-size:11px;color:var(--text3)">Email</div><div style="font-weight:500">${escapeHtml(
          organizer.email || '—'
        )}</div></div></div>
        <div style="display:flex;align-items:center;gap:10px;padding:12px;background:var(--surface3);border-radius:8px"><span>📞</span><div><div style="font-size:11px;color:var(--text3)">Phone</div><div style="font-weight:500">${escapeHtml(
          organizer.phone || '+91 9876543210'
        )}</div></div></div>
        <div style="display:flex;align-items:center;gap:10px;padding:12px;background:var(--surface3);border-radius:8px"><span>📍</span><div><div style="font-size:11px;color:var(--text3)">Location</div><div style="font-weight:500">${escapeHtml(
          organizer.city || 'India'
        )}</div></div></div>
      </div>
    </div>
  `,
    [
      {
        lbl: 'Request Event',
        cls: 'btn-primary',
        fn: `closeModal();openRequestModal('${organizerId}')`,
      },
    ],
    true
  );
}
function contactOrganizer(organizerId) {
  const organizer = DB.users.find(user => user.id === organizerId);
  if (!organizer) return;
  toast(`Opening contact form for ${organizer.name}...`, 'info');
}
let eventRequestDraft = null;
let isSubmittingEventRequest = false;
async function openRequestModal(organizerId, keepDraft = false) {
  try {
    await loadWorkflowEventPolicy();
  } catch (error) {
    toast(error.message || 'Unable to load event policies', 'error');
    return;
  }
  const organizer = DB.users.find(user => String(user.id) === String(organizerId));
  if (!organizer) return;
  const draft =
    keepDraft && eventRequestDraft?.organizerId === organizerId ? eventRequestDraft : {};
  openModal(
    `Request Event — ${escapeHtml(organizer.name)}`,
    `
    <p style="font-size:13px;color:var(--text2);margin-bottom:16px">Fill in the details below. The organizer will review your request and respond with a proposal.</p>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="form-group" style="grid-column:1/-1"><label class="form-label">Event Title *</label><input class="form-control" id="req-title" value="${escapeHtml(
        draft.eventName || ''
      )}" placeholder="e.g., Annual Product Launch 2026"></div>
      <div class="form-group"><label class="form-label">Event Type *</label><select class="form-control" id="req-type">${[
        'Corporate Events',
        'Conferences',
        'Weddings &amp; Social Events',
        'Workshops',
        'Festivals',
        'Product Launches',
        'Other',
      ]
        .map(type => `<option${draft.eventType === type ? ' selected' : ''}>${type}</option>`)
        .join('')}</select></div>
      <div class="form-group"><label class="form-label">Expected Guests *</label><input class="form-control" id="req-guests" type="number" min="1" value="${escapeHtml(
        String(draft.capacity || '')
      )}" placeholder="100"></div>
      <div class="form-group"><label class="form-label">Event Date *</label><input class="form-control" id="req-date" type="date" value="${escapeHtml(
        draft.eventDate || ''
      )}"></div>
      <div class="form-group"><label class="form-label">City *</label><input class="form-control" id="req-city" value="${escapeHtml(
        draft.city || organizer.city || ''
      )}" placeholder="e.g., Mumbai"></div>
      <div class="form-group"><label class="form-label">Budget (INR) *</label><input class="form-control" id="req-budget" type="number" min="1000" value="${escapeHtml(
        String(draft.budget || '')
      )}" placeholder="50000"></div>
      <div class="form-group"><label class="form-label" for="req-ticket-price">Ticket Price per Attendee (INR)</label><input class="form-control" id="req-ticket-price" type="number" min="0" step="0.01" value="${escapeHtml(
        String(draft.ticketPrice ?? 0)
      )}" placeholder="0"><p class="small muted">Set 0 for free admission.</p></div>
      <div class="form-group"><label class="form-label" for="req-visibility">Event Access</label><select class="form-control" id="req-visibility"><option value="public"${
        draft.visibility !== 'private' ? ' selected' : ''
      }>Public — direct registration</option><option value="private"${
      draft.visibility === 'private' ? ' selected' : ''
    }>Private — organizer approval required</option></select><p class="small muted">Public events allow direct payment and registration. Private events require approval before payment.</p></div>
      <div class="form-group" style="grid-column:1/-1"><label class="form-label">Preferred Venue (optional)</label><input class="form-control" id="req-venue" value="${escapeHtml(
        draft.venue || ''
      )}" placeholder="Venue name, landmark, or area"></div>
      <div class="form-group" style="grid-column:1/-1"><label class="form-label">Event Description &amp; Requirements *</label><textarea class="form-control" id="req-desc" rows="4" placeholder="Describe your event vision, key requirements, special arrangements, theme, guest profile...">${escapeHtml(
        draft.requirements || ''
      )}</textarea></div>
    </div>
    ${renderWorkflowEventPolicy(workflowEventPolicy, 'req-policy')}
  `,
    [
      {
        lbl: 'Review Request',
        cls: 'btn-primary',
        fn: `reviewEventRequest('${organizerId}')`,
      },
    ]
  );
}
function reviewEventRequest(organizerId) {
  isSubmittingEventRequest = false;
  const eventName = v('req-title').trim();
  const eventType = v('req-type');
  const eventDate = v('req-date');
  const capacity = Number(v('req-guests'));
  const requirements = v('req-desc').trim();
  const venue = v('req-venue').trim();
  const budget = Number(v('req-budget'));
  const ticketPrice = Number(v('req-ticket-price') || 0);
  const visibility = v('req-visibility') || 'public';
  const city = v('req-city').trim();
  const todayDate = new Date().toISOString().slice(0, 10);
  if (
    !eventName ||
    !eventDate ||
    !city ||
    !Number.isInteger(capacity) ||
    capacity < 1 ||
    capacity > 50000 ||
    !Number.isFinite(budget) ||
    budget < 1000 ||
    budget > 10000000 ||
    !requirements
  ) {
    if (capacity > 50000) {
      toast('Maximum event capacity is 50,000', 'error');
      return;
    }
    if (budget > 10000000) {
      toast('Event budget cannot exceed ₹1,00,00,000', 'error');
      return;
    }
    if (budget < 1000) {
      toast('Event budget must be at least ₹1,000', 'error');
      return;
    }
    toast(
      'Please complete all required fields: title, date, city, guests (1–50,000), budget (₹1,000–₹1,00,00,000), and description',
      'error'
    );
    return;
  }
  if (eventDate <= todayDate) {
    toast('Event date must be in the future', 'error');
    return;
  }
  if (
    !Number.isFinite(ticketPrice) ||
    ticketPrice < 0 ||
    ticketPrice > 100000 ||
    Math.abs(ticketPrice * 100 - Math.round(ticketPrice * 100)) > 0.000001
  ) {
    toast(
      ticketPrice > 100000
        ? 'Ticket price cannot exceed ₹1,00,000'
        : 'Enter a ticket price of ₹0 to ₹1,00,000, with up to 2 decimal places.',
      'error'
    );
    return;
  }
  const acknowledgement = workflowPolicyAcknowledgement(workflowEventPolicy, 'req-policy');
  if (!['public', 'private'].includes(visibility)) {
    toast('Choose Public or Private event access.', 'error');
    return;
  }
  if (!acknowledgement) return;
  eventRequestDraft = {
    ...acknowledgement,
    organizerId,
    clientId: CU.id,
    eventName,
    eventType,
    eventDate,
    capacity,
    city,
    requirements,
    venue,
    budget,
    ticketPrice,
    visibility,
  };
  const items = [
    ['Event Title', eventName],
    ['Event Type', eventType],
    ['Date', eventDate],
    ['City', city],
    ['Expected Guests', capacity],
    ['Budget', `₹${budget.toLocaleString()}`],
    [
      'Ticket Price per Attendee',
      ticketPrice === 0 ? 'Free' : `₹${ticketPrice.toLocaleString('en-IN')}`,
    ],
    [
      'Event Access',
      visibility === 'private'
        ? 'Private — organizer approval before payment'
        : 'Public — direct payment and registration',
    ],
    ['Preferred Venue', venue || '—'],
    ['Description', requirements],
  ];
  openModal(
    'Review Event Request',
    `<div class="small mb-16" style="color:var(--text2)">Review the details below before sending your request to the organizer.</div><div style="display:flex;flex-direction:column;gap:8px">${items
      .map(
        ([label, value]) =>
          `<div style="padding:10px 12px;background:var(--surface3);border-radius:8px;display:grid;grid-template-columns:130px 1fr;gap:8px"><div class="small" style="color:var(--text3)">${label}</div><div style="font-size:13px;white-space:pre-wrap;overflow-wrap:anywhere">${escapeHtml(
            String(value)
          )}</div></div>`
      )
      .join('')}</div>`,
    [
      {
        lbl: 'Back to Edit',
        cls: 'btn-ghost',
        fn: `openRequestModal('${organizerId}', true)`,
      },
      {
        lbl: 'Submit Request',
        cls: 'btn-primary',
        fn: 'submitEventRequest()',
      },
    ]
  );
}
async function submitEventRequest(organizerId) {
  if (!eventRequestDraft || isSubmittingEventRequest) return;
  isSubmittingEventRequest = true;
  const foot = typeof g === 'function' ? g('modal-foot') : null;
  const submitBtn =
    foot && foot.querySelector
      ? foot.querySelector('.btn-primary')
      : typeof document !== 'undefined' && document.querySelector
      ? document.querySelector('#modal-foot .btn-primary')
      : null;
  const originalText = submitBtn ? submitBtn.textContent : '';
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.textContent = 'Submitting...';
  }
  try {
    const response = await apiCreateEventRequest(eventRequestDraft);
    eventRequestDraft = null;
    if (typeof syncWorkflowData === 'function') {
      await syncWorkflowData();
    }
    closeModal();
    toast(response?.message || 'Request sent to organizer!', 'success');
    if (typeof renderPage === 'function' && typeof _currentPage !== 'undefined') {
      await renderPage(_currentPage);
    }
  } catch (error) {
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.textContent = originalText || 'Submit Request';
    }
    const errorMsg =
      error?.message ||
      (Array.isArray(error?.data?.message)
        ? error.data.message.join(', ')
        : 'Unable to submit the event request');
    toast(errorMsg, 'error');
  } finally {
    isSubmittingEventRequest = false;
  }
}
function pageUpcomingEvents() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const upcoming = DB.events
    .filter(event => {
      const eDate = new Date(event.date);
      return eDate >= today && event.status === 'upcoming';
    })
    .sort((leftEvent, rightEvent) => new Date(leftEvent.date) - new Date(rightEvent.date));
  return `
  <div class="page-hd">
    <div class="page-hd-left">
      <div class="page-title">Upcoming Events</div>
      <div class="page-sub">Events happening soon that you might be interested in</div>
    </div>
  </div>
  <div class="events-grid">${
    upcoming.length === 0
      ? `<div class="empty" style="grid-column:1/-1"><div class="empty-icon">📅</div><div class="empty-title">No upcoming events</div></div>`
      : upcoming.map(event => evCard(event, CU.role === 'client' ? 'client' : 'attendee')).join('')
  }</div>`;
}
function getClientWorkflowEvents() {
  if (!CU || CU.role !== 'client') {
    const publicList = (DB.events || []).filter(event => event.status !== 'cancelled');
    return {
      upcoming: publicList.filter(e => e.status === 'upcoming' || e.status === 'published'),
      ongoing: publicList.filter(e => e.status === 'ongoing'),
      completed: publicList.filter(e => e.status === 'completed'),
      all: publicList,
    };
  }
  const clientProfile = DB.clients
    ? DB.clients.find(
        client =>
          String(client.userId) === String(CU.id) || String(client.clientId) === String(CU.id)
      )
    : null;
  const clientUserId = String(CU.id);
  const clientId = clientProfile ? String(clientProfile.clientId) : clientUserId;

  // Find requests belonging to this authenticated client
  const myRequests = (DB.eventRequests || []).filter(request => {
    const rClientId = String(request.clientId || '');
    const rClientUserId = String(request.clientUserId || '');
    const rClient = String(request.client || '');
    return (
      rClientId === clientId ||
      rClientId === clientUserId ||
      rClientUserId === clientUserId ||
      rClient === clientUserId
    );
  });
  const isPlanningRequest = request =>
    !['confirmed', 'approved', 'completed'].includes(request.status) &&
    (['planning', 'plan_submitted', 'plan_revision_requested'].includes(request.status) ||
      Boolean(request.activeEventPlanId) ||
      (request.auditHistory || []).some(
        entry => entry.action === 'Client Accepted Requested Changes'
      ));

  // Include planning work without treating it as a confirmed or paid booking.
  const activeRequests = myRequests.filter(request => {
    if (['withdrawn', 'rejected', 'expired', 'cancelled'].includes(request.status)) return false;
    if (request.cancellation) return false;
    return (
      ['confirmed', 'completed', 'approved'].includes(request.status) || isPlanningRequest(request)
    );
  });

  // Map requests by eventId and requestId for deduplication
  const requestByEventId = new Map();
  const requestById = new Map();
  activeRequests.forEach(request => {
    if (request.eventId) requestByEventId.set(String(request.eventId), request);
    requestById.set(String(request.id || request.requestId), request);
  });
  const matchedEventIds = new Set();
  const unifiedEvents = [];

  // Scan DB.events for records belonging to this client or linked to their requests
  (DB.events || []).forEach(event => {
    const evId = String(event.eventId || event.id);
    if (event.status === 'cancelled' || event.cancellation) return;
    const linkedReq = requestByEventId.get(evId);
    const isClientEvent =
      String(event.clientId) === clientId ||
      String(event.clientId) === clientUserId ||
      String(event.clientUserId) === clientUserId;
    if (linkedReq || isClientEvent) {
      matchedEventIds.add(evId);
      if (linkedReq) {
        requestById.delete(String(linkedReq.id || linkedReq.requestId));
      }
      unifiedEvents.push({
        id: evId,
        eventId: evId,
        requestId: linkedReq?.id || linkedReq?.requestId,
        title: event.title || event.name || linkedReq?.eventName || linkedReq?.title || 'Event',
        name: event.title || event.name || linkedReq?.eventName || linkedReq?.title || 'Event',
        date: event.date || linkedReq?.eventDate || '',
        time: event.time || linkedReq?.eventTime || '10:00',
        endTime: event.endTime || linkedReq?.endTime || '',
        venue: event.venue || event.location || linkedReq?.venue || 'Venue TBD',
        location: event.venue || event.location || linkedReq?.venue || 'Venue TBD',
        organizerId:
          event.organizerId || event.organizer || linkedReq?.organizerId || linkedReq?.organizer,
        category: event.category || linkedReq?.eventType || 'Event',
        bookingStatus:
          event.status === 'completed' || linkedReq?.status === 'completed'
            ? 'completed'
            : event.status || linkedReq?.status || 'confirmed',
        isPlanning: Boolean(linkedReq && isPlanningRequest(linkedReq)),
        paymentStatus: linkedReq?.paymentStatus || (event.price === 0 ? 'fully_paid' : 'unpaid'),
        registered: event.registered || 0,
        capacity: event.capacity || linkedReq?.capacity || 100,
        price: event.price || event.ticketPrice || 0,
        budget: linkedReq?.budget || 0,
        image: event.image,
        color: event.color,
        emoji: event.emoji,
        tags: event.tags,
        rawEvent: event,
        rawRequest: linkedReq,
      });
    }
  });

  // Requests can be in active planning before a booked event record exists.
  activeRequests.forEach(request => {
    const reqKey = String(request.id || request.requestId);
    if (requestById.has(reqKey)) {
      const evId = String(request.eventId || request.requestId || request.id);
      if (!matchedEventIds.has(evId)) {
        matchedEventIds.add(evId);
        unifiedEvents.push({
          id: evId,
          eventId: request.eventId || (isPlanningRequest(request) ? undefined : evId),
          requestId: request.id || request.requestId,
          title: request.eventName || request.title || 'Event',
          name: request.eventName || request.title || 'Event',
          date: request.eventDate || '',
          time: request.eventTime || '10:00',
          endTime: request.endTime || '',
          venue: request.venue || 'Venue TBD',
          location: request.venue || 'Venue TBD',
          organizerId: request.organizerId || request.organizer,
          category: request.eventType || 'Event',
          bookingStatus: request.status,
          isPlanning: isPlanningRequest(request),
          paymentStatus:
            request.paymentStatus || (isPlanningRequest(request) ? 'unpaid' : 'deposit_paid'),
          registered: 0,
          capacity: request.capacity || 100,
          price: 0,
          budget: request.budget || 0,
          rawRequest: request,
        });
      }
    }
  });

  // Partition into Upcoming, Ongoing, Completed
  const upcoming = [];
  const ongoing = [];
  const completed = [];
  const now = new Date();
  const todayInIndia = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(now);
  unifiedEvents.forEach(item => {
    const orgUser = (DB.users || []).find(
      user =>
        String(user.id) === String(item.organizerId) ||
        String(user.userId) === String(item.organizerId)
    );
    const orgProfile = (DB.organizers || []).find(
      organizer =>
        String(organizer.organizerId) === String(item.organizerId) ||
        String(organizer.userId) === String(item.organizerId)
    );
    item.organizerName =
      orgUser?.name ||
      orgProfile?.businessName ||
      item.rawRequest?.organizerName ||
      'Assigned Organizer';
    if (item.isPlanning) {
      item.tab = 'ongoing';
      ongoing.push(item);
      return;
    }

    // 1. Completed check
    if (
      item.bookingStatus === 'completed' ||
      item.rawEvent?.status === 'completed' ||
      item.rawRequest?.status === 'completed'
    ) {
      item.tab = 'completed';
      completed.push(item);
      return;
    }
    if (/^\d{4}-\d{2}-\d{2}$/.test(item.date) && item.date < todayInIndia) {
      item.tab = 'completed';
      completed.push(item);
      return;
    }

    // 2. Start time check with configured timezone (+05:30)
    let startTime = new Date(NaN);
    if (/^\d{4}-\d{2}-\d{2}$/.test(item.date)) {
      const match = String(item.time || '10:00')
        .trim()
        .match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?$/i);
      let hours = 10;
      let minutes = 0;
      if (match) {
        hours = Number(match[1]);
        minutes = Number(match[2]);
        if (match[3]) {
          hours = (hours % 12) + (match[3].toUpperCase() === 'PM' ? 12 : 0);
        }
      }
      const pad = n => String(n).padStart(2, '0');
      startTime = new Date(`${item.date}T${pad(hours)}:${pad(minutes)}:00+05:30`);
    }

    // 3. If scheduled start time is in the future: UPCOMING
    if (!Number.isNaN(startTime.getTime()) && startTime > now) {
      item.tab = 'upcoming';
      upcoming.push(item);
    } else {
      // Scheduled start time has arrived: ONGOING
      item.tab = 'ongoing';
      ongoing.push(item);
    }
  });
  upcoming.sort(
    (leftEvent, rightEvent) =>
      new Date(`${leftEvent.date}T${leftEvent.time || '10:00'}`) -
      new Date(`${rightEvent.date}T${rightEvent.time || '10:00'}`)
  );
  ongoing.sort(
    (leftEvent, rightEvent) =>
      new Date(`${leftEvent.date}T${leftEvent.time || '10:00'}`) -
      new Date(`${rightEvent.date}T${rightEvent.time || '10:00'}`)
  );
  completed.sort(
    (leftEvent, rightEvent) =>
      new Date(`${rightEvent.date}T${rightEvent.time || '10:00'}`) -
      new Date(`${leftEvent.date}T${leftEvent.time || '10:00'}`)
  );
  return {
    upcoming,
    ongoing,
    completed,
    all: [...upcoming, ...ongoing, ...completed],
  };
}
function setWorkflowEventTab(tab) {
  if (!['upcoming', 'ongoing', 'completed'].includes(tab)) return;
  _workflowEventTab = tab;
  try {
    window._workflowEventTab = tab;
  } catch (e) {}
  goNav('my-events');
}
function renderWorkflowEventCard(item, tab) {
  const bannerContent = item.image
    ? `
        <img src="${item.image}" alt="${workflowHtml(
        item.title || 'Event'
      )}" class="ev-banner-img" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
        <div class="ev-banner-fallback" style="display:none;align-items:center;justify-content:center;font-size:48px;width:100%;height:100%">${
          item.emoji || '📅'
        }</div>
        <div class="ev-banner-overlay"></div>
      `
    : `<span style="font-size:48px">${item.emoji || '📅'}</span>`;
  let statusBadge = '';
  if (item.isPlanning) {
    const stage =
      {
        planning: 'Planning',
        plan_submitted: 'Plan Ready',
        plan_revision_requested: 'Plan Revision Requested',
        proposal_sent: 'Review Proposal',
        awaiting_client: 'Awaiting Payment',
        changes_requested: 'Changes Requested',
        counteroffer_received: 'Counteroffer Sent',
      }[item.rawRequest?.status] || 'Planning';
    statusBadge = `<span class="badge badge-blue">${stage}</span>`;
  } else if (tab === 'completed') {
    statusBadge = '<span class="badge badge-green">✓ Completed</span>';
  } else if (tab === 'ongoing') {
    statusBadge = '<span class="badge badge-blue">⏱️ Ongoing</span>';
  } else {
    statusBadge = '<span class="badge badge-green">✓ Confirmed</span>';
  }
  let actionsHtml = '';
  const eventTargetId = item.eventId || item.id;
  if (item.isPlanning) {
    actionsHtml = `
          <div style="font-size:12px;color:var(--text2);margin-bottom:8px">Planning in progress. Open details for the next step.</div>
          <div class="flex gap-6" style="width:100%;justify-content:space-between;flex-wrap:wrap">
            <button class="btn btn-primary btn-sm" onclick="viewWorkflowRequestDrawer('${workflowHtml(
              item.requestId
            )}')">View Details</button>
            ${
              item.rawRequest?.status === 'proposal_sent'
                ? `<button class="btn btn-primary btn-sm" onclick="openClientPlanReview('${workflowHtml(
                    item.requestId
                  )}')">Review Proposal</button>`
                : ''
            }
            ${
              item.rawRequest?.status === 'awaiting_client' ||
              (item.rawRequest?.paymentStatus === 'deposit_pending' &&
                (item.rawRequest?.proposals || []).some(proposal => proposal.status === 'accepted'))
                ? `<button class="btn btn-success btn-sm" onclick="openClientPaymentModal('${workflowHtml(
                    item.requestId
                  )}')">Proceed to Payment &amp; Confirmation</button>`
                : ''
            }
            <button class="btn btn-danger btn-sm" onclick="openClientCancelRequestModal('${workflowHtml(
              item.requestId
            )}')">Withdraw Request</button>
          </div>
        `;
  } else if (tab === 'upcoming') {
    actionsHtml = `
          <div class="flex gap-6" style="width:100%;justify-content:space-between;flex-wrap:wrap">
            <button class="btn btn-ghost btn-sm" onclick="viewWorkflowEventDetails('${workflowHtml(
              eventTargetId
            )}')">👁️ View Details</button>
            ${
              item.requestId
                ? `<button class="btn btn-danger btn-sm" onclick="openClientCancelRequestModal('${workflowHtml(
                    item.requestId
                  )}')">Cancel Event</button>`
                : ''
            }
          </div>
        `;
  } else if (tab === 'ongoing') {
    actionsHtml = `
          <div style="font-size:12px;color:var(--text2);margin-bottom:8px">⏱️ Event currently underway. Live on-site coordination in progress.</div>
          <div class="flex gap-6" style="width:100%;justify-content:space-between;flex-wrap:wrap">
            <button class="btn btn-primary btn-sm" onclick="viewWorkflowEventDetails('${workflowHtml(
              eventTargetId
            )}')">👁️ View Details</button>
            ${
              item.requestId
                ? `<button class="btn btn-danger btn-sm" onclick="openClientCancelRequestModal('${workflowHtml(
                    item.requestId
                  )}')">Cancel Event</button>`
                : ''
            }
          </div>
        `;
  } else {
    actionsHtml = `
          <div style="font-size:12px;color:var(--green);margin-bottom:8px">✓ Event Successfully Completed</div>
          <div class="flex gap-6" style="width:100%;justify-content:space-between;flex-wrap:wrap">
            <button class="btn btn-ghost btn-sm" onclick="viewWorkflowEventDetails('${workflowHtml(
              eventTargetId
            )}')">👁️ View Details</button>
            <button class="btn btn-primary btn-sm" onclick="viewWorkflowEventReport('${workflowHtml(
              eventTargetId
            )}')">📊 View Report</button>
          </div>
        `;
  }
  return `
      <div class="ev-card" style="display:flex;flex-direction:column">
        <div class="ev-banner" style="background:${item.color || 'var(--accent)'}18">
          ${bannerContent}
          <div class="ev-banner-tag">${statusBadge}</div>
        </div>
        <div class="ev-body" style="display:flex;flex-direction:column;flex:1">
          <div class="ev-title" style="margin-bottom:8px">${workflowHtml(item.title)}</div>
          <div class="ev-meta" style="flex:1">
            <div class="ev-meta-row"><span>📅</span>${workflowHtml(item.date)} · ${workflowHtml(
    item.time || '10:00'
  )}</div>
            <div class="ev-meta-row"><span>📍</span>${workflowHtml(
              item.venue || item.location || 'Venue TBD'
            )}</div>
            <div class="ev-meta-row"><span>👤</span><strong>Organizer:</strong> ${workflowHtml(
              item.organizerName || 'Assigned Organizer'
            )}</div>
            <div class="ev-meta-row"><span>🏷️</span>${workflowHtml(item.category || 'Event')}</div>
          </div>
          <div class="ev-footer" style="margin-top:12px;padding-top:12px;border-top:1px solid var(--border)">
            ${actionsHtml}
          </div>
        </div>
      </div>`;
}
function pageWorkflowEvents() {
  if (!['upcoming', 'ongoing', 'completed'].includes(_workflowEventTab)) {
    _workflowEventTab = 'upcoming';
  }
  const data = getClientWorkflowEvents();
  const upcomingCount = data.upcoming.length;
  const ongoingCount = data.ongoing.length;
  const completedCount = data.completed.length;
  let activeList = [];
  let emptyIcon = '📅';
  let emptyTitle = 'No upcoming events';
  let emptyDesc = 'Confirmed future bookings will appear here once finalized and scheduled.';
  if (_workflowEventTab === 'upcoming') {
    activeList = data.upcoming;
    emptyIcon = '📅';
    emptyTitle = 'No upcoming events';
    emptyDesc = 'Confirmed bookings whose scheduled start time is in the future will appear here.';
  } else if (_workflowEventTab === 'ongoing') {
    activeList = data.ongoing;
    emptyIcon = '⏱️';
    emptyTitle = 'No ongoing events';
    emptyDesc = 'Events in planning and confirmed events currently taking place will appear here.';
  } else {
    activeList = data.completed;
    emptyIcon = '✅';
    emptyTitle = 'No completed events';
    emptyDesc = 'Events whose completion has been recorded and finalized will appear here.';
  }
  return `
      <div class="page-hd">
        <div class="page-hd-left">
          <div class="page-title">My Events</div>
          <div class="page-sub">Track your upcoming, ongoing, and completed events and reports.</div>
        </div>
      </div>
      <div class="grid-3" style="gap:16px;margin-bottom:24px">
        <div class="stat-card" style="cursor:pointer;border-left:3px solid var(--accent)" onclick="setWorkflowEventTab('upcoming')">
          <div class="stat-icon">📅</div>
          <div class="stat-value" style="color:var(--accent)">${upcomingCount}</div>
          <div class="stat-label">Upcoming Events</div>
          <div class="stat-sub neutral">Future confirmed bookings</div>
        </div>
        <div class="stat-card" style="cursor:pointer;border-left:3px solid var(--blue)" onclick="setWorkflowEventTab('ongoing')">
          <div class="stat-icon">⏱️</div>
          <div class="stat-value" style="color:var(--blue)">${ongoingCount}</div>
          <div class="stat-label">Ongoing Events</div>
          <div class="stat-sub neutral">Planning and events in progress</div>
        </div>
        <div class="stat-card" style="cursor:pointer;border-left:3px solid var(--green)" onclick="setWorkflowEventTab('completed')">
          <div class="stat-icon">✅</div>
          <div class="stat-value" style="color:var(--green)">${completedCount}</div>
          <div class="stat-label">Completed Events</div>
          <div class="stat-sub neutral">Recorded event reports</div>
        </div>
      </div>
      <nav aria-label="Event subpages" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:20px;border-bottom:1px solid var(--border);padding-bottom:12px">
        <button type="button" class="btn ${
          _workflowEventTab === 'upcoming' ? 'btn-primary' : 'btn-ghost'
        }" aria-pressed="${
    _workflowEventTab === 'upcoming'
  }" onclick="setWorkflowEventTab('upcoming')">📅 Upcoming Events <span style="background:rgba(255,255,255,.18);padding:1px 7px;border-radius:10px;font-size:11px;margin-left:4px">${upcomingCount}</span></button>
        <button type="button" class="btn ${
          _workflowEventTab === 'ongoing' ? 'btn-primary' : 'btn-ghost'
        }" aria-pressed="${
    _workflowEventTab === 'ongoing'
  }" onclick="setWorkflowEventTab('ongoing')">⏱️ Ongoing Events <span style="background:rgba(255,255,255,.18);padding:1px 7px;border-radius:10px;font-size:11px;margin-left:4px">${ongoingCount}</span></button>
        <button type="button" class="btn ${
          _workflowEventTab === 'completed' ? 'btn-primary' : 'btn-ghost'
        }" aria-pressed="${
    _workflowEventTab === 'completed'
  }" onclick="setWorkflowEventTab('completed')">✅ Completed Events <span style="background:rgba(255,255,255,.18);padding:1px 7px;border-radius:10px;font-size:11px;margin-left:4px">${completedCount}</span></button>
      </nav>
      <section aria-label="${
        _workflowEventTab === 'upcoming'
          ? 'Upcoming Events'
          : _workflowEventTab === 'ongoing'
          ? 'Ongoing Events'
          : 'Completed Events'
      }">
        <div class="events-grid">
          ${
            activeList.length === 0
              ? `<div class="empty" style="grid-column:1/-1"><div class="empty-icon">${emptyIcon}</div><div class="empty-title">${emptyTitle}</div><div class="empty-desc">${emptyDesc}</div></div>`
              : activeList.map(item => renderWorkflowEventCard(item, _workflowEventTab)).join('')
          }
        </div>
      </section>`;
}
window.getClientWorkflowEvents = getClientWorkflowEvents;
window.setWorkflowEventTab = setWorkflowEventTab;
window.pageWorkflowEvents = pageWorkflowEvents;
function pageCompletedEvents(embedded = false) {
  const completed = DB.events
    .filter(event => event.status === 'completed')
    .sort((leftEvent, rightEvent) => new Date(rightEvent.date) - new Date(leftEvent.date));
  return `${
    embedded
      ? ''
      : `
  <div class="page-hd">
    <div class="page-hd-left">
      <div class="page-title">Completed Events</div>
      <div class="page-sub">Events that have been successfully completed</div>
    </div>
  </div>`
  }
  <div class="events-grid">${
    completed.length === 0
      ? `<div class="empty" style="grid-column:1/-1"><div class="empty-icon">✅</div><div class="empty-title">No completed events</div></div>`
      : completed
          .map(event => {
            const bannerContent = event.image
              ? `
          <img src="${event.image}" alt="${
                  event.title || 'Event'
                }" class="ev-banner-img" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
          <div class="ev-banner-fallback" style="display:none;align-items:center;justify-content:center;font-size:52px;width:100%;height:100%">${
            event.emoji || '📅'
          }</div>
          <div class="ev-banner-overlay"></div>
        `
              : `<span style="font-size:52px">${event.emoji || '📅'}</span>`;
            return `<div class="ev-card">
    <div class="ev-banner" style="background:${event.color || 'var(--accent)'}18">
      ${bannerContent}
      <div class="ev-banner-tag"><span class="badge badge-green">✓ Completed</span></div>
      <div class="ev-banner-price">${event.price === 0 ? 'Free' : '₹' + event.price}</div>
    </div>
    <div class="ev-body">
      <div class="ev-title">${event.title}</div>
      <div class="ev-meta">
        <div class="ev-meta-row"><span>📅</span>${event.date} · ${event.time}</div>
        <div class="ev-meta-row"><span>📍</span>${event.venue}</div>
        <div class="ev-meta-row"><span>🏷️</span>${event.category}</div>
      </div>
      <div style="margin-bottom:12px">
        <div class="flex justify-between ev-cap mb-4"><span>${event.registered}/${
              event.capacity
            } attended</span></div>
        <div style="font-size:12px;color:var(--green);margin-top:8px">✓ Event Successfully Completed</div>
      </div>
      <div class="ev-footer">
        <div class="flex gap-6" style="width:100%;justify-content:space-between">
          <button class="btn btn-ghost btn-xs w-full" onclick="viewWorkflowEventDetails('${
            event.id
          }')" title="View event details">👁️ View Details</button>
          <button class="btn btn-primary btn-xs" onclick="viewWorkflowEventReport('${
            event.id
          }')" title="View completion report">📊 View Report</button>
        </div>
        <div class="tag-list" style="flex:1;justify-content:flex-end">${(event.tags || [])
          .slice(0, 2)
          .map(tag => `<span class="tag">${tag}</span>`)
          .join('')}</div>
      </div>
    </div>
  </div>`;
          })
          .join('')
  }</div>`;
}
function pageOngoingEvents(embedded = false) {
  if (!['client', 'organizer'].includes(CU.role)) {
    const publicOngoing = DB.events.filter(event => event.status === 'ongoing');
    return `<div class="page-hd"><div class="page-hd-left"><div class="page-title">Ongoing Events</div><div class="page-sub">Events currently happening right now</div></div></div><div class="events-grid">${
      publicOngoing.length
        ? publicOngoing.map(event => evCard(event, 'attendee')).join('')
        : '<div class="empty" style="grid-column:1/-1"><div class="empty-icon">⏱️</div><div class="empty-title">No ongoing events</div></div>'
    }</div>`;
  }
  const ongoing = DB.events.filter(
    event =>
      event.status === 'ongoing' &&
      DB.eventRequests.some(
        request => String(request.eventId) === String(event.eventId || event.id)
      )
  );
  return `${
    embedded
      ? ''
      : `
  <div class="page-hd">
    <div class="page-hd-left">
      <div class="page-title">Ongoing Events</div>
      <div class="page-sub">Track your approved client–organizer events, payment, and completion reports</div>
    </div>
  </div>`
  }
  <div class="events-grid">${
    ongoing.length === 0
      ? `<div class="empty" style="grid-column:1/-1"><div class="empty-icon">⏱️</div><div class="empty-title">No ongoing events</div></div>`
      : ongoing
          .map(event => {
            const request = DB.eventRequests.find(
              item => String(item.eventId) === String(event.eventId || event.id)
            );
            const paid = request?.paymentStatus === 'fully_paid';
            return `<div class="card">
          <div style="display:flex;justify-content:space-between;gap:8px;align-items:center"><strong>${workflowHtml(
            event.name || event.title
          )}</strong><span class="badge badge-blue">Ongoing</span></div>
          <div style="margin-top:10px;color:var(--text2);font-size:13px">📅 ${workflowHtml(
            event.date
          )} · 📍 ${workflowHtml(event.location || event.venue || '—')}</div>
          <div style="margin-top:10px;font-size:13px">Payment: <strong style="color:${
            paid ? 'var(--green)' : 'var(--yellow)'
          }">${paid ? 'Paid' : 'Unpaid'}</strong></div>
          <button class="btn btn-primary btn-sm" style="margin-top:12px" onclick="viewWorkflowEventDetails('${workflowHtml(
            event.eventId || event.id
          )}')">View Details</button>
          ${
            CU.role === 'client'
              ? `<button class="btn btn-danger btn-sm" style="margin-top:12px" onclick="openWorkflowCancellation('${workflowHtml(
                  event.eventId || event.id
                )}')">Cancel Event</button>`
              : ''
          }
        </div>`;
          })
          .join('')
  }</div>`;
}

// ════════════════════════════════════════════════
//  MODAL SYSTEM
// ════════════════════════════════════════════════
function openModal(title, body, btns = [], showCancel = true) {
  g('modal-title').textContent = title;
  globalThis.window?.EventFlowClientPages?.clear(g('modal-body'));
  g('modal-body').innerHTML = body;
  const foot = g('modal-foot');
  globalThis.window?.EventFlowClientPages?.clear(foot);
  foot.innerHTML = '';
  let hasDismiss = false;
  const handlers = new Set();
  const actions = btns.filter(button => {
    const handler = String(button.fn || '')
      .trim()
      .replace(/;+\s*$/, '');
    const dismissesModal = /^(?:window\.)?closeModal\s*\(\s*\)$/.test(handler);
    const key = dismissesModal ? 'closeModal()' : handler;
    if (key && handlers.has(key)) return false;
    if (key) handlers.add(key);
    if (
      dismissesModal ||
      String(button.lbl || '')
        .trim()
        .toLowerCase() === 'cancel'
    )
      hasDismiss = true;
    return true;
  });
  if (showCancel && !hasDismiss) {
    const c = document.createElement('button');
    c.className = 'btn btn-ghost';
    c.textContent = 'Cancel';
    c.onclick = closeModal;
    foot.appendChild(c);
  }
  actions.forEach(b => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'btn ' + b.cls;
    button.textContent = b.lbl;
    button.disabled = Boolean(b.disabled);
    if (b.title) button.title = b.title;
    button.setAttribute('onclick', b.fn);
    foot.appendChild(button);
  });
  if (!showCancel && !actions.length) foot.style.display = 'none';
  else foot.style.display = '';
  const ov = g('modal-overlay');
  ov.classList.remove('hidden'); // ensure visible
  requestAnimationFrame(() => ov.classList.add('open'));
}
function closeModal() {
  const ov = g('modal-overlay');
  ov.classList.remove('open');
}
function closeModalOnBg(e) {
  if (e.target === g('modal-overlay')) closeModal();
}

// DRAWER
function openDrawer(title, body) {
  g('drawer-title').textContent = title;
  globalThis.window?.EventFlowClientPages?.clear(g('drawer-body'));
  g('drawer-body').innerHTML = body;
  g('drawer-overlay').classList.add('open');
  g('drawer').classList.add('open');
}
function closeDrawer() {
  g('drawer-overlay').classList.remove('open');
  g('drawer').classList.remove('open');
}

// CONFIRM
function confirm2(title, msg, cb) {
  g('confirm-title').textContent = title;
  g('confirm-msg').textContent = msg;
  _confirmCb = cb;
  const ov = g('confirm-overlay');
  ov.classList.remove('hidden');
  requestAnimationFrame(() => ov.classList.add('open'));
}
function closeConfirm() {
  g('confirm-overlay').classList.remove('open');
  _confirmCb = null;
}
function closeConfirmOnBg(e) {
  if (e.target === g('confirm-overlay')) closeConfirm();
}
function runConfirm() {
  if (_confirmCb) _confirmCb();
  closeConfirm();
}

// TOAST
function toast(msg, type = 'info') {
  const icons = {
    success: '✅',
    error: '❌',
    info: 'ℹ️',
    warning: '⚠️',
  };
  const element = document.createElement('div');
  element.className = `toast ${type}`;
  globalThis.window?.EventFlowClientPages?.clear(element);
  element.innerHTML = `<span class="toast-icon">${icons[type]}</span><span class="toast-msg">${msg}</span>`;
  g('toasts').appendChild(element);
  setTimeout(() => {
    element.style.animation = 'toastOut .3s ease forwards';
    setTimeout(() => element.remove(), 300);
  }, 3500);
}

// ════════════════════════════════════════════════
//  HELPERS
// ════════════════════════════════════════════════
// Legacy DOM helpers: g finds an element; v reads its trimmed form value.
function g(id) {
  return document.getElementById(id);
}
function v(id) {
  const element = g(id);
  return element ? element.value.trim() : '';
}
function today() {
  return new Date().toISOString().split('T')[0];
}
function showErr(id) {
  const element = g(id);
  if (element) element.classList.add('show');
}
function hideErr(id) {
  const element = g(id);
  if (element) element.classList.remove('show');
}
function evStatBadge(s) {
  return (
    {
      upcoming: 'purple',
      full: 'red',
      completed: 'green',
    }[s] || 'gray'
  );
}
function reqBadge(s) {
  return (
    {
      submitted: 'yellow',
      pending: 'yellow',
      under_review: 'purple',
      in_review: 'purple',
      info_requested: 'yellow',
      proposal_sent: 'blue',
      awaiting_client: 'blue',
      changes_requested: 'orange',
      counteroffer_received: 'purple',
      planning: 'blue',
      plan_submitted: 'purple',
      plan_revision_requested: 'orange',
      confirmed: 'green',
      approved: 'green',
      rejected: 'red',
      withdrawn: 'gray',
      cancelled: 'gray',
      expired: 'red',
    }[s] || 'gray'
  );
}

// ════════════════════════════════════════════════
//  BOOTSTRAP
// ════════════════════════════════════════════════
// CAROUSEL FUNCTIONS
// ════════════════════════════════════════════════
function scrollCarousel(direction) {
  const carousel = g('event-carousel');
  if (!carousel) return;
  const scrollAmount = 300;
  if (direction === 'left') {
    carousel.scrollBy({
      left: -scrollAmount,
      behavior: 'smooth',
    });
  } else {
    carousel.scrollBy({
      left: scrollAmount,
      behavior: 'smooth',
    });
  }
}

// Auto-enable carousel scrolling with keyboard arrows (optional)
document.addEventListener('keydown', e => {
  if (e.key === 'ArrowLeft' && g('event-carousel')) scrollCarousel('left');
  if (e.key === 'ArrowRight' && g('event-carousel')) scrollCarousel('right');
});

// ════════════════════════════════════════════════
//  CROSS-TAB DATA SYNCHRONIZATION
// ════════════════════════════════════════════════
// The 'storage' event fires ONLY in tabs that did NOT make the change.
// We debounce re-renders to avoid blinking when multiple tabs are active.
let _syncDebounceTimer = null;
window.addEventListener('storage', function (e) {
  if (e.key !== 'ffsd_db' || !e.newValue) return;

  // Skip if the data content hasn't meaningfully changed (same length = same data)
  if (e.newValue === e.oldValue) return;

  // Clear any pending re-render and schedule a new one after a short delay.
  // This collapses rapid consecutive saves (e.g. from the other tab's own renders)
  // into a single update, eliminating the visible flicker.
  clearTimeout(_syncDebounceTimer);
  _syncDebounceTimer = setTimeout(function () {
    try {
      loadDB(false);
      if (CU && _currentPage) {
        renderPage(_currentPage);
        updateNotifDot();
      }
    } catch (err) {
      console.warn('[Sync] Failed to reload from storage event:', err);
    }
  }, 600); // 600ms debounce — imperceptible delay, eliminates flicker
});

// Local changes already update the page directly. Other browser tabs are
// handled by the storage event above, so a polling-based full re-render is
// unnecessary and caused the visible dashboard flicker after login.

// ════════════════════════════════════════════════
function getRoleWorkspace(user) {
  if (!user) return null;
  const role = String(user.role || user.userRole || '')
    .toLowerCase()
    .replace(/[\s-]+/g, '_');
  const type = String(user.employeeType || '')
    .toUpperCase()
    .replace(/[\s-]+/g, '_');
  if (role === 'employee') {
    if (['SUPPORT_EXECUTIVE', 'REGISTRATION_VERIFICATION', 'EVENT_OPERATIONS'].includes(type))
      return {
        key: 'employee1',
      };
    if (['SUPPORT_FINANCE', 'FINANCE_EXECUTIVE'].includes(type))
      return {
        key: 'employee2',
      };
    return {
      key: role === 'employee' ? 'employee1' : 'landing',
    };
  }
  return (
    {
      superuser: {
        key: 'super-admin',
      },
      super_admin: {
        key: 'super-admin',
      },
      organizer: {
        key: 'organizer',
      },
      event_organizer: {
        key: 'organizer',
      },
      client: {
        key: 'client',
      },
      attendee: {
        key: 'attendee',
      },
      employee1: {
        key: 'employee1',
      },
      employee2: {
        key: 'employee2',
      },
    }[role] || null
  );
}
function routeToRoleWorkspace(user) {
  const workspace = getRoleWorkspace(user);
  if (!workspace || window.EventFlowRole?.key === workspace.key) return false;
  window.location.replace(workspace.key === 'super-admin' ? '/admin' : '/' + workspace.key);
  return true;
}
document.addEventListener('DOMContentLoaded', function boot() {
  // Restore the session synchronously. Waiting on a health request caused a
  // visible landing-page-to-dashboard swap and unnecessarily logged out
  // users whenever the optional backend was offline.
  loadDB(false);
  try {
    const saved = sessionStorage.getItem('ef_cu');
    if (saved) {
      CU = window.EventFlowAccountPolicy.normalizeSavedAccount(JSON.parse(saved));
      if (!CU) throw new Error('This account is no longer available.');
      const workspace = getRoleWorkspace(CU);
      if (workspace && routeToRoleWorkspace(CU)) return;
      if (!workspace && window.EventFlowRole?.key !== 'landing') {
        window.location.replace('/landing');
        return;
      }
      initApp();
      showPage('app');
      document.documentElement.classList.remove('restoring-session');
      return;
    }
  } catch (e) {
    CU = null;
    try {
      sessionStorage.removeItem('ef_cu');
    } catch (ignore) {}
  }
  if (window.EventFlowRole?.key !== 'landing') {
    window.location.replace('/landing');
    return;
  }
  document.documentElement.classList.remove('restoring-session');
  showPage('landing');
});

/* ===== EventFlow source: validation.js ===== */
// Global Validation Script for Specified Input Fields
document.addEventListener('DOMContentLoaded', () => {
  function getErrorSpan(input) {
    let next = input.nextElementSibling;
    if (next && next.classList.contains('form-error')) return next;
    let span = document.createElement('span');
    span.className = 'form-error';
    input.parentNode.insertBefore(span, input.nextSibling);
    return span;
  }
  function validateInput(target) {
    if (target.tagName !== 'INPUT' && target.tagName !== 'SELECT' && target.tagName !== 'TEXTAREA')
      return true;
    if (target.type === 'file' || target.type === 'checkbox' || target.type === 'radio')
      return true;
    if (target.disabled || target.readOnly) return true;
    const fg = target.closest('.form-group');
    const labelText = fg
      ? fg.querySelector('.form-label')
        ? fg.querySelector('.form-label').textContent.toLowerCase()
        : ''
      : '';
    const id = (target.id || '').toLowerCase();
    const type = (target.type || '').toLowerCase();
    // Verification codes are checked by their confirmation handler, not as contact details.
    if (id.includes('otp') || target.autocomplete === 'one-time-code') return true;

    // To support contact forms that use div labels
    let previousElement = target.previousElementSibling;
    let prevLabel =
      previousElement && previousElement.textContent
        ? previousElement.textContent.toLowerCase()
        : '';
    let fieldType = null;
    if (
      /^(full name|name|first name|last name|city|city\s*\/\s*location)$/i.test(
        labelText.replace(/\*/g, '').trim()
      ) ||
      /^(rg-name|newusername|edit-usr-name|contact-name|name)$/.test(id)
    )
      fieldType = 'name';
    else if (
      labelText.includes('email') ||
      type === 'email' ||
      id.includes('email') ||
      prevLabel.includes('email')
    )
      fieldType = 'email';
    else if (
      labelText.includes('phone') ||
      type === 'tel' ||
      id.includes('phone') ||
      prevLabel.includes('phone')
    )
      fieldType = 'phone';
    else if (labelText.includes('date') || type === 'date' || id.includes('date'))
      fieldType = 'date';
    if (!fieldType) return true;
    let val = target.value.trim();
    let isValid = true;
    let errorMsg = '';
    if (val === '') {
      if (labelText.includes('*') || target.hasAttribute('required')) {
        isValid = false;
        errorMsg = 'This field is required';
      } else {
        target.classList.remove('is-error');
        target.classList.remove('is-valid');
        const span = getErrorSpan(target);
        if (span) {
          span.classList.remove('show');
          span.textContent = '';
        }
        return true;
      }
    } else {
      if (fieldType === 'name') {
        if (!/^[\p{L}\p{M} .,'’()-]+$/u.test(val)) {
          isValid = false;
          errorMsg = 'Use letters and normal name or city characters only';
        }
      } else if (fieldType === 'email') {
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) {
          isValid = false;
          errorMsg = 'Enter a valid email format';
        }
      } else if (fieldType === 'phone') {
        if (!/^\d{10}$/.test(val)) {
          isValid = false;
          errorMsg = 'Enter a mobile number with exactly 10 digits';
        }
      } else if (fieldType === 'date') {
        const selected = new Date(val);
        const todayDate = new Date();
        todayDate.setHours(0, 0, 0, 0);
        if (
          (id !== 'rg-date-of-birth' && selected < todayDate) ||
          (id === 'rg-date-of-birth' && (Number.isNaN(selected.getTime()) || selected > todayDate))
        ) {
          isValid = false;
          errorMsg =
            id === 'rg-date-of-birth'
              ? 'Date of birth cannot be in the future'
              : 'Only future dates are allowed';
        }
      }
    }
    const span = getErrorSpan(target);
    if (isValid) {
      target.classList.remove('is-error');
      target.classList.add('is-valid');
      span.classList.remove('show');
      span.textContent = '';
      return true;
    } else {
      target.classList.remove('is-valid');
      target.classList.add('is-error');
      span.classList.add('show');
      span.textContent = errorMsg;
      return false;
    }
  }
  document.addEventListener('input', e => {
    if (e.target.tagName === 'INPUT') validateInput(e.target);
  });
  document.addEventListener('change', e => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') validateInput(e.target);
  });
  document.addEventListener('focusout', e => {
    if (e.target.tagName === 'INPUT') validateInput(e.target);
  });
  document.addEventListener('focusin', e => {
    const target = e.target;
    if (target.tagName === 'INPUT') {
      const fg = target.closest('.form-group');
      const labelText = fg
        ? fg.querySelector('.form-label')
          ? fg.querySelector('.form-label').textContent.toLowerCase()
          : ''
        : '';
      const id = (target.id || '').toLowerCase();
      let isDateField = target.type === 'date' || labelText.includes('date') || id.includes('date');
      if (isDateField) {
        const todayStr = new Date().toISOString().split('T')[0];
        if (target.type !== 'date') target.type = 'date';
        if (id !== 'rg-date-of-birth' && target.min !== todayStr) target.min = todayStr;
      }
    }
  });
  document.addEventListener(
    'click',
    e => {
      const button = e.target.closest('button');
      if (!button) return;
      if (button.dataset.validationScope === 'verification') return;
      if (
        button.classList.contains('btn-primary') ||
        button.classList.contains('btn-success') ||
        button.id === 'login-btn'
      ) {
        const onclickCode = button.getAttribute('onclick') || '';
        if (
          onclickCode.includes('open') ||
          onclickCode.includes('goNav') ||
          onclickCode.includes('showPage') ||
          onclickCode.includes('doLogin') ||
          onclickCode.includes('gotoLogin') ||
          onclickCode.includes('fillLogin') ||
          onclickCode.includes('selectEmployee') ||
          onclickCode.includes('doLogout')
        )
          return;

        // Scope validation exclusively to modals or explicit form containers
        const formScope = button.closest('.modal-box, form');
        if (!formScope) return;

        // Only validate inputs that are currently visible
        const inputs = formScope.querySelectorAll('input, select, textarea');
        let hasError = false;
        inputs.forEach(input => {
          if (
            input.offsetWidth > 0 ||
            input.offsetHeight > 0 ||
            input.getClientRects().length > 0
          ) {
            const isValid = validateInput(input);
            if (!isValid) hasError = true;
          }
        });
        if (hasError) {
          e.stopImmediatePropagation();
          e.stopPropagation();
          e.preventDefault();
          if (typeof toast === 'function')
            toast('Please fix the errors before submitting', 'error');
        }
      }
    },
    true
  );
});

/* ===== Role-owned frontend configuration ===== */
window.EventFlowRole = {
  key: 'client',
  label: 'Client',
};

// React pages read the same normalized data and keep the existing workflow action entry points.
window.EventFlowClientRuntime = {
  snapshot(pageProps = {}) {
    return {
      CU: typeof CU === 'undefined' ? undefined : CU,
      DB: typeof DB === 'undefined' ? undefined : DB,
      EMPLOYEE_TYPE_LABELS:
        typeof EMPLOYEE_TYPE_LABELS === 'undefined' ? undefined : EMPLOYEE_TYPE_LABELS,
      ROLE_COLORS: typeof ROLE_COLORS === 'undefined' ? undefined : ROLE_COLORS,
      ROLE_LABELS: typeof ROLE_LABELS === 'undefined' ? undefined : ROLE_LABELS,
      get _workflowEventTab() {
        return _workflowEventTab;
      },
      set _workflowEventTab(value) {
        _workflowEventTab = value;
      },
      _workflowReturnPage:
        typeof _workflowReturnPage === 'undefined' ? undefined : _workflowReturnPage,
      evStatBadge: typeof evStatBadge === 'undefined' ? undefined : evStatBadge,
      g: typeof g === 'undefined' ? undefined : g,
      getClientAcceptedProposal:
        typeof getClientAcceptedProposal === 'undefined' ? undefined : getClientAcceptedProposal,
      getClientBookingAmounts:
        typeof getClientBookingAmounts === 'undefined' ? undefined : getClientBookingAmounts,
      getClientWorkflowEvents:
        typeof getClientWorkflowEvents === 'undefined' ? undefined : getClientWorkflowEvents,
      isClientOwner: typeof isClientOwner === 'undefined' ? undefined : isClientOwner,
      isDepartmentEmployee:
        typeof isDepartmentEmployee === 'undefined' ? undefined : isDepartmentEmployee,
      reqBadge: typeof reqBadge === 'undefined' ? undefined : reqBadge,
      visibleNotifications:
        typeof visibleNotifications === 'undefined' ? undefined : visibleNotifications,
      workflowEventPolicy:
        typeof workflowEventPolicy === 'undefined' ? undefined : workflowEventPolicy,
      workflowMoney: typeof workflowMoney === 'undefined' ? undefined : workflowMoney,
      workflowPolicyDate:
        typeof workflowPolicyDate === 'undefined' ? undefined : workflowPolicyDate,
      workflowPolicyDocuments:
        typeof workflowPolicyDocuments === 'undefined' ? undefined : workflowPolicyDocuments,
      clientActivityLabel:
        typeof clientActivityLabel === 'undefined' ? undefined : clientActivityLabel,
      clientActivityIcon:
        typeof clientActivityIcon === 'undefined' ? undefined : clientActivityIcon,
      clientActivityTime:
        typeof clientActivityTime === 'undefined' ? undefined : clientActivityTime,
      clientUpcomingEventDate:
        typeof clientUpcomingEventDate === 'undefined' ? undefined : clientUpcomingEventDate,
      pageProps,
    };
  },
};

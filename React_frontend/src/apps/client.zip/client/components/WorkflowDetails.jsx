export function renderWorkflowCancellation(
  portalContext,
  cancellation,
  request = {},
  compact = false
) {
  const portalActions = portalContext.actions;
  const { CU: currentUser, DB: workspaceData, workflowMoney, workflowPolicyDate } = portalContext;
  const event = (workspaceData.events || []).find(
    item => request.eventId && String(item.eventId || item.id) === String(request.eventId)
  );
  const record = cancellation || event?.cancellation;
  if (!record && request.status !== 'cancelled') return '';
  const c = record || {};
  const actor = (workspaceData.users || []).find(
    user => c.cancelledBy && String(user.userId || user.id) === String(c.cancelledBy)
  );
  const role = c.cancelledByRole || actor?.role || actor?.userRole;
  const matchesActor = id =>
    id != null && c.cancelledBy != null && String(id) === String(c.cancelledBy);
  const organizer =
    ['organizer', 'event_organizer'].includes(role) ||
    [
      request.organizerUserId,
      request.organizer,
      request.organizerId,
      request.backendOrganizerId,
    ].some(matchesActor);
  const client =
    role === 'client' ||
    [request.clientUserId, request.clientId, request.backendClientId, currentUser?.id].some(
      matchesActor
    );
  const heading = organizer
    ? 'Cancelled by organizer'
    : client
    ? 'Cancelled by you'
    : ['super_admin', 'superuser'].includes(role)
    ? 'Cancelled by administrator'
    : 'Event cancelled';
  const actorName =
    c.cancelledByName ||
    actor?.name ||
    (organizer ? request.organizerName : client ? currentUser?.name : '');
  const reason =
    c.reason ||
    request.cancelReason ||
    request.cancellationReason ||
    event?.cancellationReason ||
    'A cancellation reason was not recorded. Contact the organizer for details.';
  const explanation = c.explanation || request.cancelExplanation;
  const hasAmounts = ['paidAmount', 'cancellationFee', 'refundAmount'].every(
    key => c[key] != null && c[key] !== '' && Number.isFinite(Number(c[key])) && Number(c[key]) >= 0
  );
  const refundAmount = hasAmounts ? Number(c.refundAmount) : null;
  const refundStatus = c.refundStatus || request.refundStatus;
  const simulatedRefund = c.refundSimulated === true;
  const refunded = ['completed', 'refunded'].includes(refundStatus);
  const refundTitle = !hasAmounts
    ? 'Payment and refund details not recorded'
    : refundAmount === 0
    ? Number(c.paidAmount) === 0
      ? 'No payment was taken; no refund is needed.'
      : 'No refund due under the recorded policy'
    : refunded
    ? 'Refund completed'
    : refundStatus === 'pending'
    ? simulatedRefund
      ? 'Simulated refund pending provider confirmation'
      : 'Refund pending review'
    : refundStatus === 'processing'
    ? 'Refund processing'
    : 'Refund due — status not recorded';
  const nextStep = !hasAmounts
    ? 'Contact your organizer for the payment and refund details.'
    : refundAmount === 0
    ? 'There is no refund to wait for.'
    : refunded
    ? 'Your refund is marked as completed. Contact the organizer if you need help checking it.'
    : refundStatus === 'pending'
    ? simulatedRefund
      ? 'This demo refund is simulated and awaiting provider confirmation; no payment has been sent yet.'
      : 'Your refund is recorded and awaiting review. It has not been paid yet. Contact the organizer if you need an update.'
    : 'Contact your organizer for an update on the refund.';
  const policy = request.policySnapshot || event?.policySnapshot;
  const processing =
    refundAmount > 0 && refundStatus === 'pending' && policy?.cancellation?.processingTimeline;
  const feeLabel =
    c.cancellationFeePercent != null && Number.isFinite(Number(c.cancellationFeePercent))
      ? `Cancellation fee (${Number(c.cancellationFeePercent)}%)`
      : 'Cancellation fee';
  return (
    <section
      className={`client-cancellation${compact ? ' client-cancellation-compact' : ''}`}
      aria-label="Cancellation details"
    >
      <div className="client-cancellation-heading">
        <div>
          <h3>{heading}</h3>
          <p>
            {actorName ? `${actorName} &middot; ` : ''}
            {workflowPolicyDate(c.cancelledAt || request.cancelledAt)}
          </p>
        </div>
        <span className="badge badge-red">Booking closed</span>
      </div>
      <div className="client-cancellation-reason">
        <strong>Reason for cancellation</strong>
        <p>{reason}</p>
        {explanation ? <p>{explanation}</p> : ''}
      </div>
      {hasAmounts ? (
        <div className="client-cancellation-amounts">
          <div>
            <span>Amount paid</span>
            <strong>{workflowMoney(c.paidAmount)}</strong>
          </div>
          <div>
            <span>{feeLabel}</span>
            <strong>{workflowMoney(c.cancellationFee)}</strong>
          </div>
          <div>
            <span>
              {organizer &&
              Number(c.cancellationFee) === 0 &&
              refundAmount === Number(c.paidAmount) &&
              refundAmount > 0
                ? 'Full refund due'
                : 'Refund due'}
            </span>
            <strong>{workflowMoney(c.refundAmount)}</strong>
          </div>
        </div>
      ) : (
        ''
      )}
      <ol className="client-cancellation-progress" aria-label="Cancellation progress">
        <li className="complete">Cancellation recorded</li>
        <li className={refunded || refundAmount === 0 ? 'complete' : 'pending'}>{refundTitle}</li>
      </ol>
      <p className="client-cancellation-next">
        <strong>No further booking payments are due.</strong> {nextStep}
        {processing ? (
          <>
            <br />
            Estimated processing after review: {processing}.
          </>
        ) : (
          ''
        )}
      </p>
    </section>
  );
}
export function renderWorkflowFileReports(portalContext, eventId) {
  const portalActions = portalContext.actions;
  const { DB: workspaceData } = portalContext;
  const reports = (workspaceData.eventFileReports || []).filter(
    report => String(report.eventId) === String(eventId)
  );
  return reports.length ? (
    <section
      style={{
        marginTop: '16px',
      }}
    >
      <h3>Reports from the Organizer</h3>
      {reports.map((report, index) => (
        <div
          style={{
            padding: '12px',
            border: '1px solid var(--border)',
            marginTop: '8px',
          }}
          key={index}
        >
          <strong>{report.reportTitle}</strong>
          <p
            style={{
              whiteSpace: 'pre-wrap',
              color: 'var(--text2)',
            }}
          >
            {report.reportDetails}
          </p>
          {report.documentFileName ? (
            <button
              className="btn btn-ghost btn-sm"
              onClick={() => portalActions.onDownloadWorkflowEventReport(report.eventReportId)}
            >
              Download {report.documentName}
            </button>
          ) : (
            ''
          )}
        </div>
      ))}
    </section>
  ) : (
    ''
  );
}
export function renderWorkflowEventPolicy(portalContext, policy, checkboxId) {
  const portalActions = portalContext.actions;
  const { workflowPolicyDocuments } = portalContext;
  if (!policy)
    return <p role="alert">Event policies could not be loaded. Refresh before continuing.</p>;
  workflowPolicyDocuments.set(policy.version, policy);
  return (
    <section
      style={{
        margin: '16px 0',
        padding: '16px',
        border: '1px solid var(--border)',
        background: 'var(--surface2)',
      }}
    >
      <div
        style={{
          display: 'flex',
          gap: '10px',
          flexWrap: 'wrap',
        }}
      >
        <button
          type="button"
          className="btn btn-ghost"
          data-policy-version={policy.version}
          onClick={event =>
            portalActions.onOpenWorkflowPolicyDocument(
              'policies',
              event.currentTarget.dataset.policyVersion
            )
          }
        >
          Event Policies &amp; Rules
        </button>
        <button
          type="button"
          className="btn btn-ghost"
          data-policy-version={policy.version}
          onClick={event =>
            portalActions.onOpenWorkflowPolicyDocument(
              'terms',
              event.currentTarget.dataset.policyVersion
            )
          }
        >
          Terms and Conditions
        </button>
      </div>
      <p
        className="small"
        style={{
          margin: '12px 0 0',
          lineHeight: '1.6',
        }}
      >
        Cancellation requires at least {policy.cancellation.minimumNoticeDays} days' notice. The
        cancellation fee is {policy.cancellation.feePercent}% of the amount actually paid.
      </p>
      <p
        className="small"
        style={{
          margin: '8px 0 0',
        }}
      >
        Policy version: {policy.version}
      </p>
      {checkboxId ? (
        <label
          htmlFor={checkboxId}
          style={{
            display: 'flex',
            alignItems: 'flex-start',
            gap: '10px',
            marginTop: '16px',
            cursor: 'pointer',
          }}
        >
          <input
            id={checkboxId}
            type="checkbox"
            required={true}
            style={{
              width: 'auto',
              marginTop: '4px',
              flexShrink: '0',
            }}
          />
          <span
            style={{
              fontSize: '13px',
              lineHeight: '1.6',
            }}
          >
            I have read and agree to the Event Rules, Cancellation Policy, and Terms and Conditions.
          </span>
        </label>
      ) : (
        ''
      )}
    </section>
  );
}
